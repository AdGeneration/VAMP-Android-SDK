//
//  Copyright © 2026 Supership Inc. All rights reserved.
//
package jp.supership.vamp.core.vast;

import android.text.TextUtils;
import android.util.Patterns;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLDecoder;
import java.util.regex.Pattern;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import jp.supership.vamp.core.logging.LogUtils;
import jp.supership.vamp.core.utils.VAMPList;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class VASTParser {

    public static class VASTException extends Exception {
        public VASTException(String message) {
            super(message);
        }
    }

    private VASTObject mVastObject;

    /**
     * VASTObject が保持する XML を解析し、解析結果を同じ VASTObject へ設定して返します
     *
     * @param vast 解析対象の XML を保持する VASTObject
     * @return 解析結果を設定した VASTObject (引数と同一インスタンス)
     * @throws VASTException XML の解析に失敗した場合
     */
    public VASTObject parse(@NonNull VASTObject vast) throws VASTException {
        mVastObject = vast;

        try {
            DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
            InputStream is =
                    new ByteArrayInputStream(mVastObject.getOriginalXml().getBytes("utf-8"));
            Document dom = builder.parse(is);
            setAll(dom);
        } catch (Exception e) {
            throw new VASTException("Failed to parse VAST");
        }

        return mVastObject;
    }

    private void setAll(Document dom) throws MalformedURLException {
        Element vastElem = (Element) getFirstMatchingChildNode(dom, "VAST");
        Element adElem = null;

        if (vastElem != null) {
            mVastObject.setVastVersion(vastElem.getAttribute("version"));
            adElem = (Element) vastElem.getElementsByTagName("Ad").item(0);
            mVastObject.setAdId(adElem.getAttribute("id"));
        }

        NodeList wrappedVastAds = dom.getElementsByTagName("VASTAdTagURI");

        if (wrappedVastAds.getLength() > 0) {
            // CDATA 内の &amp; は XML パーサが展開しないので、tracking / クリック計測 URL の送信時 (#1286) と同じ
            // 1 段展開を Wrapper 取得 URL にも掛ける。掛けないと ?a=1&amp;b=2 のまま取得し、Wrapper 先でクエリが
            // a=1 と amp;b=2 に割れて配信条件が壊れる (#1288)
            mVastObject.setVastAdTagURL(
                    new URL(
                            VASTTracking.normalizedUrlString(
                                    getUrlTextContent(wrappedVastAds.item(0)))));
        }

        Element inLineElem = (Element) getFirstMatchingChildNode(adElem, "InLine");
        mVastObject.setInLine(inLineElem != null);
        if (inLineElem == null) {
            inLineElem = (Element) getFirstMatchingChildNode(adElem, "Wrapper");
        }
        if (inLineElem != null) {
            Element adSystemElem = (Element) inLineElem.getElementsByTagName("AdSystem").item(0);

            if (adSystemElem != null) {
                mVastObject.setAdSystem(getTextContent(adSystemElem));
            }

            Element adTitleElem = (Element) inLineElem.getElementsByTagName("AdTitle").item(0);

            if (adTitleElem != null) {
                mVastObject.setAdTitle(getTextContent(adTitleElem));
            }

            Element descriptionElem =
                    (Element) inLineElem.getElementsByTagName("Description").item(0);

            if (descriptionElem != null) {
                mVastObject.setDescription(getTextContent(descriptionElem));
            }

            Element advertiserElem =
                    (Element) inLineElem.getElementsByTagName("Advertiser").item(0);

            if (advertiserElem != null) {
                mVastObject.setAdvertiser(getTextContent(advertiserElem));
            }

            Element creativeElem = (Element) inLineElem.getElementsByTagName("Creative").item(0);

            if (creativeElem != null) {
                mVastObject.setCreativeId(creativeElem.getAttribute("id"));

                Element linearElem = (Element) creativeElem.getElementsByTagName("Linear").item(0);

                if (linearElem != null) {
                    Element durationElem =
                            (Element) linearElem.getElementsByTagName("Duration").item(0);

                    if (durationElem != null) {
                        mVastObject.setDurationString(getTextContent(durationElem));
                    }

                    // skipoffset は optional。属性が無いとき getAttribute は空文字を返し、
                    // setSkipOffsetString が parse 失敗として E ログを出していた (#1233)。
                    // 属性はあるが値が空 (空白のみを含む) のケースも parse 不能で同じ E ログに
                    // なるため、不在と同じ扱いにする。
                    String skipOffset = linearElem.getAttribute("skipoffset");

                    if (!TextUtils.isEmpty(skipOffset.trim())) {
                        mVastObject.setSkipOffsetString(skipOffset);
                    }

                    NodeList clickThroughs = linearElem.getElementsByTagName("ClickThrough");

                    if (clickThroughs != null) {
                        for (int i = 0; i < clickThroughs.getLength(); i++) {
                            Element clickThroughElem = (Element) clickThroughs.item(i);

                            if (clickThroughElem != null) {
                                String clickThrough = getTextContent(clickThroughElem);
                                if (!TextUtils.isEmpty(clickThrough)) {
                                    mVastObject.getClickThroughURLStrings().add(clickThrough);
                                }
                            }
                        }
                    }

                    NodeList mediaFiles = linearElem.getElementsByTagName("MediaFile");

                    if (mediaFiles != null) {
                        for (int i = 0; i < mediaFiles.getLength(); i++) {
                            Element mediaFileElem = (Element) mediaFiles.item(i);

                            if (mediaFileElem != null) {
                                try {
                                    VASTMediaFile mediaFile =
                                            new VASTMediaFile(
                                                    getTextContent(mediaFileElem),
                                                    mediaFileElem.getAttribute("delivery"),
                                                    mediaFileElem.getAttribute("type"),
                                                    tryParseInt(
                                                            mediaFileElem.getAttribute("bitrate")),
                                                    tryParseInt(
                                                            mediaFileElem.getAttribute("width")),
                                                    tryParseInt(
                                                            mediaFileElem.getAttribute("height")));
                                    mVastObject.getMediaFiles().add(mediaFile);
                                } catch (VASTMediaFile.CanNotInstantiateException e) {
                                    LogUtils.devLog(e.getMessage());
                                }
                            }
                        }
                    }

                    NodeList icons = linearElem.getElementsByTagName("Icon");

                    for (int i = 0; i < icons.getLength(); ++i) {
                        Element iconElem = (Element) icons.item(i);

                        if (iconElem != null) {
                            String apiFramework = iconElem.getAttribute("apiFramework");

                            VASTIcon icon = new VASTIcon(apiFramework);
                            icon.setProgram(iconElem.getAttribute("program"));
                            icon.setWidth(tryParseInt(iconElem.getAttribute("width")));
                            icon.setHeight(tryParseInt(iconElem.getAttribute("height")));
                            icon.setXPosition(tryParseInt(iconElem.getAttribute("xPosition")));
                            icon.setYPosition(tryParseInt(iconElem.getAttribute("yPosition")));

                            Element resourceElem =
                                    (Element)
                                            iconElem.getElementsByTagName("StaticResource").item(0);
                            if (resourceElem != null) {
                                String creativeType = resourceElem.getAttribute("creativeType");
                                VASTResource vastResource =
                                        new VASTResource(
                                                creativeType, getTextContent(resourceElem));
                                icon.setStaticResource(vastResource);
                            }

                            Element iconClickThrough =
                                    (Element)
                                            iconElem.getElementsByTagName("IconClickThrough")
                                                    .item(0);
                            NodeList iconClickTrackings =
                                    iconElem.getElementsByTagName("IconClickTracking");
                            for (int j = 0; j < iconClickTrackings.getLength(); ++j) {
                                URL url =
                                        tryParseURL(getUrlTextContent(iconClickTrackings.item(j)));
                                if (url != null) {
                                    VASTTracking tracking =
                                            new VASTSingleEventTracking("click", url);
                                    icon.getClickTrackings().add(tracking);
                                }
                            }

                            icon.setClickThroughURL(getTextContent(iconClickThrough));
                            mVastObject.getIcons().add(icon);
                        }
                    }
                }

                NodeList companionAds = inLineElem.getElementsByTagName("CompanionAds");

                if (companionAds != null) {
                    Element companionAdsElem = (Element) companionAds.item(0);

                    if (companionAdsElem != null) {
                        NodeList companions = companionAdsElem.getElementsByTagName("Companion");

                        for (int i = 0; i < companions.getLength(); i++) {
                            Element companionElem = (Element) companions.item(i);

                            if (companionElem != null) {
                                VASTCompanion companion = new VASTCompanion();
                                mVastObject.getCompanions().add(companion);
                                parseCompanionElement(companionElem);
                            }
                        }
                    }
                }
            }

            // Extentionsを取得
            NodeList extensions = inLineElem.getElementsByTagName("Extension");
            for (int i = 0; i < extensions.getLength(); i++) {
                Element extension = (Element) extensions.item(i);
                // ExtentionからtypeがAdVerificationsのものを取り出す
                if (extension != null && extension.getAttribute("AdVerifications") != null) {
                    // Verificationを取得
                    NodeList verifications = extension.getElementsByTagName("Verification");
                    // AdVerificationsをパース
                    if (verifications != null) {
                        VAMPList<VASTVerificationExtension> verificationExtensions =
                                parseMeasurementVerifications(verifications);
                        if (verificationExtensions != null) {
                            mVastObject.getVerificationExtensions().addAll(verificationExtensions);
                        }
                    }
                }
            }
        }

        setImpressions(dom);
        setErrors(dom);
        setTrackers(dom);
        setApcExtensions(dom);
        setPMPCreativeExtension(dom);
    }

    private void setImpressions(Document dom) throws MalformedURLException {
        NodeList nodes = dom.getElementsByTagName("Impression");

        for (int i = 0; i < nodes.getLength(); i++) {
            Node node = nodes.item(i);
            URL url = new URL(getUrlTextContent(node));
            VASTSingleEventTracking tracking = new VASTSingleEventTracking("impression", url);
            mVastObject.getImpressionTrackings().add(tracking);
        }
    }

    private void setErrors(Document dom) {
        NodeList nodes = dom.getElementsByTagName("Error");

        for (int i = 0; i < nodes.getLength(); i++) {
            Node node = nodes.item(i);

            // URL 要素なので内部の改行・空白も除く (#1289。iOS と同じく ClickThrough の遷移先は対象外)
            String urlString = getUrlTextContent(node);
            if (!TextUtils.isEmpty(urlString)) {
                mVastObject.getErrors().add(urlString);
            }
        }
    }

    private void setTrackers(Document dom) {
        NodeList clickTracking = dom.getElementsByTagName("ClickTracking");

        for (int i = 0; i < clickTracking.getLength(); i++) {
            Node node = clickTracking.item(i);

            try {
                String content = getUrlTextContent(node);

                if (content != null && content.length() > 0) {
                    URL url = new URL(content);
                    VASTSingleEventTracking tracking = new VASTSingleEventTracking("click", url);
                    mVastObject.getClickTrackings().add(tracking);
                }
            } catch (MalformedURLException e) {
                LogUtils.devLog("Failed to set trackers.");
            }
        }

        NodeList trackingNodeList = dom.getElementsByTagName("Tracking");

        for (int i = 0; i < trackingNodeList.getLength(); i++) {
            Element eventElem = (Element) trackingNodeList.item(i);
            String event = eventElem.getAttribute("event");
            String content = getUrlTextContent(eventElem);

            try {
                URL url = new URL(content);

                if (event.equals("progress")) {
                    VASTSingleEventTracking tracking =
                            new VASTSingleEventTracking(
                                    event, url, eventElem.getAttribute("offset"));
                    mVastObject.getProgressTrackings().add(tracking);
                } else if (event.equals("start")) {
                    VASTSingleEventTracking tracking = new VASTSingleEventTracking(event, url);
                    mVastObject.getStartTrackings().add(tracking);
                } else if (event.equals("firstQuartile")) {
                    VASTSingleEventTracking tracking = new VASTSingleEventTracking(event, url);
                    mVastObject.getFirstQuartileTrackings().add(tracking);
                } else if (event.equals("midpoint")) {
                    VASTSingleEventTracking tracking = new VASTSingleEventTracking(event, url);
                    mVastObject.getMidpointTrackings().add(tracking);
                } else if (event.equals("thirdQuartile")) {
                    VASTSingleEventTracking tracking = new VASTSingleEventTracking(event, url);
                    mVastObject.getThirdQuartileTrackings().add(tracking);
                } else if (event.equals("complete")) {
                    VASTSingleEventTracking tracking = new VASTSingleEventTracking(event, url);
                    mVastObject.getCompleteTrackings().add(tracking);
                } else if (event.equals("creativeView")) {
                    VASTTracking tracking = new VASTTracking(event, url);
                    mVastObject.getCreativeViewTrackings().add(tracking);
                } else if (event.equals("mute")) {
                    VASTTracking tracking = new VASTTracking(event, url);
                    mVastObject.getMuteTrackings().add(tracking);
                } else if (event.equals("unmute")) {
                    VASTTracking tracking = new VASTTracking(event, url);
                    mVastObject.getUnmuteTrackings().add(tracking);
                } else if (event.equals("pause")) {
                    VASTTracking tracking = new VASTTracking(event, url);
                    mVastObject.getPauseTrackings().add(tracking);
                } else if (event.equals("resume")) {
                    VASTTracking tracking = new VASTTracking(event, url);
                    mVastObject.getResumeTrackings().add(tracking);
                }
            } catch (Exception e) {
                // MalformedURLException の message は URL 全体 (例: "no protocol: host/path?query")
                // を含むため、
                // Throwable の message を出さず種別だけをログに残す (#1289)
                LogUtils.e(
                        "VASTParser: Failed to parse a tracking event. ("
                                + e.getClass().getSimpleName()
                                + ")");
            }
        }
    }

    /**
     * アドジェネAPC専用Extensions
     *
     * @param dom
     */
    private void setApcExtensions(Document dom) {
        NodeList extensions = dom.getElementsByTagName("Extension");
        for (int i = 0; i < extensions.getLength(); i++) {
            Element extensionElem = (Element) extensions.item(i);

            if (extensionElem == null) {
                return;
            }

            String service = extensionElem.getAttribute("service");
            String type = extensionElem.getAttribute("type");
            String adnw = extensionElem.getAttribute("adnw");

            VASTAPCExtension extension = null;

            if ("adg".equals(service) && "apc".equals(type)) {
                extension = new VASTAPCExtension();
                extension.setAdnw(adnw);
                extension.setService(service);
                extension.setType(type);
                mVastObject.getApcExtensions().add(extension);
            }

            // 止め画像
            NodeList endCardList = extensionElem.getElementsByTagName("EndCard");

            if (endCardList != null && endCardList.getLength() > 0) {

                // TODO: 複数EndCardがあったときの選び方
                Element endCardElem = (Element) endCardList.item(0);

                if (endCardElem != null) {
                    String imageUrl = getTextContent(endCardElem);
                    VASTEndCard endCard = new VASTEndCard(imageUrl);
                    String height = endCardElem.getAttribute("height");
                    String width = endCardElem.getAttribute("width");

                    endCard.setAttributeHeight(height != null ? tryParseInt(height) : 0);
                    endCard.setAttributeWidth(width != null ? tryParseInt(width) : 0);

                    if (extension != null && extension.isApc()) {
                        extension.getEndCards().add(endCard);
                    }
                }
            }

            // ランディングページ
            NodeList lpUrlList = extensionElem.getElementsByTagName("LPURL");

            if (lpUrlList != null && lpUrlList.getLength() > 0) {
                Element lpUrlElem = (Element) lpUrlList.item(0);

                if (lpUrlElem != null) {
                    String lpUrl = getTextContent(lpUrlElem);
                    if (mVastObject.getApcExtensions().size() > 0) {
                        // iOSと同様に最後に追加したExtensionに対して設定する
                        if (extension != null && extension.isApc()) {
                            extension.setLpURLString(lpUrl);
                        }
                    } else {
                        LogUtils.d("extensions list is empty.");
                    }
                }
            }

            NodeList resources = extensionElem.getElementsByTagName("Resource");

            for (int j = 0; j < resources.getLength(); j++) {
                try {
                    Element elem = (Element) resources.item(j);
                    String resourceType = elem.getAttribute("type");

                    if (resourceType.equals("end_credit_image")) {
                        VASTEndCard endCard = new VASTEndCard(getTextContent(elem));
                        mVastObject.setEndCard(endCard);
                    }
                } catch (Exception e) {
                    LogUtils.d(e.getMessage());
                }
            }

            NodeList interactions = extensionElem.getElementsByTagName("Interaction");

            for (int k = 0; k < interactions.getLength(); k++) {
                try {
                    Element elem = (Element) interactions.item(k);
                    if (elem != null) {
                        String linkText = getTextContent(elem);
                        String interactionType = elem.getAttribute("type");
                        if (interactionType != null && interactionType.equals("linktext")) {
                            mVastObject.setLinkText(URLDecoder.decode(linkText, "UTF-8"));
                        }
                    }
                } catch (Exception e) {
                    LogUtils.d(e.getMessage());
                }
            }
        }
    }

    private void parseCompanionElement(Element companionElem) {
        try {
            int width = Integer.valueOf(companionElem.getAttribute("width"));
            int height = Integer.valueOf(companionElem.getAttribute("height"));

            if (mVastObject.getCompanions().size() > 0) {
                VASTCompanion companion =
                        mVastObject.getCompanions().get(mVastObject.getCompanions().size() - 1);
                companion.setWidth(width);
                companion.setHeight(height);
            }
        } catch (NumberFormatException e) {
            // 属性値を含む例外メッセージは stderr に出さず、種別だけをログに残す (#1289)
            LogUtils.w(
                    "VASTParser: Companion width/height is not a number. ("
                            + e.getClass().getSimpleName()
                            + ")");
        }

        Element staticResourceElem =
                (Element) companionElem.getElementsByTagName("StaticResource").item(0);

        if (staticResourceElem != null) {
            String creativeType = staticResourceElem.getAttribute("creativeType");

            if (creativeType != null && creativeType.toLowerCase().startsWith("image")) {
                if (mVastObject.getCompanions().size() > 0) {
                    VASTCompanion companion =
                            mVastObject.getCompanions().get(mVastObject.getCompanions().size() - 1);
                    companion.setImageURLString(getTextContent(staticResourceElem));
                }
            }
        }

        Element htmlResourceElem =
                (Element) companionElem.getElementsByTagName("HTMLResource").item(0);

        if (htmlResourceElem != null) {
            if (mVastObject.getCompanions().size() > 0) {
                VASTCompanion companion =
                        mVastObject.getCompanions().get(mVastObject.getCompanions().size() - 1);
                companion.setHtmlResource(getTextContent(htmlResourceElem));
            }
        }

        Element companionClickThroughElem =
                (Element) companionElem.getElementsByTagName("CompanionClickThrough").item(0);

        if (companionClickThroughElem != null) {
            if (mVastObject.getCompanions().size() > 0) {
                VASTCompanion companion =
                        mVastObject.getCompanions().get(mVastObject.getCompanions().size() - 1);
                companion.setClickThroughURLString(getTextContent(companionClickThroughElem));
            }
        }

        Element companionClickTrackingElem =
                (Element) companionElem.getElementsByTagName("CompanionClickTracking").item(0);

        if (companionClickTrackingElem != null) {
            if (mVastObject.getCompanions().size() > 0) {
                VASTCompanion companion =
                        mVastObject.getCompanions().get(mVastObject.getCompanions().size() - 1);
                companion
                        .getClickTrackingURLStrings()
                        .add(getUrlTextContent(companionClickTrackingElem));
            }
        }
    }

    private Node getFirstMatchingChildNode(Document dom, String name) {
        if (dom == null || TextUtils.isEmpty(name)) {
            return null;
        }

        NodeList nodeList = dom.getElementsByTagName(name);
        if (nodeList != null) {
            return nodeList.item(0);
        }
        return null;
    }

    private Node getFirstMatchingChildNode(Element element, String name) {
        if (element == null || TextUtils.isEmpty(name)) {
            return null;
        }

        NodeList nodeList = element.getElementsByTagName(name);
        if (nodeList != null) {
            return nodeList.item(0);
        }

        return null;
    }

    private VAMPList<VASTVerificationExtension> parseMeasurementVerifications(
            @NonNull NodeList verifications) {
        VAMPList<VASTVerificationExtension> list = new VAMPList<>();

        try {
            for (int i = 0; i < verifications.getLength(); i++) {
                // Verificationを取得
                Element verification = (Element) verifications.item(i);
                if (verification != null) {
                    // Listにモデルを追加
                    VASTVerificationExtension model = parseMeasurementVerification(verification);
                    if (model != null) {
                        list.add(model);
                    }
                }
            }
        } catch (Exception e) {
            // MalformedURLException の message は URL 全体を含むため、Throwable を渡さず種別だけをログに残す (#1289)
            LogUtils.w(
                    "VASTParser: Failed to parse AdVerifications. ("
                            + e.getClass().getSimpleName()
                            + ")");
            return null;
        }

        return list;
    }

    @Nullable
    private VASTVerificationExtension parseMeasurementVerification(@NonNull Element verification) {
        try {
            // verificationのtypeからVendorKeyを取得
            final String vendor = verification.getAttribute("vendor");

            // JavaScriptResourceを取得
            final Element jsResource =
                    (Element) verification.getElementsByTagName("JavaScriptResource").item(0);
            VASTJavaScriptResource javaScriptResource = null;
            if (jsResource != null) {
                // JavaScriptResourceのtypeからApiFrameworkを取得
                final String apiFramework = jsResource.getAttribute("apiFramework");
                // JavaScriptResourceのtypeからBrowserOptionalを取得
                final boolean browserOpt =
                        Boolean.parseBoolean(jsResource.getAttribute("browserOptional"));
                // JavaScriptResourceのURLを取得
                final String url = jsResource.getTextContent();
                try {
                    javaScriptResource = new VASTJavaScriptResource(apiFramework, browserOpt, url);
                } catch (VASTJavaScriptResource.CanNotInstantiateException e) {
                    // message に URL が入りうるため種別だけをログに残す (#1289)
                    LogUtils.e(
                            "VASTParser: Failed to parse JavaScriptResource. ("
                                    + e.getClass().getSimpleName()
                                    + ")");
                }
            }

            // VerificationParametersを取得
            final Element verificationParameters =
                    (Element) verification.getElementsByTagName("VerificationParameters").item(0);
            final String params;
            if (verificationParameters != null) {
                // VerificationParametersのURLを取得
                params = verificationParameters.getTextContent();
            } else {
                params = null;
            }

            // TrackingEventsを取得
            final NodeList trackingEvents = verification.getElementsByTagName("Tracking");
            final VAMPList<VASTTracking> trackings = new VAMPList<>();
            if (trackingEvents != null) {
                // モデルにTrackingEventを追加
                for (int i = 0; i < trackingEvents.getLength(); ++i) {
                    final VASTTracking tracking =
                            parseMeasurementTrackingEvent((Element) trackingEvents.item(i));
                    if (tracking != null) {
                        trackings.add(tracking);
                    }
                }
            }

            return new VASTVerificationExtension(vendor, javaScriptResource, params, trackings);
        } catch (Exception e) {
            // 原因の message に URL が入りうるため種別だけをログに残す (#1289)
            LogUtils.e(
                    "VASTParser: Failed to parse a Verification. ("
                            + e.getClass().getSimpleName()
                            + ")");
            return null;
        }
    }

    @Nullable
    private VASTTracking parseMeasurementTrackingEvent(@NonNull Element trackingEventElem) {

        try {
            if (trackingEventElem.getAttribute("event") != null) {
                // TrackingEventの名前を取得
                String eventName = String.valueOf(trackingEventElem.getAttribute("event"));
                // TrackingEventのURLを取得
                String url = excludeWhitespaceCRLF(trackingEventElem.getTextContent());
                if (isValidWebURL(url)) {
                    return new VASTTracking(eventName, new URL(url));
                }
            }
        } catch (Exception e) {
            // Patterns.WEB_URL は scheme の無い host/path?query を通すため、ここで new URL() が失敗しうる。
            // MalformedURLException の message は URL 全体を含むため、Throwable を渡さず種別だけをログに残す
            // (printStackTrace() は setDebugLogging に関係なく stderr / logcat へ出ていた。#1289)
            LogUtils.w(
                    "VASTParser: Failed to parse a measurement tracking event. ("
                            + e.getClass().getSimpleName()
                            + ")");
            return null;
        }

        return null;
    }

    private void setPMPCreativeExtension(Document dom) {
        // 既に設定されている場合は何もしない
        if (mVastObject.getPmpExtension() != null) {
            return;
        }

        Element extensionElement = getPMPCreativeExtensionElement(dom);

        if (extensionElement == null) {
            return;
        }

        VASTPMPCreativeExtension extension = parsePMPExtension(extensionElement);
        if (extension != null) {
            mVastObject.setPmpExtension(extension);
        }
    }

    private static Element getPMPCreativeExtensionElement(Document dom) {
        NodeList extensions = dom.getElementsByTagName("CreativeExtension");

        for (int i = 0; i < extensions.getLength(); i++) {
            Element element = (Element) extensions.item(i);
            String type = element.getAttribute("type");

            if ("pmp".equals(type)) {
                return element;
            }
        }

        return null;
    }

    private static VASTPMPCreativeExtension parsePMPExtension(Element extensionElem) {
        int hSize = VASTPMPCreativeExtension.CTA_BUTTON_HSIZE_DEFAULT;
        try {
            hSize = Integer.parseInt(extensionElem.getAttribute("h_size"));
        } catch (Exception e) {
            //            e.printStackTrace();
        }

        boolean onPlaying = true;
        try {
            String onPlayingString = extensionElem.getAttribute("on_playing");
            if (!TextUtils.isEmpty(onPlayingString)) {
                onPlaying = Boolean.parseBoolean(onPlayingString);
            }
        } catch (Exception e) {
            //            e.printStackTrace();
        }

        NodeList ctaButtonTextList = extensionElem.getElementsByTagName("CtaButtonText");
        String ctaButtonText = "";
        String ctaButtonTextExtra = "";

        if (ctaButtonTextList != null && ctaButtonTextList.getLength() > 0) {
            Element ctaButtonTextElem = (Element) ctaButtonTextList.item(0);

            if (ctaButtonTextElem != null) {
                ctaButtonText = getTextContent(ctaButtonTextElem);
            }
        }

        NodeList ctaButtonTextExtraList = extensionElem.getElementsByTagName("CtaButtonTextExtra");

        if (ctaButtonTextExtraList != null && ctaButtonTextExtraList.getLength() > 0) {
            Element ctaButtonTextExtraElem = (Element) ctaButtonTextExtraList.item(0);

            if (ctaButtonTextExtraElem != null) {
                ctaButtonTextExtra = getTextContent(ctaButtonTextExtraElem);
            }
        }

        if (!TextUtils.isEmpty(ctaButtonText)) {
            VASTPMPCreativeExtension extension =
                    new VASTPMPCreativeExtension(ctaButtonText, ctaButtonTextExtra, hSize);
            extension.setButtonEnableOnPlaying(onPlaying);
            return extension;
        }

        return null;
    }

    private static String getTextContent(Node node) {
        return (node != null && node.getTextContent() != null) ? node.getTextContent().trim() : "";
    }

    /**
     * URLを保持するノード専用のテキスト取得。実配信のVASTは可読性のためURL本文を改行・インデント付きで 折り返すことがあり、{@link
     * #getTextContent}のtrim()だけでは先頭/末尾の空白しか除去できず内部の 改行・空白が残る。{@code new
     * URL(...)}はこれを例外にせず、内部に改行を含んだまま黙って受理してしまう
     * ため、実際のビーコン発火(URLとして不正なリクエストになる)・json側URLとの重複排除の完全一致比較の
     * 両方が壊れる。URL以外のテキスト(AdTitle等、意味のある空白を含みうる)には使わないこと。
     */
    private static String getUrlTextContent(Node node) {
        return excludeWhitespaceCRLF(getTextContent(node));
    }

    /**
     * URL 内部の空白文字 ({@code \s} = 空白・タブ・改行・CR・VT・FF) をすべて除く。{@code \n} / {@code \r} は {@code \s}
     * に含まれる
     */
    private static final Pattern WHITESPACE = Pattern.compile("\\s+");

    private static String excludeWhitespaceCRLF(String value) {
        return WHITESPACE.matcher(value).replaceAll("");
    }

    private static boolean isValidWebURL(String str) {
        return !TextUtils.isEmpty(str) && Patterns.WEB_URL.matcher(str).matches();
    }

    private static int tryParseInt(String str) {
        int ret = 0;
        try {
            ret = Integer.parseInt(str);
        } catch (NumberFormatException e) {
            LogUtils.devLog(e.getMessage());
        }

        return ret;
    }

    private static URL tryParseURL(String str) {
        URL url = null;
        try {
            url = new URL(str);
        } catch (MalformedURLException e) {
            LogUtils.devLog(e.getMessage());
        }

        return url;
    }
}
