//
//  Copyright © 2026 Supership Inc. All rights reserved.
//
package jp.supership.vamp;

import androidx.annotation.Nullable;
import java.util.ArrayList;
import jp.supership.vamp.mediation.Adapter;

public interface AdapterProviding {
    @Nullable
    Adapter getAdapter(String adNetworkName) throws AdapterNotFoundException;

    /**
     * サポートしているアダプタの一覧を返します。
     *
     * <p>publicなGlobalAdapterProvider.injectProviderで差し替え可能なため非nullは保証できません。呼び出し側でnullを許容してください。
     */
    @Nullable
    ArrayList<Adapter> getSupportedAdapters();
}
