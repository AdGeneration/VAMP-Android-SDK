//
//  Copyright © 2026 Supership Inc. All rights reserved.
//
package jp.supership.vamp;

import android.app.Activity;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import java.lang.ref.WeakReference;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.TimerTask;
import jp.supership.sscore.vamp.http.SSCoreHttp;
import jp.supership.sscore.vamp.http.SSCoreHttpClient;
import jp.supership.sscore.vamp.rewardedad.SSCoreAdNetworkNames;
import jp.supership.sscore.vamp.rewardedad.SSCoreRewardedAdMediationTimeout;
import jp.supership.sscore.vamp.timer.SSCoreScheduledTimer;
import jp.supership.sscore.vamp.timer.SSCoreTimerSchedulable;
import jp.supership.sscore.vamp.type.Optional;
import jp.supership.vamp.core.logging.LogUtils;
import jp.supership.vamp.mediation.AdNetworkErrorInfo;
import jp.supership.vamp.mediation.Adapter;
import jp.supership.vamp.mediation.AdapterConfiguration;
import jp.supership.vamp.mediation.AdapterEventListener;
import jp.supership.vamp.mediation.Event;
import jp.supership.vamp.player.VAMPCreativeInfo;
import jp.supership.vamp.utils.JsonUtils;
import org.json.JSONException;
import org.json.JSONObject;

/** Created by masaki.ando on 2018/04/02. */
public final class Mediation {
    public interface Listener {
        void onLoadSuccess(@NonNull Mediation ad);

        void onVideoStart(@NonNull Mediation ad);

        void onVideoComplete(@NonNull Mediation ad);

        void onFailed(@NonNull Mediation ad, @NonNull VAMPError error);

        void onAdClosed(@NonNull Mediation ad, boolean adClicked);

        void sendLogEvent(@NonNull Mediation ad, @Nullable AdNetworkErrorInfo errorInfo);

        /**
         * この表示について、表示開始(open)を一度も通知しないまま表示失敗を通知済みかどうかを返します。
         *
         * <p>trueの場合、{@link Mediation}はCOMPLETEイベントのcompleteビーコンを送出しません。 報酬確定({@link
         * #onVideoComplete}以降の通知)を止める判定と同じ事実を返すことで、「アプリへ報酬を通知しない表示に
         * completeビーコンだけが計上される」ずれを防ぎます(#1249)。
         *
         * <p>表示開始の<b>後</b>に届いた失敗ではfalseを返してください。openの後に失敗しても報酬確定が正当なケース
         * (Pangleはクローズ時・AppLovinはリワード検証と完全視聴が揃った時点で確定)があり、 そこでcompleteビーコンを止めると
         * 正当な完視聴が計上されなくなるためです(#1247と同じ非対称性)。
         *
         * <p>既定はfalse(従来どおりcompleteビーコンを送出)です。報酬確定ガードを持つ{@link MediationManager}だけが
         * overrideします。抽象メソッドではなくdefaultメソッドにしているのは、既存の実装クラスに対する ABI・ソース互換を保つためです。
         *
         * <p>trueのときは、COMPLETEイベントのcompleteビーコンに加えて、OPENイベントのstartビーコンも送出しません(#1284)。
         * impressionビーコンは{@link #show}で{@code adapter.show()}を呼ぶ前に送るため、表示失敗より常に先に出ており、 本判定の対象外です。
         *
         * @param ad イベントを受けたMediation
         * @return open未通知のまま表示失敗を通知済みならtrue
         */
        default boolean hasFailedBeforeOpen(@NonNull Mediation ad) {
            return false;
        }
    }

    public static class BuildErrorException extends Exception {
        BuildErrorException(String message) {
            super(message);
        }
    }

    public static class Builder {
        @Nullable private Listener listener;

        @NonNull
        private SSCoreRewardedAdMediationTimeout mediationTimeout =
                SSCoreRewardedAdMediationTimeout.newDefault();

        @Nullable private SSCoreHttpClient impressionBeaconHttpClient;
        @Nullable private SSCoreHttpClient startBeaconHttpClient;
        @Nullable private SSCoreHttpClient completeBeaconHttpClient;

        public Builder() {}

        @NonNull
        public Builder withMediationTimeout(
                @NonNull final SSCoreRewardedAdMediationTimeout timeout) {
            this.mediationTimeout = timeout;
            return this;
        }

        @NonNull
        public Builder withListener(@Nullable final Listener listener) {
            this.listener = listener;
            return this;
        }

        @NonNull
        public Builder withImpressionBeaconHttpClient(@Nullable final SSCoreHttpClient client) {
            this.impressionBeaconHttpClient = client;
            return this;
        }

        @NonNull
        public Builder withStartBeaconHttpClient(@Nullable final SSCoreHttpClient client) {
            this.startBeaconHttpClient = client;
            return this;
        }

        @NonNull
        public Builder withCompleteBeaconHttpClient(@Nullable final SSCoreHttpClient client) {
            this.completeBeaconHttpClient = client;
            return this;
        }

        /**
         * @return Mediation
         * @throws BuildErrorException 引数不正や呼び出しクラスが見つからない場合、 またアドネットワークSDKがサポートしないAPI
         *     levelの場合に発生します
         */
        @NonNull
        public Mediation build(
                @NonNull final Context applicationContext,
                @Nullable final Activity activity,
                @Nullable final AdResponse adResponse,
                @Nullable final VAMPRequest request)
                throws BuildErrorException {
            if (adResponse == null) {
                throw new BuildErrorException("adResponse is null.");
            }
            if (request == null) {
                throw new BuildErrorException("request is null.");
            }

            final String adNetworkName;
            if (adResponse.isVastAd()) {
                adNetworkName = SSCoreAdNetworkNames.VAMP;
            } else {
                String className = adResponse.creativeParams.mediationClassName;
                adNetworkName = SSCoreAdNetworkNames.getAdNetworkName(className);
                if (TextUtils.isEmpty(adNetworkName)) {
                    throw new BuildErrorException(
                            "adNetworkName for " + className + " could not be resolved.");
                }
            }

            final Adapter adapter;
            try {
                adapter = GlobalAdapterProvider.getProvider().getAdapter(adNetworkName);
                Objects.requireNonNull(adapter);
            } catch (Exception e) {
                throw new BuildErrorException(e.getMessage());
            }

            if (!adapter.isSupported()) {
                throw new BuildErrorException(
                        adNetworkName + " does not support current API level.");
            }

            final Map<String, String> mediationParams = new HashMap<>();
            try {
                JSONObject mediationParamJson = adResponse.creativeParams.getMediationParams();
                Map<String, Object> map = JsonUtils.toMap(mediationParamJson);
                for (Map.Entry<String, Object> entry : map.entrySet()) {
                    if (entry.getValue() instanceof String) {
                        mediationParams.put(entry.getKey(), (String) entry.getValue());
                    }
                }
            } catch (JSONException e) {
                throw new BuildErrorException("mediationParams occurred JSONException.");
            }

            final Map<String, String> adParams = new HashMap<>();
            try {
                Map<String, Object> map = JsonUtils.toMap(adResponse.adParams);
                for (Map.Entry<String, Object> entry : map.entrySet()) {
                    if (entry.getValue() instanceof String) {
                        adParams.put(entry.getKey(), (String) entry.getValue());
                    }
                }
            } catch (JSONException e) {
                throw new BuildErrorException("adParams occurred JSONException.");
            }

            final Map<String, String> bidderParams = new HashMap<>();
            try {
                Map<String, Object> map =
                        JsonUtils.toMap(adResponse.creativeParams.getBidderParams());
                for (Map.Entry<String, Object> entry : map.entrySet()) {
                    if (entry.getValue() instanceof String) {
                        bidderParams.put(entry.getKey(), (String) entry.getValue());
                    }
                }
            } catch (JSONException e) {
                throw new BuildErrorException("bidderParams occurred JSONException.");
            }

            final String adId =
                    adResponse.isVastAd()
                            ? adResponse.placementId
                            : adResponse.creativeParams.mediationAdId.orElse("");

            final AdapterConfiguration.Builder configBuilder =
                    new AdapterConfiguration.Builder(adId, mediationParams);

            if (adResponse.isVastAd()) {
                configBuilder.withVastXml(adResponse.vastxml);
            }

            // landingPageが不正な値でも処理を続行する
            try {
                String actualLP = adResponse.creativeParams.actualLandingPage.unwrap();
                if (!TextUtils.isEmpty(actualLP)) {
                    configBuilder.withLandingUrl(new URL(actualLP));
                }
            } catch (Optional.NotPresentException | MalformedURLException e) {
                LogUtils.d("actualLandingPage is invalid: " + e);
            }

            final AdapterConfiguration config =
                    configBuilder
                            .withPlacementId(adResponse.placementId)
                            .withAdParams(adParams)
                            .withBidderParams(bidderParams)
                            .withContentUrl(request.getContentUrl())
                            .build();

            final Context context;
            try {
                context = getContextForAdapter(adNetworkName, applicationContext, activity);
            } catch (Exception e) {
                throw new BuildErrorException(e.getMessage());
            }

            final AdapterResponseInfo responseInfo =
                    new AdapterResponseInfo.Builder()
                            .withAdId(adId)
                            .withAdNetworkName(adNetworkName)
                            .withClassName(adapter.getClass().getName())
                            .withCreativeId(adResponse.crid)
                            .withDspId(adResponse.dspId)
                            .withAdNetworkId(adResponse.adnwId)
                            .withSeat(adResponse.seat)
                            .build();

            // json側ビーコンはここでは無条件に構築する。VASTトラッキングとの重複排除はここでは行わず、
            // send*Beacon()(sendBeaconIfNotSuppressed())で実際に送信する直前に、その時点でVASTAdapterが
            // 保持している実パース済みVASTObjectと比較して判定する(詳細はisTrackingAlreadyDefinedInVast()を参照)。
            final Optional<Tracking> impressionBeacon =
                    Tracking.impression(
                            adResponse.getBeaconUrl(),
                            impressionBeaconHttpClient != null
                                    ? impressionBeaconHttpClient
                                    : SSCoreHttp.newClient());

            final Optional<Tracking> startBeacon =
                    Tracking.start(
                            adResponse.start,
                            startBeaconHttpClient != null
                                    ? startBeaconHttpClient
                                    : SSCoreHttp.newClient());

            final Optional<Tracking> completeBeacon =
                    Tracking.complete(
                            adResponse.complete,
                            completeBeaconHttpClient != null
                                    ? completeBeaconHttpClient
                                    : SSCoreHttp.newClient());

            if (adapter instanceof VASTAdapter) {
                VASTAdapter vastAdapter = (VASTAdapter) adapter;
                VAMPCreativeInfo creativeInfo =
                        new VAMPCreativeInfo(
                                adResponse.crid,
                                adResponse.adnwId,
                                adResponse.dspId,
                                adResponse.seat);

                vastAdapter.setCreativeInfo(creativeInfo);
            }

            return new Mediation(
                    context,
                    adapter,
                    config,
                    mediationTimeout,
                    responseInfo,
                    listener,
                    adResponse.creativeParams.beaconNotifications,
                    impressionBeacon,
                    startBeacon,
                    completeBeacon);
        }
    }

    @NonNull private final Adapter adapter;
    @NonNull private final AdapterConfiguration config;
    @NonNull private final SSCoreRewardedAdMediationTimeout mediationTimeout;
    @NonNull private final AdapterResponseInfo responseInfo;
    @Nullable private final Listener listener;

    /** creative_params.notifications.beacon */
    @NonNull private final ArrayList<Tracking> beaconNotifications;

    @NonNull private final Optional<Tracking> impressionBeacon;
    @NonNull private final Optional<Tracking> startBeacon;
    @NonNull private final Optional<Tracking> completeBeacon;
    @NonNull private final SSCoreTimerSchedulable mediationTimer = new SSCoreScheduledTimer();
    private boolean adClicked = false;

    private Mediation(
            @NonNull final Context context,
            @NonNull final Adapter adapter,
            @NonNull final AdapterConfiguration config,
            @NonNull final SSCoreRewardedAdMediationTimeout mediationTimeout,
            @NonNull final AdapterResponseInfo responseInfo,
            @Nullable final Listener listener,
            @NonNull final ArrayList<Tracking> beaconNotifications,
            @NonNull final Optional<Tracking> impressionBeacon,
            @NonNull final Optional<Tracking> startBeacon,
            @NonNull final Optional<Tracking> completeBeacon)
            throws BuildErrorException {
        this.adapter = adapter;
        this.config = config;
        this.mediationTimeout = mediationTimeout;
        this.responseInfo = responseInfo;
        this.listener = listener;
        this.beaconNotifications = beaconNotifications;
        this.impressionBeacon = impressionBeacon;
        this.startBeacon = startBeacon;
        this.completeBeacon = completeBeacon;

        // アダプタのセットアップ
        final boolean success =
                adapter.prepare(
                        context,
                        config,
                        new AdapterEventListener() {
                            @Override
                            public void onEvent(@NonNull Event event) {
                                vampEvent(event);
                            }
                        });
        if (!success) {
            throw new BuildErrorException("Failed to prepare " + adapter.getClass().getName());
        }
    }

    public void load(@NonNull final Context applicationContext, @Nullable final Activity activity) {
        setMediationTimer();

        responseInfo.startLoading();

        if (isReady()) {
            LogUtils.d(formatLog("Already loaded."));
            vampEvent(new Event(Event.EVENT_LOAD_SUCCESS));
            return;
        }

        try {
            adapter.load(getContextForAdapter(getAdNetworkName(), applicationContext, activity));
        } catch (LinkageError | Exception e) { // #1224: ADNW SDK欠落・版不一致のError系も隔離
            vampEvent(
                    new Event(
                            Event.EVENT_FAIL,
                            new AdNetworkErrorInfo.Builder("load", VAMPError.ADNETWORK_ERROR)
                                    .build()));
        }
    }

    public boolean isReady() {
        try {
            final boolean isReady = adapter.isReady();
            LogUtils.devLog(formatLog("isReady=" + isReady));
            return isReady;
        } catch (LinkageError | Exception e) { // #1224: ADNW SDK欠落・版不一致のError系も隔離
            return false;
        }
    }

    /**
     * 広告の表示を開始します
     *
     * @param activity このActivityインスタンスを使って、広告ActivityがstartActivityされます
     */
    public void show(@NonNull final Activity activity) {
        // 素のadapter.isReady()はtry外で、第三者実装のthrow / Errorがそのままメインスレッドへ抜ける。
        // 同クラスのisReady()はguard済みなのでそちらを使う(#1224)。
        if (!isReady()) {
            vampEvent(
                    new Event(
                            Event.EVENT_FAIL,
                            new AdNetworkErrorInfo.Builder("show", VAMPError.NOT_LOADED_AD)
                                    .build()));
            return;
        }

        sendImpressionBeacon();

        try {
            adapter.show(activity);
        } catch (LinkageError | Exception e) { // #1224: ADNW SDK欠落・版不一致のError系も隔離
            vampEvent(
                    new Event(
                            Event.EVENT_FAIL,
                            new AdNetworkErrorInfo.Builder("show", VAMPError.ADNETWORK_ERROR)
                                    .build()));
        }
    }

    public void destroy() {
        LogUtils.devLog(formatLog("destroy"));

        clearMediationTimer();

        try {
            adapter.destroy();
        } catch (LinkageError | Exception e) { // #1224: ADNW SDK欠落・版不一致のError系も隔離
            e.printStackTrace();
        }
    }

    @NonNull
    AdapterResponseInfo getResponseInfo() {
        return responseInfo;
    }

    public boolean isVastAd() {
        return !TextUtils.isEmpty(config.getVastXml());
    }

    public boolean hasBidderParams() {
        return config.getBidderParams().size() > 0;
    }

    @NonNull
    public String getAdNetworkName() {
        // 応答受信後のクラウドログ(logItem)・QAログ・loadAdOrStopのラベルとして呼ばれる。
        // loadAdOrStopはメインスレッドへpostされ、しかもad.load()のtryより前で呼ぶため、
        // ここで伝播させるとアプリが落ちる(#1224)。
        try {
            return adapter.getAdNetworkName();
        } catch (LinkageError | Exception e) {
            // formatLogは本メソッドを呼ぶため、ここで使うと自己再入する。LogUtils.wを直接使う。
            // スタックトレースは出さない: 本メソッドはload毎に複数回呼ばれ、SDK欠落構成では
            // そのたびに同一トレースが数十行出るため(#1225レビュー指摘2)。
            LogUtils.w("Failed to get the ad network name. " + e);
            // 応答由来の名前へ倒す。空文字だとクラウドログでどのアドネットワークが壊れたのか
            // 分からなくなり、getContextForAdapterのmaio / LINEAds / ironSource判定も外れる
            // (#1225レビュー指摘4)。
            final String nameFromResponse = responseInfo.getAdNetworkName();
            return nameFromResponse != null ? nameFromResponse : "";
        }
    }

    @NonNull
    public List<String> getAdNetworkAdIdentifiers() {
        // getAdNetworkNameと同じくlogItemから呼ばれる(#1224)。
        try {
            return adapter.getAdNetworkAdIdentifiers();
        } catch (LinkageError | Exception e) {
            LogUtils.w(formatLog("Failed to get the ad network ad identifiers. " + e));
            return Collections.emptyList();
        }
    }

    @NonNull
    public String getAdapterVersion() {
        // アダプタjarはあってもアドネットワークSDK本体が未導入・除去済み / 版不一致の構成では
        // ここでNoClassDefFoundErrorやNoSuchMethodErrorが飛ぶ。本メソッドはクラウドログ(logItem)と
        // デバッグログからのみ呼ばれるテレメトリ用途のため、収益経路を巻き込まないよう空文字へ倒す(#1224)。
        try {
            return adapter.getAdapterVersion();
        } catch (LinkageError | Exception e) {
            LogUtils.w(formatLog("Failed to get the adapter version. " + e));
            return "";
        }
    }

    @NonNull
    public String getAdNetworkVersion() {
        // getAdapterVersionと同じ理由(#1224)。こちらはアドネットワークSDKの定数・APIを直接参照する
        // 実装が多く、SDK欠落時にNoClassDefFoundErrorが飛ぶ確度が高い。ここで伝播させると広告応答後の
        // logDebugMediationList / logItemが巻き戻り、SSCoreの応答lambdaを実行するプールスレッドで
        // 握り潰されてクラッシュもログも残らないままREQUEST_TIMEOUTになる。
        try {
            return adapter.getAdNetworkVersion();
        } catch (LinkageError | Exception e) {
            LogUtils.w(formatLog("Failed to get the ad network version. " + e));
            return "";
        }
    }

    private void vampEvent(final Event event) {
        // ADNWからのイベントが必ずしもMainスレッドで通知されるとは限らないため,必ずMainスレッド実行にする.
        // バックグラウンドスレッドで実行し続けると,Failしてから次をロードする際にクラッシュするリスクがある.
        // ADNW SDKのload/show直前でMainスレッドに切り替える方がパフォーマンス的に良いかもしれないが
        // 現状の実装では難しい部分があるため,ここでの切り替えにしておく
        final WeakReference<Mediation> adWeakReference = new WeakReference<>(this);
        new Handler(Looper.getMainLooper())
                .post(
                        new Runnable() {

                            @Override
                            public void run() {
                                if (event == null) {
                                    LogUtils.e(formatLog("Invalid Argument. event is null."));
                                    return;
                                }

                                final Mediation ad = adWeakReference.get();
                                if (ad == null) {
                                    LogUtils.e(formatLog("Invalid Argument. ad is null."));
                                    return;
                                }

                                if (isLoading()) {
                                    clearMediationTimer();

                                    responseInfo.finishLoading();

                                    if (event.isFail()) {
                                        if (listener != null) {
                                            listener.sendLogEvent(ad, event.getErrorInfo());

                                            final AdNetworkErrorInfo errorInfo =
                                                    event.getErrorInfo();
                                            listener.onFailed(
                                                    ad,
                                                    errorInfo != null
                                                            ? errorInfo.getError()
                                                            : VAMPError.ADNETWORK_ERROR);
                                        }
                                    }

                                    if (event.isLoadSuccess()) {
                                        // 在庫ありのときはすべてのADNWにおいてbeaconを送信する
                                        for (Tracking tracking : beaconNotifications) {
                                            tracking.send();
                                        }

                                        if (listener != null) {
                                            listener.onLoadSuccess(ad);
                                        }
                                    }
                                } else {
                                    if (event.isFail()) {
                                        if (listener != null) {
                                            listener.sendLogEvent(ad, event.getErrorInfo());

                                            final AdNetworkErrorInfo errorInfo =
                                                    event.getErrorInfo();
                                            listener.onFailed(
                                                    ad,
                                                    errorInfo != null
                                                            ? errorInfo.getError()
                                                            : VAMPError.ADNETWORK_ERROR);
                                        }
                                    }

                                    if (event.isOpen()) {
                                        // startビーコンもcompleteと同じ事実(open未通知のまま表示失敗を通知済み)で抑止する。
                                        // アプリへのonOpenedはlistener側のstate(FINISHED)で止まるが、送出はlistenerより前に
                                        // あるため、ここで止めないと「アプリは失敗を受け取ったのに計測上は開始が付く」(#1284)
                                        if (listener != null && listener.hasFailedBeforeOpen(ad)) {
                                            LogUtils.d(
                                                    formatLog(
                                                            "Skipped the start beacon because the"
                                                                    + " show failure was notified"
                                                                    + " before the open."));
                                        } else {
                                            sendStartBeacon();
                                        }

                                        if (listener != null) {
                                            listener.onVideoStart(ad);
                                        }
                                    }

                                    if (event.isClick()) {
                                        ad.adClicked = true;
                                    }

                                    if (event.isComplete()) {
                                        // completeビーコンは報酬確定(listener.onVideoComplete)と同じ事実で抑止する。
                                        // 送出はlistenerより前にあるため、listener側のガードだけでは止まらない(#1249)
                                        if (listener != null && listener.hasFailedBeforeOpen(ad)) {
                                            LogUtils.d(
                                                    formatLog(
                                                            "Skipped the complete beacon because the"
                                                                    + " show failure was notified"
                                                                    + " before the open."));
                                        } else {
                                            sendCompleteBeacon();
                                        }

                                        if (listener != null) {
                                            listener.onVideoComplete(ad);
                                        }
                                    }

                                    if (event.isClose()) {
                                        if (listener != null) {
                                            listener.onAdClosed(ad, ad.adClicked);
                                        }
                                    }
                                }

                                // 異常系の場合は最後に終了処理を実行
                                if (event.isFail()) {
                                    destroy();
                                }
                            }
                        });
    }

    @NonNull
    private String formatLog(@NonNull final String msg) {
        return msg + " (" + getAdNetworkName() + ")";
    }

    private void sendImpressionBeacon() {
        sendBeaconIfNotSuppressed(Tracking.EVENT_IMPRESSION, impressionBeacon);
    }

    private void sendStartBeacon() {
        sendBeaconIfNotSuppressed(Tracking.EVENT_START, startBeacon);
    }

    private void sendCompleteBeacon() {
        sendBeaconIfNotSuppressed(Tracking.EVENT_COMPLETE, completeBeacon);
    }

    private void sendBeaconIfNotSuppressed(
            @NonNull String event, @NonNull Optional<Tracking> beacon) {
        try {
            Tracking tracking = beacon.unwrap();
            if (isTrackingAlreadyDefinedInVast(tracking.getUrlString(), event)) {
                LogUtils.d(
                        formatLog(
                                "Skipped the "
                                        + event
                                        + " beacon because the same URL is defined in VAST."));
            } else {
                tracking.send();
            }
        } catch (Optional.NotPresentException ignored) {
        }
    }

    /**
     * json側ビーコン(impression/start/complete)のURLが、既にVAST側の同一イベントで発火済み/発火予定かを判定します (二重送信の抑制)。iOS版
     * {@code VAMPMediation}(VAMP-iOS-SDK feature/vamp_v6.0)の house-VAST dedup と対応する。
     *
     * <p>VASTメディエーション({@code adapter}が{@link VASTAdapter})の場合のみ、判定を{@link
     * VASTAdapter#isTrackingUrlDefined}に委譲します。ADNWメディエーションにvastxmlが付随していてもVAST側は
     * 再生されず発火しないため、抑制すると計測ロスになります。
     *
     * <p>VASTがまだロードされていない、またはパース自体に失敗した場合はfalseを返すため、json側ビーコンは発火します (誤抑制による欠測より二重送信を許容する方針)。
     */
    private boolean isTrackingAlreadyDefinedInVast(
            @NonNull String urlString, @NonNull String event) {
        if (!(adapter instanceof VASTAdapter)) {
            return false;
        }

        return ((VASTAdapter) adapter).isTrackingUrlDefined(urlString, event);
    }

    private void setMediationTimer() {
        clearMediationTimer();

        LogUtils.devLog(formatLog("set timer: " + mediationTimeout + "ms."));

        mediationTimer.cancelAndSchedule(
                mediationTimeout.getTimeInMilliseconds(), new MediationTimerTask(this));
    }

    private void clearMediationTimer() {
        LogUtils.devLog(formatLog("clear timer."));

        mediationTimer.cancelIfScheduled();
    }

    private boolean isLoading() {
        return mediationTimer.isScheduled();
    }

    /**
     * 基本的にはApplication Contextを返しますが、 Activityを要求するアダプタに対してはactivityインスタンスを返します。
     * ただし、activityインスタンスは破棄されている可能性があります
     */
    @NonNull
    private static Context getContextForAdapter(
            @NonNull final String adNetworkName,
            @NonNull final Context applicationContext,
            @Nullable final Activity activity)
            throws Exception {
        Context ctx =
                ("maio".equalsIgnoreCase(adNetworkName)
                                || "LINEAds".equalsIgnoreCase(adNetworkName)
                                || "ironSource".equalsIgnoreCase(adNetworkName))
                        ? activity
                        : applicationContext;

        if (ctx == null) {
            throw new Exception("The context is null.");
        }

        if (ctx instanceof Activity) {
            if (((Activity) ctx).isFinishing()) {
                throw new Exception("The activity is finishing.");
            } else if (((Activity) ctx).isDestroyed()) {
                throw new Exception("The activity was destroyed.");
            }
        }

        return ctx;
    }

    private static class MediationTimerTask extends TimerTask {
        private final WeakReference<Mediation> adRef;

        MediationTimerTask(Mediation ad) {
            adRef = new WeakReference<>(ad);
        }

        @Override
        public void run() {
            Mediation ad = adRef.get();

            if (ad == null) {
                cancel();
                return;
            }

            LogUtils.d("Mediation Error: " + ad.getAdNetworkName() + " timeout.");

            ad.vampEvent(
                    new Event(
                            Event.EVENT_FAIL,
                            new AdNetworkErrorInfo.Builder(
                                            "MediationTimerTask", VAMPError.MEDIATION_TIMEOUT)
                                    .setAdNetworkErrorMessage("Mediation timeout.")
                                    .build()));

            cancel();
        }
    }
}
