//
//  Copyright © 2026 Supership Inc. All rights reserved.
//
package jp.supership.vamp;

import android.text.TextUtils;
import androidx.annotation.Nullable;
import androidx.annotation.VisibleForTesting;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import jp.supership.vamp.core.logging.LogUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

final class Response {
    /** インスタンスを生成できません。詳細はmessageを参照してください */
    static class CanNotInstantiateException extends Exception {
        CanNotInstantiateException(String message) {
            super(message);
        }
    }

    /**
     * 配信可能な広告レスポンスが1件もありません。
     *
     * <p>results が空の場合、または ad 本文が {@code <!-- st=noad ... -->} 形式の在庫なし (noad)
     * 応答である場合にスローされます。message は null の場合もあります。
     */
    static class NoAdException extends Exception {
        NoAdException() {
            super();
        }

        NoAdException(String message) {
            super(message);
        }
    }

    private static final String KEY_LOCATION_ID = "locationid";
    private static final String KEY_RESULTS = "results";
    private static final String KEY_AD = "ad";

    /** {@code <!-- st=noad : id=... : pos=... -->} のような在庫なし (noad) 応答マーカー */
    private static final Pattern NO_AD_MARKUP_PATTERN =
            Pattern.compile("<!--\\s*(st=noad\\b[^>]*?)-->");

    /**
     * ad 本文から在庫なし (st=noad) 応答マーカーのコメント本文を抽出します。
     *
     * <p>ad 本文中の任意の位置に {@code <!-- st=noad ... -->} 形式の HTML コメントが含まれる場合、 そのコメント本文 (例: {@code
     * "st=noad : id=53072 : pos=SSPLOC"}) を返します (先頭限定ではありません)。null や空文字、st=noad
     * を含まないコメント、コメント形式でない文字列は マーカーでないものとして null を返します。
     */
    @VisibleForTesting
    @Nullable
    static String extractNoAdMarkupBody(@Nullable String ad) {
        if (TextUtils.isEmpty(ad)) {
            return null;
        }
        Matcher matcher = NO_AD_MARKUP_PATTERN.matcher(ad);
        return matcher.find() ? matcher.group(1).trim() : null;
    }

    /** 配信可能な広告レスポンスのリスト */
    final ArrayList<AdResponse> results = new ArrayList<>();

    /**
     * JSON文字列をパースしてインスタンスを生成します。 例外が発生したときはインスタンス化しません
     *
     * <p>``` { "locationid": String, "results": String(AdResponse[]) } ```
     */
    static Response newInstance(@Nullable String jsonString)
            throws CanNotInstantiateException, NoAdException {
        if (TextUtils.isEmpty(jsonString)) {
            throw new CanNotInstantiateException("Given jsonString is null or empty.");
        }

        try {
            return newInstance(new JSONObject(jsonString));
        } catch (JSONException e) {
            throw new CanNotInstantiateException("JSONException occurred. " + e);
        }
    }

    static Response newInstance(@Nullable JSONObject obj)
            throws CanNotInstantiateException, NoAdException {
        return new Response(obj);
    }

    @VisibleForTesting
    Response(@Nullable JSONObject obj) throws CanNotInstantiateException, NoAdException {
        if (obj == null) {
            throw new CanNotInstantiateException("Given jsonObject is null.");
        }

        String placementId = obj.optString(KEY_LOCATION_ID);
        if (TextUtils.isEmpty(placementId)) {
            String noAdMarkup = extractNoAdMarkupBody(obj.optString(KEY_AD));
            if (noAdMarkup != null) {
                throw new NoAdException("st=noad response. " + noAdMarkup);
            }
            throw new CanNotInstantiateException(
                    "The locationid's value in the response is null or empty.");
        }

        try {
            JSONArray arr = new JSONArray(obj.getString(KEY_RESULTS));

            for (int i = 0, len = arr.length(); i < len; i++) {
                try {
                    AdResponse adResponse = new AdResponse(placementId, arr.getJSONObject(i));
                    results.add(adResponse);
                } catch (AdResponse.CanNotInstantiateException e) {
                    LogUtils.devLog(e.getMessage());
                }
            }
        } catch (JSONException e) {
            throw new CanNotInstantiateException("JSONException occurred. " + e);
        }

        if (results.size() <= 0) {
            throw new NoAdException();
        }
    }
}
