//
//  Copyright © 2026 Supership Inc. All rights reserved.
//
package jp.supership.vamp;

import android.app.Activity;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.VisibleForTesting;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TimerTask;
import jp.supership.sscore.vamp.adrequest.SSCoreChildDirected;
import jp.supership.sscore.vamp.adrequest.SSCoreRewardedAdClient;
import jp.supership.sscore.vamp.cloudlogger.SSCoreCloudLogEvent;
import jp.supership.sscore.vamp.cloudlogger.SSCoreCloudLogItem;
import jp.supership.sscore.vamp.cloudlogger.SSCoreCloudLoggable;
import jp.supership.sscore.vamp.rewardedad.SSCoreAdNetworkNames;
import jp.supership.sscore.vamp.rewardedad.SSCoreRewardKey;
import jp.supership.sscore.vamp.rewardedad.SSCoreRewardedAdMediationTimeout;
import jp.supership.sscore.vamp.rewardedad.SSCoreRewardedAdRequestTimeout;
import jp.supership.sscore.vamp.rewardedad.SSCoreRewardedAdState;
import jp.supership.sscore.vamp.rewardedad.SSCoreRewardedAdStateValue;
import jp.supership.sscore.vamp.timer.SSCoreScheduledTimer;
import jp.supership.sscore.vamp.timer.SSCoreStopwatch;
import jp.supership.sscore.vamp.timer.SSCoreTimerSchedulable;
import jp.supership.sscore.vamp.type.Optional;
import jp.supership.sscore.vamp.userconsent.SSCoreUnderAgeOfConsent;
import jp.supership.vamp.core.logging.LogUtils;
import jp.supership.vamp.core.utils.StopwatchLogUtils;
import jp.supership.vamp.core.utils.VAMPMap;
import jp.supership.vamp.mediation.AdNetworkErrorInfo;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

final class AppOpenMediationManager implements Mediation.Listener {
    interface Listener {

        void onReceived();

        void onFailedToShow(@NonNull VAMPError error);

        void onFailedToLoad(@NonNull VAMPError error);

        void onOpened();

        void onCompleted();

        void onClosed(boolean adClicked);
    }

    @NonNull private final SSCoreRewardedAdClient adClient;
    @NonNull private final SdkAvailability.IAvailabilityChecker availabilityChecker;
    @NonNull private final SSCoreCloudLoggable cloudLogger;
    @NonNull private final Context applicationContext;

    /** Activityインスタンスは画面が閉じられるなどにより破棄される可能性があります。 なるべく依存しないようにしましょう */
    @NonNull private final WeakReference<Activity> activity_dangerousInstance;

    @VisibleForTesting @NonNull String placementId;
    @NonNull SSCoreRewardedAdState state = SSCoreRewardedAdState.idle();
    @Nullable private final Listener listener;
    @NonNull private Optional<MediationContainer> mediationContainer = Optional.empty();

    /** 広告リクエストタイマー */
    @NonNull private final SSCoreTimerSchedulable requestTimer = new SSCoreScheduledTimer();

    /** ロード時間計測オブジェクト */
    @NonNull private Optional<SSCoreStopwatch> loadTimeMeasurement = Optional.empty();

    /** 表示時間計測オブジェクト */
    @NonNull private Optional<SSCoreStopwatch> playbackTimeMeasurement = Optional.empty();

    @NonNull private Optional<MediationResponseInfo.Builder> responseInfo = Optional.empty();

    /** 最後にonReceiveが呼ばれた時間を記録 */
    private long latestReceivedTime;

    @NonNull AppOpenOptions options;
    @NonNull private final Handler mainHandler = new Handler(Looper.getMainLooper());

    AppOpenMediationManager(
            @NonNull final SSCoreRewardedAdClient adClient,
            @NonNull final SdkAvailability.IAvailabilityChecker availabilityChecker,
            @NonNull final SSCoreCloudLoggable cloudLogger,
            @NonNull final Activity activity,
            @NonNull final String placementId,
            @Nullable final Listener listener,
            @NonNull final AppOpenOptions options) {
        this.adClient = adClient;
        this.availabilityChecker = availabilityChecker;
        this.cloudLogger = cloudLogger;
        this.applicationContext = activity.getApplicationContext();
        this.activity_dangerousInstance = new WeakReference<>(activity);
        this.listener = listener;
        this.placementId = placementId.trim();
        this.options = options;

        QALogger.setQATestMode(applicationContext);
        AdapterVersionPrint.printList();
    }

    boolean isReady() {
        if (!state.isLoaded()) {
            return false;
        }

        return mediationContainer
                .flatMap(MediationContainer::getCurrentMediation)
                .map(Mediation::isReady)
                .orElse(false);
    }

    @NonNull
    VAMPResponseInfo getResponseInfo() {
        return responseInfo.orElse(new MediationResponseInfo.Builder()).build();
    }

    void load(@NonNull final VAMPRequest request) throws SSCoreRewardedAdState.NotChangedException {
        state = state.changed(SSCoreRewardedAdStateValue.LOADING);

        try {
            availabilityChecker.check(Optional.of(placementId));
        } catch (SdkAvailability.UnavailableException e) {
            failedToLoad(e.error, new VAMPMap().add(e.errorReason));
            return;
        }

        setRequestTimer(request.requestTimeout);

        loadTimeMeasurement = Optional.of(SSCoreStopwatch.start());

        LogUtils.d("Start requesting an ad.");
        SSCoreChildDirected childDirected =
                MediationRequestParams.toSSCoreChildDirected(
                        VAMPPrivacySettings.getChildDirected());
        SSCoreUnderAgeOfConsent underAgeOfConsent =
                MediationRequestParams.toSSCoreUnderAgeOfConsent(
                        VAMPPrivacySettings.getUnderAgeOfConsent());

        adClient.requestRewardedAd(
                placementId,
                VAMP.SDKVersion(),
                VAMP.isTestMode(),
                childDirected,
                underAgeOfConsent,
                MediationRequestParams.getAdapterParams(
                        GlobalAdapterProvider.getProvider(), applicationContext),
                request.contentUrl,
                result -> {
                    if (result.error.isPresent()) {
                        LogUtils.e("Ad request failed.");
                        Throwable throwable = result.error.forced();
                        failedToLoad(
                                VAMPError.SERVER_ERROR,
                                new VAMPMap().add("Ad request failed. " + throwable.getMessage()));
                        return;
                    }

                    Response response;
                    try {
                        response = Response.newInstance(result.data.unwrap());
                    } catch (Response.CanNotInstantiateException | Optional.NotPresentException e) {
                        failedToLoad(
                                VAMPError.UNKNOWN,
                                new VAMPMap().add("Failed to parse response. " + e.getMessage()));
                        return;
                    } catch (Response.NoAdException e) {
                        failedToLoad(
                                VAMPError.NO_ADNETWORK,
                                new VAMPMap().add("Received NoAd. " + e.getMessage()));
                        return;
                    }

                    final Activity activity = getActivity();
                    if (activity == null) {
                        failedToLoad(
                                VAMPError.INVALID_PARAMETER,
                                new VAMPMap().add("Activity was destroyed."));
                        return;
                    }

                    final ArrayList<AdResponse> adResponses = response.results;
                    final ArrayList<Mediation> mediationList = new ArrayList<>();
                    for (AdResponse adResponse : adResponses) {
                        try {
                            mediationList.add(
                                    new Mediation.Builder()
                                            .withListener(AppOpenMediationManager.this)
                                            .withMediationTimeout(
                                                    VAMPDebugUtils.newInstance()
                                                            .mediationTimeout
                                                            .orElse(
                                                                    SSCoreRewardedAdMediationTimeout
                                                                            .newDefault()))
                                            .build(
                                                    applicationContext,
                                                    activity,
                                                    adResponse,
                                                    request));
                        } catch (LinkageError | Exception e) {
                            // Mediation.Builder.build内のgetAdapter / isSupported() /
                            // prepare()から飛ぶError系もadResponse単位で隔離する(#1224)。
                            // 伝播するとSSCoreの応答lambdaが巻き戻り無音のREQUEST_TIMEOUTになる。
                            LogUtils.w("build adapter failed. " + e.getMessage());
                        }
                    }

                    mediationContainer = Optional.of(new MediationContainer(mediationList));

                    final MediationResponseInfo.Builder respInfo =
                            new MediationResponseInfo.Builder()
                                    .withAdapterResponseList(
                                            mediationContainer
                                                    .map(MediationContainer::getAdapterResponseList)
                                                    .maybe())
                                    .withSeqId(
                                            !adResponses.isEmpty()
                                                    ? adResponses.get(0).getSeqId()
                                                    : null);
                    responseInfo = Optional.of(respInfo);

                    final ArrayList<String> adNetworkNames = new ArrayList<>();
                    for (Mediation mediation : mediationList) {
                        adNetworkNames.add(mediation.getAdNetworkName());
                    }

                    cloudLogger.send(
                            baseLogItem()
                                    .setListener("load")
                                    .setEvent(SSCoreCloudLogEvent.ADNETWORK_LIST)
                                    .setAdNetworkList(String.join(",", adNetworkNames)));

                    QALogger.logWeightEvent(adNetworkNames);

                    if (VAMP.isDebugMode()) {
                        logDebugMediationList(mediationList);
                    }

                    mainHandler.post(
                            () -> {
                                if (loadAdOrStop()) {
                                    failedToLoad(
                                            VAMPError.NO_ADSTOCK,
                                            new VAMPMap()
                                                    .add(
                                                            "Failed to load all adnetwork."
                                                                    + " (empty)"));
                                }
                            });
                });
    }

    /**
     * 表示が進行中(BEGIN_PLAYBACK / SHOWING)かどうかを返します。
     *
     * <p>公開ラッパ({@link VAMPAppOpenAd#show})はこの判定をリスナー代入より前に行います。 判定を{@link
     * #show}の内側だけに置くと、却下される要求でも代入が先に走り、 進行中の表示の通知先が差し替わってしまうためです(#1247)。
     */
    boolean isShowInProgress() {
        return state.isBeginPlayback() || state.isShowing();
    }

    void show(@Nullable final Activity activity) {
        // 表示中(BEGIN_PLAYBACK / SHOWING)の再showは「表示要求そのものの却下」であり、進行中の表示について
        // 何も語らない。ここでfailedToShowへ落とすと、進行中の表示と同じリスナーへ失敗を通知した上で
        // destroyManager()が進行中の表示ごと破棄してしまうため、却下は進行中の表示から完全に分離し、
        // ログのみで静かに握り潰す。AppOpenAdには報酬確定が無いので影響は表示の破壊のみ(#1247)
        if (isShowInProgress()) {
            LogUtils.d("Rejected the show request because the ad is already being shown.");
            return;
        }

        // 未ロード(IDLE / LOADING / FINISHED など)・有効期限切れの表示要求は従来どおり失敗を通知する
        if (!isReady()) {
            failedToShow(VAMPError.NOT_LOADED_AD);
            return;
        }

        if (isExpired()) {
            failedToShow(VAMPError.NOT_LOADED_AD);
            return;
        }

        try {
            state = state.changed(SSCoreRewardedAdStateValue.BEGIN_PLAYBACK);
        } catch (SSCoreRewardedAdState.NotChangedException e) {
            LogUtils.d(e.getMessage());
            return;
        }

        try {
            availabilityChecker.check(Optional.of(placementId));
        } catch (SdkAvailability.UnavailableException e) {
            LogUtils.w(e.errorReason);
            failedToShow(e.error);
            return;
        }

        // Viewを操作するのでバックグラウンド実行されたとしても確実にUIスレッドで実行する
        mainHandler.post(
                () -> {
                    if (activity == null || activity.isFinishing() || activity.isDestroyed()) {
                        final String errMsg = "activity is null or already finished.";
                        LogUtils.e(errMsg);
                        failedToShow(VAMPError.INVALID_PARAMETER);

                        cloudLogger.send(
                                baseLogItem()
                                        .setError(VAMPError.INVALID_PARAMETER.name(), errMsg)
                                        .setListener("show"));
                        return;
                    }

                    try {
                        final Mediation ad =
                                mediationContainer
                                        .flatMap(MediationContainer::getCurrentMediation)
                                        .unwrap();

                        QALogger.logShowEvent(ad.getAdNetworkName());

                        playbackTimeMeasurement = Optional.of(SSCoreStopwatch.start());

                        ad.show(activity);
                    } catch (Optional.NotPresentException e) {
                        LogUtils.e("Failed to show because the ad is not present.");
                        destroyManager();
                    }
                });
    }

    void destroyManager() {
        try {
            state = state.changed(SSCoreRewardedAdStateValue.FINISHED);
        } catch (SSCoreRewardedAdState.NotChangedException ignored) {
        }

        mediationContainer.ifPresent(MediationContainer::destroyContainer);
        mediationContainer = Optional.empty();

        clearRequestTimer();

        activity_dangerousInstance.clear();
    }

    /**
     * @return 破棄されていないActivityの場合はActivityインスタンスを返します。 それ以外はnullを返します
     */
    @Nullable
    private Activity getActivity() {
        Activity activity = activity_dangerousInstance.get();
        if (activity == null || activity.isFinishing() || activity.isDestroyed()) {
            return null;
        } else {
            return activity;
        }
    }

    /** 広告をロードします。ロードする広告がない場合はtrueを返します。 広告がある場合はロード開始の成功/失敗に関わらずfalseを返します */
    private boolean loadAdOrStop() {
        final Mediation ad;
        try {
            ad = mediationContainer.flatMap(MediationContainer::getCurrentMediation).unwrap();
        } catch (Optional.NotPresentException e) {
            return true;
        }

        final String name = ad.getAdNetworkName();

        LogUtils.d(String.format("Start loading %s.", name));

        cloudLogger.send(
                logItem(ad)
                        .setEvent(SSCoreCloudLogEvent.LOAD_ADNETWORK)
                        .setListener("loadAdOrStop"));

        ad.load(applicationContext, getActivity());

        return false;
    }

    private void setRequestTimer(@NonNull final SSCoreRewardedAdRequestTimeout requestTimeout) {
        LogUtils.devLog("set request timer.");
        clearRequestTimer();

        requestTimer.cancelAndSchedule(
                requestTimeout.timeInMilliseconds(), new RequestTimerTask(this));
    }

    private void clearRequestTimer() {
        LogUtils.devLog("clear request timer.");

        requestTimer.cancelIfScheduled();
    }

    private void logDebugMediationList(@NonNull final List<Mediation> mediationList) {
        final ArrayList<Map<String, String>> debugLogs = new ArrayList<>();
        for (Mediation ad : mediationList) {
            final Map<String, String> debugLog = new LinkedHashMap<>();
            debugLog.put("adnw", ad.getAdNetworkName());
            debugLog.put("version", ad.getAdNetworkVersion());
            debugLog.put("ready", String.valueOf(ad.isReady()));
            debugLogs.add(debugLog);
        }

        final JSONArray jsonArray = new JSONArray();
        for (Map<String, String> map : debugLogs) {
            jsonArray.put(new JSONObject(map));
        }

        try {
            LogUtils.d("Ad network list: " + jsonArray.toString(4));
        } catch (JSONException ignored) {
            // Ignore formatting errors
        }
    }

    @NonNull
    private SSCoreCloudLogItem baseLogItem() {
        return new SSCoreCloudLogItem(SSCoreRewardKey.getAppUserKey(), VAMP.SDKVersion())
                .setAdId(placementId)
                .setState(state.toString())
                .setSequenceId(getResponseInfo().getSeqID());
    }

    @NonNull
    private SSCoreCloudLogItem logItem(@NonNull final Mediation mediation) {
        return baseLogItem()
                .setAdNetworkName(mediation.getAdNetworkName())
                .setAdNetworkVersion(mediation.getAdNetworkVersion())
                .setAdNetworkAdIdentifiers(mediation.getAdNetworkAdIdentifiers())
                .setAdapterVersion(mediation.getAdapterVersion());
    }

    @Override
    public void sendLogEvent(
            @NonNull final Mediation ad, @Nullable final AdNetworkErrorInfo errorInfo) {
        if (errorInfo == null) return;

        final SSCoreCloudLogItem item =
                logItem(ad)
                        .setListener(errorInfo.getMethodName())
                        .setError(errorInfo.getError().name(), errorInfo.getErrorMessage())
                        .setAdNetworkErrorCode(errorInfo.getAdNetworkErrorCode())
                        .setAdNetworkErrorMessage(errorInfo.getAdNetworkErrorMessage());

        if (state.isShowing() && playbackTimeMeasurement.isPresent()) {
            item.setShowSeconds(
                    StopwatchLogUtils.elapsedSecondsWithLog(
                            "playbackTime", playbackTimeMeasurement.forced()));
        }

        cloudLogger.send(item);
    }

    @Override
    public void onLoadSuccess(@NonNull final Mediation mediation) {
        try {
            state = state.changed(SSCoreRewardedAdStateValue.LOADED);
        } catch (SSCoreRewardedAdState.NotChangedException e) {
            LogUtils.d(e.getMessage());
            return;
        }

        try {
            responseInfo.unwrap().withAdNetworkName(mediation.getAdNetworkName());
        } catch (Optional.NotPresentException ignored) {
        }

        LogUtils.d("Loaded " + mediation.getAdNetworkName());

        QALogger.logReceiveEvent(mediation.getAdNetworkName());

        cloudLogger.send(
                logItem(mediation)
                        .setEvent(SSCoreCloudLogEvent.RECEIVE)
                        .setListener("onLoadSuccess")
                        .setLoadSeconds(
                                loadTimeMeasurement.isPresent()
                                        ? StopwatchLogUtils.elapsedSecondsWithLog(
                                                "loadTime", loadTimeMeasurement.forced())
                                        : 0));

        if (listener != null) {
            listener.onReceived();
        }

        clearRequestTimer();
        latestReceivedTime = System.currentTimeMillis();
    }

    @Override
    public void onFailed(@NonNull final Mediation mediation, @NonNull final VAMPError error) {
        if (state.isLoading()) {
            LogUtils.d("Failed to load " + mediation.getAdNetworkName());

            QALogger.logAdNetworkFailEvent(mediation.getAdNetworkName(), error, null);

            if (error != VAMPError.MEDIATION_TIMEOUT) {
                mediationContainer.ifPresent(MediationContainer::nextMediation);

                if (loadAdOrStop()) {
                    failedToLoad(
                            VAMPError.NO_ADSTOCK,
                            new VAMPMap().add("Failed to load all adnetwork."));
                }
            } else {
                // タイムアウトエラーならば中断する.
                // 回線状況が悪い中でADNWのロードを続けるのは悪循環になるため.
                // ただし,一応のケアとしてVAST広告のロードを試みる
                // (通信は発生するが,VAST広告は在庫が担保されているので待ち続ければロード成功する.ただ,時間がかかれば結局タイムアウトしてしまう...)
                mediationContainer.ifPresent(MediationContainer::nextVASTMediation);

                if (loadAdOrStop()) {
                    failedToLoad(VAMPError.MEDIATION_TIMEOUT, new VAMPMap());
                }
            }
        } else if (state.isBeginPlayback() || state.isShowing()) {
            failedToShow(error);
        }
    }

    @Override
    public void onVideoStart(@NonNull final Mediation mediation) {
        try {
            state = state.changed(SSCoreRewardedAdStateValue.SHOWING);
        } catch (SSCoreRewardedAdState.NotChangedException e) {
            LogUtils.d(e.getMessage());
            return;
        }

        cloudLogger.send(
                logItem(mediation).setEvent(SSCoreCloudLogEvent.OPEN).setListener("onVideoStart"));

        if (listener != null) {
            listener.onOpened();
        }
    }

    @Override
    public void onVideoComplete(@NonNull final Mediation mediation) {
        // AppOpenAdでは通知しない
    }

    /** AppOpenAdは報酬確定を持たず、open前失敗の事実も保持しないため、completeビーコンの送出は従来どおりとします(#1249)。 */
    @Override
    public boolean hasFailedBeforeOpen(@NonNull final Mediation mediation) {
        return false;
    }

    @Override
    public void onAdClosed(@NonNull final Mediation mediation, final boolean adClicked) {
        // Closeはどのような状態でも必ず発火されること。また1回だけ発火されること
        try {
            state = state.compareAndSetOnClose();
        } catch (SSCoreRewardedAdState.NotChangedException e) {
            LogUtils.d(e.getMessage());
            return;
        }

        QALogger.logCloseEvent(mediation.getAdNetworkName());

        cloudLogger.send(
                logItem(mediation)
                        .setEvent(SSCoreCloudLogEvent.CLOSE)
                        .setListener("onAdClosed")
                        .setAdClicked(Optional.of(adClicked)));

        if (listener != null) {
            listener.onClosed(adClicked);
        }

        destroyManager();
    }

    private boolean isExpired() {
        if (latestReceivedTime <= 0) return true;

        final String adNetworkName =
                mediationContainer
                        .flatMap(MediationContainer::getCurrentMediation)
                        .map(Mediation::getAdNetworkName)
                        .orElse("");

        long ttl = options.getExpirationTimeInMilliSeconds(adNetworkName);

        // 経過時間がTTLを超えているかチェック
        long elapsedTime = System.currentTimeMillis() - latestReceivedTime;

        // Pangleはリロードされるのでexpire扱いとしない
        return elapsedTime > ttl && !adNetworkName.equals(SSCoreAdNetworkNames.PANGLE);
    }

    private void failedToLoad(
            @NonNull final VAMPError error, @NonNull final VAMPMap errorMessages) {
        if (!state.isLoading()) {
            LogUtils.d("The state is not loading.");
            return;
        }

        LogUtils.d("Failed to load: " + error + ", " + errorMessages);

        final String adNetworkName =
                mediationContainer
                        .flatMap(MediationContainer::getCurrentMediation)
                        .map(Mediation::getAdNetworkName)
                        .orElse("");
        QALogger.logAdNetworkFailEvent(adNetworkName, error, errorMessages.toString());

        cloudLogger.send(
                baseLogItem()
                        .setEvent(SSCoreCloudLogEvent.LOAD_FAILURE)
                        .setListener("failedToLoad")
                        .setLoadSeconds(
                                loadTimeMeasurement.isPresent()
                                        ? StopwatchLogUtils.elapsedSecondsWithLog(
                                                "loadTime", loadTimeMeasurement.forced())
                                        : 0));

        if (listener != null) {
            listener.onFailedToLoad(error);
        }

        destroyManager();
    }

    private void failedToShow(@NonNull final VAMPError error) {
        LogUtils.d("Failed to show: " + error);

        QALogger.logFailEvent(getResponseInfo().getAdNetworkName(), error);

        if (listener != null) {
            listener.onFailedToShow(error);
        }

        destroyManager();
    }

    private static final class RequestTimerTask extends TimerTask {
        @NonNull private final Handler handler = new Handler(Looper.getMainLooper());
        @NonNull private final WeakReference<AppOpenMediationManager> managerRef;

        RequestTimerTask(@NonNull final AppOpenMediationManager manager) {
            managerRef = new WeakReference<>(manager);
        }

        @Override
        public void run() {
            handler.post(
                    () -> {
                        AppOpenMediationManager manager = managerRef.get();

                        if (manager == null) {
                            cancel();
                            return;
                        }

                        LogUtils.d("Request Timeout.");

                        manager.failedToLoad(VAMPError.REQUEST_TIMEOUT, new VAMPMap());
                        cancel();
                    });
        }
    }
}
