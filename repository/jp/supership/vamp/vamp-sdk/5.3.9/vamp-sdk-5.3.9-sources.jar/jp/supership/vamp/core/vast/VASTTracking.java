//
//  Copyright © 2026 Supership Inc. All rights reserved.
//
package jp.supership.vamp.core.vast;

import android.text.TextUtils;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import java.io.Serializable;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import jp.supership.sscore.vamp.http.SSCoreHttp;
import jp.supership.sscore.vamp.http.SSCoreHttpClient;
import jp.supership.sscore.vamp.http.SSCoreHttpRequest;
import jp.supership.vamp.core.error.VAMPInternalError;
import jp.supership.vamp.core.logging.LogUtils;
import jp.supership.vamp.core.utils.Strings;

public class VASTTracking implements Serializable {
    @NonNull public final String event;
    @NonNull public final URL url;
    @Nullable public final String offset;
    private final long timeMilliSec;
    private final float percentage;
    private int count;

    private static final int VAMP_VAST_TRACKING_INVALID_VALUE = -1;

    public VASTTracking(@NonNull final String event, @NonNull final URL url) {
        this(event, url, null);
    }

    public VASTTracking(
            @NonNull final String event, @NonNull final URL url, @Nullable final String offset) {
        this(event, url, offset, 0);
    }

    public VASTTracking(
            @NonNull final String event,
            @NonNull final URL url,
            @Nullable final String offset,
            int count) {
        LogUtils.devLog("VASTTracking(" + event + ", " + url + ", " + offset + ", " + count + ")");
        this.event = event;
        this.url = url;
        this.offset = offset;
        this.count = count;

        int time = VAMP_VAST_TRACKING_INVALID_VALUE;
        float per = VAMP_VAST_TRACKING_INVALID_VALUE;
        if (!TextUtils.isEmpty(offset)) {
            assert offset != null;
            try {
                if (Strings.isAbsoluteTracker(offset)) {
                    Integer t = Strings.parseAbsoluteOffset(offset);
                    if (t != null) {
                        time = t;
                    }
                }

                if (Strings.isPercentageTracker(offset)) {
                    per = Float.parseFloat(offset.replace("%", ""));
                }
            } catch (Exception e) {
                LogUtils.e("VASTTracking#offset parse error");
            }
        }
        timeMilliSec = time;
        percentage = per;

        LogUtils.devLog("timeMilliSec:" + timeMilliSec + " percentage:" + percentage);
    }

    public boolean reachedTime(long currentTimeMilliSec, float currentPercentage) {
        return (timeMilliSec != VAMP_VAST_TRACKING_INVALID_VALUE
                        && currentTimeMilliSec >= timeMilliSec)
                || (this.percentage != VAMP_VAST_TRACKING_INVALID_VALUE
                        && currentPercentage >= this.percentage);
    }

    public void send(
            @Nullable Map<String, String> headers,
            @Nullable final VASTObject.VASTEventListener listener) {
        send(SSCoreHttp.newClient(), headers, listener);
    }

    public boolean isDone() {
        return false;
    }

    /**
     * 送信直前と重複排除の照合に適用する tracking URL の正規化 (CDATA 内に書かれた {@code &amp;} を {@code &} へ展開)。
     *
     * <p>CDATA の中身は XML 仕様上エンティティ展開の対象外のため、{@code <![CDATA[...?a=1&amp;b=2]]>} と書かれた URL は DOM
     * パーサーを素通りし、そのまま GET するとサーバー側でクエリが {@code a=1} と {@code amp;b=2} に割れる。CDATA の外の {@code &amp;} は
     * DOM パーサーが展開済みなので本関数では何も起きない。
     *
     * <p>展開するのは {@code &amp;} だけで、二重エスケープ ({@code &amp;amp;}) は 1 段だけ展開する (iOS {@code
     * HouseVASTEngine.normalizedTrackingURLString} と同じ規則。SSCore-iOS #361 / #368)。
     *
     * <p><b>本関数は {@link #send} の送信 URL と、{@code VASTAdapter#isTrackingUrlDefined} の照合の VAST
     * 側で使うこと。</b> 片方だけに掛けると、json 側ビーコンを抑制したのに VAST 側は別の URL を送る (当該 URL の計測が 0 件)、 または両方を送る (二重送信)
     * 状態になる。json 側は生の文字列を送るので、照合でも json 側には掛けない (前後の空白を除くだけ)。
     *
     * <p>対象は VAST から取り出して SDK が送る GET (Impression / TrackingEvents / ClickTracking /
     * IconClickTracking / OM の verificationNotExecuted / clickThrough のクリック計測リクエスト {@code
     * ClickThrough#send})。iOS #368・ADR-003 No.55 と同じ範囲。clickThrough の遷移先・OM の
     * JavaScriptResource・MediaFile・EndCard の URL と、json 側ビーコンの送信 URL には掛けない。
     *
     * <p>送信 GET のほかに、Wrapper を取得する {@code VASTAdTagURI} にも掛ける (#1288)。こちらは照合相手が無いため {@code
     * VASTParser} がパース時に 1 回だけ掛け、取得・ログ・ループ検出のすべてが正規化後の URL を見る。
     *
     * @param urlString 正規化する URL 文字列
     * @return {@code &amp;} を {@code &} へ 1 段だけ展開した文字列
     */
    @NonNull
    public static String normalizedUrlString(@NonNull final String urlString) {
        return urlString.replace("&amp;", "&");
    }

    /**
     * 送信時に {@code SSCoreHttpRequest.Builder} が {@code new URL(raw)} で作る URL の外部形式 ({@code
     * java.net.URL#toString()}) を返します (scheme の小文字化・前後の {@code <= ' '} の除去が掛かる。既定ポート・
     * fragment・パーセントエンコードの差は保持する)。重複排除の照合で「照合する文字列 = 送信に使う URL の外部形式」を 両側で揃えるために使います。
     *
     * @param raw 送信に渡す URL 文字列 (VAST 側は {@link #normalizedUrlString} を掛けた後のもの)
     * @return {@code new URL(raw).toString()}
     * @throws MalformedURLException URL として不正な場合 (送信も同じ例外で失敗する)
     */
    @NonNull
    public static String sentUrlString(@NonNull final String raw) throws MalformedURLException {
        return new URL(raw).toString();
    }

    public int getCount() {
        return count;
    }

    void send(
            @NonNull SSCoreHttpClient httpClient,
            @Nullable Map<String, String> headers,
            @Nullable final VASTObject.VASTEventListener listener) {
        if (isDone()) {
            LogUtils.d("Already done. " + event);
            return;
        }

        count++;

        LogUtils.devLog("send " + event + " event.");

        if (headers == null) {
            headers = new HashMap<>();
        }

        SSCoreHttpRequest httpRequest;
        try {
            httpRequest =
                    new SSCoreHttpRequest.Builder(normalizedUrlString(url.toString()))
                            .withMethod(SSCoreHttpRequest.Method.GET)
                            .withHeaders(new SSCoreHttpRequest.Headers(headers))
                            .build();
        } catch (MalformedURLException | SSCoreHttpRequest.InvalidRequestParameterException e) {
            LogUtils.devLog("send " + event + " failed. url:" + url + " message:" + e.getMessage());
            return;
        }

        httpClient.request(
                httpRequest,
                result -> {
                    if (result.isSuccess()) {
                        if (listener != null) {
                            listener.onComplete(url, null);
                        }
                    } else {
                        final String errorMessage =
                                result.error.map(Throwable::getMessage).orElse("Unknown error");

                        final int statusCodeMessage =
                                result.data.map(response -> response.statusCode).orElse(0);

                        final String message = statusCodeMessage + ", " + errorMessage;

                        if (listener != null) {
                            listener.onComplete(
                                    url,
                                    new VAMPInternalError(
                                            VAMPInternalError.Code.NETWORK_ERROR, message));
                        }

                        LogUtils.devLog(
                                "send " + event + " failed. url:" + url + " message:" + message);
                    }
                });
    }
}
