//
//  Copyright © 2026 Supership Inc. All rights reserved.
//
package jp.supership.vamp;

import java.util.ArrayList;
import java.util.List;
import jp.supership.sscore.vamp.rewardedad.SSCoreAdNetworkNames;
import jp.supership.vamp.core.logging.LogUtils;
import jp.supership.vamp.mediation.Adapter;

class AdapterProvider implements AdapterProviding {

    private static final String MEDIATION_PACKAGE_NAME = "jp.supership.vamp.mediation";

    @Override
    public Adapter getAdapter(String adNetworkName) throws AdapterNotFoundException {
        String className;

        if (adNetworkName.equalsIgnoreCase(SSCoreAdNetworkNames.VAMP)) {
            className = "jp.supership.vamp.VASTAdapter";
        } else {
            String classPrefix =
                    adNetworkName.substring(0, 1).toUpperCase() + adNetworkName.substring(1);
            className =
                    String.format(
                            "%s.%s.%sAdapter",
                            MEDIATION_PACKAGE_NAME, adNetworkName.toLowerCase(), classPrefix);
        }

        LogUtils.devLog("class name:" + className);

        try {
            Class<?> cls = Class.forName(className);
            return (Adapter) cls.newInstance();
        } catch (LinkageError | Exception e) {
            // アダプタクラスは同梱されていてもアドネットワークSDK本体が未導入・除去済みの構成では、
            // staticイニシャライザやコンストラクタからExceptionInInitializerError・NoSuchMethodError・
            // UnsatisfiedLinkErrorなどNoClassDefFoundError以外のLinkageErrorも飛ぶ。ここで取りこぼすと
            // getSupportedAdaptersのループ全体が巻き戻り、健全なアダプタのビッドパラメータまで欠落する（#1189）
            LogUtils.devLog(e.getMessage());
        }
        throw new AdapterNotFoundException(
                String.format("Adapter class for %s not found.", adNetworkName));
    }

    @Override
    public ArrayList<Adapter> getSupportedAdapters() {
        List<String> names = SSCoreAdNetworkNames.getAdNetworkNames();
        ArrayList<Adapter> results = new ArrayList<>();

        for (String adNetworkName : names) {
            try {
                Adapter adapter = getAdapter(adNetworkName);
                results.add(adapter);
            } catch (AdapterNotFoundException e) {
                LogUtils.devLog(e.getMessage());
            }
        }

        return results;
    }
}
