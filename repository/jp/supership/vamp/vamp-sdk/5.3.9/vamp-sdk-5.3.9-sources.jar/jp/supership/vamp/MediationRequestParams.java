//
//  Copyright © 2026 Supership Inc. All rights reserved.
//
package jp.supership.vamp;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import jp.supership.sscore.vamp.adrequest.SSCoreChildDirected;
import jp.supership.sscore.vamp.userconsent.SSCoreUnderAgeOfConsent;
import jp.supership.vamp.core.logging.LogUtils;
import jp.supership.vamp.mediation.Adapter;
import jp.supership.vamp.mediation.RTBAdapter;

/**
 * 広告リクエスト組み立て時にリワード（{@link MediationManager}）とAppOpen（{@link
 * AppOpenMediationManager}）の双方が使うパラメータ収集・変換の共通ヘルパです。
 *
 * <p>両Managerに同一セマンティクスの複製があると、enum追加や例外ハードニングの修正が片側だけ静かに劣化するため、ここへ一本化します（#1189）。
 */
final class MediationRequestParams {

    private MediationRequestParams() {}

    /**
     * RTBアダプタからビッドパラメータを収集します。
     *
     * <p>単一のサードパーティ製アダプタの不具合でSDK全体を巻き込まないよう、アダプタごとに例外を捕捉して続行し、失敗したアダプタのみスキップします（#1189）。
     *
     * <p>両ManagerともstateをLOADINGへ遷移させsetRequestTimerでリクエストタイマーを起動した後に本メソッドを呼びます。したがってここで例外が伝播しても状態自体はfailedToLoad(REQUEST_TIMEOUT)で解消されますが、例外はNotChangedExceptionしか捕捉しない公開API（VAMPRewardedAd.load・VAMPAppOpenAd.load）を素通りしてアプリ側へ未捕捉のまま到達し得ます。
     *
     * <p>{@link Exception}に加えて{@link
     * LinkageError}も捕捉します。アダプタクラス自体は同梱されていてもアドネットワークSDK本体が未導入・除去済みの構成では、収集処理の中でNoClassDefFoundErrorやUnsatisfiedLinkErrorが発生しうるためです。同種の配慮は{@code
     * AdapterProvider#getAdapter}にもあり、そちらも{@link LinkageError}と{@link Exception}を捕捉します。
     *
     * <p>{@link LinkageError}以外の{@link Error}（AssertionErrorやVirtualMachineErrorなど）は捕捉せずそのまま伝播します。
     */
    @NonNull
    static Map<String, String> getAdapterParams(
            @NonNull final AdapterProviding provider, @NonNull final Context context) {
        final Map<String, String> adapterParams = new HashMap<>();

        final ArrayList<Adapter> supportedAdapters;
        try {
            supportedAdapters = provider.getSupportedAdapters();
        } catch (LinkageError | Exception e) {
            LogUtils.w("Failed to get supported adapters.", e);
            return adapterParams;
        }

        // AdapterProvidingはgetSupportedAdapters()の非nullを宣言しておらず、
        // GlobalAdapterProvider.injectProviderで差し替え可能なため、nullでも落とさない
        if (supportedAdapters == null) {
            LogUtils.w("The adapter provider returned no supported adapters.");
            return adapterParams;
        }

        // 差し替え可能なproviderが返すコレクション由来でイテレータ自体が失敗しても、
        // 収集済みのパラメータは捨てずに返す
        try {
            for (Adapter adapter : supportedAdapters) {
                if (!(adapter instanceof RTBAdapter)) {
                    continue;
                }

                collectFrom((RTBAdapter) adapter, context, adapterParams);
            }
        } catch (LinkageError | Exception e) {
            LogUtils.w("Failed to iterate supported adapters.", e);
        }

        return adapterParams;
    }

    /**
     * 1つのRTBアダプタからビッドパラメータを収集し、成功した場合のみ{@code adapterParams}へ合流させます。
     *
     * <p>アダプタ単位のall-or-nothingにするため、いったん一時Mapへ集めてから合流させます。返却Mapの反復途中で失敗した場合に、一部のキーだけが累積Mapに残ることを防ぐためです。
     */
    private static void collectFrom(
            @NonNull final RTBAdapter adapter,
            @NonNull final Context context,
            @NonNull final Map<String, String> adapterParams) {
        try {
            final Map<String, String> collected = new HashMap<>();

            final Map<String, String> map = adapter.collectParametersForAdRequest(context);
            if (map != null) {
                for (Map.Entry<String, String> entry : map.entrySet()) {
                    // SSCoreのクエリ組み立てはキーのnull検査をせずtrimするため、ここで落とす
                    if (entry.getKey() == null || entry.getValue() == null) {
                        continue;
                    }

                    collected.put(entry.getKey(), entry.getValue());
                }
            }

            adapterParams.putAll(collected);
        } catch (LinkageError | Exception e) {
            LogUtils.w(
                    "Failed to collect bid parameters from " + adapter.getClass().getName() + ".",
                    e);
        }
    }

    /**
     * VAMPChildDirected → SSCoreChildDirected 変換関数
     *
     * <p>{@link
     * VAMPPrivacySettings#setChildDirected}は{@code @NonNull}を実行時に検査しないため、nullを渡されてもUNKNOWNへ倒して広告リクエスト自体は続行させます。
     */
    @NonNull
    static SSCoreChildDirected toSSCoreChildDirected(
            @Nullable final VAMPPrivacySettings.ChildDirected v) {
        if (v == null) {
            return SSCoreChildDirected.UNKNOWN;
        }

        switch (v) {
            case TRUE:
                return SSCoreChildDirected.YES;
            case FALSE:
                return SSCoreChildDirected.NO;
            default:
                return SSCoreChildDirected.UNKNOWN;
        }
    }

    /**
     * VAMPUnderAgeOfConsent → SSCoreUnderAgeOfConsent 変換関数
     *
     * <p>{@link
     * VAMPPrivacySettings#setUnderAgeOfConsent}は{@code @NonNull}を実行時に検査しないため、nullを渡されてもUNKNOWNへ倒して広告リクエスト自体は続行させます。
     */
    @NonNull
    static SSCoreUnderAgeOfConsent toSSCoreUnderAgeOfConsent(
            @Nullable final VAMPPrivacySettings.UnderAgeOfConsent v) {
        if (v == null) {
            return SSCoreUnderAgeOfConsent.UNKNOWN;
        }

        switch (v) {
            case TRUE:
                return SSCoreUnderAgeOfConsent.CHILD_APPROPRIATE;
            case FALSE:
                return SSCoreUnderAgeOfConsent.NOT_CHILD_APPROPRIATE;
            default:
                return SSCoreUnderAgeOfConsent.UNKNOWN;
        }
    }
}
