package jp.supership.vamp;

import android.app.Activity;
import android.os.Handler;
import android.os.Looper;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.VisibleForTesting;

import jp.supership.vamp.core.logging.LogUtils;

import java.util.concurrent.ConcurrentHashMap;

public class VAMPAppOpenAd {
    @NonNull
    private static final ConcurrentHashMap<String, VAMPAppOpenAd> appOpenAdMap =
            new ConcurrentHashMap<>();

    @NonNull private final AppOpenMediationManager manager;

    /** アプリ開発者に実行スレッドを意識して実装させるのは酷なので、 listenerメソッドは必ずMainスレッドで実行します */
    @NonNull private final Handler handler = new Handler(Looper.getMainLooper());

    @Nullable private AppOpenMediationManager.Listener listener;
    @Nullable private VAMPAppOpenAdListener showListener;

    /**
     * 指定した広告枠IDの広告を取得します。
     *
     * @param activity アクティビティ
     * @param placementId 広告枠ID
     * @param request VAMPRequestオブジェクト
     * @param listener {@link VAMPAppOpenAdLoadListener}
     */
    public static void load(
            @NonNull final Activity activity,
            @NonNull final String placementId,
            @NonNull final VAMPRequest request,
            @Nullable final VAMPAppOpenAdLoadListener listener) {

        VAMPAppOpenAd theAppOpenAd = appOpenAdMap.get(placementId);
        if (theAppOpenAd != null && theAppOpenAd.manager.state.isLoading()) {
            // ロード中の場合はスキップ
            LogUtils.d(String.format("VAMPAppOpenAd(%s) is already loading.", placementId));
            return;
        } else if (theAppOpenAd != null
                && (theAppOpenAd.manager.state.isBeginPlayback()
                        || theAppOpenAd.manager.state.isShowing())) {
            // 表示中の場合もスキップ
            LogUtils.d(
                    String.format(
                            "VAMPAppOpenAd(%s) is showing now. Not permitted to load while showing"
                                    + " the ad.",
                            placementId));
            return;
        }

        if (theAppOpenAd != null && theAppOpenAd.manager.isReady()) {
            LogUtils.d(
                    String.format(
                            "VAMPAppOpenAd(%s) is already ready. Reusing existing ad.",
                            placementId));
            theAppOpenAd.listener = theAppOpenAd.newInternalListener(listener, placementId);
            theAppOpenAd.notifyLoadSucceeded(listener, placementId);
            return;
        }

        if (theAppOpenAd != null) {
            // ロード済みの場合は破棄(タイマーの解放を含む)。managerを破棄することで、このインスタンスは実質的に無効化される
            LogUtils.w(
                    String.format(
                            "VAMPAppOpenAd(%s) is not ready. Discarding existing ad and"
                                    + " loading a new one.",
                            placementId));
            theAppOpenAd.manager.destroyManager();
            theAppOpenAd.listener = null;
            appOpenAdMap.remove(placementId);
        }

        final VAMPAppOpenAd appOpenAd = new VAMPAppOpenAd(activity, placementId);
        appOpenAd.showListener = null;
        appOpenAd.listener = appOpenAd.newInternalListener(listener, placementId);

        appOpenAdMap.put(placementId, appOpenAd);

        try {
            appOpenAd.manager.load(request);
        } catch (MediationState.NotChangedException e) {
            LogUtils.d(e.getMessage());
        }
    }

    /**
     * 指定した広告枠IDの広告を表示する準備が完了している場合、 {@link VAMPAppOpenAd}オブジェクトを返します。 それ以外の場合はnullを返します。
     *
     * @param placementId 広告枠ID
     * @return {@link VAMPAppOpenAd}オブジェクト
     */
    @Nullable
    public static VAMPAppOpenAd of(@NonNull final String placementId) {
        // appOpenAdオブジェクトはshowメソッドを実行するためのオブジェクトという位置づけのため、
        // ロードが完了していないならば、appOpenAdオブジェクトが存在する意味はないので、nullを返す
        VAMPAppOpenAd appOpenAd = appOpenAdMap.get(placementId);
        if (appOpenAd != null && appOpenAd.manager.state.isLoaded()) {
            return appOpenAd;
        } else {
            return null;
        }
    }

    /**
     * 指定した広告枠IDのレスポンス情報を取得します。
     *
     * @param placementId 広告枠ID
     * @return {@link VAMPResponseInfo}オブジェクト
     */
    @Nullable
    public static VAMPResponseInfo getResponseInfo(@NonNull final String placementId) {
        VAMPAppOpenAd appOpenAd = appOpenAdMap.get(placementId);
        if (appOpenAd == null) {
            return null;
        }

        return appOpenAd.manager.getResponseInfo();
    }

    @VisibleForTesting
    static void removeAllInstances() {
        appOpenAdMap.clear();
    }

    /**
     * VAMPAppOpenAdオブジェクトを初期化します。
     *
     * @param activity アクティビティ
     * @param placementID 広告枠ID
     */
    private VAMPAppOpenAd(@NonNull final Activity activity, @NonNull final String placementID) {
        manager =
                AppOpenMediationManagerDependency.getResolver()
                        .newInstance(
                                activity,
                                placementID,
                                new AppOpenMediationManager.Listener() {
                                    @Override
                                    public void onReceived() {
                                        handler.post(
                                                () -> {
                                                    if (listener != null) {
                                                        listener.onReceived();
                                                    }
                                                });
                                    }

                                    @Override
                                    public void onFailedToLoad(@NonNull final VAMPError error) {
                                        handler.post(
                                                () -> {
                                                    if (listener != null) {
                                                        listener.onFailedToLoad(error);
                                                    }
                                                });
                                    }

                                    @Override
                                    public void onOpened() {
                                        handler.post(
                                                () -> {
                                                    if (listener != null) {
                                                        listener.onOpened();
                                                    }
                                                });
                                    }

                                    @Override
                                    public void onFailedToShow(@NonNull final VAMPError error) {
                                        handler.post(
                                                () -> {
                                                    if (listener != null) {
                                                        listener.onFailedToShow(error);
                                                    }
                                                });
                                    }

                                    @Override
                                    public void onCompleted() {
                                        handler.post(
                                                () -> {
                                                    if (listener != null) {
                                                        listener.onCompleted();
                                                    }
                                                });
                                    }

                                    @Override
                                    public void onClosed(final boolean adClicked) {
                                        handler.post(
                                                () -> {
                                                    if (listener != null) {
                                                        listener.onClosed(adClicked);
                                                    }
                                                });
                                    }
                                });
    }

    private void notifyLoadSucceeded(
            @Nullable final VAMPAppOpenAdLoadListener listener,
            @NonNull final String placementId) {
        handler.post(
                () -> {
                    if (listener != null) {
                        listener.onReceived(placementId);
                    }
                });
    }

    @NonNull
    private AppOpenMediationManager.Listener newInternalListener(
            @Nullable final VAMPAppOpenAdLoadListener loadListener,
            @NonNull final String placementId) {
        return new AppOpenMediationManager.Listener() {
            @Override
            public void onReceived() {
                // ロード成功のためappOpenAdオブジェクトを維持
                if (loadListener != null) {
                    loadListener.onReceived(placementId);
                }

                LogUtils.d(String.format("VAMPAppOpenAd(%s) received the ad.", placementId));
            }

            @Override
            public void onFailedToShow(@NonNull VAMPError error) {
                if (showListener != null) {
                    showListener.onFailedToShow(placementId, error);
                    showListener = null;
                }

                LogUtils.d(
                        String.format(
                                "VAMPAppOpenAd(%s) failed to show because an error: %s occurred.",
                                placementId, error));
            }

            @Override
            public void onFailedToLoad(@NonNull VAMPError error) {
                // ロード失敗のためappOpenAdオブジェクトを維持しない
                appOpenAdMap.remove(placementId);

                if (loadListener != null) {
                    loadListener.onFailedToLoad(placementId, error);
                }

                LogUtils.d(
                        String.format(
                                "VAMPAppOpenAd(%s) failed to load because an error: %s occurred.",
                                placementId, error));
            }

            @Override
            public void onOpened() {
                if (showListener != null) {
                    showListener.onOpened(placementId);
                }

                LogUtils.d(String.format("VAMPAppOpenAd(%s) opened the ad.", placementId));
            }

            @Override
            public void onCompleted() {
                // AppOpenAdでは通知しない
            }

            @Override
            public void onClosed(boolean adClicked) {
                appOpenAdMap.remove(placementId);

                if (showListener != null) {
                    showListener.onClosed(placementId, adClicked);
                    showListener = null;
                }

                LogUtils.d(String.format("VAMPAppOpenAd(%s) closed the ad.", placementId));
            }
        };
    }

    /**
     * 広告を表示します。
     *
     * <p>※動画が再生されます。
     *
     * <p>show実行時には、{@link VAMPAppOpenAdListener#onClosed}を受け取るまでは load を実行しないでください。
     *
     * @param activity アクティビティ
     */
    public void show(@NonNull final Activity activity, @Nullable VAMPAppOpenAdListener listener) {
        this.showListener = listener;
        manager.show(activity);
    }
}
