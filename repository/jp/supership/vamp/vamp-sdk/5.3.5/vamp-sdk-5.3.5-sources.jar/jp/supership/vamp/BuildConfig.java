/**
 * Automatically generated file. DO NOT MODIFY
 */
package jp.supership.vamp;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "jp.supership.vamp";
  public static final String BUILD_TYPE = "release";
  // Field from default config.
  public static final boolean DEV_LOG = false;
  // Field from default config.
  public static final boolean DEV_SERVER = false;
  // Field from default config.
  public static final String SDKVERSION = "v5.3.5";
}
