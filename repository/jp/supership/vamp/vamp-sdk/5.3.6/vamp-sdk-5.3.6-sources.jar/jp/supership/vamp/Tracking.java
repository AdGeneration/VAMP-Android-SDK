package jp.supership.vamp;

import android.text.TextUtils;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.VisibleForTesting;

import jp.supership.sscore.vamp.http.SSCoreHttpClient;
import jp.supership.sscore.vamp.http.SSCoreHttpException;
import jp.supership.sscore.vamp.http.SSCoreHttpRequest;
import jp.supership.sscore.vamp.type.Optional;
import jp.supership.sscore.vamp.type.Result;
import jp.supership.vamp.core.logging.LogUtils;

import java.net.MalformedURLException;
import java.net.URL;

final class Tracking {
    /** インスタンスを生成できません。詳細はmessageを参照してください */
    static final class CanNotInstantiateException extends Exception {
        CanNotInstantiateException(@NonNull String message) {
            super(message);
        }
    }

    static final String EVENT_IMPRESSION = "impression";
    static final String EVENT_START = "start";
    static final String EVENT_COMPLETE = "complete";
    static final String EVENT_BEACON = "beacon";
    static final String EVENT_VIEW = "view";

    @NonNull private final String event;
    @NonNull private final String urlString;
    @NonNull private final SSCoreHttpClient httpClient;
    private boolean done;

    @VisibleForTesting
    Tracking(
            @NonNull final String event,
            @NonNull final String urlString,
            @NonNull final SSCoreHttpClient httpClient)
            throws CanNotInstantiateException {
        if (TextUtils.isEmpty(event)) {
            throw new CanNotInstantiateException("Tracking: event is empty.");
        }
        this.event = event;

        if (TextUtils.isEmpty(urlString)) {
            throw new CanNotInstantiateException("Tracking(" + event + "): urlString is empty.");
        }

        URL url;
        try {
            url = new URL(urlString);
        } catch (MalformedURLException e) {
            throw new CanNotInstantiateException("Tracking(" + event + "): " + e);
        }

        final String protocol = url.getProtocol();
        if (!protocol.equals("http") && !protocol.equals("https")) {
            throw new CanNotInstantiateException(
                    "Tracking(" + event + "): protocol is not http(s).");
        }

        this.urlString = urlString;
        this.httpClient = httpClient;
    }

    @NonNull
    static Optional<Tracking> impression(
            @NonNull final String urlString, @NonNull final SSCoreHttpClient httpClient) {
        try {
            return Optional.of(new Tracking(EVENT_IMPRESSION, urlString, httpClient));
        } catch (CanNotInstantiateException e) {
            LogUtils.d(e.getMessage());
            return Optional.empty();
        }
    }

    @NonNull
    static Optional<Tracking> start(
            @NonNull final String urlString, @NonNull final SSCoreHttpClient httpClient) {
        try {
            return Optional.of(new Tracking(EVENT_START, urlString, httpClient));
        } catch (CanNotInstantiateException e) {
            LogUtils.d(e.getMessage());
            return Optional.empty();
        }
    }

    @NonNull
    static Optional<Tracking> complete(
            @NonNull final String urlString, @NonNull final SSCoreHttpClient httpClient) {
        try {
            return Optional.of(new Tracking(EVENT_COMPLETE, urlString, httpClient));
        } catch (CanNotInstantiateException e) {
            LogUtils.d(e.getMessage());
            return Optional.empty();
        }
    }

    @NonNull
    static Optional<Tracking> beacon(
            @NonNull final String urlString, @NonNull final SSCoreHttpClient httpClient) {
        try {
            return Optional.of(new Tracking(EVENT_BEACON, urlString, httpClient));
        } catch (CanNotInstantiateException e) {
            LogUtils.d(e.getMessage());
            return Optional.empty();
        }
    }

    @NonNull
    static Optional<Tracking> view(
            @NonNull final String urlString, @NonNull final SSCoreHttpClient httpClient) {
        try {
            return Optional.of(new Tracking(EVENT_VIEW, urlString, httpClient));
        } catch (CanNotInstantiateException e) {
            LogUtils.d(e.getMessage());
            return Optional.empty();
        }
    }

    void send() {
        send(
                result -> {
                    if (result.isSuccess()) {
                        LogUtils.d(event + " beacon succeeded.");
                    } else {
                        final String errorMessage =
                                result.error.map(Throwable::getMessage).orElse("Unknown error");
                        LogUtils.d(event + " beacon failed. error: " + errorMessage);
                    }
                });
    }

    private void send(@Nullable SSCoreHttpClient.OnRequestCompleteListener listener) {
        if (done) {
            LogUtils.d("Tracking(" + event + "): already done.");
            return;
        }

        done = true;

        SSCoreHttpRequest httpRequest;
        try {
            httpRequest =
                    new SSCoreHttpRequest.Builder(urlString)
                            .withMethod(SSCoreHttpRequest.Method.GET)
                            .build();
        } catch (MalformedURLException | SSCoreHttpRequest.InvalidRequestParameterException e) {
            if (listener != null) {
                listener.onRequestCompleted(
                        Result.failure(SSCoreHttpException.invalidRequestParameter(e)));
            }
            return;
        }

        httpClient.request(httpRequest, listener);
    }

    @VisibleForTesting
    boolean isDone() {
        return done;
    }
}
