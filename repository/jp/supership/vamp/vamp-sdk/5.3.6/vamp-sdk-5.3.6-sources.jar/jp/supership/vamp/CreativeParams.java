package jp.supership.vamp;

import android.text.TextUtils;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import jp.supership.sscore.vamp.http.SSCoreHttp;
import jp.supership.sscore.vamp.type.Optional;
import jp.supership.vamp.utils.JsonUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

final class CreativeParams {
    /** インスタンスを生成できません。詳細はmessageを参照してください */
    static class CanNotInstantiateException extends Exception {
        CanNotInstantiateException(String message) {
            super(message);
        }
    }

    private static final String CREATIVE_PARAMS_KEY_MEDIATION = "mediation";
    private static final String CREATIVE_PARAMS_KEY_ACTUAL_LP = "actual_landing_page";
    private static final String CREATIVE_PARAMS_KEY_BIDDER_PARAMS = "bidder_params";
    private static final String CREATIVE_PARAMS_KEY_VIEWABILITY = "viewability";
    private static final String CREATIVE_PARAMS_KEY_TRACKERS = "trackers";
    private static final String CREATIVE_PARAMS_KEY_NOTIFICATIONS = "notifications";
    private static final String CREATIVE_PARAMS_KEY_NOTIFICATIONS_BEACON = "beacon";
    private static final String CREATIVE_PARAMS_KEY_NOTIFICATIONS_VIEW = "view";

    // mediationの中身
    private static final String MEDIATION_KEY_AD_ID = "adid";
    private static final String MEDIATION_KEY_CLASS = "class";
    private static final String MEDIATION_KEY_PARAM = "param";
    private static final String MEDIATION_KEY_TYPE = "type";

    // paramの中身
    private static final String MEDIATION_KEY_CLASS_NAME = "className";

    /** mediation.classの値は"jp.supership.vamp.mediation.VAMPMediation"で固定です */
    private static final String CLASS_CONST_VALUE = "jp.supership.vamp.mediation.VAMPMediation";

    private static final String VAST_MEDIATION_CLASS_NAME =
            "jp.supership.vamp.mediation.adnw.VASTMediation";

    /** mediation.adid */
    final Optional<String> mediationAdId;

    /**
     * mediation.class
     *
     * <p>未使用
     */
    @Deprecated final Optional<String> mediationClass;

    /** mediation.param.className */
    @NonNull final String mediationClassName;

    /** mediation.param */
    private final Optional<String> mediationParamJson;

    /** mediation.type */
    final Optional<Integer> mediationType;

    final Optional<String> actualLandingPage;
    private final Optional<String> bidderParamsJson;
    private final Optional<String> viewabilityParamsJson;
    final ArrayList<Tracking> beaconNotifications = new ArrayList<>();
    @Deprecated final ArrayList<Tracking> viewNotifications = new ArrayList<>();

    /**
     * アドネットワークメディエーションパラメータからインスタンスを生成します。 アドネットワークメディエーションが無くVAST XMLがある(hasVastXml=true)場合は、
     * VASTアダプタが利用できるように設定されます。 例外が発生したときはインスタンス化しません
     *
     * <p>``` { "mediation": { "adid": String, "class": "jp.supership.vamp.mediation.VAMPMediation",
     * "param": { "className": String, ... }, "type": 1 } } ```
     *
     * @param jsonObject レスポンスデータ
     * @param hasVastXml レスポンスにVAST XMLが含まれているか
     */
    CreativeParams(@Nullable final JSONObject jsonObject, boolean hasVastXml)
            throws CanNotInstantiateException {
        JSONObject jsonObj;
        if (jsonObject != null) {
            jsonObj = jsonObject;
        } else {
            jsonObj = new JSONObject();
        }

        String mediationAdId = null;
        String mediationClass = null;
        String mediationClassName = null;
        String mediationParamJson = null;
        int mediationType = -1;

        JSONObject mediation = jsonObj.optJSONObject(CREATIVE_PARAMS_KEY_MEDIATION);
        if (mediation != null) {
            mediationAdId = mediation.optString(MEDIATION_KEY_AD_ID);
            mediationClass = mediation.optString(MEDIATION_KEY_CLASS);
            mediationParamJson = mediation.optString(MEDIATION_KEY_PARAM);
            mediationType = mediation.optInt(MEDIATION_KEY_TYPE);
            if (!isBitON(mediationType)) {
                throw new CanNotInstantiateException(
                        "The creativeParams isn't the mediation type.");
            }

            // classNameだけチェック用に先取り
            JSONObject param = mediation.optJSONObject(MEDIATION_KEY_PARAM);
            if (param != null) {
                mediationClassName = param.optString(MEDIATION_KEY_CLASS_NAME);
            }
        }

        // アドネットワークメディエーションが無くVAST XMLがレスポンスに含まれている場合は
        // VASTアダプタを利用できるように設定する
        if (hasVastXml && TextUtils.isEmpty(mediationClassName)) {
            mediationClass = CLASS_CONST_VALUE;
            mediationClassName = VAST_MEDIATION_CLASS_NAME;
        }

        if (TextUtils.isEmpty(mediationClassName)) {
            throw new CanNotInstantiateException("mediation.param.className not found.");
        }

        this.mediationAdId = Optional.of(mediationAdId);
        this.mediationClass = Optional.of(mediationClass);
        assert mediationClassName != null;
        this.mediationClassName = mediationClassName;
        this.mediationParamJson = Optional.of(mediationParamJson);
        this.mediationType = Optional.of(mediationType);

        actualLandingPage = Optional.of(jsonObj.optString(CREATIVE_PARAMS_KEY_ACTUAL_LP));
        bidderParamsJson = Optional.of(jsonObj.optString(CREATIVE_PARAMS_KEY_BIDDER_PARAMS));
        viewabilityParamsJson = Optional.of(jsonObj.optString(CREATIVE_PARAMS_KEY_VIEWABILITY));

        JSONObject notificationsJson = jsonObj.optJSONObject(CREATIVE_PARAMS_KEY_NOTIFICATIONS);
        if (notificationsJson != null) {
            JSONArray beaconArray =
                    notificationsJson.optJSONArray(CREATIVE_PARAMS_KEY_NOTIFICATIONS_BEACON);
            if (beaconArray != null) {
                for (int i = 0; i < beaconArray.length(); ++i) {
                    final String urlString = beaconArray.optString(i);
                    try {
                        // TODO: httpClientをコンストラクタインジェクション
                        beaconNotifications.add(
                                Tracking.beacon(urlString, SSCoreHttp.newClient()).unwrap());
                    } catch (Optional.NotPresentException ignored) {
                    }
                }
            }

            JSONArray viewArray =
                    notificationsJson.optJSONArray(CREATIVE_PARAMS_KEY_NOTIFICATIONS_VIEW);
            if (viewArray != null) {
                for (int i = 0; i < viewArray.length(); ++i) {
                    final String urlString = viewArray.optString(i);
                    try {
                        // TODO: httpClientをコンストラクタインジェクション
                        viewNotifications.add(
                                Tracking.view(urlString, SSCoreHttp.newClient()).unwrap());
                    } catch (Optional.NotPresentException ignored) {
                    }
                }
            }
        }
    }

    /**
     * @return VASTメディエーションならばtrue、それ以外はfalse
     */
    boolean isVastMediation() {
        return VAST_MEDIATION_CLASS_NAME.equals(mediationClassName);
    }

    @NonNull
    JSONObject getMediationParams() {
        return JsonUtils.fromJson(mediationParamJson.maybe());
    }

    @NonNull
    JSONObject getBidderParams() {
        return JsonUtils.fromJson(bidderParamsJson.maybe());
    }

    @NonNull
    JSONObject getViewabilityParams() {
        return JsonUtils.fromJson(viewabilityParamsJson.maybe());
    }

    private static boolean isBitON(int num) {
        return (num & 0x00000001) == 1;
    }
}
