package jp.supership.vamp;

import android.text.TextUtils;

import androidx.annotation.Nullable;
import androidx.annotation.VisibleForTesting;

import jp.supership.vamp.core.logging.LogUtils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

final class Response {
    /** インスタンスを生成できません。詳細はmessageを参照してください */
    static class CanNotInstantiateException extends Exception {
        CanNotInstantiateException(String message) {
            super(message);
        }
    }

    /** 配信可能な広告レスポンスが1件もありません */
    static class NoAdException extends Exception {}

    private static final String KEY_LOCATION_ID = "locationid";
    private static final String KEY_RESULTS = "results";

    /** 配信可能な広告レスポンスのリスト */
    final ArrayList<AdResponse> results = new ArrayList<>();

    /**
     * JSON文字列をパースしてインスタンスを生成します。 例外が発生したときはインスタンス化しません
     *
     * <p>``` { "locationid": String, "results": String(AdResponse[]) } ```
     */
    static Response newInstance(@Nullable String jsonString)
            throws CanNotInstantiateException, NoAdException {
        if (TextUtils.isEmpty(jsonString)) {
            throw new CanNotInstantiateException("Given jsonString is null or empty.");
        }

        try {
            return newInstance(new JSONObject(jsonString));
        } catch (JSONException e) {
            throw new CanNotInstantiateException("JSONException occurred. " + e);
        }
    }

    static Response newInstance(@Nullable JSONObject obj)
            throws CanNotInstantiateException, NoAdException {
        return new Response(obj);
    }

    @VisibleForTesting
    Response(@Nullable JSONObject obj) throws CanNotInstantiateException, NoAdException {
        if (obj == null) {
            throw new CanNotInstantiateException("Given jsonObject is null.");
        }

        String placementId = obj.optString(KEY_LOCATION_ID);
        if (TextUtils.isEmpty(placementId)) {
            throw new CanNotInstantiateException(
                    "The locationid's value in the response is null or empty.");
        }

        try {
            JSONArray arr = new JSONArray(obj.getString(KEY_RESULTS));

            for (int i = 0, len = arr.length(); i < len; i++) {
                try {
                    AdResponse adResponse = new AdResponse(placementId, arr.getJSONObject(i));
                    results.add(adResponse);
                } catch (AdResponse.CanNotInstantiateException e) {
                    LogUtils.devLog(e.getMessage());
                }
            }
        } catch (JSONException e) {
            throw new CanNotInstantiateException("JSONException occurred. " + e);
        }

        if (results.size() <= 0) {
            throw new NoAdException();
        }
    }
}
