package jp.supership.vamp;

import androidx.annotation.NonNull;

public interface VAMPAppOpenAdListener {
    /**
     * 広告の表示に失敗すると通知されます。<br>
     *
     * <p>例) 視聴完了する前にユーザがキャンセルするなど。
     *
     * @param placementId 広告枠ID
     * @param error {@link VAMPError}
     */
    void onFailedToShow(@NonNull String placementId, @NonNull VAMPError error);

    /**
     * 広告の表示が開始されると通知されます。
     *
     * @param placementId 広告枠ID
     */
    void onOpened(@NonNull String placementId);

    /**
     * 広告が閉じられると通知されます。<br>
     *
     * @param placementId 広告枠ID
     * @param adClicked 広告がクリックされたかどうか
     */
    void onClosed(@NonNull String placementId, boolean adClicked);
}
