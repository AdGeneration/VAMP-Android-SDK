package jp.supership.vamp;

import android.app.Activity;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import jp.supership.sscore.vamp.http.SSCoreHttp;
import jp.supership.sscore.vamp.http.SSCoreHttpClient;
import jp.supership.sscore.vamp.timer.SSCoreScheduledTimer;
import jp.supership.sscore.vamp.timer.SSCoreTimerSchedulable;
import jp.supership.sscore.vamp.type.Optional;
import jp.supership.vamp.core.logging.LogUtils;
import jp.supership.vamp.mediation.AdNetworkErrorInfo;
import jp.supership.vamp.mediation.Adapter;
import jp.supership.vamp.mediation.AdapterConfiguration;
import jp.supership.vamp.mediation.AdapterEventListener;
import jp.supership.vamp.mediation.Event;
import jp.supership.vamp.player.VAMPCreativeInfo;
import jp.supership.vamp.utils.JsonUtils;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.lang.ref.WeakReference;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.TimerTask;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Created by masaki.ando on 2018/04/02. */
public final class Mediation {
    public interface Listener {
        void onLoadSuccess(@NonNull Mediation ad);

        void onVideoStart(@NonNull Mediation ad);

        void onVideoComplete(@NonNull Mediation ad);

        void onFailed(@NonNull Mediation ad, @NonNull VAMPError error);

        void onAdClosed(@NonNull Mediation ad, boolean adClicked);

        void sendLogEvent(@NonNull Mediation ad, @Nullable AdNetworkErrorInfo errorInfo);
    }

    public static class BuildErrorException extends Exception {
        BuildErrorException(String message) {
            super(message);
        }
    }

    public static class Builder {
        @Nullable private Listener listener;
        @NonNull private MediationTimeout mediationTimeout = MediationTimeout.newDefault();
        @Nullable private SSCoreHttpClient impressionBeaconHttpClient;
        @Nullable private SSCoreHttpClient startBeaconHttpClient;
        @Nullable private SSCoreHttpClient completeBeaconHttpClient;

        public Builder() {}

        @NonNull
        public Builder withMediationTimeout(@NonNull final MediationTimeout timeout) {
            this.mediationTimeout = timeout;
            return this;
        }

        @NonNull
        public Builder withListener(@Nullable final Listener listener) {
            this.listener = listener;
            return this;
        }

        @NonNull
        public Builder withImpressionBeaconHttpClient(@Nullable final SSCoreHttpClient client) {
            this.impressionBeaconHttpClient = client;
            return this;
        }

        @NonNull
        public Builder withStartBeaconHttpClient(@Nullable final SSCoreHttpClient client) {
            this.startBeaconHttpClient = client;
            return this;
        }

        @NonNull
        public Builder withCompleteBeaconHttpClient(@Nullable final SSCoreHttpClient client) {
            this.completeBeaconHttpClient = client;
            return this;
        }

        /**
         * @return Mediation
         * @throws BuildErrorException 引数不正や呼び出しクラスが見つからない場合、 またアドネットワークSDKがサポートしないAPI
         *     levelの場合に発生します
         */
        @NonNull
        public Mediation build(
                @NonNull final Context applicationContext,
                @Nullable final Activity activity,
                @Nullable final AdResponse adResponse,
                @Nullable final VAMPRequest request)
                throws BuildErrorException {
            if (adResponse == null) {
                throw new BuildErrorException("adResponse is null.");
            }
            if (request == null) {
                throw new BuildErrorException("request is null.");
            }

            final String adNetworkName;
            if (adResponse.isVastAd()) {
                adNetworkName = AdNetworkNames.VAMP_ADNETWORK_NAME_VAMP;
            } else {
                String className = adResponse.creativeParams.mediationClassName;
                adNetworkName = AdNetworkNames.getAdNetworkName(className);
                if (TextUtils.isEmpty(adNetworkName)) {
                    throw new BuildErrorException(
                            "adNetworkName for " + className + " could not be resolved.");
                }
            }

            final Adapter adapter;
            try {
                adapter = GlobalAdapterProvider.getProvider().getAdapter(adNetworkName);
                Objects.requireNonNull(adapter);
            } catch (Exception e) {
                throw new BuildErrorException(e.getMessage());
            }

            if (!adapter.isSupported()) {
                throw new BuildErrorException(
                        adNetworkName + " does not support current API level.");
            }

            final Map<String, String> mediationParams = new HashMap<>();
            try {
                JSONObject mediationParamJson = adResponse.creativeParams.getMediationParams();
                Map<String, Object> map = JsonUtils.toMap(mediationParamJson);
                for (Map.Entry<String, Object> entry : map.entrySet()) {
                    if (entry.getValue() instanceof String) {
                        mediationParams.put(entry.getKey(), (String) entry.getValue());
                    }
                }
            } catch (JSONException e) {
                throw new BuildErrorException("mediationParams occurred JSONException.");
            }

            final Map<String, String> adParams = new HashMap<>();
            try {
                Map<String, Object> map = JsonUtils.toMap(adResponse.adParams);
                for (Map.Entry<String, Object> entry : map.entrySet()) {
                    if (entry.getValue() instanceof String) {
                        adParams.put(entry.getKey(), (String) entry.getValue());
                    }
                }
            } catch (JSONException e) {
                throw new BuildErrorException("adParams occurred JSONException.");
            }

            final Map<String, String> bidderParams = new HashMap<>();
            try {
                Map<String, Object> map =
                        JsonUtils.toMap(adResponse.creativeParams.getBidderParams());
                for (Map.Entry<String, Object> entry : map.entrySet()) {
                    if (entry.getValue() instanceof String) {
                        bidderParams.put(entry.getKey(), (String) entry.getValue());
                    }
                }
            } catch (JSONException e) {
                throw new BuildErrorException("bidderParams occurred JSONException.");
            }

            final String adId =
                    adResponse.isVastAd()
                            ? adResponse.placementId
                            : adResponse.creativeParams.mediationAdId.orElse("");

            final AdapterConfiguration.Builder configBuilder =
                    new AdapterConfiguration.Builder(adId, mediationParams);

            if (adResponse.isVastAd()) {
                configBuilder.withVastXml(adResponse.vastxml);
            }

            // landingPageが不正な値でも処理を続行する
            try {
                String actualLP = adResponse.creativeParams.actualLandingPage.unwrap();
                if (!TextUtils.isEmpty(actualLP)) {
                    configBuilder.withLandingUrl(new URL(actualLP));
                }
            } catch (Optional.NotPresentException | MalformedURLException e) {
                LogUtils.d("actualLandingPage is invalid: " + e);
            }

            final AdapterConfiguration config =
                    configBuilder
                            .withPlacementId(adResponse.placementId)
                            .withAdParams(adParams)
                            .withBidderParams(bidderParams)
                            .build();

            final Context context;
            try {
                context = getContextForAdapter(adNetworkName, applicationContext, activity);
            } catch (Exception e) {
                throw new BuildErrorException(e.getMessage());
            }

            final AdapterResponseInfo responseInfo =
                    new AdapterResponseInfo.Builder()
                            .withAdId(adId)
                            .withAdNetworkName(adNetworkName)
                            .withClassName(adapter.getClass().getName())
                            .withCreativeId(adResponse.crid)
                            .withDspId(adResponse.dspId)
                            .withAdNetworkId(adResponse.adnwId)
                            .withSeat(adResponse.seat)
                            .build();

            final Optional<Tracking> impressionBeacon;
            if (isDefinedInVASTXml(Tracking.EVENT_IMPRESSION, adResponse)) {
                impressionBeacon = Optional.empty();
            } else {
                impressionBeacon =
                        Tracking.impression(
                                adResponse.getBeaconUrl(),
                                impressionBeaconHttpClient != null
                                        ? impressionBeaconHttpClient
                                        : SSCoreHttp.newClient());
            }

            final Optional<Tracking> startBeacon;
            if (isDefinedInVASTXml(Tracking.EVENT_START, adResponse)) {
                startBeacon = Optional.empty();
            } else {
                startBeacon =
                        Tracking.start(
                                adResponse.start,
                                startBeaconHttpClient != null
                                        ? startBeaconHttpClient
                                        : SSCoreHttp.newClient());
            }

            final Optional<Tracking> completeBeacon;
            if (isDefinedInVASTXml(Tracking.EVENT_COMPLETE, adResponse)) {
                completeBeacon = Optional.empty();
            } else {
                completeBeacon =
                        Tracking.complete(
                                adResponse.complete,
                                completeBeaconHttpClient != null
                                        ? completeBeaconHttpClient
                                        : SSCoreHttp.newClient());
            }

            if (adapter instanceof VASTAdapter) {
                VASTAdapter vastAdapter = (VASTAdapter) adapter;
                VAMPCreativeInfo creativeInfo =
                        new VAMPCreativeInfo(
                                adResponse.crid,
                                adResponse.adnwId,
                                adResponse.dspId,
                                adResponse.seat);

                vastAdapter.setCreativeInfo(creativeInfo);
            }

            return new Mediation(
                    context,
                    adapter,
                    config,
                    mediationTimeout,
                    responseInfo,
                    listener,
                    adResponse.creativeParams.beaconNotifications,
                    impressionBeacon,
                    startBeacon,
                    completeBeacon);
        }

        private static boolean isDefinedInVASTXml(String event, @NonNull AdResponse adResponse) {
            final String vastXML = adResponse.vastxml;
            if (TextUtils.isEmpty(vastXML)) {
                return false;
            }

            String urlString = "";
            switch (event) {
                case Tracking.EVENT_IMPRESSION:
                    urlString = adResponse.getBeaconUrl();
                    break;
                case Tracking.EVENT_START:
                    urlString = adResponse.start;
                    break;
                case Tracking.EVENT_COMPLETE:
                    urlString = adResponse.complete;
                    break;
            }

            if (TextUtils.isEmpty(urlString)) {
                return false;
            }

            String beacon = urlString.replace("&amp", "&");
            try {
                beacon = URLEncoder.encode(beacon, "utf-8");
            } catch (UnsupportedEncodingException e) {
                LogUtils.e(e.getMessage());
                return false;
            }

            Pattern pattern;
            if (event.equals(Tracking.EVENT_IMPRESSION)) {
                pattern =
                        Pattern.compile(String.format("<Impression>.*(%s).*</Impression>", beacon));
            } else if (event.equals(Tracking.EVENT_START)
                    || event.equals(Tracking.EVENT_COMPLETE)) {
                pattern =
                        Pattern.compile(
                                String.format(
                                        "<Tracking\\s*event=\"%s\">.*(%s).*</Tracking>",
                                        event, beacon));
            } else {
                LogUtils.devLog(event + " event not supported.");
                return false;
            }

            Matcher matcher = pattern.matcher(vastXML);
            return matcher.find();
        }
    }

    @NonNull private final Adapter adapter;
    @NonNull private final AdapterConfiguration config;
    @NonNull private final MediationTimeout mediationTimeout;
    @NonNull private final AdapterResponseInfo responseInfo;
    @Nullable private final Listener listener;

    /** creative_params.notifications.beacon */
    @NonNull private final ArrayList<Tracking> beaconNotifications;

    @NonNull private final Optional<Tracking> impressionBeacon;
    @NonNull private final Optional<Tracking> startBeacon;
    @NonNull private final Optional<Tracking> completeBeacon;
    @NonNull private final SSCoreTimerSchedulable mediationTimer = new SSCoreScheduledTimer();
    private boolean adClicked = false;

    private Mediation(
            @NonNull final Context context,
            @NonNull final Adapter adapter,
            @NonNull final AdapterConfiguration config,
            @NonNull final MediationTimeout mediationTimeout,
            @NonNull final AdapterResponseInfo responseInfo,
            @Nullable final Listener listener,
            @NonNull final ArrayList<Tracking> beaconNotifications,
            @NonNull final Optional<Tracking> impressionBeacon,
            @NonNull final Optional<Tracking> startBeacon,
            @NonNull final Optional<Tracking> completeBeacon)
            throws BuildErrorException {
        this.adapter = adapter;
        this.config = config;
        this.mediationTimeout = mediationTimeout;
        this.responseInfo = responseInfo;
        this.listener = listener;
        this.beaconNotifications = beaconNotifications;
        this.impressionBeacon = impressionBeacon;
        this.startBeacon = startBeacon;
        this.completeBeacon = completeBeacon;

        // アダプタのセットアップ
        final boolean success =
                adapter.prepare(
                        context,
                        config,
                        new AdapterEventListener() {
                            @Override
                            public void onEvent(@NonNull Event event) {
                                vampEvent(event);
                            }
                        });
        if (!success) {
            throw new BuildErrorException("Failed to prepare " + adapter.getClass().getName());
        }
    }

    public void load(@NonNull final Context applicationContext, @Nullable final Activity activity) {
        setMediationTimer();

        responseInfo.startLoading();

        if (isReady()) {
            LogUtils.d(formatLog("Already loaded."));
            vampEvent(new Event(Event.EVENT_LOAD_SUCCESS));
            return;
        }

        try {
            adapter.load(getContextForAdapter(getAdNetworkName(), applicationContext, activity));
        } catch (Exception e) {
            vampEvent(
                    new Event(
                            Event.EVENT_FAIL,
                            new AdNetworkErrorInfo.Builder("load", VAMPError.ADNETWORK_ERROR)
                                    .build()));
        }
    }

    public boolean isReady() {
        try {
            final boolean isReady = adapter.isReady();
            LogUtils.devLog(formatLog("isReady=" + isReady));
            return isReady;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * 広告の表示を開始します
     *
     * @param activity このActivityインスタンスを使って、広告ActivityがstartActivityされます
     */
    public void show(@NonNull final Activity activity) {
        if (!adapter.isReady()) {
            vampEvent(
                    new Event(
                            Event.EVENT_FAIL,
                            new AdNetworkErrorInfo.Builder("show", VAMPError.NOT_LOADED_AD)
                                    .build()));
            return;
        }

        sendImpressionBeacon();

        try {
            adapter.show(activity);
        } catch (Exception e) {
            vampEvent(
                    new Event(
                            Event.EVENT_FAIL,
                            new AdNetworkErrorInfo.Builder("show", VAMPError.ADNETWORK_ERROR)
                                    .build()));
        }
    }

    public void destroy() {
        LogUtils.devLog(formatLog("destroy"));

        clearMediationTimer();

        try {
            adapter.destroy();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @NonNull
    AdapterResponseInfo getResponseInfo() {
        return responseInfo;
    }

    public boolean isVastAd() {
        return !TextUtils.isEmpty(config.getVastXml());
    }

    public boolean hasBidderParams() {
        return config.getBidderParams().size() > 0;
    }

    @NonNull
    public String getAdNetworkName() {
        return adapter.getAdNetworkName();
    }

    @NonNull
    public List<String> getAdNetworkAdIdentifiers() {
        return adapter.getAdNetworkAdIdentifiers();
    }

    @NonNull
    public String getAdapterVersion() {
        return adapter.getAdapterVersion();
    }

    @NonNull
    public String getAdNetworkVersion() {
        return adapter.getAdNetworkVersion();
    }

    private void vampEvent(final Event event) {
        // ADNWからのイベントが必ずしもMainスレッドで通知されるとは限らないため,必ずMainスレッド実行にする.
        // バックグラウンドスレッドで実行し続けると,Failしてから次をロードする際にクラッシュするリスクがある.
        // ADNW SDKのload/show直前でMainスレッドに切り替える方がパフォーマンス的に良いかもしれないが
        // 現状の実装では難しい部分があるため,ここでの切り替えにしておく
        final WeakReference<Mediation> adWeakReference = new WeakReference<>(this);
        new Handler(Looper.getMainLooper())
                .post(
                        new Runnable() {

                            @Override
                            public void run() {
                                if (event == null) {
                                    LogUtils.e(formatLog("Invalid Argument. event is null."));
                                    return;
                                }

                                final Mediation ad = adWeakReference.get();
                                if (ad == null) {
                                    LogUtils.e(formatLog("Invalid Argument. ad is null."));
                                    return;
                                }

                                if (isLoading()) {
                                    clearMediationTimer();

                                    responseInfo.finishLoading();

                                    if (event.isFail()) {
                                        if (listener != null) {
                                            listener.sendLogEvent(ad, event.getErrorInfo());

                                            final AdNetworkErrorInfo errorInfo =
                                                    event.getErrorInfo();
                                            listener.onFailed(
                                                    ad,
                                                    errorInfo != null
                                                            ? errorInfo.getError()
                                                            : VAMPError.ADNETWORK_ERROR);
                                        }
                                    }

                                    if (event.isLoadSuccess()) {
                                        // 在庫ありのときはすべてのADNWにおいてbeaconを送信する
                                        for (Tracking tracking : beaconNotifications) {
                                            tracking.send();
                                        }

                                        if (listener != null) {
                                            listener.onLoadSuccess(ad);
                                        }
                                    }
                                } else {
                                    if (event.isFail()) {
                                        if (listener != null) {
                                            listener.sendLogEvent(ad, event.getErrorInfo());

                                            final AdNetworkErrorInfo errorInfo =
                                                    event.getErrorInfo();
                                            listener.onFailed(
                                                    ad,
                                                    errorInfo != null
                                                            ? errorInfo.getError()
                                                            : VAMPError.ADNETWORK_ERROR);
                                        }
                                    }

                                    if (event.isOpen()) {
                                        sendStartBeacon();

                                        if (listener != null) {
                                            listener.onVideoStart(ad);
                                        }
                                    }

                                    if (event.isClick()) {
                                        ad.adClicked = true;
                                    }

                                    if (event.isComplete()) {
                                        sendCompleteBeacon();

                                        if (listener != null) {
                                            listener.onVideoComplete(ad);
                                        }
                                    }

                                    if (event.isClose()) {
                                        if (listener != null) {
                                            listener.onAdClosed(ad, ad.adClicked);
                                        }
                                    }
                                }

                                // 異常系の場合は最後に終了処理を実行
                                if (event.isFail()) {
                                    destroy();
                                }
                            }
                        });
    }

    @NonNull
    private String formatLog(@NonNull final String msg) {
        return msg + " (" + getAdNetworkName() + ")";
    }

    private void sendImpressionBeacon() {
        try {
            impressionBeacon.unwrap().send();
        } catch (Optional.NotPresentException ignored) {
        }
    }

    private void sendStartBeacon() {
        try {
            startBeacon.unwrap().send();
        } catch (Optional.NotPresentException ignored) {
        }
    }

    private void sendCompleteBeacon() {
        try {
            completeBeacon.unwrap().send();
        } catch (Optional.NotPresentException ignored) {
        }
    }

    private void setMediationTimer() {
        clearMediationTimer();

        LogUtils.devLog(formatLog("set timer: " + mediationTimeout + "ms."));

        mediationTimer.cancelAndSchedule(
                mediationTimeout.timeInMilliseconds, new MediationTimerTask(this));
    }

    private void clearMediationTimer() {
        LogUtils.devLog(formatLog("clear timer."));

        mediationTimer.cancelIfScheduled();
    }

    private boolean isLoading() {
        return mediationTimer.isScheduled();
    }

    /**
     * 基本的にはApplication Contextを返しますが、 Activityを要求するアダプタに対してはactivityインスタンスを返します。
     * ただし、activityインスタンスは破棄されている可能性があります
     */
    @NonNull
    private static Context getContextForAdapter(
            @NonNull final String adNetworkName,
            @NonNull final Context applicationContext,
            @Nullable final Activity activity)
            throws Exception {
        Context ctx =
                ("maio".equalsIgnoreCase(adNetworkName)
                                || "LINEAds".equalsIgnoreCase(adNetworkName)
                                || "ironSource".equalsIgnoreCase(adNetworkName))
                        ? activity
                        : applicationContext;

        if (ctx == null) {
            throw new Exception("The context is null.");
        }

        if (ctx instanceof Activity) {
            if (((Activity) ctx).isFinishing()) {
                throw new Exception("The activity is finishing.");
            } else if (((Activity) ctx).isDestroyed()) {
                throw new Exception("The activity was destroyed.");
            }
        }

        return ctx;
    }

    private static class MediationTimerTask extends TimerTask {
        private final WeakReference<Mediation> adRef;

        MediationTimerTask(Mediation ad) {
            adRef = new WeakReference<>(ad);
        }

        @Override
        public void run() {
            Mediation ad = adRef.get();

            if (ad == null) {
                cancel();
                return;
            }

            LogUtils.d("Mediation Error: " + ad.getAdNetworkName() + " timeout.");

            ad.vampEvent(
                    new Event(
                            Event.EVENT_FAIL,
                            new AdNetworkErrorInfo.Builder(
                                            "MediationTimerTask", VAMPError.MEDIATION_TIMEOUT)
                                    .setAdNetworkErrorMessage("Mediation timeout.")
                                    .build()));

            cancel();
        }
    }
}
