package jp.supership.vamp;

import androidx.annotation.NonNull;

import jp.supership.sscore.vamp.type.Optional;

enum AppOpenExpirationPolicy {
    BY_NETWORK,
    FIXED
}

final class AppOpenOptions {
    /** 有効期限ポリシー デフォルト: BY_NETWORK */
    final AppOpenExpirationPolicy expirationPolicy;

    final MediationTimeout mediationTimeout;
    final long fixedExpirationTimeInMilliSeconds;

    @NonNull
    public static AppOpenOptions defaultOption() {
        MediationTimeout mediationTimeout;
        try {
            mediationTimeout = VAMPDebugUtils.newInstance().mediationTimeout.unwrap();
        } catch (Optional.NotPresentException e) {
            mediationTimeout = MediationTimeout.newDefault();
        }

        return new AppOpenOptions(mediationTimeout, AppOpenExpirationPolicy.BY_NETWORK);
    }

    public AppOpenOptions(
            @NonNull MediationTimeout mediationTimeout,
            @NonNull AppOpenExpirationPolicy expirationPolicy) {
        this.mediationTimeout = mediationTimeout;
        this.expirationPolicy = expirationPolicy;
        this.fixedExpirationTimeInMilliSeconds = 3600 * 1000;
    }

    public long getExpirationTimeInMilliSeconds(@NonNull String adNetworkName) {
        if (expirationPolicy == AppOpenExpirationPolicy.FIXED) {
            return fixedExpirationTimeInMilliSeconds;
        }

        long expirationTimeInMilliSeconds = 3600 * 1000;
        if (AdNetworkNames.VAMP_ADNETWORK_NAME_PANGLE.equals(adNetworkName)) {
            expirationTimeInMilliSeconds = 3600 * 1000;
        } else if (AdNetworkNames.VAMP_ADNETWORK_NAME_ADMOB.equals(adNetworkName)) {
            expirationTimeInMilliSeconds = 14400 * 1000;
        }

        return expirationTimeInMilliSeconds;
    }
}
