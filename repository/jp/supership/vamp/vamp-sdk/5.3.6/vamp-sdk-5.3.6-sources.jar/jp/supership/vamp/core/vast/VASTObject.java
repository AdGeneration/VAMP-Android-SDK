package jp.supership.vamp.core.vast;

import androidx.annotation.NonNull;

import jp.supership.sscore.vamp.http.SSCoreHttpClient;
import jp.supership.sscore.vamp.http.SSCoreHttpRequest;
import jp.supership.sscore.vamp.http.SSCoreHttpResponse;
import jp.supership.sscore.vamp.type.Optional;
import jp.supership.vamp.core.error.VAMPInternalError;
import jp.supership.vamp.core.logging.LogUtils;
import jp.supership.vamp.core.utils.Strings;
import jp.supership.vamp.core.utils.VAMPList;

import java.io.Serializable;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Map;

public class VASTObject implements Serializable {
    static final int INVALID_VALUE = -1;
    private String originalXml;

    private VASTObject vastAdTagObject;
    private URL vastAdTagURL;

    // ad
    private String vastVersion;
    private String adId;
    private String adSystem;
    private String adTitle;
    private String description;
    private String advertiser;

    // creatives
    private String creativeId;
    private int skipOffset = INVALID_VALUE;
    private String durationString;

    private VAMPList<String> clickThroughURLStrings;
    private VAMPList<String> errors;
    private VAMPList<VASTMediaFile> mediaFiles;
    private VAMPList<VASTCompanion> companions;
    private VAMPList<VASTAPCExtension> apcExtensions;
    private VAMPList<VASTVerificationExtension> verificationExtensions;
    private VASTPMPCreativeExtension pmpExtension;
    private VAMPList<VASTIcon> icons;
    private VAMPList<VASTTracking> impressionTrackings;
    private VAMPList<VASTTracking> progressTrackings;
    private VAMPList<VASTTracking> startTrackings;
    private VAMPList<VASTTracking> firstQuartileTrackings;
    private VAMPList<VASTTracking> midpointTrackings;
    private VAMPList<VASTTracking> thirdQuartileTrackings;
    private VAMPList<VASTTracking> completeTrackings;
    private VAMPList<VASTTracking> creativeViewTrackings;
    private VAMPList<VASTTracking> muteTrackings;
    private VAMPList<VASTTracking> unmuteTrackings;
    private VAMPList<VASTTracking> pauseTrackings;
    private VAMPList<VASTTracking> resumeTrackings;
    private VAMPList<VASTTracking> clickTrackings;
    private VASTEndCard endCard;
    private String linkText;

    public interface IVASTLoadListener {
        void onLoadVAST(VAMPInternalError error);
    }

    public interface IVASTCreateListener {
        void onCreateVAST(VASTObject vastObject, VAMPInternalError error);
    }

    public interface VASTEventListener {
        void onComplete(URL url, VAMPInternalError error);
    }

    public VASTObject(String vast) {
        originalXml = vast;
        clickThroughURLStrings = new VAMPList<>();
        apcExtensions = new VAMPList<>();
        impressionTrackings = new VAMPList<>();
        clickTrackings = new VAMPList<>();
        icons = new VAMPList<>();
        errors = new VAMPList<>();
        mediaFiles = new VAMPList<>();
        companions = new VAMPList<>();
        progressTrackings = new VAMPList<>();
        startTrackings = new VAMPList<>();
        firstQuartileTrackings = new VAMPList<>();
        midpointTrackings = new VAMPList<>();
        thirdQuartileTrackings = new VAMPList<>();
        completeTrackings = new VAMPList<>();
        creativeViewTrackings = new VAMPList<>();
        verificationExtensions = new VAMPList<>();
        muteTrackings = new VAMPList<>();
        unmuteTrackings = new VAMPList<>();
        pauseTrackings = new VAMPList<>();
        resumeTrackings = new VAMPList<>();
        pmpExtension = null;
    }

    public void release() {
        LogUtils.devLog("release");
        if (clickThroughURLStrings != null) {
            clickThroughURLStrings.clear();
            clickThroughURLStrings = null;
        }

        if (mediaFiles != null) {
            mediaFiles.clear();
            mediaFiles = null;
        }

        if (companions != null) {
            companions.clear();
            companions = null;
        }

        if (apcExtensions != null) {
            apcExtensions.clear();
            apcExtensions = null;
        }

        if (errors != null) {
            errors.clear();
            errors = null;
        }

        if (icons != null) {
            icons.clear();
            icons = null;
        }

        if (impressionTrackings != null) {
            impressionTrackings.clear();
            impressionTrackings = null;
        }

        if (progressTrackings != null) {
            progressTrackings.clear();
            progressTrackings = null;
        }

        if (startTrackings != null) {
            startTrackings.clear();
            startTrackings = null;
        }

        if (firstQuartileTrackings != null) {
            firstQuartileTrackings.clear();
            firstQuartileTrackings = null;
        }

        if (midpointTrackings != null) {
            midpointTrackings.clear();
            midpointTrackings = null;
        }

        if (thirdQuartileTrackings != null) {
            thirdQuartileTrackings.clear();
            ;
            thirdQuartileTrackings = null;
        }

        if (completeTrackings != null) {
            completeTrackings.clear();
            completeTrackings = null;
        }

        if (creativeViewTrackings != null) {
            creativeViewTrackings.clear();
            creativeViewTrackings = null;
        }

        if (muteTrackings != null) {
            muteTrackings.clear();
            muteTrackings = null;
        }

        if (unmuteTrackings != null) {
            unmuteTrackings.clear();
            unmuteTrackings = null;
        }

        if (pauseTrackings != null) {
            pauseTrackings.clear();
            pauseTrackings = null;
        }

        if (resumeTrackings != null) {
            resumeTrackings.clear();
            resumeTrackings = null;
        }

        if (clickTrackings != null) {
            clickTrackings.clear();
            clickTrackings = null;
        }
    }

    public static void create(
            String vast, SSCoreHttpClient httpClient, final IVASTCreateListener listener) {
        try {
            final VASTObject vastObject = new VASTParser().parse(new VASTObject(vast));

            vastObject.loadVASTAdTags(
                    httpClient,
                    error -> {
                        if (error != null) {
                            if (listener != null) {
                                listener.onCreateVAST(null, error);
                            }
                            return;
                        }

                        vastObject.loadVASTAdTags(
                                httpClient,
                                error1 -> {
                                    if (listener != null) {
                                        listener.onCreateVAST(vastObject, error1);
                                    }
                                });
                    });
        } catch (Exception e) {
            if (listener != null) {
                listener.onCreateVAST(
                        null,
                        new VAMPInternalError(
                                VAMPInternalError.Code.XML_PARSE_ERROR, e.getMessage()));
            }
        }
    }

    public void sendTrackingEventImpression(
            Map<String, String> headers, final VASTEventListener listener) {
        LogUtils.devLog("sendTrackingEventImpression");
        for (final VASTTracking tracking : impressionTrackings) {
            tracking.send(headers, listener);
        }
    }

    public void sendTrackingEventStart(
            Map<String, String> headers, final VASTEventListener listener) {
        LogUtils.devLog("sendTrackingEventStart");
        for (final VASTTracking tracking : startTrackings) {
            tracking.send(headers, listener);
        }
    }

    public void sendTrackingEventFirstQuartile(
            Map<String, String> headers, final VASTEventListener listener) {
        LogUtils.devLog("sendTrackingEventFirstQuartile");
        for (final VASTTracking tracking : firstQuartileTrackings) {
            tracking.send(headers, listener);
        }
    }

    public void sendTrackingEventMidpoint(
            Map<String, String> headers, final VASTEventListener listener) {
        LogUtils.devLog("sendTrackingEventMidpoint");
        for (final VASTTracking tracking : midpointTrackings) {
            tracking.send(headers, listener);
        }
    }

    public void sendTrackingEventThirdQuartile(
            Map<String, String> headers, final VASTEventListener listener) {
        LogUtils.devLog("sendTrackingEventThirdQuartile");
        for (final VASTTracking tracking : thirdQuartileTrackings) {
            tracking.send(headers, listener);
        }
    }

    public void sendTrackingEventComplete(
            Map<String, String> headers, final VASTEventListener listener) {
        LogUtils.devLog("sendTrackingEventComplete");
        for (final VASTTracking tracking : completeTrackings) {
            tracking.send(headers, listener);
        }
    }

    public void sendTrackingEventProgress(
            Map<String, String> headers,
            final VASTEventListener listener,
            long currentTimeMs,
            float currentPercentage) {
        for (final VASTTracking tracking : progressTrackings) {
            if (!tracking.isDone() && tracking.reachedTime(currentTimeMs, currentPercentage)) {
                LogUtils.devLog("sendTrackingEventProgress[" + tracking.offset + "]");
                tracking.send(headers, listener);
            }
        }
    }

    public void sendTrackingEventCreativeView(
            Map<String, String> headers, final VASTEventListener listener) {
        LogUtils.devLog("sendTrackingEventCreativeView");
        for (final VASTTracking tracking : creativeViewTrackings) {
            tracking.send(headers, listener);
        }
    }

    public void sendTrackingEventMute(
            Map<String, String> headers, final VASTEventListener listener) {
        LogUtils.devLog("sendTrackingEventMute");
        for (final VASTTracking tracking : muteTrackings) {
            tracking.send(headers, listener);
        }
    }

    public void sendTrackingEventUnmute(
            Map<String, String> headers, final VASTEventListener listener) {
        LogUtils.devLog("sendTrackingEventUnmute");
        for (final VASTTracking tracking : unmuteTrackings) {
            tracking.send(headers, listener);
        }
    }

    public void sendTrackingEventPause(
            Map<String, String> headers, final VASTEventListener listener) {
        LogUtils.devLog("sendTrackingEventPause");
        for (final VASTTracking tracking : pauseTrackings) {
            tracking.send(headers, listener);
        }
    }

    public void sendTrackingEventResume(
            Map<String, String> headers, final VASTEventListener listener) {
        LogUtils.devLog("sendTrackingEventResume");
        for (VASTTracking tracking : resumeTrackings) {
            tracking.send(headers, listener);
        }
    }

    public void sendTrackingEventClick(
            Map<String, String> headers, final VASTEventListener listener) {
        // TODO <仕様メモ> CompanionのClickTrackingは送信していない
        LogUtils.devLog("sendTrackingEventClick");
        for (VASTTracking tracking : clickTrackings) {
            tracking.send(headers, listener);
        }
    }

    private void loadVASTAdTags(
            @NonNull SSCoreHttpClient httpClient, final IVASTLoadListener listener) {
        if (this.vastAdTagURL == null) {
            if (listener != null) {
                listener.onLoadVAST(null);
            }
            return;
        }

        SSCoreHttpRequest httpRequest;
        try {
            httpRequest =
                    new SSCoreHttpRequest.Builder(vastAdTagURL.toString())
                            .withMethod(SSCoreHttpRequest.Method.GET)
                            .build();
        } catch (MalformedURLException | SSCoreHttpRequest.InvalidRequestParameterException e) {
            if (listener != null) {
                listener.onLoadVAST(
                        new VAMPInternalError(VAMPInternalError.Code.UNKNOWN, e.getMessage()));
            }

            LogUtils.devLog(
                    "loadVASTAdTagUrl failed. url:" + vastAdTagURL + " message:" + e.getMessage());
            return;
        }

        httpClient.request(
                httpRequest,
                result -> {
                    if (!result.isSuccess()) {
                        final String errorMessage =
                                result.error.map(Throwable::getMessage).orElse("Unknown error");

                        if (listener != null) {
                            listener.onLoadVAST(
                                    new VAMPInternalError(
                                            VAMPInternalError.Code.NETWORK_ERROR, errorMessage));
                        }

                        LogUtils.devLog(
                                "loadVASTAdTagUrl failed. url:"
                                        + vastAdTagURL
                                        + " message:"
                                        + errorMessage);
                        return;
                    }

                    int statusCode;
                    String vast;
                    try {
                        SSCoreHttpResponse response = result.data.unwrap();
                        vast = response.readString().unwrap();
                        statusCode = result.data.unwrap().statusCode;
                    } catch (Optional.NotPresentException e) {
                        if (listener != null) {
                            listener.onLoadVAST(
                                    new VAMPInternalError(
                                            VAMPInternalError.Code.NETWORK_ERROR,
                                            "Invalid response. " + e.getMessage()));
                        }
                        return;
                    }

                    if (vast.isEmpty()) {
                        if (listener != null) {
                            listener.onLoadVAST(
                                    new VAMPInternalError(
                                            VAMPInternalError.Code.NETWORK_ERROR,
                                            "VAST is empty."));
                        }
                        return;
                    }

                    // statusCodeが200でない場合は失敗扱いとする
                    if (statusCode != 200) {
                        final String errorMessage =
                                result.error.map(Throwable::getMessage).orElse("Unknown error");

                        if (listener != null) {
                            listener.onLoadVAST(
                                    new VAMPInternalError(
                                            VAMPInternalError.Code.NETWORK_ERROR,
                                            "statusCode = "
                                                    + statusCode
                                                    + ", errorMessage = "
                                                    + errorMessage));
                        }
                        return;
                    }

                    try {
                        vastAdTagObject = new VASTParser().parse(new VASTObject(vast));

                        // VASTAdTagが有る限り再帰的に全ロードする
                        vastAdTagObject.loadVASTAdTags(httpClient, listener);
                    } catch (Exception e) {
                        if (listener != null) {
                            listener.onLoadVAST(
                                    new VAMPInternalError(
                                            VAMPInternalError.Code.XML_PARSE_ERROR,
                                            e.getMessage()));
                        }
                    }
                });
    }

    private void setVASTAdTagObjects(
            ArrayList<VASTObject> vastAdTagObjects, VASTObject vastObject) {
        if (vastObject != null && vastObject.vastAdTagObject != null && vastAdTagObjects != null) {
            vastAdTagObjects.add(vastObject.vastAdTagObject);
            setVASTAdTagObjects(vastAdTagObjects, vastObject.vastAdTagObject);
        }
    }

    private VASTObject retrieveClosestVASTObject(VASTObject vastObject) {
        if (vastObject != null && vastObject.getVastAdTagObject() != null) {
            return retrieveClosestVASTObject(vastObject.getVastAdTagObject());
        }

        return vastObject;
    }

    public String getOriginalXml() {
        return originalXml;
    }

    public String getVastVersion() {
        return vastVersion;
    }

    public void setVastVersion(String vastVersion) {
        this.vastVersion = vastVersion;
    }

    public String getAdId() {
        return adId;
    }

    public void setAdId(String adId) {
        this.adId = adId;
    }

    public String getAdSystem() {
        return adSystem;
    }

    public void setAdSystem(String adSystem) {
        this.adSystem = adSystem;
    }

    public String getAdTitle() {
        return adTitle;
    }

    public void setAdTitle(String adTitle) {
        this.adTitle = adTitle;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getAdvertiser() {
        return advertiser;
    }

    public void setAdvertiser(String advertiser) {
        this.advertiser = advertiser;
    }

    public String getCreativeId() {
        return creativeId;
    }

    public void setCreativeId(String creativeId) {
        this.creativeId = creativeId;
    }

    public boolean isPlayerCancelable() {
        return skipOffset > 1000;
    }

    public int getSkipOffset(int duration) {
        if (skipOffset > 0) {
            // 1秒以上120秒以下かつ動画再生時間内
            skipOffset = Math.max(Math.min(Math.min(skipOffset, 120 * 1000), duration), 1000);
        }

        return skipOffset;
    }

    public int getSkipOffset() {
        return skipOffset;
    }

    public void setSkipOffsetString(String skipOffsetString) {
        try {
            int videoDuration = INVALID_VALUE;
            if (Strings.isAbsoluteTracker(durationString)) {
                videoDuration = Strings.parseAbsoluteOffset(durationString);
            }

            if (Strings.isAbsoluteTracker(skipOffsetString)) {
                skipOffset = Strings.parseAbsoluteOffset(skipOffsetString);
            } else if (Strings.isPercentageTracker(skipOffsetString) && videoDuration > 0) {
                skipOffset = Strings.parsePercentageOffset(skipOffsetString, videoDuration);
            } else {
                LogUtils.e("offset parse err.");
                skipOffset = INVALID_VALUE;
            }
        } catch (Exception e) {
            e.printStackTrace();
            skipOffset = INVALID_VALUE;
        }
    }

    public String getDurationString() {
        return durationString;
    }

    public void setDurationString(String durationString) {
        this.durationString = durationString;
    }

    public String getClickThroughURLString() {
        // ClickThroughUrlは最初に設定されているもの
        return clickThroughURLStrings.size() > 0 ? clickThroughURLStrings.get(0) : null;
    }

    public VAMPList<String> getClickThroughURLStrings() {
        return clickThroughURLStrings;
    }

    public VAMPList<VASTIcon> getIcons() {
        return icons;
    }

    public VAMPList<VASTTracking> getImpressionTrackings() {
        return impressionTrackings;
    }

    public void setImpressionTrackings(VAMPList<VASTTracking> impressionTrackings) {
        this.impressionTrackings = impressionTrackings;
    }

    public VAMPList<VASTTracking> getClickTrackings() {
        return clickTrackings;
    }

    public void setClickTrackings(VAMPList<VASTTracking> clickTrackings) {
        this.clickTrackings = clickTrackings;
    }

    public VAMPList<VASTAPCExtension> getApcExtensions() {
        return apcExtensions;
    }

    public VAMPList<String> getErrors() {
        return errors;
    }

    public VAMPList<VASTMediaFile> getMediaFiles() {
        return mediaFiles;
    }

    public VAMPList<VASTCompanion> getCompanions() {
        return companions;
    }

    public VAMPList<VASTVerificationExtension> getVerificationExtensions() {
        return verificationExtensions;
    }

    public void setVerificationExtensions(
            VAMPList<VASTVerificationExtension> verificationExtensions) {
        this.verificationExtensions = verificationExtensions;
    }

    public VASTPMPCreativeExtension getPmpExtension() {
        return pmpExtension;
    }

    public void setPmpExtension(VASTPMPCreativeExtension pmpExtension) {
        this.pmpExtension = pmpExtension;
    }

    public void setVastAdTagURL(URL vastAdTagURL) {
        this.vastAdTagURL = vastAdTagURL;
    }

    public VAMPList<VASTTracking> getProgressTrackings() {
        return progressTrackings;
    }

    public void setProgressTrackings(VAMPList<VASTTracking> progressTrackings) {
        this.progressTrackings = progressTrackings;
    }

    public VAMPList<VASTTracking> getStartTrackings() {
        return startTrackings;
    }

    public void setStartTrackings(VAMPList<VASTTracking> startTrackings) {
        this.startTrackings = startTrackings;
    }

    public VAMPList<VASTTracking> getFirstQuartileTrackings() {
        return firstQuartileTrackings;
    }

    public void setFirstQuartileTrackings(VAMPList<VASTTracking> firstQuartileTrackings) {
        this.firstQuartileTrackings = firstQuartileTrackings;
    }

    public VAMPList<VASTTracking> getMidpointTrackings() {
        return midpointTrackings;
    }

    public void setMidpointTrackings(VAMPList<VASTTracking> midpointTrackings) {
        this.midpointTrackings = midpointTrackings;
    }

    public VAMPList<VASTTracking> getThirdQuartileTrackings() {
        return thirdQuartileTrackings;
    }

    public void setThirdQuartileTrackings(VAMPList<VASTTracking> thirdQuartileTrackings) {
        this.thirdQuartileTrackings = thirdQuartileTrackings;
    }

    public VAMPList<VASTTracking> getCompleteTrackings() {
        return completeTrackings;
    }

    public void setCompleteTrackings(VAMPList<VASTTracking> completeTrackings) {
        this.completeTrackings = completeTrackings;
    }

    public VAMPList<VASTTracking> getCreativeViewTrackings() {
        return creativeViewTrackings;
    }

    public VAMPList<VASTTracking> getMuteTrackings() {
        return muteTrackings;
    }

    public VAMPList<VASTTracking> getUnmuteTrackings() {
        return unmuteTrackings;
    }

    public VAMPList<VASTTracking> getPauseTrackings() {
        return pauseTrackings;
    }

    public VAMPList<VASTTracking> getResumeTrackings() {
        return resumeTrackings;
    }

    public VASTEndCard getEndCard() {
        return endCard;
    }

    public void setEndCard(VASTEndCard endCard) {
        this.endCard = endCard;
    }

    public void setLinkText(String linkText) {
        this.linkText = linkText;
    }

    public String getLinkText() {
        return linkText;
    }

    public VASTObject getVastAdTagObject() {
        return vastAdTagObject;
    }

    public VASTObject collectedObject() {
        VASTObject vastObject = new VASTObject(originalXml);
        VAMPList<VASTObject> vastObjects = new VAMPList<>();
        vastObjects.add(this);

        setVASTAdTagObjects(vastObjects, this);
        // プロパティの上書き,結合
        for (VASTObject object : vastObjects) {
            vastObject.vastVersion = object.vastVersion;
            vastObject.adId = object.adId;
            vastObject.adSystem = object.adSystem;
            vastObject.adTitle = object.adTitle;
            vastObject.description = object.description;
            vastObject.advertiser = object.advertiser;
            vastObject.creativeId = object.creativeId;
            vastObject.skipOffset = object.skipOffset;
            vastObject.durationString = object.durationString;
            vastObject.clickThroughURLStrings.addAll(object.clickThroughURLStrings);
            vastObject.mediaFiles.addAll(object.mediaFiles);
            vastObject.companions.addAll(object.companions);
            vastObject.apcExtensions.addAll(object.apcExtensions);
            vastObject.icons.addAll(object.icons);
            vastObject.errors.addAll(object.errors);
            vastObject.impressionTrackings.addAll(object.impressionTrackings);
            vastObject.progressTrackings.addAll(object.progressTrackings);
            vastObject.startTrackings.addAll(object.startTrackings);
            vastObject.firstQuartileTrackings.addAll(object.firstQuartileTrackings);
            vastObject.midpointTrackings.addAll(object.midpointTrackings);
            vastObject.thirdQuartileTrackings.addAll(object.thirdQuartileTrackings);
            vastObject.completeTrackings.addAll(object.completeTrackings);
            vastObject.creativeViewTrackings.addAll(object.creativeViewTrackings);
            vastObject.muteTrackings.addAll(object.muteTrackings);
            vastObject.unmuteTrackings.addAll(object.unmuteTrackings);
            vastObject.pauseTrackings.addAll(object.pauseTrackings);
            vastObject.resumeTrackings.addAll(object.resumeTrackings);
            vastObject.clickTrackings.addAll(object.clickTrackings);
            vastObject.verificationExtensions.addAll(object.verificationExtensions);
            vastObject.pmpExtension = object.pmpExtension;
            vastObject.endCard = object.endCard;
            vastObject.linkText = object.linkText;
        }

        return vastObject;
    }

    public VASTObject getClosestVASTObject() {
        return retrieveClosestVASTObject(this);
    }
}
