package jp.supership.vamp;

import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import jp.supership.sscore.vamp.region.SSCoreRegionService;
import jp.supership.sscore.vamp.userconsent.SSCoreUserConsentManager;
import jp.supership.vamp.core.logging.LogUtils;

/** VAMP SDKで動画リワードを使用するための基本的な機能を提供します。 */
public class VAMP {
    private static boolean sTestMode = false;
    private static boolean sDebugMode = false;

    /**
     * VAMPのSDKバージョンを取得します。例v1.0など
     *
     * @return VAMPのSDKバージョン
     */
    @NonNull
    public static String SDKVersion() {
        return BuildConfig.SDKVERSION;
    }

    /**
     * サポート対象OSか確認できます。
     *
     * @return サポート対象OSならtrue、そうでなければfalse
     * @since v1.2.3
     */
    public static boolean isSupported() {
        // API level 23 Marshmallow
        // Released publicly as Android 6.0 in October 2015.
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.M;
    }

    /**
     * 収益が発生しないテスト広告が配信されるようになります。<br>
     *
     * <p>ストアに申請する際は<b>コメントアウト</b>か<b>false</b>に設定してください。<br>
     *
     * <p>各アドネットワークのテストモードと連動します。<br>
     *
     * <p>※アドネットワークによっては、テストモードに対応していないものもあります。<br>
     *
     * <p>デフォルト（設定していない場合）はfalse。RTB案件は配信されません。<br>
     *
     * @param testMode テストモードを有効にするかどうか
     */
    public static void setTestMode(boolean testMode) {
        sTestMode = testMode;
    }

    /**
     * テストモードが設定されているか確認できます。
     *
     * @return テストモードが有効の場合はtrue、無効の場合はfalse
     */
    public static boolean isTestMode() {
        return sTestMode;
    }

    /**
     * ログを詳細に出力するデバッグモードを設定します。<br>
     *
     * <p>各アドネットワークのデバッグモードと連動します。<br>
     *
     * <p>※アドネットワークによっては、デバッグモードに対応していないものもあります。<br>
     *
     * <p>デフォルト（設定していない場合）はfalse。
     *
     * @param debugMode デバッグモードを有効にするかどうか
     */
    public static void setDebugMode(boolean debugMode) {
        sDebugMode = debugMode;

        if (sDebugMode) {
            LogUtils.setLogLevel(Log.DEBUG);

            UncaughtExceptionHandler.set();
        } else {
            LogUtils.setLogLevel(Log.INFO);

            UncaughtExceptionHandler.unset();
        }
    }

    /**
     * デバッグモードが設定されているか確認できます。
     *
     * @return デバッグモードが有効の場合はtrue、無効の場合はfalse
     */
    public static boolean isDebugMode() {
        return sDebugMode;
    }

    /**
     * リワードキーを設定します
     *
     * @param rewardKey リワードキー
     */
    public static void setRewardKey(String rewardKey) {
        try {
            RewardKey.setAppUserKey(new RewardKey(rewardKey));
        } catch (RewardKey.CanNotInstantiateException e) {
            LogUtils.d(e.getMessage());
        }
    }

    /**
     * EU圏アクセス判定をします（trueならEU圏からのアクセス）。<br>
     *
     * <p>IPを元に以下の国からのアクセスかを判定します。<br>
     *
     * <p>ベルギーBE, ブルガリアBG, チェコCZ, デンマークDK,ドイツDE, エストニアEE, アイルランドIE, ギリシャGR, スペインES, フランスFR, クロアチアHR,
     * イタリアIT, キプロスCY, ラトビアLV, リトアニアLT, ルクセンブルクLU, ハンガリーHU, マルタMT, オランダNL, オーストリアAT, ポーランドPL,
     * ポルトガルPT, ルーマニアRO, スロベニアSI, スロバキアSK, フィンランドFI, スウェーデンSE,
     * イギリスGB、アイスランドIS、リヒテンシュタインLI、ノルウエーNO、ギアナGF、ポリネシアPF、フランス領南方・南極地域TF、サン・マルタン（フランス領）MF、シント・マールテン（オランダ領）SX、イギリス領ヴァージン諸島VG、イギリス領インド洋地域IO
     * <br>
     *
     * <p>※IPから国が判別できなかった場合もtrueに判定されます。
     *
     * @param context Context
     * @param listener EU圏からのアクセスかを判定するための {@link VAMPPrivacySettings.UserConsentListener} リスナー
     */
    public static void isEUAccess(
            @NonNull Context context,
            @Nullable final VAMPPrivacySettings.UserConsentListener listener) {
        SSCoreUserConsentManager.createInstance(context)
                .shouldRequestConsent(
                        isRequired -> {
                            if (listener != null) {
                                new Handler(Looper.getMainLooper())
                                        .post(() -> listener.onRequired(isRequired));
                            }
                        });
    }

    /**
     * ２文字の国コード（JP、USなど<a href="https://ja.wikipedia.org/wiki/ISO_3166-1">ISO3166-1</a>）を取得します。<br>
     *
     * <p>IPから国を判別できなかった、リクエストがタイムアウトしたなど、正常に値が返せないケースは"99"を返却します。<br>
     *
     * @param listener 　{@link VAMPGetLocationListener} リスナー
     * @see <a
     *     href="https://gist.github.com/mukae-ss/9131fa350e09db77dbab247500c94750">UnityPluginで国判定するサンプル</a>
     *     <br>
     */
    public static void getLocation(@Nullable final VAMPGetLocationListener listener) {
        SSCoreRegionService.createInstance()
                .getRegionAsync(
                        ssCoreRegionInfo -> {
                            final VAMPLocation location =
                                    new VAMPLocation(
                                            ssCoreRegionInfo.getCountryCode(),
                                            ssCoreRegionInfo.getRegion());
                            if (listener != null) {
                                new Handler(Looper.getMainLooper())
                                        .post(() -> listener.onLocation(location));
                            }
                        });
    }

    /**
     * Meta Audience Network（旧Facebook Audience Network） Biddingを設定します。 Meta Audience Network
     * Biddingを有効にするときはuseBiddingをtrueにしてください。 また、Meta Audience Network
     * BiddingのテストをするときはtestModeもtrueにしてください。 ※ストアにリリースするときは必ずtestModeをfalseにしてください。
     *
     * @param useBidding trueにするとMeta Audience Network Biddingを有効にします
     * @param testMode Meta Audience Network Biddingのテストをするときはtrueを指定します
     */
    @Deprecated
    public static void setMetaAudienceNetworkBidding(boolean useBidding, boolean testMode) {}

    /**
     * Meta Audience Network Biddingが有効か判定します
     *
     * @return Meta Audience Network Biddingが有効のときはtrueを返します
     */
    @Deprecated
    public static boolean useMetaAudienceNetworkBidding() {
        return false;
    }

    /**
     * Meta Audience Network Biddingのテストモードか判定します
     *
     * @return Meta Audience Network Biddingのテストモードが有効のときはtrueを返します
     */
    @Deprecated
    public static boolean isMetaAudienceNetworkBiddingTestMode() {
        return false;
    }
}
