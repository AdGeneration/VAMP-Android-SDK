package jp.supership.vamp;

import androidx.annotation.NonNull;
import androidx.annotation.VisibleForTesting;

import jp.supership.sscore.vamp.type.Optional;

import java.util.ArrayList;

final class MediationContainer {
    @NonNull private final ArrayList<Mediation> mediationList;
    private int currentCursor;

    MediationContainer(@NonNull final ArrayList<Mediation> mediationList) {
        this.mediationList = mediationList;
    }

    void nextMediation() {
        ++currentCursor;
    }

    void nextVASTMediation() {
        while (++currentCursor < mediationList.size()) {
            final Mediation mediation = mediationList.get(currentCursor);

            if (mediation.isVastAd() || mediation.hasBidderParams()) {
                break;
            }
        }
    }

    @NonNull
    Optional<Mediation> getCurrentMediation() {
        if (currentCursor >= 0 && currentCursor < mediationList.size()) {
            return Optional.of(mediationList.get(currentCursor));
        } else {
            return Optional.empty();
        }
    }

    @NonNull
    ArrayList<AdapterResponseInfo> getAdapterResponseList() {
        final ArrayList<AdapterResponseInfo> infoList = new ArrayList<>();
        for (Mediation mediation : mediationList) {
            infoList.add(mediation.getResponseInfo());
        }
        return infoList;
    }

    void destroyContainer() {
        for (Mediation mediation : mediationList) {
            mediation.destroy();
        }

        mediationList.clear();
    }

    @VisibleForTesting
    int getCurrentCursor() {
        return currentCursor;
    }
}
