package jp.supership.vamp;

public interface AdapterResponseInfo {
    String getAdNetworkName();

    String getClassName();

    long getLatencyMillis();

    String getAdID();
}
