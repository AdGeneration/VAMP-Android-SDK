package jp.supership.vamp;

import androidx.annotation.NonNull;

/** 広告リクエストのタイムアウト。この時間内にアドネットワークまたはVAST広告のロードが一つも完了しなかった場合はタイムアウトとなります */
final class RequestTimeout {
    /** ロードのリクエストタイムアウトのデフォルト値 */
    static final int DEFAULT_TIMEOUT_IN_SECONDS = 60;
    /** ロードのリクエストタイムアウトの最小値 */
    static final int MIN_TIMEOUT_IN_SECONDS = 30;
    /** ロードのリクエストタイムアウトの最大値 */
    static final int MAX_TIMEOUT_IN_SECONDS = 120;

    /** タイムアウト [秒] */
    final int timeInSeconds;

    RequestTimeout(final int timeInSeconds) {
        this.timeInSeconds =
                Math.min(Math.max(timeInSeconds, MIN_TIMEOUT_IN_SECONDS), MAX_TIMEOUT_IN_SECONDS);
    }

    /**
     * @return デフォルトのタイムアウトを返します
     */
    @NonNull
    static RequestTimeout newDefault() {
        return new RequestTimeout(DEFAULT_TIMEOUT_IN_SECONDS);
    }

    /**
     * タイムアウトをミリ秒で返します
     *
     * @return タイムアウト値 [ミリ秒]
     */
    long timeInMilliseconds() {
        return timeInSeconds * 1000L;
    }

    @NonNull
    @Override
    public String toString() {
        return "" + timeInSeconds;
    }
}
