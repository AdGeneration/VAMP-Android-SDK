package jp.supership.vamp.measurement;

import androidx.annotation.NonNull;

import jp.supership.sscore.vamp.type.Optional;

public interface OnJsLibraryFetchListener {
    /**
     * omsdk.jsのダウンロード処理終了時に呼ばれます
     *
     * @param js ダウンロードに成功したときはomsdk.jsを格納したオブジェクトを、 失敗したときはOptional.emptyが渡されます
     */
    void onJsLibraryFetch(@NonNull Optional<String> js);
}
