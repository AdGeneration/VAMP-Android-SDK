package jp.supership.vamp;

import androidx.annotation.NonNull;

/** アドネットワークのロード処理のタイムアウト。 アドネットワークのロードを開始した時点から計測し、この時間内にロードが完了しなかった場合はタイムアウトとなります */
final class MediationTimeout {
    /** デフォルトのタイムアウト */
    private static final long DEFAULT_TIMEOUT_IN_MILLISECONDS = 15 * 1000;
    /** タイムアウトの最小値 */
    private static final long MIN_TIMEOUT_IN_MILLISECONDS = 1;

    /** タイムアウト [ミリ秒] */
    final long timeInMilliseconds;

    MediationTimeout(final long timeInMilliseconds) {
        this.timeInMilliseconds = Math.max(timeInMilliseconds, MIN_TIMEOUT_IN_MILLISECONDS);
    }

    /**
     * @return デフォルトのタイムアウトを返します
     */
    @NonNull
    static MediationTimeout newDefault() {
        return new MediationTimeout(DEFAULT_TIMEOUT_IN_MILLISECONDS);
    }

    @NonNull
    @Override
    public String toString() {
        return "" + timeInMilliseconds;
    }
}
