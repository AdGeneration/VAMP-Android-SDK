package jp.supership.vamp.mediation;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import jp.supership.vamp.VAMPError;

import java.util.List;

public final class Event {
    public static final int EVENT_LOAD_SUCCESS = 0x01;
    public static final int EVENT_FAIL = 0x01 << 1;
    public static final int EVENT_OPEN = 0x01 << 2;
    public static final int EVENT_COMPLETE = 0x01 << 3;
    public static final int EVENT_CLOSE = 0x01 << 4;
    @Deprecated public static final int EVENT_REWARD = 0x01 << 5;
    public static final int EVENT_CLICK = 0x01 << 6;

    private final int event;
    @Nullable private final AdNetworkErrorInfo errorInfo;

    public Event(final int event) {
        this(event, null);
    }

    public Event(final int event, @Nullable final AdNetworkErrorInfo errorInfo) {
        this.event = event;
        this.errorInfo = errorInfo;
    }

    @NonNull
    @Override
    public String toString() {
        return "Event(" + "event=" + event + ", errorInfo=" + errorInfo + ")";
    }

    public boolean isLoadSuccess() {
        return (event & EVENT_LOAD_SUCCESS) != 0;
    }

    public boolean isFail() {
        return (event & EVENT_FAIL) != 0;
    }

    public boolean isOpen() {
        return (event & EVENT_OPEN) != 0;
    }

    public boolean isComplete() {
        return (event & EVENT_COMPLETE) != 0;
    }

    public boolean isClose() {
        return (event & EVENT_CLOSE) != 0;
    }

    public boolean isClick() {
        return (event & EVENT_CLICK) != 0;
    }

    @Nullable
    public AdNetworkErrorInfo getErrorInfo() {
        return errorInfo;
    }

    @NonNull
    public static Event newActivityNotFoundErrorEvent(@NonNull final String methodName) {
        final String errorMessage = methodName + " method requires an Activity context.";
        return new Event(
                Event.EVENT_FAIL,
                new AdNetworkErrorInfo.Builder(methodName, VAMPError.INVALID_PARAMETER)
                        .setErrorMessage(errorMessage)
                        .build());
    }

    @NonNull
    public static Event newNullOrEmptyParameterErrorEvent(
            @NonNull final String methodName, @NonNull final List<String> parameterNames) {
        final String errorMessage =
                methodName
                        + " method requires non-null and non-empty parameters: "
                        + parameterNames;
        return new Event(
                Event.EVENT_FAIL,
                new AdNetworkErrorInfo.Builder(methodName, VAMPError.INVALID_PARAMETER)
                        .setErrorMessage(errorMessage)
                        .build());
    }
}
