package jp.supership.vamp;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;

/** 広告レスポンスの情報を取得します。 */
public interface VAMPResponseInfo {
    /**
     * リクエスト毎にユニークなIDを取得します。
     *
     * @return リクエスト毎にユニークなID
     */
    @Nullable
    String getSeqID();

    /**
     * Adapterのレスポンス情報を取得します。
     *
     * @return Adapterのレスポンス情報
     */
    @NonNull
    ArrayList<VAMPAdapterResponseInfo> getAdapterResponseInfos();

    /**
     * アドネットワーク名を取得します。
     *
     * @return アドネットワーク名
     */
    @NonNull
    String getAdNetworkName();
}
