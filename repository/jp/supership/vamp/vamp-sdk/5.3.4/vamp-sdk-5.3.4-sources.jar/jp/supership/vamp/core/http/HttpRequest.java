package jp.supership.vamp.core.http;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import jp.supership.vamp.core.logging.LogUtils;

import java.io.BufferedOutputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

public class HttpRequest {
    private final int HTTP_REQUEST_CONNECTION_TIMEOUT = 5000; // 5秒
    private final int HTTP_REQUEST_READ_TIMEOUT = 15000;

    private Map<String, String> requestProperties = new HashMap<>();
    private String requestBody = "";
    private int connectionTimeout = HTTP_REQUEST_CONNECTION_TIMEOUT;
    private int readTimeout = HTTP_REQUEST_READ_TIMEOUT;
    private URL url;

    private HttpMethod method = HttpMethod.GET;

    public HttpRequest(@Nullable String url) {
        try {
            this.url = new URL(url);
        } catch (Exception e) {
            LogUtils.e(e.getMessage());
        }
    }

    public HttpRequest(@NonNull URL url) {
        this.url = url;
    }

    /**
     * GETメソッドのリクエストを生成します
     *
     * @param url URL
     * @return HttpRequest
     */
    @NonNull
    public static HttpRequest get(@NonNull final URL url) {
        return new HttpRequest(url).setMethod(HttpMethod.GET);
    }

    /**
     * POSTメソッドのリクエストを生成します
     *
     * @param url URL
     * @return HttpRequest
     */
    @NonNull
    public static HttpRequest post(@NonNull final URL url) {
        return new HttpRequest(url).setMethod(HttpMethod.POST);
    }

    /**
     * PUTメソッドのリクエストを生成します
     *
     * @param url URL
     * @return HttpRequest
     */
    @NonNull
    public static HttpRequest put(@NonNull final URL url) {
        return new HttpRequest(url).setMethod(HttpMethod.PUT);
    }

    /**
     * DELETEメソッドのリクエストを生成します
     *
     * @param url URL
     * @return HttpRequest
     */
    @NonNull
    public static HttpRequest delete(@NonNull final URL url) {
        return new HttpRequest(url).setMethod(HttpMethod.DELETE);
    }

    public URL getUrl() {
        return url;
    }

    public HttpRequest setMethod(@NonNull HttpMethod method) {
        this.method = method;
        return this;
    }

    public HttpMethod getMethod() {
        return method;
    }

    public HttpRequest appendRequestProperty(@NonNull String key, @NonNull String value) {
        this.requestProperties.put(key, value);
        return this;
    }

    public HttpRequest setRequestProperty(@Nullable Map<String, String> requestProperty) {
        this.requestProperties = requestProperty;
        return this;
    }

    public Map<String, String> getRequestProperties() {
        return requestProperties;
    }

    public HttpRequest setRequestBody(String requestBody) {
        this.requestBody = requestBody;
        return this;
    }

    public String getRequestBody() {
        return requestBody;
    }

    public HttpRequest setConnectionTimeout(int connectionTimeout) {
        this.connectionTimeout = connectionTimeout;
        return this;
    }

    public int getConnectionTimeout() {
        return connectionTimeout;
    }

    public HttpRequest setReadTimeout(int mReadTimeout) {
        this.readTimeout = mReadTimeout;
        return this;
    }

    public int getReadTimeout() {
        return readTimeout;
    }

    public HttpURLConnection newConnection() throws IOException {
        final HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setUseCaches(false);
        connection.setRequestMethod(method.toString());
        connection.setConnectTimeout(connectionTimeout);
        connection.setReadTimeout(readTimeout);
        if (requestProperties != null) {
            for (String key : requestProperties.keySet()) {
                connection.addRequestProperty(key, requestProperties.get(key));
            }
        }

        switch (method) {
            case POST:
            case PUT:
                connection.setDoInput(true);
                connection.setDoOutput(true);
                if (requestBody.length() > 0) {
                    BufferedOutputStream os = null;

                    try {
                        os = new BufferedOutputStream(connection.getOutputStream());
                        os.write(requestBody.getBytes());
                        os.flush();
                    } catch (Exception e) {
                        if (os != null) {
                            os.close();
                        }
                        throw e;
                    } finally {
                        try {
                            if (os != null) {
                                os.close();
                            }
                        } catch (IOException e) {
                            LogUtils.devLog(e.getMessage());
                        }
                    }
                }
                break;
            default:
                connection.setUseCaches(false);
                break;
        }

        return connection;
    }
}
