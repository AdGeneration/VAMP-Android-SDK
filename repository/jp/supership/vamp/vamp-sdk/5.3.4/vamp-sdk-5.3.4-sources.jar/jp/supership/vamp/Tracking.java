package jp.supership.vamp;

import android.text.TextUtils;

import androidx.annotation.NonNull;
import androidx.annotation.VisibleForTesting;

import jp.supership.sscore.vamp.type.Optional;
import jp.supership.vamp.core.http.HttpRequest;
import jp.supership.vamp.core.http.HttpResponse;
import jp.supership.vamp.core.http.IHttpClient;
import jp.supership.vamp.core.http.IHttpClientListener;
import jp.supership.vamp.core.logging.LogUtils;

import java.net.MalformedURLException;
import java.net.URL;

final class Tracking {
    /** インスタンスを生成できません。詳細はmessageを参照してください */
    static final class CanNotInstantiateException extends Exception {
        CanNotInstantiateException(@NonNull String message) {
            super(message);
        }
    }

    static final String EVENT_IMPRESSION = "impression";
    static final String EVENT_START = "start";
    static final String EVENT_COMPLETE = "complete";
    static final String EVENT_BEACON = "beacon";
    static final String EVENT_VIEW = "view";

    @NonNull private final String event;
    @NonNull private final URL url;
    @NonNull private final IHttpClient httpClient;
    private boolean done;

    @VisibleForTesting
    Tracking(
            @NonNull final String event,
            @NonNull final String urlString,
            @NonNull final IHttpClient httpClient)
            throws CanNotInstantiateException {
        if (TextUtils.isEmpty(event)) {
            throw new CanNotInstantiateException("Tracking: event is empty.");
        }
        this.event = event;

        if (TextUtils.isEmpty(urlString)) {
            throw new CanNotInstantiateException("Tracking(" + event + "): urlString is empty.");
        }

        try {
            this.url = new URL(urlString);
        } catch (MalformedURLException e) {
            throw new CanNotInstantiateException("Tracking(" + event + "): " + e);
        }

        final String protocol = url.getProtocol();
        if (!protocol.equals("http") && !protocol.equals("https")) {
            throw new CanNotInstantiateException(
                    "Tracking(" + event + "): protocol is not http(s).");
        }

        this.httpClient = httpClient;
    }

    @NonNull
    static Optional<Tracking> impression(
            @NonNull final String urlString, @NonNull final IHttpClient httpClient) {
        try {
            return Optional.of(new Tracking(EVENT_IMPRESSION, urlString, httpClient));
        } catch (CanNotInstantiateException e) {
            LogUtils.d(e.getMessage());
            return Optional.empty();
        }
    }

    @NonNull
    static Optional<Tracking> start(
            @NonNull final String urlString, @NonNull final IHttpClient httpClient) {
        try {
            return Optional.of(new Tracking(EVENT_START, urlString, httpClient));
        } catch (CanNotInstantiateException e) {
            LogUtils.d(e.getMessage());
            return Optional.empty();
        }
    }

    @NonNull
    static Optional<Tracking> complete(
            @NonNull final String urlString, @NonNull final IHttpClient httpClient) {
        try {
            return Optional.of(new Tracking(EVENT_COMPLETE, urlString, httpClient));
        } catch (CanNotInstantiateException e) {
            LogUtils.d(e.getMessage());
            return Optional.empty();
        }
    }

    @NonNull
    static Optional<Tracking> beacon(
            @NonNull final String urlString, @NonNull final IHttpClient httpClient) {
        try {
            return Optional.of(new Tracking(EVENT_BEACON, urlString, httpClient));
        } catch (CanNotInstantiateException e) {
            LogUtils.d(e.getMessage());
            return Optional.empty();
        }
    }

    @NonNull
    static Optional<Tracking> view(
            @NonNull final String urlString, @NonNull final IHttpClient httpClient) {
        try {
            return Optional.of(new Tracking(EVENT_VIEW, urlString, httpClient));
        } catch (CanNotInstantiateException e) {
            LogUtils.d(e.getMessage());
            return Optional.empty();
        }
    }

    void send() {
        send(
                new IHttpClientListener() {
                    @Override
                    public void onSuccess(HttpResponse response) {
                        LogUtils.d(event + " beacon succeeded.");
                    }

                    @Override
                    public void onFail(String errorMsg) {
                        LogUtils.d(event + " beacon failed. error: " + errorMsg);
                    }
                });
    }

    private void send(IHttpClientListener listener) {
        if (done) {
            LogUtils.d("Tracking(" + event + "): already done.");
            return;
        }

        done = true;

        httpClient.send(HttpRequest.get(url), listener);
    }

    @VisibleForTesting
    boolean isDone() {
        return done;
    }
}
