package jp.supership.vamp;

import android.text.TextUtils;

import androidx.annotation.Nullable;

/** ユーザ識別ID。アプリによって定義された任意のIDになります */
final class RewardKey {
    /** インスタンスを生成できません。詳細はmessageを参照してください */
    static class CanNotInstantiateException extends Exception {
        CanNotInstantiateException(String message) {
            super(message);
        }
    }

    private static final Object LOCK_OBJECT = new Object();

    /** アプリから渡された任意のユーザ識別ID。 この値はクラウドログに送信され、ユーザ単位の解析に利用されます */
    @Nullable private static RewardKey appUserKey;

    final String value;

    RewardKey(final String value) throws CanNotInstantiateException {
        if (TextUtils.isEmpty(value)) {
            throw new CanNotInstantiateException("The reward key is null or empty.");
        }

        String key = value.trim();

        if (TextUtils.isEmpty(key)) {
            throw new CanNotInstantiateException("The reward key is empty.");
        }

        if (key.length() > 128) {
            throw new CanNotInstantiateException(
                    "The length of the reward key must be less than 128.");
        }

        this.value = key;
    }

    static void setAppUserKey(@Nullable RewardKey rewardKey) {
        synchronized (LOCK_OBJECT) {
            appUserKey = rewardKey;
        }
    }

    @Nullable
    static RewardKey getAppUserKey() {
        return appUserKey;
    }
}
