package jp.supership.vamp.player;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

final class PlayerActivityEvent {
    static final int EVENT_BEGIN_PLAYBACK = 0x01;
    static final int EVENT_END_PLAYBACK = 0x01 << 1;
    static final int EVENT_RESUME = 0x01 << 2;
    static final int EVENT_PAUSE = 0x01 << 3;
    static final int EVENT_UNMUTE = 0x01 << 4;
    static final int EVENT_MUTE = 0x01 << 5;
    static final int EVENT_CLOSE = 0x01 << 6;
    static final int EVENT_FAIL = 0x01 << 7;
    static final int EVENT_CLICK = 0x01 << 8;

    private final int event;
    @Nullable final VAMPPlayerError error;
    final boolean isUserCanceled;

    PlayerActivityEvent(final int event) {
        this(event, null, false);
    }

    PlayerActivityEvent(
            final int event, @Nullable final VAMPPlayerError error, final boolean isUserCanceled) {
        this.event = event;
        this.error = error;
        this.isUserCanceled = isUserCanceled;
    }

    @NonNull
    static PlayerActivityEvent failed(@NonNull final VAMPPlayerError error) {
        return new PlayerActivityEvent(EVENT_FAIL, error, false);
    }

    @NonNull
    static PlayerActivityEvent playbackEnded(final boolean isUserCanceled) {
        return new PlayerActivityEvent(EVENT_END_PLAYBACK, null, isUserCanceled);
    }

    boolean isBeginPlayback() {
        return (event & EVENT_BEGIN_PLAYBACK) != 0;
    }

    boolean isEndPlayback() {
        return (event & EVENT_END_PLAYBACK) != 0;
    }

    boolean isResume() {
        return (event & EVENT_RESUME) != 0;
    }

    boolean isPause() {
        return (event & EVENT_PAUSE) != 0;
    }

    boolean isUnmute() {
        return (event & EVENT_UNMUTE) != 0;
    }

    boolean isMute() {
        return (event & EVENT_MUTE) != 0;
    }

    boolean isClose() {
        return (event & EVENT_CLOSE) != 0;
    }

    boolean isFail() {
        return (event & EVENT_FAIL) != 0;
    }

    boolean isClick() {
        return (event & EVENT_CLICK) != 0;
    }
}
