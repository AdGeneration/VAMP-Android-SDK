package jp.supership.vamp.mediation;

import androidx.annotation.NonNull;

public interface AdapterEventListener {
    void onEvent(@NonNull Event event);
}
