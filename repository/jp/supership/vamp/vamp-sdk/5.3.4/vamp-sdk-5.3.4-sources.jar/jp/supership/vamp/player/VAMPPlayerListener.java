package jp.supership.vamp.player;

import android.content.Context;

import androidx.annotation.Nullable;

public interface VAMPPlayerListener {
    void onBeginPlayback();

    void onEndPlayback(boolean userCancel);

    void onResumeVideo();

    void onPauseVideo();

    void onUnmuteVideo();

    void onMuteVideo();

    void onClick();

    void onClose();

    void onFail(@Nullable VAMPPlayerError error);

    EndCard onShowEndCard(Context context);
}
