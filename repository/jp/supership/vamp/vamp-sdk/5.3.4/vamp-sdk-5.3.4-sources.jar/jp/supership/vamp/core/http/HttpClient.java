package jp.supership.vamp.core.http;

import androidx.annotation.NonNull;
import androidx.annotation.VisibleForTesting;

public class HttpClient {
    private static IHttpClient impl = null;

    @NonNull
    public static IHttpClient newInstance() {
        return new HttpClientImpl();
    }

    @Deprecated
    public static IHttpClient getInstance() {
        if (impl == null) {
            synchronized (HttpClient.class) {
                if (impl == null) {
                    impl = new HttpClientImpl();
                }
            }
        }

        return impl;
    }

    @Deprecated
    @VisibleForTesting(otherwise = VisibleForTesting.PRIVATE)
    public static void injectHttpClient(IHttpClient httpClient) {
        synchronized (HttpClient.class) {
            impl = httpClient;
        }
    }
}
