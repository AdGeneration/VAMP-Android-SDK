package jp.supership.vamp.core.vast;

import android.text.TextUtils;
import android.util.Patterns;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.Serializable;
import java.net.MalformedURLException;
import java.net.URL;

public final class VASTJavaScriptResource implements Serializable {
    /** インスタンスを生成できません。詳細はmessageを参照してください */
    public static final class CanNotInstantiateException extends Exception {
        CanNotInstantiateException(@NonNull String message) {
            super(message);
        }
    }

    @Nullable public final String apiFramework;
    public final boolean isBrowserOptional;
    @NonNull public final URL javaScript;

    public VASTJavaScriptResource(
            @Nullable final String apiFramework,
            final boolean browserOptional,
            @Nullable final String javaScript)
            throws CanNotInstantiateException {
        this.apiFramework = apiFramework;
        isBrowserOptional = browserOptional;

        if (TextUtils.isEmpty(javaScript)) {
            throw new CanNotInstantiateException("javaScript is null or empty.");
        }
        assert javaScript != null;

        final String js = excludeWhitespaceCRLF(javaScript);
        if (TextUtils.isEmpty(js)) {
            throw new CanNotInstantiateException("js is null or empty.");
        }

        if (!Patterns.WEB_URL.matcher(js).matches()) {
            throw new CanNotInstantiateException("The javaScript URL is invalid format.");
        }
        try {
            this.javaScript = new URL(js);
        } catch (MalformedURLException e) {
            throw new CanNotInstantiateException(e.toString());
        }
    }

    @NonNull
    private static String excludeWhitespaceCRLF(@NonNull String url) {
        return url.replaceAll("\\n", "").replaceAll("\\r", "").replaceAll("\\s", "");
    }
}
