package jp.supership.vamp.core.error;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public final class VAMPInternalError {
    public enum Code {
        NETWORK_ERROR,
        XML_PARSE_ERROR,
        IO_ERROR,
        CACHE_SERVICE_ERROR,
        EXCEED_FILE_SIZE,
        FAILED_TO_PREPARE_MEDIA,
        FILE_NOT_FOUND,
        HARDWARE_ACCELERATION_DISABLED,
        HTTP_REQUEST_TIMEOUT,
        MEDIA_ERROR_UNKNOWN,
        MOVIE_FORCED_CLOSED,
        NEED_CONNECTION,
        NO_AD,
        PARSE_ERROR,
        SERVER_ERROR,
        SETTING_ERROR,
        TIMEOUT,
        UNKNOWN,
        USER_CANCEL
    }

    @NonNull public final Code code;
    @NonNull public final String message;

    public VAMPInternalError(@NonNull final Code code, @Nullable final String message) {
        this.code = code;
        this.message = message != null ? message : "";
    }
}
