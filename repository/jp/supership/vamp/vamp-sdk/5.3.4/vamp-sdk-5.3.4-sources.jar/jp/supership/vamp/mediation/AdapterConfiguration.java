package jp.supership.vamp.mediation;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import jp.supership.vamp.VAMP;
import jp.supership.vamp.VAMPPrivacySettings;

import java.net.URL;
import java.util.HashMap;
import java.util.Map;

public final class AdapterConfiguration {
    @NonNull private final String placementId;
    @NonNull private final String adId;
    @NonNull private final Map<String, String> mediationParams;
    @NonNull private final Map<String, String> adParams;
    @NonNull private final Map<String, String> bidderParams;
    @NonNull private final String vastXml;
    @Nullable private final URL landingUrl;
    private final boolean testMode;
    private final boolean debugMode;
    @NonNull private final VAMPPrivacySettings.ChildDirected childDirected;
    @NonNull private final VAMPPrivacySettings.UnderAgeOfConsent underAgeOfConsent;
    @NonNull private final VAMPPrivacySettings.ConsentStatus consentStatus;

    private AdapterConfiguration(
            @NonNull final String placementId,
            @NonNull final String adId,
            @NonNull final Map<String, String> mediationParams,
            @NonNull final Map<String, String> adParams,
            @NonNull final Map<String, String> bidderParams,
            @NonNull final String vastXml,
            @Nullable final URL landingUrl) {
        this.placementId = placementId;
        this.adId = adId;
        this.mediationParams = mediationParams;
        this.adParams = adParams;
        this.bidderParams = bidderParams;
        this.vastXml = vastXml;
        this.landingUrl = landingUrl;
        testMode = VAMP.isTestMode();
        debugMode = VAMP.isDebugMode();
        childDirected = VAMPPrivacySettings.getChildDirected();
        underAgeOfConsent = VAMPPrivacySettings.getUnderAgeOfConsent();
        consentStatus = VAMPPrivacySettings.getConsentStatus();
    }

    public static final class Builder {
        @NonNull private String placementId = "";
        @NonNull private final String adId;
        @NonNull private final Map<String, String> mediationParams;
        @NonNull private Map<String, String> adParams = new HashMap<>();
        @NonNull private Map<String, String> bidderParams = new HashMap<>();
        @NonNull private String vastXml = "";
        @Nullable private URL landingUrl;

        public Builder(
                @NonNull final String adId, @NonNull final Map<String, String> mediationParams) {
            this.adId = adId;
            this.mediationParams = mediationParams;
        }

        @NonNull
        public Builder withPlacementId(@NonNull final String placementId) {
            this.placementId = placementId;
            return this;
        }

        @NonNull
        public Builder withVastXml(@Nullable final String vastXml) {
            this.vastXml = vastXml != null ? vastXml : "";
            return this;
        }

        @NonNull
        public Builder withLandingUrl(@Nullable final URL landingUrl) {
            this.landingUrl = landingUrl;
            return this;
        }

        @NonNull
        public Builder withAdParams(@NonNull final Map<String, String> adParams) {
            this.adParams = adParams;
            return this;
        }

        @NonNull
        public Builder withBidderParams(@NonNull final Map<String, String> bidderParams) {
            this.bidderParams = bidderParams;
            return this;
        }

        @NonNull
        public AdapterConfiguration build() {
            return new AdapterConfiguration(
                    placementId,
                    adId,
                    mediationParams,
                    adParams,
                    bidderParams,
                    vastXml,
                    landingUrl);
        }
    }

    @NonNull
    public String getPlacementID() {
        return placementId;
    }

    @NonNull
    public String getAdID() {
        return adId;
    }

    @NonNull
    public Map<String, String> getMediationParams() {
        return new HashMap<>(mediationParams);
    }

    @NonNull
    public Map<String, String> getBidderParams() {
        return new HashMap<>(bidderParams);
    }

    @NonNull
    public Map<String, String> getAdParams() {
        return new HashMap<>(adParams);
    }

    @NonNull
    public String getVastXml() {
        return vastXml;
    }

    @Nullable
    public URL getLandingUrl() {
        return landingUrl;
    }

    public boolean isTestMode() {
        return testMode;
    }

    public boolean isDebugMode() {
        return debugMode;
    }

    @NonNull
    public VAMPPrivacySettings.ChildDirected getChildDirected() {
        return childDirected;
    }

    @NonNull
    public VAMPPrivacySettings.UnderAgeOfConsent getUnderAgeOfConsent() {
        return underAgeOfConsent;
    }

    @NonNull
    public VAMPPrivacySettings.ConsentStatus getConsentStatus() {
        return consentStatus;
    }
}
