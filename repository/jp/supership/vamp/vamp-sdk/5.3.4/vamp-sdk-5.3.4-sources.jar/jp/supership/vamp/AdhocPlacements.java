package jp.supership.vamp;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;

final class AdhocPlacements {

    private static final String JSON_SERVER_URL_FORMAT =
            "https://d2dylwb3shzel1.cloudfront.net/adid/%s.json";
    private static final String ADHOC_PLACEMENTS_IDS_KEY = "jp.supership.vamp.ADHOC_PLACEMENT_IDS";

    static boolean contains(String placementId, Context context) {
        PackageManager pm = context.getPackageManager();
        ApplicationInfo info;

        try {
            info = pm.getApplicationInfo(context.getPackageName(), PackageManager.GET_META_DATA);
        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }

        if (info.metaData.containsKey(ADHOC_PLACEMENTS_IDS_KEY)) {
            String placementIds;

            try {
                placementIds = (String) info.metaData.get(ADHOC_PLACEMENTS_IDS_KEY);
            } catch (ClassCastException e) {
                placementIds = "" + info.metaData.getInt(ADHOC_PLACEMENTS_IDS_KEY);
            }

            if (placementIds != null) {
                String[] ids = placementIds.split(",");

                for (String id : ids) {
                    if (id.trim().equals(placementId)) {
                        return true;
                    }
                }
            }
        }

        return false;
    }

    static AdServerUrl getUrl(String placementId, Context context)
            throws AdServerUrl.CanNotInstantiateException {
        if (!contains(placementId, context)) {
            throw new AdServerUrl.CanNotInstantiateException(
                    "This placementId doesn't support the adhoc mode.");
        }

        return new AdServerUrl(String.format(JSON_SERVER_URL_FORMAT, placementId));
    }
}
