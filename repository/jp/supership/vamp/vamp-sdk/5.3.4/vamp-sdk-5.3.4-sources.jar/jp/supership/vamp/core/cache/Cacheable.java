package jp.supership.vamp.core.cache;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

/** Created by masaki.ando on 2019/03/12. */
public interface Cacheable {
    @Nullable
    CacheData retrieveData(@NonNull String key) throws CacheException;

    boolean storeData(@NonNull CacheData cacheData, @NonNull String key) throws CacheException;
}
