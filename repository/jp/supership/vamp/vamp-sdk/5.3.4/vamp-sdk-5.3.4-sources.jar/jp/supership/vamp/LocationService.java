package jp.supership.vamp;

import android.content.Context;
import android.text.TextUtils;

import androidx.annotation.NonNull;
import androidx.annotation.VisibleForTesting;

import jp.supership.sscore.vamp.type.Optional;
import jp.supership.vamp.core.cache.CacheData;
import jp.supership.vamp.core.cache.CacheException;
import jp.supership.vamp.core.cache.Cacheable;
import jp.supership.vamp.core.cache.MemoryCache;
import jp.supership.vamp.core.http.HttpClient;
import jp.supership.vamp.core.http.HttpContent;
import jp.supership.vamp.core.http.HttpMethod;
import jp.supership.vamp.core.http.HttpRequest;
import jp.supership.vamp.core.http.HttpResponse;
import jp.supership.vamp.core.http.IHttpClient;
import jp.supership.vamp.core.http.IHttpClientListener;
import jp.supership.vamp.core.logging.LogUtils;
import jp.supership.vamp.utils.JsonUtils;

import org.json.JSONObject;

import java.util.HashMap;

/** Created by masaki.ando on 2022/10/05. */
final class LocationService {
    static final class InvalidParameterException extends Exception {
        InvalidParameterException(String message) {
            super(message);
        }
    }

    static final class Location extends VAMPLocation {
        @NonNull public final String ip;

        Location(@NonNull String countryCode, @NonNull String region, @NonNull String ip) {
            super(countryCode, region);

            this.ip = ip;
        }

        /**
         * JSONデータからインスタンスを生成します。 バリデーションエラーのときは例外が発生し、インスタンスは生成されません
         *
         * @param jsonObject 以下のJSON <code>
         *                   {
         *                   "isoCode": String,
         *                   "region": String,
         *                   "ip": String,
         *                   ["error"|undefined]: { "message": String }
         *                   ["message"|undefined]: String
         *                   }
         *                   </code>
         * @throws InvalidParameterException バリデーションエラーが発生したとき
         */
        @NonNull
        static Location from(@NonNull JSONObject jsonObject) throws InvalidParameterException {
            String isoCode = jsonObject.optString("isoCode");

            if (TextUtils.isEmpty(isoCode)) {
                JSONObject error = jsonObject.optJSONObject("error");
                String errMsg;
                if (error != null) {
                    errMsg = error.optString("message");
                } else {
                    errMsg = jsonObject.optString("message");
                }
                throw new InvalidParameterException(errMsg);
            }

            String region = jsonObject.optString("region");

            String ip = jsonObject.optString("ip");

            return new Location(isoCode, region, ip);
        }

        /** 国コード不明のインスタンスを生成します */
        @NonNull
        static Location unknown() {
            return new Location(VAMPLocation.UNKNOWN_COUNTRY_CODE, "", "");
        }

        @NonNull
        @Override
        public String toString() {
            return "Location { countryCode="
                    + getCountryCode()
                    + " region="
                    + getRegion()
                    + " ip="
                    + ip
                    + " }";
        }

        boolean isUnknown() {
            return VAMPLocation.UNKNOWN_COUNTRY_CODE.equals(getCountryCode());
        }
    }

    interface LocationFetchListener {
        void onLocationFetched(@NonNull Location location);
    }

    interface ILocationProvider {
        /** 現在のプロバイダでロケーションが取得できなかった場合、 このメソッドが返すプロバイダで取得を再試行します */
        Optional<ILocationProvider> getNextProvider();

        /** 指定プロバイダを現在のプロバイダのnextProviderにセットします */
        void setNextProvider(Optional<ILocationProvider> provider);

        /** ロケーションを取得します */
        void fetch(@NonNull LocationFetchListener listener);
    }

    static class LocationProvider implements ILocationProvider {
        static final class Config {
            @NonNull String apiName;
            @NonNull String url;

            Config(@NonNull final String apiName, @NonNull final String url) {
                this.apiName = apiName;
                this.url = url;
            }
        }

        private static final String TOKEN_KEY = "X-SO-USE-GEOIP-TOKEN";
        private static final String TOKEN_VALUE =
                "CmmlkzMymCQAjeHl6PHUMshDqgWWBWDKDTw5hluodZLhYcnc";

        private static final int CONNECTION_TIMEOUT_MS = 10000;

        @VisibleForTesting @NonNull final Config config;
        @NonNull private final IHttpClient httpClient;
        private Optional<ILocationProvider> nextProvider = Optional.empty();

        LocationProvider(@NonNull Config config, @NonNull IHttpClient httpClient) {
            this.config = config;
            this.httpClient = httpClient;
        }

        @Override
        public Optional<ILocationProvider> getNextProvider() {
            return nextProvider;
        }

        @Override
        public void setNextProvider(Optional<ILocationProvider> provider) {
            nextProvider = provider;
        }

        @Override
        public void fetch(@NonNull final LocationFetchListener listener) {
            LogUtils.d("Fetch the location using api: " + config.apiName);
            LogUtils.devLog("url: " + config.url);

            HashMap<String, String> headers = new HashMap<>();
            headers.put(TOKEN_KEY, TOKEN_VALUE);

            HttpRequest request =
                    new HttpRequest(config.url)
                            .setRequestProperty(headers)
                            .setMethod(HttpMethod.GET)
                            .setConnectionTimeout(CONNECTION_TIMEOUT_MS);

            httpClient.send(
                    request,
                    new IHttpClientListener() {
                        @Override
                        public void onSuccess(HttpResponse response) {
                            try {
                                if (response == null) {
                                    throw new Exception("response is null.");
                                }

                                int statusCode = response.getStatusCode();
                                if (statusCode != 200) {
                                    throw new Exception("statusCode is not 200: " + statusCode);
                                }

                                HttpContent content = response.getContent();
                                if (content == null) {
                                    throw new Exception("response body is null.");
                                }

                                String body = content.readAsString();
                                if (TextUtils.isEmpty(body)) {
                                    throw new Exception("response body is empty.");
                                }

                                JSONObject jsonObject = JsonUtils.fromJson(body);
                                LogUtils.devLog("response: " + jsonObject.toString(4));

                                Location location = Location.from(jsonObject);

                                LogUtils.d("Fetched the location using api: " + config.apiName);
                                LogUtils.devLog("fetched location: " + location);

                                listener.onLocationFetched(location);
                            } catch (Exception e) {
                                LogUtils.d(
                                        "Failed to fetch the location using api: "
                                                + config.apiName
                                                + "\n"
                                                + e.getMessage());

                                listener.onLocationFetched(Location.unknown());
                            }
                        }

                        @Override
                        public void onFail(String errorMessage) {
                            LogUtils.d(
                                    "Failed to request using api: "
                                            + config.apiName
                                            + ". "
                                            + errorMessage);

                            listener.onLocationFetched(Location.unknown());
                        }
                    });
        }
    }

    interface IFetchLocation {
        /** ロケーションを取得します */
        void fetch(@NonNull LocationFetchListener listener);
    }

    static final class FetchLocation implements IFetchLocation {
        private static final String CACHE_KEY = "jp.supership.vamp.LocationService.FetchLocation";
        private static final int CACHE_TIME_SEC = 12 * 60 * 60;

        private static FetchLocation instance = null;

        @NonNull private final ILocationProvider provider;
        @NonNull private final Optional<Cacheable> cacheHandler;

        @VisibleForTesting
        FetchLocation(
                @NonNull ILocationProvider provider, @NonNull Optional<Cacheable> cacheHandler) {
            this.provider = provider;
            this.cacheHandler = cacheHandler;
        }

        /**
         * シングルトンインスタンスを返します
         *
         * @param appContext アプリケーションコンテキスト
         */
        @NonNull
        static synchronized FetchLocation getInstance(Optional<Context> appContext) {
            if (instance == null) {
                ILocationProvider provider1 =
                        new LocationProvider(
                                new LocationProvider.Config(
                                        "locationFromIP",
                                        "https://asia-northeast1-ss-vamp.cloudfunctions.net/locationFromIP"),
                                HttpClient.getInstance());
                ILocationProvider provider2 =
                        new LocationProvider(
                                new LocationProvider.Config(
                                        "geoip", "https://d.socdm.com/aux/geoip"),
                                HttpClient.getInstance());
                provider1.setNextProvider(Optional.of(provider2));

                Cacheable cacheHandler = MemoryCache.getInstance();

                instance = new FetchLocation(provider1, Optional.of(cacheHandler));
            }
            return instance;
        }

        @Override
        public void fetch(@NonNull LocationFetchListener listener) {
            try {
                Location cache = locationCache().unwrap();
                listener.onLocationFetched(cache);
                return;
            } catch (Optional.NotPresentException ignored) {
            }

            // Use 1st provider.
            fetch(provider, listener);
        }

        private void fetch(
                @NonNull final ILocationProvider locationProvider,
                @NonNull final LocationFetchListener listener) {
            locationProvider.fetch(
                    new LocationFetchListener() {
                        @Override
                        public void onLocationFetched(@NonNull Location location) {
                            if (location.isUnknown()
                                    && locationProvider.getNextProvider().isPresent()) {
                                fetch(locationProvider.getNextProvider().forced(), listener);
                                return;
                            }

                            // 取得に失敗しても(isUnknown=trueでも)通信回数を抑制するため、
                            // 期限付きのキャッシュを生成する
                            CacheData cacheData = new CacheData(location, CACHE_TIME_SEC);
                            try {
                                cacheHandler.unwrap().storeData(cacheData, CACHE_KEY);
                            } catch (Exception e) {
                                LogUtils.d("Failed to create a cache: " + e);
                            }

                            listener.onLocationFetched(location);
                        }
                    });
        }

        private Optional<Location> locationCache() {
            try {
                CacheData cacheData = cacheHandler.unwrap().retrieveData(CACHE_KEY);

                if (cacheData == null || !cacheData.isValid()) {
                    return Optional.empty();
                }

                Location location = (Location) cacheData.value;
                LogUtils.d("Use the location cache.");

                return Optional.of(location);
            } catch (CacheException | Optional.NotPresentException e) {
                return Optional.empty();
            }
        }
    }

    private LocationService() {}
}
