package jp.supership.vamp;

import androidx.annotation.NonNull;

/** 国コードを取得するためのリスナー */
public interface VAMPGetLocationListener {
    /**
     * {@link VAMP#getLocation(VAMPGetLocationListener)} で国コードを取得した時に通知します。
     *
     * @param location 2文字の国コード（JP、USなど<a
     *     href="https://ja.wikipedia.org/wiki/ISO_3166-1">ISO3166-1</a>）
     */
    void onLocation(@NonNull VAMPLocation location);
}
