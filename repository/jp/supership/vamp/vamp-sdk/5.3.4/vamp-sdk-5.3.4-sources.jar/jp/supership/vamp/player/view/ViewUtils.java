package jp.supership.vamp.player.view;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;

import java.io.IOException;
import java.io.InputStream;

/** Created by sanojimaru on 15/06/02. */
final class ViewUtils {
    static void removeFromParent(View view) {
        if (view == null || view.getParent() == null) {
            return;
        }

        if (view.getParent() instanceof ViewGroup) {
            ((ViewGroup) view.getParent()).removeView(view);
        }
    }

    static void setBackground(View view, Drawable d) {
        setBackgroundNewApi(view, d);
    }

    private static void setBackgroundNewApi(@NonNull View view, Drawable d) {
        view.setBackground(d);
    }

    static void setImageFromAssets(@NonNull Context context, @NonNull ImageView view, String path)
            throws IOException {
        InputStream is = context.getResources().getAssets().open(path);
        Bitmap bm = BitmapFactory.decodeStream(is);
        view.setImageBitmap(bm);
    }

    static void clearChild(@NonNull ViewGroup parent) {
        int ct = parent.getChildCount();
        View view;
        for (int i = 0; i < ct; i++) {
            view = parent.getChildAt(i);
            if (view instanceof ViewGroup) {
                clearChild((ViewGroup) view);
            } else if (view instanceof ImageView) {
                Drawable drawable = ((ImageView) view).getDrawable();
                if (drawable instanceof BitmapDrawable) {
                    Bitmap bitmap = ((BitmapDrawable) drawable).getBitmap();
                    if (bitmap != null) {
                        bitmap.recycle();
                    }
                }
                ((ImageView) view).setImageDrawable(null);
            }
            setBackground(view, null);
            view.setOnClickListener(null);
            view.setOnLongClickListener(null);
        }
        parent.removeAllViews();
    }

    private ViewUtils() {}
}
