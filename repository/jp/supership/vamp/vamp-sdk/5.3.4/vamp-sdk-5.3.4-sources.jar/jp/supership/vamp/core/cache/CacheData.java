package jp.supership.vamp.core.cache;

import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;

/** Created by masaki.ando on 2019/03/12. */
public class CacheData implements Serializable {

    private static final SimpleDateFormat DATE_FORMAT =
            new SimpleDateFormat("yyyy/MM/dd HH:mm:ss", Locale.US);

    public final Object value;
    public final String createdAt;
    private final int lifeTime;

    public CacheData(Object value, int lifeTimeSec) {
        this.value = value;
        this.lifeTime = lifeTimeSec;
        this.createdAt = DATE_FORMAT.format(new Date());
    }

    public Date getExpiredAt() {
        try {
            Date created = DATE_FORMAT.parse(createdAt);
            Calendar calendar = new GregorianCalendar();
            calendar.setTime(created);
            calendar.add(Calendar.SECOND, lifeTime);

            return calendar.getTime();
        } catch (ParseException e) {
            return null;
        }
    }

    public boolean isValid() {
        Date expired = getExpiredAt();

        if (expired != null) {
            Date now = new Date();

            return now.before(expired);
        }

        return false;
    }
}
