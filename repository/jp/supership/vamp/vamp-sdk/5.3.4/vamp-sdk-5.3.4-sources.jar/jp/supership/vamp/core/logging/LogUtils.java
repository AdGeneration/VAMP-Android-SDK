package jp.supership.vamp.core.logging;

import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import jp.supership.sscore.vamp.logger.SSCoreLogger;
import jp.supership.sscore.vamp.logger.SSCoreNoticeLogger;
import jp.supership.vamp.BuildConfig;

public class LogUtils {
    static {
        SSCoreNoticeLogger.setLogger(new SSCoreNoticeLogger.AndroidLogger("VAMPSDK"));
    }

    public interface Logger {
        void setLogLevel(int logLevel);

        void v(@NonNull String tag, @NonNull String message);

        void d(@NonNull String tag, @NonNull String message);

        void i(@NonNull String tag, @NonNull String message);

        void w(@NonNull String tag, @NonNull String message, @Nullable Throwable e);

        void e(@NonNull String tag, @NonNull String message, @Nullable Throwable e);

        /** 開発用ログを出力します */
        void dev(@NonNull String tag, @NonNull String message);
    }

    public static final class AndroidLogger implements Logger {
        private int logLevel = Log.INFO;

        @Override
        public void setLogLevel(int logLevel) {
            this.logLevel = logLevel;
        }

        @Override
        public void v(@NonNull String tag, @NonNull String message) {
            if (loggable(Log.VERBOSE)) {
                Log.v(tag, message);
            }
        }

        @Override
        public void d(@NonNull String tag, @NonNull String message) {
            if (loggable(Log.DEBUG)) {
                Log.d(tag, message);
            }
        }

        @Override
        public void i(@NonNull String tag, @NonNull String message) {
            if (loggable(Log.INFO)) {
                Log.i(tag, message);
            }
        }

        @Override
        public void w(@NonNull String tag, @NonNull String message, @Nullable Throwable e) {
            if (loggable(Log.WARN)) {
                if (e == null) {
                    Log.w(tag, message);
                } else {
                    Log.w(tag, message, e);
                }
            }
        }

        @Override
        public void e(@NonNull String tag, @NonNull String message, @Nullable Throwable e) {
            if (loggable(Log.ERROR)) {
                if (e == null) {
                    Log.e(tag, message);
                } else {
                    Log.e(tag, message, e);
                }
            }
        }

        @Override
        public void dev(@NonNull String tag, @NonNull String message) {
            if (BuildConfig.DEV_LOG) {
                Log.e(tag, message);
            }
        }

        private boolean loggable(int level) {
            return level >= logLevel;
        }
    }

    @NonNull public static final String TAG = "VAMPSDK";
    @NonNull private static Logger logger = new AndroidLogger();

    public static synchronized void setLogger(@NonNull Logger logger) {
        LogUtils.logger = logger;
    }

    public static void setLogLevel(int level) {
        logger.setLogLevel(level);

        // SSCoreロガーの有効/無効を設定
        if (level == Log.DEBUG) {
            SSCoreLogger.DEFAULT.level = SSCoreLogger.LogLevel.DEBUG;
            SSCoreLogger.DEVELOPMENT.level = SSCoreLogger.LogLevel.DEBUG;
        } else {
            SSCoreLogger.DEFAULT.level = SSCoreLogger.LogLevel.OFF;
            SSCoreLogger.DEVELOPMENT.level = SSCoreLogger.LogLevel.OFF;
        }
    }

    public static void v(String message) {
        logv(getMetaInfo() + null2str(message));
    }

    public static void v(String message, boolean displayMetaInfo) {
        logv((displayMetaInfo ? getMetaInfo() : "") + null2str(message));
    }

    public static void d(String message) {
        logd(getMetaInfo() + null2str(message));
    }

    public static void d(String message, boolean displayMetaInfo) {
        logd((displayMetaInfo ? getMetaInfo() : "") + null2str(message));
    }

    public static void i(String message) {
        logi(getMetaInfo() + null2str(message));
    }

    public static void i(String message, boolean displayMetaInfo) {
        logi((displayMetaInfo ? getMetaInfo() : "") + null2str(message));
    }

    public static void w(String message) {
        logw(getMetaInfo() + null2str(message), null);
    }

    public static void w(String message, boolean displayMetaInfo) {
        logw((displayMetaInfo ? getMetaInfo() : "") + null2str(message), null);
    }

    public static void w(String message, Throwable e) {
        logw(getMetaInfo() + null2str(message), e);
    }

    public static void w(String message, Throwable e, boolean displayMetaInfo) {
        logw((displayMetaInfo ? getMetaInfo() : "") + null2str(message), e);
    }

    public static void e(String message) {
        loge(getMetaInfo() + null2str(message), null);
    }

    public static void e(String message, boolean displayMetaInfo) {
        loge((displayMetaInfo ? getMetaInfo() : "") + null2str(message), null);
    }

    public static void e(String message, Throwable e) {
        loge(getMetaInfo() + null2str(message), e);
    }

    public static void e(String message, Throwable e, boolean displayMetaInfo) {
        loge((displayMetaInfo ? getMetaInfo() : "") + null2str(message), e);
    }

    private static void logv(String message) {
        logger.v(TAG, message);
    }

    private static void logd(String message) {
        logger.d(TAG, message);
    }

    private static void logi(String message) {
        logger.i(TAG, message);
    }

    private static void logw(String message, Throwable e) {
        logger.w(TAG, message, e);
    }

    private static void loge(String message, Throwable e) {
        logger.e(TAG, message, e);
    }

    private static String null2str(String string) {
        if (string == null) {
            return "(null)";
        }
        return string;
    }

    /**
     * ログ呼び出し元のメタ情報を取得する
     *
     * @return [className#methodName:line th:threadName]
     */
    private static String getMetaInfo() {
        // スタックトレースから情報を取得 // 0: VM, 1: Thread, 2: LogUtil#getMetaInfo, 3:
        // LogUtil#d など, 4: 呼び出し元
        final StackTraceElement element = Thread.currentThread().getStackTrace()[4];
        // クラス名、メソッド名、行数を取得
        final String fullClassName = element.getClassName();
        final String simpleClassName = fullClassName.substring(fullClassName.lastIndexOf(".") + 1);
        final String methodName = element.getMethodName();
        final int lineNumber = element.getLineNumber();
        // メタ情報
        return "["
                + simpleClassName
                + "#"
                + methodName
                + ":"
                + lineNumber
                + " th:"
                + Thread.currentThread().getName()
                + "] ";
    }

    // ----------------------------------------
    // 開発中テスト用ログ
    // ----------------------------------------
    private static final String DEV_TAG = TAG + "_DEV";

    public static void devLog(String message) {
        logger.dev(DEV_TAG, getMetaInfo() + null2str(message));
    }
}
