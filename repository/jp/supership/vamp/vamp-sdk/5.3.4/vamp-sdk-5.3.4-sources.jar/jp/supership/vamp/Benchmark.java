package jp.supership.vamp;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import jp.supership.vamp.core.logging.LogUtils;

final class Benchmark {
    @NonNull private final String key;
    private final long startInMilliseconds;

    private Benchmark(@NonNull final String key) {
        this.key = key;
        this.startInMilliseconds = System.currentTimeMillis();
    }

    /**
     * 計測を開始します
     *
     * @param key 任意のキー
     * @return 計測オブジェクト
     */
    @NonNull
    static Benchmark start(@Nullable final String key) {
        return new Benchmark(key == null ? "" : key);
    }

    /**
     * {@link #start(String)}メソッドを呼び出した時からの経過時間をミリ秒単位で返します
     *
     * @return 経過時間
     */
    long getElapsedTimeInMilliseconds() {
        final long elapsed = System.currentTimeMillis() - startInMilliseconds;
        LogUtils.devLog("Benchmark[" + key + "] " + elapsed + "ms");
        return elapsed;
    }

    /**
     * {@link #start(String)}メソッドを呼び出した時からの経過時間を秒単位で返します
     *
     * @return 経過時間
     */
    double getElapsedTimeInSeconds() {
        return getElapsedTimeInMilliseconds() / 1000.0;
    }
}
