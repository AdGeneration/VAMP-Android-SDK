package jp.supership.vamp.mediation;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import jp.supership.vamp.VAMPError;

public final class AdNetworkErrorInfo {
    @NonNull private final String methodName;
    @NonNull private final VAMPError error;
    @Nullable private final String errorMessage;
    @Nullable private final String adNetworkErrorCode;
    @Nullable private final String adNetworkErrorMessage;

    private AdNetworkErrorInfo(
            @NonNull final String methodName,
            @NonNull final VAMPError error,
            @Nullable final String errorMessage,
            @Nullable final String adNetworkErrorCode,
            @Nullable final String adNetworkErrorMessage) {
        this.methodName = methodName;
        this.error = error;
        this.errorMessage = errorMessage;
        this.adNetworkErrorCode = adNetworkErrorCode;
        this.adNetworkErrorMessage = adNetworkErrorMessage;
    }

    public static final class Builder {
        @NonNull private final String methodName;
        @NonNull private final VAMPError error;
        @Nullable private String errorMessage;
        @Nullable private String adNetworkErrorCode;
        @Nullable private String adNetworkErrorMessage;

        /**
         * ビルダーインスタンスを生成します
         *
         * @param methodName エラーが発生したメソッド名
         * @param error VAMP SDKに定義されているエラーコード
         */
        public Builder(@NonNull final String methodName, @NonNull final VAMPError error) {
            this.methodName = methodName;
            this.error = error;
        }

        /**
         * VAMP SDKが生成したエラーメッセージをセットします
         *
         * @param errorMessage エラーメッセージ
         * @return this
         */
        @NonNull
        public Builder setErrorMessage(@Nullable final String errorMessage) {
            this.errorMessage = errorMessage;
            return this;
        }

        /**
         * アドネットワークSDKが返すエラーコードをセットします
         *
         * @param adNetworkErrorCode アドネットワークSDKが返すエラーコード
         * @return this
         */
        @NonNull
        public Builder setAdNetworkErrorCode(@Nullable final String adNetworkErrorCode) {
            this.adNetworkErrorCode = adNetworkErrorCode;
            return this;
        }

        /**
         * アドネットワークSDKが返すエラーメッセージをセットします
         *
         * @param adNetworkErrorMessage アドネットワークSDKが返すエラーメッセージ
         * @return this
         */
        @NonNull
        public Builder setAdNetworkErrorMessage(@Nullable final String adNetworkErrorMessage) {
            this.adNetworkErrorMessage = adNetworkErrorMessage;
            return this;
        }

        @NonNull
        public AdNetworkErrorInfo build() {
            return new AdNetworkErrorInfo(
                    methodName, error, errorMessage, adNetworkErrorCode, adNetworkErrorMessage);
        }
    }

    @NonNull
    @Override
    public String toString() {
        return "AdNetworkErrorInfo("
                + "methodName="
                + methodName
                + ", error="
                + error
                + ", errorMessage="
                + errorMessage
                + ", adNetworkErrorCode="
                + adNetworkErrorCode
                + ", adNetworkErrorMessage="
                + adNetworkErrorMessage
                + ")";
    }

    @NonNull
    public String getMethodName() {
        return methodName;
    }

    @NonNull
    public VAMPError getError() {
        return error;
    }

    @Nullable
    public String getErrorMessage() {
        return errorMessage;
    }

    @Nullable
    public String getAdNetworkErrorCode() {
        return adNetworkErrorCode;
    }

    @Nullable
    public String getAdNetworkErrorMessage() {
        return adNetworkErrorMessage;
    }
}
