package jp.supership.vamp.core.cache;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.os.Environment;
import android.text.TextUtils;

import jp.supership.vamp.core.logging.LogUtils;
import jp.supership.vamp.core.utils.DeviceUtils;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Locale;

public class DiskLruCache {
    // TODO: DiskLruCacheをインタフェースにして、vamp.playerパッケージ内で実装する
    public static final String SHARED_PREFERENCES_NAME = "VAMPPlayerSharedPreferences";
    private static final String CACHE_DIRECTORY_NAME = "jp.supership.vamp.diskLruCache";
    private static final String STORAGE_KEY_CLEANUP = "cleanup";
    private static final Object LOCK_OBJECT = new Object();
    private static final int APP_VERSION = 1;
    // The number of values per cache entry. Must be positive.
    private static final int VALUE_COUNT = 1;
    private static final int DISK_CACHE_INDEX = 0;
    private static DiskLruCacheImpl impl;

    public static synchronized DiskLruCache newInstance(Context context) throws CacheException {
        return new DiskLruCache(context);
    }

    private DiskLruCache(Context context) throws CacheException {
        if (context == null) {
            throw new CacheException("Given `context` is null.");
        }

        if (impl == null || impl.isClosed()) {
            final File cacheDirectory = getDiskCacheDirectory(context);
            if (!cacheDirectory.exists()) {
                if (!cacheDirectory.mkdirs()) {
                    throw new CacheException("Cache directory not created.");
                }
            }
            final long diskCacheSizeBytes = DeviceUtils.diskCacheSizeBytes(cacheDirectory);
            try {
                impl =
                        DiskLruCacheImpl.open(
                                cacheDirectory, APP_VERSION, VALUE_COUNT, diskCacheSizeBytes);
            } catch (IOException e) {
                throw new CacheException(e.getMessage());
            }
        }

        // check cache size on startup
        cleanUp(context);
    }

    private static File getDiskCacheDirectory(final Context context) {
        //        final String cachePath = context.getCacheDir().getPath();
        // TODO:ishii リワードの時のみの分岐が必要になる可能性あり
        // 外部ストレージがあれば外部ストレージを使用するように変更
        File dir = null;
        if (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
            dir = context.getExternalCacheDir();
        }
        if (dir == null) {
            dir = context.getCacheDir();
        }
        final String cachePath = dir.getPath();
        return new File(cachePath + File.separator + CACHE_DIRECTORY_NAME);
    }

    public boolean cachedDataExists(String key) throws CacheException {
        if (impl == null || impl.isClosed()) {
            throw new CacheException("cache closed.");
        }

        synchronized (LOCK_OBJECT) {
            try {
                DiskLruCacheImpl.Snapshot snapshot = impl.get(createValidDiskCacheKey(key));
                return snapshot != null;
            } catch (Exception e) {
                throw new CacheException(e.getMessage());
            }
        }
    }

    public Object retrieveData(String key) throws CacheException {
        if (impl == null || impl.isClosed()) {
            throw new CacheException("cache closed.");
        }

        Object cacheData = null;
        synchronized (LOCK_OBJECT) {
            ObjectInputStream ois = null;

            try {
                DiskLruCacheImpl.Snapshot snapshot = impl.get(createValidDiskCacheKey(key));
                InputStream is = snapshot.getInputStream(DISK_CACHE_INDEX);
                ois = new ObjectInputStream(is);
                cacheData = ois.readObject();
            } catch (Exception e) {
                throw new CacheException(e.getMessage());
            } finally {
                try {
                    if (ois != null) {
                        ois.close();
                    }
                } catch (IOException e) {
                    LogUtils.devLog(e.getMessage());
                }
            }
        }

        return cacheData;
    }

    public boolean storeData(InputStream content, final String key) throws CacheException {
        synchronized (LOCK_OBJECT) {
            if (impl == null || impl.isClosed()) {
                throw new CacheException("cache closed.");
            }

            DiskLruCacheImpl.Editor editor = null;
            OutputStream os = null;
            try {
                editor = impl.edit(createValidDiskCacheKey(key));

                if (editor == null) {
                    throw new CacheException("another edit is in progress.");
                }

                os = new BufferedOutputStream(editor.newOutputStream(DISK_CACHE_INDEX));
                Streams.copyContent(content, os);
                os.flush();

                impl.flush();
                editor.commit();
            } catch (Exception e) {
                try {
                    if (editor != null) {
                        editor.abort();
                    }
                } catch (IOException ignore) {
                    LogUtils.devLog(ignore.getMessage());
                    // ignore
                }

                throw new CacheException(e.getMessage());
            } finally {
                try {
                    if (os != null) {
                        os.close();
                    }
                } catch (IOException e) {
                    LogUtils.devLog(e.getMessage());
                }
            }
        }

        return true;
    }

    public boolean storeData(final Bitmap bitmap, final String key) throws CacheException {
        synchronized (LOCK_OBJECT) {
            if (impl == null || impl.isClosed()) {
                throw new CacheException("cache closed.");
            }

            DiskLruCacheImpl.Editor editor = null;
            OutputStream os = null;
            try {
                editor = impl.edit(createValidDiskCacheKey(key));

                if (editor == null) {
                    throw new CacheException("another edit is in progress.");
                }

                os = new BufferedOutputStream(editor.newOutputStream(DISK_CACHE_INDEX));
                bitmap.compress(Bitmap.CompressFormat.JPEG, 82, os);
                os.flush();

                impl.flush();
                editor.commit();
            } catch (Exception e) {
                try {
                    if (editor != null) {
                        editor.abort();
                    }
                } catch (IOException ignore) {
                    LogUtils.devLog(ignore.getMessage());
                    // ignore
                }

                throw new CacheException(e.getMessage());
            } finally {
                try {
                    if (os != null) {
                        os.close();
                    }
                } catch (IOException e) {
                    LogUtils.devLog(e.getMessage());
                }
            }
        }
        return true;
    }

    public String retrieveFilePath(final String key) {
        try {
            if (impl == null) {
                return null;
            }

            String tmpKey = createValidDiskCacheKey(key);
            if (TextUtils.isEmpty(tmpKey)) {
                return null;
            }

            String extension = "";
            String subKey = tmpKey;
            if (!TextUtils.isEmpty(tmpKey)) {
                int extPos = tmpKey.lastIndexOf("_");
                if (extPos != -1) {
                    extension = "." + tmpKey.substring(extPos + 1, tmpKey.length());
                } else {
                    extPos = tmpKey.length();
                }
                subKey = tmpKey.substring(0, extPos);
            }

            return impl.getDirectory()
                    + File.separator
                    + subKey
                    + "."
                    + DISK_CACHE_INDEX
                    + extension;

        } catch (Exception e) {
            LogUtils.e(e.getMessage());
        }

        return null;
    }

    private void cleanUp(final Context context) throws CacheException {
        if (impl != null && context != null) {
            SharedPreferences sp =
                    context.getSharedPreferences(SHARED_PREFERENCES_NAME, Context.MODE_PRIVATE);
            long nowTime = System.currentTimeMillis();

            if (sp != null) {
                long oldTime = sp.getLong(STORAGE_KEY_CLEANUP, -1);
                if (oldTime == -1 || oldTime <= nowTime - DiskLruCacheImpl.CLEANUP_TIME) {
                    SharedPreferences.Editor editor = sp.edit();
                    editor.putLong(STORAGE_KEY_CLEANUP, nowTime);
                    editor.apply();

                    try {
                        LogUtils.devLog("DiskLruCache Clean up.");
                        impl.cleanup();
                    } catch (IOException e) {
                        throw new CacheException(e.getMessage());
                    }
                }
            }
        }
    }

    private static String createValidDiskCacheKey(final String key) {
        String extension = "";
        if (!TextUtils.isEmpty(key)) {
            int pos = key.lastIndexOf(".");
            if (pos >= 0 && key.length() - pos <= 5) {
                extension = "_" + key.substring(pos + 1);
            }
        }

        try {
            return toSha1(key) + extension;
        } catch (Exception e) {
            LogUtils.devLog(e.getMessage());
            return "";
        }
    }

    private static String toSha1(String string)
            throws NoSuchAlgorithmException, UnsupportedEncodingException {
        StringBuilder stringBuilder = new StringBuilder();

        MessageDigest digest = MessageDigest.getInstance("SHA-1");
        byte[] bytes = string.getBytes("UTF-8");
        digest.update(bytes, 0, bytes.length);
        bytes = digest.digest();

        for (final byte b : bytes) {
            stringBuilder.append(String.format("%02X", b));
        }

        return stringBuilder.toString().toLowerCase(Locale.US);
    }

    /** Created by sanojimaru on 15/05/27. */
    static final class Streams {
        static void copyContent(final InputStream inputStream, final OutputStream outputStream)
                throws IOException {
            if (inputStream == null || outputStream == null) {
                throw new IOException("Unable to copy from or to a null stream.");
            }

            byte[] buffer = new byte[16384];
            int length;

            while ((length = inputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, length);
            }
        }
    }
}
