package jp.supership.vamp.core.cache;

/** Created by masaki.ando on 2019/03/12. */
public class CacheException extends Exception {

    public CacheException(String message) {
        super(message);
    }
}
