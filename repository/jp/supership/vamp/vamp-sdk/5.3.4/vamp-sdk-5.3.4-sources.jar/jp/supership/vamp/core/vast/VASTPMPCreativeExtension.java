package jp.supership.vamp.core.vast;

import android.text.TextUtils;

import java.io.Serializable;

public class VASTPMPCreativeExtension implements Serializable {
    public static final int CTA_BUTTON_HSIZE_SMALL = 1;
    public static final int CTA_BUTTON_HSIZE_DEFAULT = 2;
    public static final int CTA_BUTTON_HSIZE_MIDDLE = 3;
    public static final int CTA_BUTTON_HSIZE_LARGE = 4;
    public static final int CTA_BUTTON_HSIZE_XLARGE = 5;

    private int ctaButtonHSize = CTA_BUTTON_HSIZE_DEFAULT;
    private String ctaButtonText;
    private String ctaButtonTextExtra;
    private boolean buttonEnableOnPlaying;

    public VASTPMPCreativeExtension(String ctaButtonText, String ctaButtonTextExtra, int hSize) {
        this.ctaButtonText = ctaButtonText;
        this.ctaButtonTextExtra = ctaButtonTextExtra;
        this.buttonEnableOnPlaying = true;
        setCtaButtonHSize(hSize);
    }

    public String getCtaButtonText() {
        return ctaButtonText;
    }

    public String getCtaButtonTextExtra() {
        return !TextUtils.isEmpty(ctaButtonTextExtra) ? ctaButtonTextExtra : "";
    }

    public void setCtaButtonHSize(int size) {
        if (size < CTA_BUTTON_HSIZE_SMALL || size > CTA_BUTTON_HSIZE_XLARGE) {
            ctaButtonHSize = CTA_BUTTON_HSIZE_DEFAULT;
        } else {
            ctaButtonHSize = size;
        }
    }

    public int getCtaButtonHSize() {
        return ctaButtonHSize;
    }

    public void setButtonEnableOnPlaying(boolean enableOnPlaying) {
        this.buttonEnableOnPlaying = enableOnPlaying;
    }

    public boolean isButtonEnableOnPlaying() {
        return buttonEnableOnPlaying;
    }
}
