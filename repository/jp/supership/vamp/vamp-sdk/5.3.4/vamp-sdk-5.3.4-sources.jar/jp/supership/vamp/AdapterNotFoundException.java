package jp.supership.vamp;

public class AdapterNotFoundException extends Exception {
    public AdapterNotFoundException(String message) {
        super(message);
    }
}
