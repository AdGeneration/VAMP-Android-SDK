package jp.supership.vamp.core.http;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.Serializable;
import java.net.URL;

public interface IHttpClient extends Serializable {
    @Deprecated
    void get(@NonNull String urlString, @Nullable IHttpClientListener listener);

    @Deprecated
    void get(@NonNull URL url, @Nullable IHttpClientListener listener);

    void send(@NonNull final HttpRequest request, @Nullable final IHttpClientListener listener);
}
