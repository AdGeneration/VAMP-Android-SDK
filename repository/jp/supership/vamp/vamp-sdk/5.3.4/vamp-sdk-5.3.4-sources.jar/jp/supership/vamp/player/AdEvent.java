package jp.supership.vamp.player;

class AdEvent {
    public static final int EVENT_RESUME = 0x01;
    public static final int EVENT_PAUSE = 0x01 << 1;
    public static final int EVENT_START = 0x01 << 2;
    public static final int EVENT_FIRST_QUARTILE = 0x01 << 3;
    public static final int EVENT_MIDPOINT = 0x01 << 4;
    public static final int EVENT_THIRD_QUARTILE = 0x01 << 5;
    public static final int EVENT_COMPLETE = 0x01 << 6;

    private final int event;

    public AdEvent(int event) {
        this.event = event;
    }

    public boolean isResumeEvent() {
        return (event & EVENT_RESUME) != 0;
    }

    public boolean isPauseEvent() {
        return (event & EVENT_PAUSE) != 0;
    }

    public boolean isStartEvent() {
        return (event & EVENT_START) != 0;
    }

    public boolean isFirstQuartileEvent() {
        return (event & EVENT_FIRST_QUARTILE) != 0;
    }

    public boolean isMidpointEvent() {
        return (event & EVENT_MIDPOINT) != 0;
    }

    public boolean isThirdQuartileEvent() {
        return (event & EVENT_THIRD_QUARTILE) != 0;
    }

    public boolean isCompleteEvent() {
        return (event & EVENT_COMPLETE) != 0;
    }
}
