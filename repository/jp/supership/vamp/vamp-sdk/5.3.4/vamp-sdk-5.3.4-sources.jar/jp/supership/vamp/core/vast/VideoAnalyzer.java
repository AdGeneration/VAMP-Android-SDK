package jp.supership.vamp.core.vast;

import android.annotation.TargetApi;
import android.media.MediaCodecInfo;
import android.media.MediaCodecList;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.os.Build;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.VisibleForTesting;

import jp.supership.vamp.core.logging.LogUtils;

public final class VideoAnalyzer {
    public interface Analyzable {
        boolean isSupportedSize(int width, int height);

        boolean isSupportedMedia(@NonNull String fileUrl);
    }

    /**
     * 実機で利用できるアナライザ
     *
     * <p>*ユニットテストでは利用できないため、ユニットテスト時はAnalyzableインタフェースを実装してください
     */
    private static final class Impl implements Analyzable {
        public boolean isSupportedSize(int width, int height) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                return isSupportedSizeV21(width, height);
            } else {
                // 調べようがないのでtrueを返しておく
                return true;
            }
        }

        public boolean isSupportedMedia(@NonNull String fileUrl) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                return isSupportedMediaFileV21(fileUrl);
            } else {
                // 調べようがないのでtrueを返しておく
                return true;
            }
        }

        @TargetApi(Build.VERSION_CODES.LOLLIPOP)
        private static boolean isSupportedSizeV21(int width, int height) {
            MediaCodecList allCodecs = new MediaCodecList(MediaCodecList.ALL_CODECS);
            MediaCodecInfo[] infos = allCodecs.getCodecInfos();

            for (MediaCodecInfo info : infos) {
                for (String type : info.getSupportedTypes()) {
                    MediaCodecInfo.CodecCapabilities capabilities =
                            info.getCapabilitiesForType(type);

                    if (capabilities == null) {
                        continue;
                    }

                    MediaCodecInfo.VideoCapabilities videoCapabilities =
                            capabilities.getVideoCapabilities();

                    if (videoCapabilities == null) {
                        continue;
                    }

                    if (videoCapabilities.isSizeSupported(width, height)) {
                        return true;
                    }
                }
            }

            return false;
        }

        @TargetApi(Build.VERSION_CODES.LOLLIPOP)
        private static boolean isSupportedMediaFileV21(@NonNull String fileUrl) {
            MediaExtractor mediaExtractor = new MediaExtractor();

            try {
                mediaExtractor.setDataSource(fileUrl);
                int count = mediaExtractor.getTrackCount();
                for (int i = 0; i < count; ++i) {
                    MediaFormat format = mediaExtractor.getTrackFormat(i);
                    String mimeType = "";
                    int height = 0;
                    int width = 0;
                    try {
                        mimeType = format.getString(MediaFormat.KEY_MIME);
                        height = format.getInteger(MediaFormat.KEY_HEIGHT);
                        width = format.getInteger(MediaFormat.KEY_WIDTH);
                    } catch (Exception ignored) {
                    }

                    if (height > 0
                            && width > 0
                            && !isSupportedMediaFileV21(mimeType, height, width)) {
                        return false;
                    }
                    // audioの場合heightが取得できないので無視する
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                mediaExtractor.release();
            }

            return true;
        }

        @TargetApi(Build.VERSION_CODES.LOLLIPOP)
        private static boolean isSupportedMediaFileV21(String mimeType, int height, int width) {
            MediaCodecList allCodecs = new MediaCodecList(MediaCodecList.ALL_CODECS);
            MediaCodecInfo[] infos = allCodecs.getCodecInfos();

            for (MediaCodecInfo info : infos) {
                for (String type : info.getSupportedTypes()) {
                    if (!type.equalsIgnoreCase(mimeType)) {
                        continue;
                    }

                    LogUtils.devLog("type:" + type);
                    MediaCodecInfo.CodecCapabilities capabilities =
                            info.getCapabilitiesForType(type);

                    if (capabilities == null) {
                        continue;
                    }

                    MediaCodecInfo.VideoCapabilities videoCapabilities =
                            capabilities.getVideoCapabilities();

                    if (videoCapabilities == null) {
                        LogUtils.devLog("video capabilities null");
                        continue;
                    }

                    if (width > 0 && height > 0) {
                        if (videoCapabilities.isSizeSupported(width, height)) {
                            return true;
                        }
                    } else {
                        if (width > 0) {
                            if (!videoCapabilities.getSupportedWidths().contains(width)) {
                                continue;
                            }
                        }

                        if (height > 0) {
                            if (!videoCapabilities.getSupportedHeights().contains(height)) {
                                continue;
                            }
                        }
                        return true;
                    }
                }
            }

            return false;
        }
    }

    @NonNull private static Analyzable instance = new Impl();

    private VideoAnalyzer() {}

    @NonNull
    public static Analyzable getAnalyzer() {
        return instance;
    }

    @VisibleForTesting
    public static synchronized void injectAnalyzer(@Nullable Analyzable analyzer) {
        if (analyzer == null) {
            instance = new Impl();
        } else {
            instance = analyzer;
        }
    }
}
