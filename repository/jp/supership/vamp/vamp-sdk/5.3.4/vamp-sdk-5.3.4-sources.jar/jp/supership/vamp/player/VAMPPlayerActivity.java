package jp.supership.vamp.player;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.URLUtil;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import jp.supership.sscore.vamp.type.Optional;
import jp.supership.vamp.BuildConfig;
import jp.supership.vamp.core.eventbus.EventBus;
import jp.supership.vamp.core.eventbus.Subscribe;
import jp.supership.vamp.core.eventbus.ThreadMode;
import jp.supership.vamp.core.logging.LogUtils;
import jp.supership.vamp.core.vast.VASTIcon;
import jp.supership.vamp.core.vast.VASTMediaFile;
import jp.supership.vamp.measurement.NativeVideoMeasurementManager;
import jp.supership.vamp.measurement.Obstruction;
import jp.supership.vamp.measurement.VideoPlayerInfo;
import jp.supership.vamp.player.view.ControlView;
import jp.supership.vamp.player.view.FullScreenContentView;
import jp.supership.vamp.player.view.VASTPlayerView;
import jp.supership.vamp.player.view.VideoView;

import java.util.ArrayList;

/** Created by yumiko.ishii on 2017/03/14. */
public class VAMPPlayerActivity extends Activity implements VASTPlayerView.Listener {
    private static final String CLASS_NAME = VAMPPlayerActivity.class.getSimpleName();
    private static final String EXTRA_DATA_AD = "jp.supership.vamp.player.EXTRA_DATA_AD";
    private static final String SAVED_DATA_AD = "jp.supership.vamp.player.SAVED_DATA_AD";
    private static final String SAVED_DATA_AUTO_INSTALL =
            "jp.supership.vamp.player.SAVED_DATA_AUTO_INSTALL";
    private static final String OPTOUT_LINK = "https://supership.jp/optout/";

    @NonNull private Optional<FullScreenContentView> fullScreenContentView = Optional.empty();
    @NonNull private Optional<VASTPlayerView> playerView = Optional.empty();
    @NonNull private Optional<VAMPPlayerAd> ad = Optional.empty();
    /** オーディオフォーカス状態 */
    private int audioFocusResult;
    /** インストール自動遷移 */
    private boolean isAutoInstall;

    @NonNull private Optional<NativeVideoMeasurementManager> measurementManager = Optional.empty();
    @NonNull private Optional<ScreenOffBroadcastReceiver> screenOffReceiver = Optional.empty();

    static void show(@NonNull final Activity activity, @NonNull final VAMPPlayerAd ad) {
        // バックグラウンドスレッドでshowメソッドが実行されたとしても確実にUIスレッドで表示する
        new Handler(Looper.getMainLooper())
                .post(
                        new Runnable() {
                            @Override
                            public void run() {
                                FullScreenContentStateManager.getInstance().present();

                                Intent intent =
                                        new Intent(activity, VAMPPlayerActivity.class)
                                                .setAction(Intent.ACTION_VIEW)
                                                .putExtra(EXTRA_DATA_AD, ad.serialized())
                                                .setFlags(Intent.FLAG_ACTIVITY_NO_USER_ACTION);
                                activity.startActivity(intent);
                            }
                        });
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LogUtils.d(CLASS_NAME + "#onCreate called.");

        // Activityの表示モード設定
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        hideNavigationBar();

        if (savedInstanceState != null) {
            // Activity復元時
            // onSaveInstanceStateで一時保存したデータを復元
            ad =
                    VAMPPlayerAd.from(
                            (VAMPPlayerAd.SerializableObject)
                                    savedInstanceState.getSerializable(SAVED_DATA_AD));
            isAutoInstall = savedInstanceState.getBoolean(SAVED_DATA_AUTO_INSTALL);
        } else {
            // Activity初期生成時
            Intent intent = getIntent();
            if (intent != null) {
                ad =
                        VAMPPlayerAd.from(
                                (VAMPPlayerAd.SerializableObject)
                                        intent.getSerializableExtra(EXTRA_DATA_AD));
            }
        }

        if (ad.isEmpty()) {
            VAMPPlayerReport report =
                    new VAMPPlayerReport(
                            new Throwable(), VAMPPlayerError.UNSPECIFIED, "vampPlayerAd == null");
            VAMPPlayerReport.setLastError(report);
            failed(VAMPPlayerError.UNSPECIFIED);
            return;
        }

        final VAMPPlayerAd ad = this.ad.forced();
        ad.setLogListener(
                new VAMPPlayerAd.ILogListener() {
                    @Override
                    public void onLog(@NonNull String log, @Nullable String devLog) {
                        LogUtils.d(log);
                        if (devLog != null) {
                            LogUtils.devLog(devLog);
                        }
                    }
                });

        // Activityが異常終了したかどうか判定できないため、
        // onDestroyが既に呼ばれている場合はActivityの復元を中断して終了
        if (FullScreenContentStateManager.getInstance().isDestroyed()) {
            LogUtils.d("The ad is already destroyed.");
            finish();
            return;
        }

        if (!EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().register(this);
        }

        screenOffReceiver =
                Optional.of(
                        ScreenOffBroadcastReceiver.register(
                                this,
                                new ScreenOffBroadcastReceiver.Listener() {
                                    @Override
                                    public void onScreenOn() {
                                        LogUtils.d(CLASS_NAME + "#onScreenOn called.");
                                        resume();
                                    }
                                }));

        audioFocusResult = AudioManager.AUDIOFOCUS_REQUEST_FAILED;

        final FullScreenContentView fullScreenContentView =
                FullScreenContentView.setToActivity(this);
        this.fullScreenContentView = Optional.of(fullScreenContentView);

        final VASTMediaFile mediaFile = ad.selectedMediaFile;
        // キャッシュファイルが削除されている可能性もあるため、ロード処理を再実行。
        // キャッシュがある場合は即時リターンされるため、複数回実行してもパフォーマンスに影響はない
        mediaFile.loadMediaFileOrFallback(
                this,
                new VASTMediaFile.ILoadOrFallbackListener() {
                    @Override
                    public void onCompleted(@NonNull String videoFileOrNetworkUrl) {
                        LogUtils.d("Prepare to use video.");

                        String endCard = null;
                        try {
                            endCard =
                                    ad.selectedEndCard
                                            .unwrap()
                                            .getImageFilePath(VAMPPlayerActivity.this);
                        } catch (Optional.NotPresentException ignored) {
                        }

                        String iMarkFilePath = null;
                        String privacyText = "";
                        try {
                            final VASTIcon icon = ad.selectedIcon.unwrap();
                            privacyText = icon.getProgram();
                            if (icon.getStaticResource() != null) {
                                iMarkFilePath =
                                        icon.getStaticResource()
                                                .getImageFilePath(VAMPPlayerActivity.this);
                            }
                        } catch (Optional.NotPresentException ignored) {
                        }

                        if (BuildConfig.DEV_LOG) {
                            privacyText += ad.vastObject.getAdSystem();
                        }

                        VASTPlayerView playerView =
                                new VASTPlayerView(
                                        VAMPPlayerActivity.this,
                                        videoFileOrNetworkUrl,
                                        endCard,
                                        privacyText,
                                        iMarkFilePath,
                                        isAutoInstall,
                                        ad,
                                        VAMPPlayerActivity.this);
                        VAMPPlayerActivity.this.playerView = Optional.of(playerView);

                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                            playerView.setAudioContentType(AudioAttributes.CONTENT_TYPE_MUSIC);
                        } else {
                            playerView.setAudioStreamType(AudioManager.STREAM_MUSIC);
                        }

                        fullScreenContentView.setPlayerView(playerView);
                    }
                });

        // OMSDKの計測開始
        startMeasurement(fullScreenContentView.adView);
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);

        try {
            playerView.unwrap().controlView.changeLayout(newConfig.orientation);
        } catch (Optional.NotPresentException ignored) {
        }
    }

    @Override
    public void onBackPressed() {
        final VAMPPlayerAd ad;
        final VASTPlayerView playerView;
        try {
            ad = this.ad.unwrap();
            playerView = this.playerView.unwrap();
        } catch (Optional.NotPresentException e) {
            // 異常終了
            // 万が一、ad, playerViewがnullになっていてもバックキーで閉じられるようにしておく
            LogUtils.e("Back key pressed. Abnormal termination.");
            closeActivity();
            return;
        }

        if (!ad.isCompleted()) {
            // 動画再生中は何もしない(エンドカード表示後はバックキーで閉じれるようにする)
            return;
        }

        if (playerView.canEndCardWebViewGoBack()) {
            playerView.endCardWebViewGoBack();
        } else {
            closeActivity();
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        LogUtils.d(CLASS_NAME + "#onSaveInstanceState called.");

        try {
            outState.putSerializable(SAVED_DATA_AD, ad.unwrap().serialized());
        } catch (Optional.NotPresentException ignored) {
        }
        outState.putBoolean(SAVED_DATA_AUTO_INSTALL, isAutoInstall);
    }

    @Override
    protected void onResume() {
        super.onResume();
        LogUtils.d(CLASS_NAME + "#onResume called.");

        ScreenKeep.start(this);

        startAudioFocus();

        try {
            if (screenOffReceiver.unwrap().isScreenUnlocked()) {
                resume();
            }
        } catch (Optional.NotPresentException ignored) {
        }
    }

    @Override
    protected void onPause() {
        LogUtils.d(CLASS_NAME + "#onPause called.");

        ScreenKeep.stop(this);

        stopAudioFocus();
        pause();

        super.onPause();
    }

    @Override
    protected void onDestroy() {
        LogUtils.d(CLASS_NAME + "#onDestroy called.");

        // Activityが異常終了した場合、closeActivity()が呼ばれない可能性があるため、
        // destroyIfNeeded()を呼んでおく
        destroyIfNeeded();

        super.onDestroy();
    }

    private void destroyIfNeeded() {
        if (FullScreenContentStateManager.getInstance().isDestroyed()) {
            return;
        }
        FullScreenContentStateManager.getInstance().destroy();

        postPlayerActivityEvent(new PlayerActivityEvent(PlayerActivityEvent.EVENT_CLOSE));

        sendMeasurementVideoEvent(NativeVideoMeasurementManager.VideoEvent.FINISH);

        try {
            playerView.unwrap().destroy();
            playerView = Optional.empty();
        } catch (Optional.NotPresentException ignored) {
        }

        try {
            fullScreenContentView.unwrap().destroy();
            fullScreenContentView = Optional.empty();
        } catch (Optional.NotPresentException ignored) {
        }

        try {
            screenOffReceiver.unwrap().unregister(this);
            screenOffReceiver = Optional.empty();
        } catch (Optional.NotPresentException ignored) {
        }

        if (EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().unregister(this);
        }
    }

    private void closeActivity() {
        LogUtils.d(CLASS_NAME + "#closeActivity called.");

        // Unity-Pluginで実行した時に動画再生中に画面を回転してから閉じると
        // onDestroy()が呼ばれず、クラッシュする端末があったため、
        // closeActivity()でもdestroyIfNeeded()を呼んでおく
        destroyIfNeeded();

        finish();
    }

    /** OM SDKのアドセッションを生成して計測を開始します */
    private void startMeasurement(@NonNull final View adView) {
        VAMPPlayerAd ad;
        try {
            ad = this.ad.unwrap();
        } catch (Optional.NotPresentException e) {
            return;
        }

        if (measurementManager.isPresent()) {
            LogUtils.devLog("measurementManager is already initialized.");
            return;
        }

        try {
            NativeVideoMeasurementManager manager =
                    new NativeVideoMeasurementManager(
                            getApplicationContext(),
                            ad.vastObject,
                            ad.getOmJsLibrary(),
                            adView,
                            getObstructions(ad));
            measurementManager = Optional.of(manager);
        } catch (NativeVideoMeasurementManager.CanNotInstantiateException e) {
            LogUtils.e("Can not create OM instance.: " + e.getMessage());
        }
    }

    /** OM SDKのロードイベントを送信します */
    private void sendMeasurementLoadedEvent() {
        final NativeVideoMeasurementManager manager;
        final VAMPPlayerAd ad;
        try {
            manager = measurementManager.unwrap();
            ad = this.ad.unwrap();
        } catch (Optional.NotPresentException e) {
            return;
        }
        manager.sendLoaded(ad.getSkipOffset() / 1000.f, ad.canSkip());
    }

    /**
     * OM SDKのビデオイベントを送信します
     *
     * @param event イベントタイプ
     */
    private void sendMeasurementVideoEvent(
            @NonNull final NativeVideoMeasurementManager.VideoEvent event) {
        final NativeVideoMeasurementManager manager;
        try {
            manager = measurementManager.unwrap();
        } catch (Optional.NotPresentException e) {
            return;
        }
        VideoPlayerInfo videoPlayerInfo;
        try {
            VideoView videoView = playerView.unwrap().videoView;
            videoPlayerInfo = new VideoPlayerInfo(videoView.getDuration(), !videoView.isVolume());
        } catch (Optional.NotPresentException e) {
            videoPlayerInfo = null;
        }
        manager.sendVideoEvent(event, videoPlayerInfo);
    }

    /** OM SDKのクリックイベントを通知します */
    private void sendMeasurementClickEvent() {
        final NativeVideoMeasurementManager manager;
        final ClickThrough clickThrough;
        try {
            manager = measurementManager.unwrap();
            clickThrough = ad.unwrap().selectedClickThrough.unwrap();
        } catch (Optional.NotPresentException e) {
            return;
        }
        if (clickThrough.isHttpProtocol()) {
            manager.sendVideoEvent(NativeVideoMeasurementManager.VideoEvent.USER_INTERACTION_CLICK);
        } else {
            manager.sendVideoEvent(
                    NativeVideoMeasurementManager.VideoEvent.USER_INTERACTION_INVITATION_ACCEPTED);
        }
    }

    /**
     * OM SDKのクリックイベントを通知します
     *
     * @param url 遷移先のURL
     */
    private void sendMeasurementClickEvent(String url) {
        final NativeVideoMeasurementManager manager;
        try {
            manager = measurementManager.unwrap();
        } catch (Optional.NotPresentException e) {
            return;
        }

        if (URLUtil.isNetworkUrl(url)) {
            manager.sendVideoEvent(NativeVideoMeasurementManager.VideoEvent.USER_INTERACTION_CLICK);
        } else {
            manager.sendVideoEvent(
                    NativeVideoMeasurementManager.VideoEvent.USER_INTERACTION_INVITATION_ACCEPTED);
        }
    }

    /** OM SDKに登録する障害物リストを生成します */
    @NonNull
    private ArrayList<Obstruction> getObstructions(@NonNull final VAMPPlayerAd ad) {
        final ControlView controlView;
        try {
            controlView = playerView.unwrap().controlView;
        } catch (Optional.NotPresentException e) {
            return new ArrayList<>();
        }

        final ArrayList<Obstruction> obstructions = new ArrayList<>();

        if (ad.canSkip()) {
            final Obstruction obstruction =
                    controlView.getObstruction(Obstruction.ObstructedViewType.COUNT_DOWN_VIEW);
            if (obstruction != null) {
                obstructions.add(obstruction);
            }
        } else {
            final Obstruction obstruction =
                    controlView.getObstruction(Obstruction.ObstructedViewType.CLOSE_BUTTON);
            if (obstruction != null) {
                obstructions.add(obstruction);
            }
        }

        {
            final Obstruction obstruction =
                    controlView.getObstruction(Obstruction.ObstructedViewType.IMARK_BUTTON);
            if (obstruction != null) {
                obstructions.add(obstruction);
            }
        }

        {
            final Obstruction obstruction =
                    controlView.getObstruction(Obstruction.ObstructedViewType.ADREPORT_BUTTON);
            if (obstruction != null) {
                obstructions.add(obstruction);
            }
        }

        {
            final Obstruction obstruction =
                    controlView.getObstruction(Obstruction.ObstructedViewType.SOUND_BUTTON_AREA);
            if (obstruction != null) {
                obstructions.add(obstruction);
            }
        }

        return obstructions;
    }

    /** OM SDKに登録した広告の障害物を解除します */
    private void unregisterObstruction(
            @NonNull final VASTPlayerView playerView,
            @NonNull final Obstruction.ObstructedViewType type) {
        Obstruction obstruction = playerView.controlView.getObstruction(type);
        if (obstruction == null) {
            return;
        }
        try {
            measurementManager.unwrap().unregisterObstruction(obstruction);
        } catch (Optional.NotPresentException ignored) {
        }
    }

    private void hideNavigationBar() {
        final View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);
    }

    /** オーディオフォーカス開始 */
    private void startAudioFocus() {
        AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            // TODO: usageはUSAGE_UNKNOWN?
            AudioFocusRequest audioFocusRequest =
                    new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                            .setAudioAttributes(
                                    new AudioAttributes.Builder()
                                            .setUsage(AudioAttributes.USAGE_UNKNOWN)
                                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                                            .build())
                            .setAcceptsDelayedFocusGain(true)
                            .setOnAudioFocusChangeListener(
                                    new AudioManager.OnAudioFocusChangeListener() {
                                        @Override
                                        public void onAudioFocusChange(int focusChange) {
                                            // nothing to do.
                                        }
                                    })
                            .build();
            am.requestAudioFocus(audioFocusRequest);
        } else {
            audioFocusResult =
                    am.requestAudioFocus(
                            audioFocusChangeListener,
                            AudioManager.STREAM_MUSIC,
                            AudioManager.AUDIOFOCUS_GAIN);
        }
    }

    /** オーディオフォーカス終了 */
    private void stopAudioFocus() {
        if (audioFocusResult == AudioManager.AUDIOFOCUS_REQUEST_GRANTED) {
            AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
            if (am != null) {
                am.abandonAudioFocus(audioFocusChangeListener);
            } else {
                LogUtils.devLog("AudioManager null.");
            }
        }
    }

    /** エラー終了します */
    private void failed(@NonNull final VAMPPlayerError error) {
        postPlayerActivityEvent(PlayerActivityEvent.failed(error));
        closeActivity();
    }

    private void play() {
        final VAMPPlayerAd ad;
        final VASTPlayerView playerView;
        try {
            ad = this.ad.unwrap();
            playerView = this.playerView.unwrap();
        } catch (Optional.NotPresentException ignored) {
            return;
        }

        if (ad.isCompleted()) {
            return;
        }

        if (!playerView.isPlaying()) {
            // ModelとViewの時刻の乖離を補正
            playerView.resume((int) ad.getCurrentTime());
        }
    }

    private void resume() {
        try {
            ad.unwrap().resume();
        } catch (Optional.NotPresentException ignored) {
        }
    }

    private void pause() {
        try {
            ad.unwrap().pause();
        } catch (Optional.NotPresentException ignored) {
        }
    }

    private void showEndCard() {
        final VAMPPlayerAd ad;
        final VASTPlayerView playerView;
        try {
            ad = this.ad.unwrap();
            playerView = this.playerView.unwrap();
        } catch (Optional.NotPresentException e) {
            return;
        }

        ScreenKeep.stop(this);

        final boolean isClickable = ad.vastObject.getPmpExtension() == null;
        playerView.showEndCard(isClickable);

        unregisterObstruction(playerView, Obstruction.ObstructedViewType.SOUND_BUTTON_AREA);
    }

    private void hideEndCard() {
        final VASTPlayerView playerView;
        try {
            playerView = this.playerView.unwrap();
        } catch (Optional.NotPresentException e) {
            return;
        }

        ScreenKeep.start(this);

        playerView.hideEndCard();
    }

    /**
     * 外部ブラウザでクリックスルーURLを開きます
     *
     * @param close trueの場合、外部ブラウザ起動後にこのActivityを閉じます
     */
    private void openClickThrough(boolean close) {
        // ブラウザでクリックスルーを開く=HTTPリクエスト送信のため、ad.sendClickThrough()は呼ばない
        sendTrackingEventClick();

        try {
            final ClickThrough clickThrough = ad.unwrap().selectedClickThrough.unwrap();
            ExternalAppLauncher.startApp(this, clickThrough.consume());
        } catch (Optional.NotPresentException
                | ExternalAppLauncher.NotLaunchException
                | ClickThrough.AlreadyConsumedException ignored) {
        }

        if (close) {
            closeActivity();
        }
    }

    /** 外部アプリでランディングページを開きます */
    private void openLandingPage() {
        final VAMPPlayerAd ad;
        try {
            ad = this.ad.unwrap();
        } catch (Optional.NotPresentException e) {
            return;
        }

        // PMPは特殊仕様
        if (ad.vastObject.getPmpExtension() != null) {
            openClickThrough(true);
            return;
        }

        ad.sendClickThrough();
        sendTrackingEventClick();

        try {
            ExternalAppLauncher.startApp(this, ad.selectedLandingPage.unwrap());
        } catch (Optional.NotPresentException | ExternalAppLauncher.NotLaunchException ignored) {
        }

        closeActivity();
    }

    private void postPlayerActivityEvent(@NonNull final PlayerActivityEvent event) {
        if (EventBus.getDefault().hasSubscriberForEvent(PlayerActivityEvent.class)) {
            EventBus.getDefault().post(event);
        }
    }

    private void sendTrackingEventClick() {
        final VAMPPlayerAd ad;
        try {
            ad = this.ad.unwrap();
        } catch (Optional.NotPresentException e) {
            return;
        }

        postPlayerActivityEvent(new PlayerActivityEvent(PlayerActivityEvent.EVENT_CLICK));
        ad.sendTrackingEventClick();
        sendMeasurementClickEvent();
    }

    @Override
    public void onPrepared() {
        LogUtils.d(CLASS_NAME + "#onPrepared called.");

        final VAMPPlayerAd ad;
        final VASTPlayerView playerView;
        try {
            ad = this.ad.unwrap();
            playerView = this.playerView.unwrap();
        } catch (Optional.NotPresentException e) {
            return;
        }

        sendMeasurementLoadedEvent();

        if (ad.getCurrentTime() <= 0 && !playerView.isPlaying()) {
            postPlayerActivityEvent(
                    new PlayerActivityEvent(PlayerActivityEvent.EVENT_BEGIN_PLAYBACK));

            sendMeasurementVideoEvent(NativeVideoMeasurementManager.VideoEvent.IMPRESSION);
        }

        playerView.resume((int) ad.getCurrentTime());

        resume();
    }

    @Override
    public void onProgress(int currentTime, int duration) {
        final VAMPPlayerAd ad;
        final VASTPlayerView playerView;
        try {
            ad = this.ad.unwrap();
            playerView = this.playerView.unwrap();
        } catch (Optional.NotPresentException e) {
            return;
        }

        if (!ad.updatePlaybackTime(currentTime, duration)) {
            return;
        }

        if (duration > 0) {
            final int count = Math.max((duration - currentTime) / 1000, 0);
            // 全て再生が終わった後にcurrentTimeが0になり、countにduration/1000の値が一瞬表示されるので
            // currentTimeが0以下の場合はcountDownViewを更新しない
            if (currentTime > 0) {
                playerView.updateCount(count, currentTime >= ad.vastObject.getSkipOffset(duration));
            }
        }
    }

    @Override
    public void onCompleted(int duration) {
        LogUtils.d(CLASS_NAME + "#onCompleted called.");

        final VAMPPlayerAd ad;
        final VASTPlayerView playerView;
        try {
            ad = this.ad.unwrap();
            playerView = this.playerView.unwrap();
        } catch (Optional.NotPresentException e) {
            return;
        }

        playerView.setSeekEndCapture(this, ad.selectedMediaFile.networkUrl);
        ad.completePlayback(duration);
    }

    @Override
    public void onError(@NonNull VAMPPlayerError error) {
        LogUtils.d(CLASS_NAME + "#onError called.");

        failed(error);
    }

    @Override
    public void onClose() {
        LogUtils.d(CLASS_NAME + "#onClose called.");

        closeActivity();
    }

    @Override
    public void onLinkTextClick() {
        LogUtils.d(CLASS_NAME + "#onLinkTextClick called.");

        final VAMPPlayerAd ad;
        try {
            ad = this.ad.unwrap();
        } catch (Optional.NotPresentException e) {
            return;
        }

        // 視聴完了しているならば、遷移先画面から戻ったとき、広告が閉じられている状態にする
        openClickThrough(ad.isCompleted());
    }

    @Override
    public void onAdClick() {
        LogUtils.d(CLASS_NAME + "#onAdClick called.");

        final VAMPPlayerAd ad;
        try {
            ad = this.ad.unwrap();
        } catch (Optional.NotPresentException e) {
            return;
        }

        if (ad.isCompleted()) {
            openClickThrough(true);
        } else {
            // 何らかの原因で動画再生が止まってしまった場合に
            // クリックで再生復帰できるようにする為の補助処理
            play();
        }
    }

    @Override
    public void onInstallButtonClick() {
        LogUtils.d(CLASS_NAME + "#onInstallButtonClick called.");

        final VAMPPlayerAd ad;
        final VASTPlayerView playerView;
        try {
            ad = this.ad.unwrap();
            playerView = this.playerView.unwrap();
        } catch (Optional.NotPresentException e) {
            return;
        }

        if (ad.isCompleted()) {
            openLandingPage();
        } else {
            isAutoInstall = !isAutoInstall;
            playerView.controlView.setAutoInstall(isAutoInstall);
        }
    }

    @Override
    public void onOptOutLinkClick() {
        LogUtils.d(CLASS_NAME + "#onOptOutLinkClick called.");

        final VAMPPlayerAd ad;
        try {
            ad = this.ad.unwrap();
        } catch (Optional.NotPresentException e) {
            return;
        }

        Uri uri = null;

        try {
            final VASTIcon icon = ad.selectedIcon.unwrap();
            if (icon.getClickThroughURL() != null && icon.getClickThroughURL().startsWith("http")) {
                uri = Uri.parse(icon.getClickThroughURL());
            }
        } catch (Optional.NotPresentException ignored) {
        }

        if (uri == null) {
            uri = Uri.parse(OPTOUT_LINK);
        }

        ad.sendIMarkClickTracking();
        sendMeasurementClickEvent(uri.toString());

        startActivity(new Intent(Intent.ACTION_VIEW, uri));
    }

    @Override
    public void onSkip() {
        LogUtils.d(CLASS_NAME + "#onSkip called.");

        final VASTPlayerView playerView;
        try {
            playerView = this.playerView.unwrap();
        } catch (Optional.NotPresentException e) {
            return;
        }

        // 動画を最後までスキップする
        playerView.seekToEnd();

        sendMeasurementVideoEvent(NativeVideoMeasurementManager.VideoEvent.SKIPPED);
    }

    @Override
    public void onPaused(int currentTime, int duration) {
        final VAMPPlayerAd ad;
        try {
            ad = this.ad.unwrap();
        } catch (Optional.NotPresentException e) {
            return;
        }

        ad.updatePlaybackTime(ad.isCompleted() ? duration : currentTime, duration);

        sendMeasurementVideoEvent(NativeVideoMeasurementManager.VideoEvent.PAUSE);
    }

    @Override
    public void onResumed() {
        sendMeasurementVideoEvent(NativeVideoMeasurementManager.VideoEvent.RESUME);
    }

    @Override
    public void onUnmute() {
        final VAMPPlayerAd ad;
        try {
            ad = this.ad.unwrap();
        } catch (Optional.NotPresentException e) {
            return;
        }

        ad.unmute();

        sendMeasurementVideoEvent(NativeVideoMeasurementManager.VideoEvent.VOLUME_CHANGE_ON);
    }

    @Override
    public void onMute() {
        final VAMPPlayerAd ad;
        try {
            ad = this.ad.unwrap();
        } catch (Optional.NotPresentException e) {
            return;
        }

        ad.mute();

        sendMeasurementVideoEvent(NativeVideoMeasurementManager.VideoEvent.VOLUME_CHANGE_OFF);
    }

    @Override
    public void onBuffering(int percent) {
        final VASTPlayerView playerView;
        try {
            playerView = this.playerView.unwrap();
        } catch (Optional.NotPresentException e) {
            return;
        }

        // 現在の再生地点をパーセントで算出
        final int percentile =
                playerView.videoView.getCurrentPosition() / playerView.videoView.getDuration();
        // 再生地点より大きい場合または100%の場合はバッファリングに問題がないため再生が止まらないと判断
        if (percentile < percent || 100 <= percentile) {
            sendMeasurementVideoEvent(NativeVideoMeasurementManager.VideoEvent.BUFFER_END);
        } else {
            sendMeasurementVideoEvent(NativeVideoMeasurementManager.VideoEvent.BUFFER_START);
        }
    }

    @Override
    public void onEndCardWebViewShown() {
        try {
            ad.unwrap().sendClickThrough();
        } catch (Optional.NotPresentException ignored) {
        }
        sendTrackingEventClick();
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEvent(@NonNull PlayerEvent event) {
        if (event.isClose()) {
            closeActivity();
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEvent(@NonNull AdEvent event) {
        final VASTPlayerView playerView;
        try {
            playerView = this.playerView.unwrap();
        } catch (Optional.NotPresentException e) {
            return;
        }

        if (event.isResumeEvent()) {
            try {
                if (screenOffReceiver.unwrap().isScreenUnlocked()) {
                    play();
                }
            } catch (Optional.NotPresentException ignored) {
            }
        }

        if (event.isPauseEvent()) {
            playerView.pause();
        }

        if (event.isStartEvent()) {
            sendMeasurementVideoEvent(NativeVideoMeasurementManager.VideoEvent.START);
        }

        if (event.isFirstQuartileEvent()) {
            sendMeasurementVideoEvent(NativeVideoMeasurementManager.VideoEvent.FIRST_QUARTILE);
        }

        if (event.isMidpointEvent()) {
            sendMeasurementVideoEvent(NativeVideoMeasurementManager.VideoEvent.MIDPOINT);
        }

        if (event.isThirdQuartileEvent()) {
            sendMeasurementVideoEvent(NativeVideoMeasurementManager.VideoEvent.THIRD_QUARTILE);
        }

        if (event.isCompleteEvent()) {
            showEndCard();

            sendMeasurementVideoEvent(NativeVideoMeasurementManager.VideoEvent.COMPLETE);

            postPlayerActivityEvent(PlayerActivityEvent.playbackEnded(false));

            if (isAutoInstall) {
                openLandingPage();
            }
        }
    }

    private final AudioManager.OnAudioFocusChangeListener audioFocusChangeListener =
            new AudioManager.OnAudioFocusChangeListener() {
                @Override
                public void onAudioFocusChange(int focusChange) {
                    // Nothing to do.
                }
            };
}
