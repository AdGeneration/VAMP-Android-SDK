package jp.supership.vamp.core.vast;

import android.text.TextUtils;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import jp.supership.vamp.core.error.VAMPInternalError;
import jp.supership.vamp.core.http.HttpClient;
import jp.supership.vamp.core.http.HttpMethod;
import jp.supership.vamp.core.http.HttpRequest;
import jp.supership.vamp.core.http.HttpResponse;
import jp.supership.vamp.core.http.IHttpClient;
import jp.supership.vamp.core.http.IHttpClientListener;
import jp.supership.vamp.core.logging.LogUtils;
import jp.supership.vamp.core.utils.Strings;

import java.io.Serializable;
import java.net.URL;
import java.util.Map;

public class VASTTracking implements Serializable {
    @NonNull public final String event;
    @NonNull public final URL url;
    @Nullable public final String offset;
    private final long timeMilliSec;
    private final float percentage;
    private int count;

    private static final int VAMP_VAST_TRACKING_INVALID_VALUE = -1;

    public VASTTracking(@NonNull final String event, @NonNull final URL url) {
        this(event, url, null);
    }

    public VASTTracking(
            @NonNull final String event, @NonNull final URL url, @Nullable final String offset) {
        this(event, url, offset, 0);
    }

    public VASTTracking(
            @NonNull final String event,
            @NonNull final URL url,
            @Nullable final String offset,
            int count) {
        LogUtils.devLog("VASTTracking(" + event + ", " + url + ", " + offset + ", " + count + ")");
        this.event = event;
        this.url = url;
        this.offset = offset;
        this.count = count;

        int time = VAMP_VAST_TRACKING_INVALID_VALUE;
        float per = VAMP_VAST_TRACKING_INVALID_VALUE;
        if (!TextUtils.isEmpty(offset)) {
            assert offset != null;
            try {
                if (Strings.isAbsoluteTracker(offset)) {
                    Integer t = Strings.parseAbsoluteOffset(offset);
                    if (t != null) {
                        time = t;
                    }
                }

                if (Strings.isPercentageTracker(offset)) {
                    per = Float.parseFloat(offset.replace("%", ""));
                }
            } catch (Exception e) {
                LogUtils.e("VASTTracking#offset parse error");
            }
        }
        timeMilliSec = time;
        percentage = per;

        LogUtils.devLog("timeMilliSec:" + timeMilliSec + " percentage:" + percentage);
    }

    public boolean reachedTime(long currentTimeMilliSec, float currentPercentage) {
        return (timeMilliSec != VAMP_VAST_TRACKING_INVALID_VALUE
                        && currentTimeMilliSec >= timeMilliSec)
                || (this.percentage != VAMP_VAST_TRACKING_INVALID_VALUE
                        && currentPercentage >= this.percentage);
    }

    public void send(Map<String, String> headers, final VASTObject.VASTEventListener listener) {
        if (isDone()) {
            LogUtils.d("Already done. " + event);
            return;
        }

        count++;

        LogUtils.devLog("send " + event + " event.");
        HttpRequest request =
                new HttpRequest(url).setMethod(HttpMethod.GET).setRequestProperty(headers);

        IHttpClient httpClient = HttpClient.getInstance();
        httpClient.send(
                request,
                new IHttpClientListener() {
                    @Override
                    public void onSuccess(HttpResponse response) {
                        if (response != null && response.isSuccess()) {
                            if (listener != null) {
                                listener.onComplete(url, null);
                            }
                        } else {
                            if (listener != null) {
                                listener.onComplete(
                                        url,
                                        new VAMPInternalError(
                                                VAMPInternalError.Code.NETWORK_ERROR,
                                                response != null
                                                        ? response.getMessage()
                                                                + " statusCode:"
                                                                + response.getStatusCode()
                                                        : ""));
                            }
                        }
                    }

                    @Override
                    public void onFail(String errorMsg) {
                        if (listener != null) {
                            listener.onComplete(
                                    url,
                                    new VAMPInternalError(
                                            VAMPInternalError.Code.NETWORK_ERROR, errorMsg));
                        }

                        LogUtils.devLog(
                                "send " + event + " failed. url:" + url + " message:" + errorMsg);
                    }
                });
    }

    public boolean isDone() {
        return false;
    }

    public int getCount() {
        return count;
    }
}
