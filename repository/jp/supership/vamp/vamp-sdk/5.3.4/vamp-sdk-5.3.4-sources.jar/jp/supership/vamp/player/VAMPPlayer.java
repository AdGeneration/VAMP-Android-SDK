package jp.supership.vamp.player;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Handler;
import android.os.Looper;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import jp.supership.vamp.core.eventbus.EventBus;
import jp.supership.vamp.core.eventbus.Subscribe;
import jp.supership.vamp.core.eventbus.ThreadMode;
import jp.supership.vamp.core.logging.LogUtils;

import java.lang.ref.WeakReference;

public class VAMPPlayer {
    @Nullable private final VAMPPlayerListener playerListener;
    @NonNull private final WeakReference<Activity> activityRef;

    private VAMPPlayer(Activity activity, @Nullable VAMPPlayerListener listener) {
        activityRef = new WeakReference<>(activity);
        playerListener = listener;

        registerEvent();
    }

    @Nullable
    public static VAMPPlayer show(
            final Activity activity,
            @NonNull final VAMPPlayerAd ad,
            @Nullable final VAMPPlayerListener listener) {
        if (!isAvailable(activity)) {
            return null;
        }

        VAMPPlayerActivity.show(activity, ad);

        return new VAMPPlayer(activity, listener);
    }

    private static boolean isAvailable(Activity activity) {
        // 参照できるActivityがない
        if (activity == null) {
            LogUtils.w("VAMPPlayer must have the activity instance.");
            return false;
        }

        // 参照できるActivityが既に破棄されている
        if (activity.isFinishing()) {
            LogUtils.w("Parent activity of VAMPPlayer have finished.");
            return false;
        } else if (activity.isDestroyed()) {
            LogUtils.w("Parent activity of VAMPPlayer was destroyed.");
            return false;
        }

        // permission check(INTERNET)
        boolean permissionInternet =
                activity.checkCallingOrSelfPermission(Manifest.permission.INTERNET)
                        == PackageManager.PERMISSION_GRANTED;
        if (!permissionInternet) {
            LogUtils.w("INTERNET permission not found.");
            return false;
        }

        // permission check(ACCESS_NETWORK_STATE)
        boolean permissionANS =
                activity.checkCallingOrSelfPermission(Manifest.permission.ACCESS_NETWORK_STATE)
                        == PackageManager.PERMISSION_GRANTED;
        if (!permissionANS) {
            LogUtils.w("ACCESS_NETWORK_STATE permission not found.");
            return false;
        }

        return true;
    }

    public void close() {
        EventBus.getDefault().post(new PlayerEvent(PlayerEvent.EVENT_CLOSE));
    }

    public void release() {
        unregisterEvent();
    }

    private void registerEvent() {
        if (!EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().register(this);
        }
    }

    public void unregisterEvent() {
        if (EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().unregister(this);
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEvent(@NonNull PlayerActivityEvent event) {
        if (event.isBeginPlayback()) {
            if (playerListener != null) {
                playerListener.onBeginPlayback();
            }
        }

        if (event.isEndPlayback()) {
            if (playerListener != null) {
                playerListener.onEndPlayback(event.isUserCanceled);

                new Handler(Looper.getMainLooper())
                        .post(
                                new Runnable() {
                                    @Override
                                    public void run() {
                                        Activity activity = activityRef.get();
                                        if (activity != null) {
                                            EndCard endCard =
                                                    playerListener.onShowEndCard(activity);
                                            if (endCard != null) {
                                                endCard.show(activity);
                                            }
                                        }
                                    }
                                });
            }
        }

        if (event.isClose()) {
            if (playerListener != null) {
                playerListener.onClose();
            }
            unregisterEvent();
        }

        if (event.isFail()) {
            if (playerListener != null) {
                playerListener.onFail(event.error);
            }
        }

        if (event.isResume()) {
            if (playerListener != null) {
                playerListener.onResumeVideo();
            }
        }

        if (event.isPause()) {
            if (playerListener != null) {
                playerListener.onPauseVideo();
            }
        }

        if (event.isMute()) {
            if (playerListener != null) {
                playerListener.onMuteVideo();
            }
        }

        if (event.isUnmute()) {
            if (playerListener != null) {
                playerListener.onUnmuteVideo();
            }
        }

        if (event.isClick()) {
            if (playerListener != null) {
                playerListener.onClick();
            }
        }
    }
}
