package jp.supership.vamp.core.utils;

import android.os.AsyncTask;
import android.os.Build;

import jp.supership.vamp.core.logging.LogUtils;

import java.util.concurrent.RejectedExecutionException;

public class AsyncTaskUtils {
    /**
     * API LEVEL 11以降でThreadPoolExecutorを使ってTaskを並列実行するためのメソッド API LEVEL
     * 11以下の場合は、executeで内部的にThreadPoolExecutorが使われる
     *
     * @param asyncTask
     * @param params
     * @param <Params>
     * @param <Progress>
     * @param <Result>
     */
    public static <Params, Progress, Result> void execute(
            AsyncTask<Params, Progress, Result> asyncTask, Params... params) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
                asyncTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, params);
            } else {
                asyncTask.execute(params);
            }
        } catch (RejectedExecutionException e) {
            // スレッドが128超えた場合にクラッシュした事例があったのでcatchして握りつぶす
            LogUtils.w(e.getMessage());
        }
    }

    public static <Params, Progress, Result> void stop(
            AsyncTask<Params, Progress, Result> asyncTask) {
        if (asyncTask != null) {
            if (asyncTask.getStatus() == AsyncTask.Status.RUNNING) {
                asyncTask.cancel(true);
            }
            asyncTask = null;
        }
    }
}
