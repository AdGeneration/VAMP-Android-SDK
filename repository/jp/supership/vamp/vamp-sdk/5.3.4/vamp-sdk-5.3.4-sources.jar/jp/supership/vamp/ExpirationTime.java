package jp.supership.vamp;

import androidx.annotation.NonNull;

/** 広告のロードが完了した時点から、その広告が表示可能である期限 */
final class ExpirationTime {
    /** デフォルトの有効期限 */
    private static final long DEFAULT_TIME_IN_MILLISECONDS = 55 * 60 * 1000;
    /** 有効期限の最小値 */
    private static final long MIN_TIME_IN_MILLISECONDS = 0;
    /** 有効期限の最大値 */
    private static final long MAX_TIME_IN_MILLISECONDS = DEFAULT_TIME_IN_MILLISECONDS;

    /** 有効期限 [ミリ秒] */
    final long timeInMilliseconds;

    ExpirationTime(final long timeInMilliseconds) {
        this.timeInMilliseconds =
                Math.min(
                        Math.max(timeInMilliseconds, MIN_TIME_IN_MILLISECONDS),
                        MAX_TIME_IN_MILLISECONDS);
    }

    /**
     * @return デフォルトの有効期限を返します
     */
    @NonNull
    static ExpirationTime newDefault() {
        return new ExpirationTime(DEFAULT_TIME_IN_MILLISECONDS);
    }
}
