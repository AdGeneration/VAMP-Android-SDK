package jp.supership.vamp.measurement;

import android.content.Context;
import android.text.TextUtils;

import androidx.annotation.NonNull;
import androidx.annotation.VisibleForTesting;

import jp.supership.sscore.vamp.cloudconfig.SSCoreCloudConfigLoadable;
import jp.supership.sscore.vamp.cloudconfig.SSCoreCloudConfigLoader;
import jp.supership.sscore.vamp.cloudconfig.SSCoreCloudConfigOmSdkUrl;
import jp.supership.sscore.vamp.type.Optional;
import jp.supership.vamp.core.cache.CacheData;
import jp.supership.vamp.core.cache.CacheException;
import jp.supership.vamp.core.cache.Cacheable;
import jp.supership.vamp.core.cache.DiskCache;
import jp.supership.vamp.core.http.HttpClient;
import jp.supership.vamp.core.http.HttpResponse;
import jp.supership.vamp.core.http.IHttpClient;
import jp.supership.vamp.core.http.IHttpClientListener;
import jp.supership.vamp.core.logging.LogUtils;

import java.util.ArrayList;

public final class OmSdkLoader implements IOmSdkLoader {
    private static final String CACHE_KEY = "jp.supership.vamp.measurement.OMSdkInitializer_1.5.3";
    private static final int CACHE_TIME = 24 * 60 * 60; // 24h

    /** 初期化中フラグ */
    private boolean isInitializing;

    @NonNull private final ArrayList<OnJsLibraryFetchListener> listeners = new ArrayList<>();
    @NonNull private final SSCoreCloudConfigLoadable cloudConfigLoader;
    /** omsdk.jsをGETするHTTPクライアント */
    @NonNull private final IHttpClient httpClient;

    @NonNull private final Optional<Cacheable> cacheHandler;

    private static OmSdkLoader instance = null;

    /**
     * デフォルトのインスタンスを返します
     *
     * @param appContext アプリケーションコンテキスト
     */
    public static synchronized OmSdkLoader getDefault(@NonNull final Context appContext) {
        if (instance == null) {
            Optional<Cacheable> cacheHandler;
            try {
                Cacheable cache = DiskCache.newInstance(appContext);
                cacheHandler = Optional.of(cache);
            } catch (CacheException e) {
                LogUtils.d("Failed to instantiate the cache handler.");
                cacheHandler = Optional.empty();
            }
            instance =
                    new OmSdkLoader(
                            SSCoreCloudConfigLoader.newLoader(appContext),
                            HttpClient.newInstance(),
                            cacheHandler);
        }
        return instance;
    }

    @VisibleForTesting
    public OmSdkLoader(
            @NonNull final SSCoreCloudConfigLoadable cloudConfigLoader,
            @NonNull final IHttpClient httpClient,
            @NonNull final Optional<Cacheable> cacheHandler) {
        this.cloudConfigLoader = cloudConfigLoader;
        this.httpClient = httpClient;
        this.cacheHandler = cacheHandler;
    }

    @Override
    public void load(@NonNull final OnJsLibraryFetchListener listener) {
        final Optional<String> omSdkJs = jsLibraryCache();
        if (omSdkJs.isPresent()) {
            LogUtils.d("Use omsdk.js cache.");
            listener.onJsLibraryFetch(omSdkJs);
            return;
        }

        listeners.add(listener);

        if (isInitializing) {
            LogUtils.d("Initializing OM SDK...");
            return;
        }
        isInitializing = true;

        cloudConfigLoader.loadCloudConfig(
                result -> {
                    // クラウドコンフィグからomsdk.jsのURLを抽出
                    SSCoreCloudConfigOmSdkUrl omSdkUrl;
                    try {
                        omSdkUrl = result.data.unwrap().omSdkUrl;
                    } catch (Optional.NotPresentException e) {
                        LogUtils.d("omsdk URL not found.");

                        onFetched(Optional.<String>empty());
                        return;
                    }

                    // omsdk.jsをダウンロード
                    httpClient.get(
                            omSdkUrl.value,
                            new IHttpClientListener() {
                                @Override
                                public void onSuccess(HttpResponse response) {
                                    try {
                                        if (response == null || response.getContent() == null) {
                                            throw new Exception("The response data is null.");
                                        }
                                        if (response.getStatusCode() != 200) {
                                            throw new Exception("The status code is not 200.");
                                        }

                                        final String js = response.getContent().readAsString();
                                        if (TextUtils.isEmpty(js)) {
                                            throw new Exception("omsdk.js is null or empty.");
                                        }

                                        CacheData cacheData = new CacheData(js, CACHE_TIME);
                                        try {
                                            cacheHandler.unwrap().storeData(cacheData, CACHE_KEY);
                                        } catch (Exception e) {
                                            LogUtils.d("Failed to create omsdk.js cache.");
                                        }

                                        onFetched(Optional.of(js));
                                    } catch (Exception e) {
                                        LogUtils.d("Failed to get omsdk.js: " + e);

                                        onFetched(Optional.<String>empty());
                                    }
                                }

                                @Override
                                public void onFail(String errorMsg) {
                                    LogUtils.d("Failed to get omsdk.js.: " + errorMsg);

                                    onFetched(Optional.<String>empty());
                                }
                            });
                });
    }

    private void onFetched(@NonNull Optional<String> js) {
        for (OnJsLibraryFetchListener listener : listeners) {
            listener.onJsLibraryFetch(js);
        }

        listeners.clear();
        isInitializing = false;
    }

    @NonNull
    private Optional<String> jsLibraryCache() {
        try {
            CacheData cacheData = cacheHandler.unwrap().retrieveData(CACHE_KEY);
            if (cacheData == null) {
                throw new Exception("No omsdk.js cache.");
            }
            if (!cacheData.isValid()) {
                throw new Exception("Invalid omsdk.js cache.");
            }
            return Optional.of((String) cacheData.value);
        } catch (Exception e) {
            LogUtils.d(e.getMessage());
            return Optional.empty();
        }
    }
}
