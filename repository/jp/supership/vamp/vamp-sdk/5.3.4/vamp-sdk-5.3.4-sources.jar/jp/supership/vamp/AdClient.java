package jp.supership.vamp;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.VisibleForTesting;

import jp.supership.sscore.vamp.adid.SSCoreAdIdClientNotFoundException;
import jp.supership.sscore.vamp.adid.SSCoreAdIdProvidable;
import jp.supership.sscore.vamp.device.SSCoreAppInfo;
import jp.supership.sscore.vamp.device.SSCoreAppInfoProvidable;
import jp.supership.sscore.vamp.device.SSCoreDevice;
import jp.supership.sscore.vamp.device.SSCoreDeviceProvidable;
import jp.supership.sscore.vamp.sequence.Sequencer;
import jp.supership.sscore.vamp.type.Optional;
import jp.supership.sscore.vamp.type.Result;
import jp.supership.vamp.core.http.HttpClient;
import jp.supership.vamp.core.http.HttpContent;
import jp.supership.vamp.core.http.HttpResponse;
import jp.supership.vamp.core.http.IHttpClient;
import jp.supership.vamp.core.http.IHttpClientListener;
import jp.supership.vamp.core.logging.LogUtils;

import java.io.IOException;

/** このクラスの責務は以下になります 1. Adリクエストを諸条件から構築 2. Adサーバにリクエスト 3. Adサーバからのレスポンスを解析してオブジェクトに変換 */
final class AdClient {
    interface Completable {
        /** リクエスト処理が完了したときに呼ばれます。 正常系のとき、`error==null`になります。 反対に異常系のときは`error!=null`となります */
        void onCompete(@Nullable Response response, @Nullable VAMPError error);
    }

    interface IAdClient {
        void request(String placementId, Completable completion);
    }

    private static final class Client implements IAdClient {
        @NonNull private final Context appContext;
        @NonNull private final IHttpClient httpClient;
        @NonNull private final SSCoreAdIdProvidable adIdProvider;
        @NonNull private final SSCoreDeviceProvidable deviceProvider;
        @NonNull private final SSCoreAppInfoProvidable appInfoProvider;
        @NonNull private final ConsentManager.IRequireUserConsent requireUserConsent;

        private Client(
                @NonNull final Context appContext,
                @NonNull final IHttpClient httpClient,
                @NonNull final SSCoreAdIdProvidable adIdProvider,
                @NonNull final SSCoreDeviceProvidable deviceProvider,
                @NonNull final SSCoreAppInfoProvidable appInfoProvider,
                @NonNull final ConsentManager.IRequireUserConsent requireUserConsent) {
            this.appContext = appContext;
            this.httpClient = httpClient;
            this.adIdProvider = adIdProvider;
            this.deviceProvider = deviceProvider;
            this.appInfoProvider = appInfoProvider;
            this.requireUserConsent = requireUserConsent;
        }

        @Override
        public void request(final String placementId, final Completable completion) {
            new Sequencer(
                            completable ->
                                    requireUserConsent.check(
                                            isRequired -> {
                                                LogUtils.d("AdClient have checked user consent.");

                                                final AdRequestParam adRequestParam =
                                                        new AdRequestParam();

                                                adRequestParam.isConsentRequired = isRequired;
                                                completable.onComplete(
                                                        Result.success(adRequestParam));
                                            }))
                    .then(
                            (result, handler) ->
                                    adIdProvider.getAdInfo(
                                            e -> {
                                                if (e
                                                        instanceof
                                                        SSCoreAdIdClientNotFoundException) {
                                                    // com.google.android.gms.ads.identifier.AdvertisingIdClientクラスがインポートされていない
                                                    LogUtils.e(
                                                            "Please import Google Play services"
                                                                    + " SDK.");
                                                    handler.onComplete(
                                                            Result.failure(
                                                                    VAMPException.settingError()));
                                                } else {
                                                    LogUtils.d("AdClient have gotten the ad ID.");
                                                    // result: AdRequestParam
                                                    try {
                                                        handler.onComplete(
                                                                Result.success(result.unwrap()));
                                                    } catch (Optional.NotPresentException ignored) {
                                                        handler.onComplete(
                                                                Result.failure(
                                                                        VAMPException
                                                                                .unknownError()));
                                                    }
                                                }
                                            }))
                    .then(
                            (result, handler) ->
                                    deviceProvider.provideDevice(
                                            deviceResult -> {
                                                assert result.isPresent();
                                                final AdRequestParam adRequestParam =
                                                        (AdRequestParam) result.forced();
                                                adRequestParam.device = deviceResult.data;
                                                handler.onComplete(Result.success(adRequestParam));
                                            }))
                    .then(
                            (result, handler) ->
                                    appInfoProvider.provideAppInfo(
                                            appInfoResult -> {
                                                assert result.isPresent();
                                                final AdRequestParam adRequestParam =
                                                        (AdRequestParam) result.forced();
                                                adRequestParam.appInfo = appInfoResult.data;
                                                handler.onComplete(Result.success(adRequestParam));
                                            }))
                    .then(
                            (result, handler) -> {
                                // テストモードの時はNo RTBでリクエスト
                                // テストモード時はRTBを無駄に消費してしまうため
                                final boolean noRtb = VAMP.isTestMode();

                                assert result.isPresent();
                                final AdRequestParam adRequestParam =
                                        (AdRequestParam) result.forced();
                                final boolean isConsentRequired = adRequestParam.isConsentRequired;

                                // ユーザ同意が必須な圏内はADIDを送信しないようにする
                                VAMPPrivacySettings.ConsentStatus status =
                                        isConsentRequired
                                                ? VAMPPrivacySettings.ConsentStatus.DENIED
                                                : VAMPPrivacySettings.ConsentStatus.UNKNOWN;

                                VAMPPrivacySettings.ChildDirected childDirected =
                                        VAMPPrivacySettings.getChildDirected();
                                if (childDirected != VAMPPrivacySettings.ChildDirected.TRUE) {
                                    if (VAMPPrivacySettings.getUnderAgeOfConsent()
                                            == VAMPPrivacySettings.UnderAgeOfConsent.TRUE) {
                                        childDirected = VAMPPrivacySettings.ChildDirected.TRUE;
                                    } else if (VAMPPrivacySettings.getUnderAgeOfConsent()
                                            == VAMPPrivacySettings.UnderAgeOfConsent.FALSE) {
                                        // childDirectedがUnknownかFalseなのでFalseに設定
                                        childDirected = VAMPPrivacySettings.ChildDirected.FALSE;
                                    }
                                }

                                AdServerUrl serverUrl;
                                try {
                                    // EU圏かつ特別なIDであればADGサーバを迂回して直接JSONをダウンロードする
                                    if (isConsentRequired
                                            && AdhocPlacements.contains(placementId, appContext)) {
                                        serverUrl = AdhocPlacements.getUrl(placementId, appContext);
                                    } else {
                                        serverUrl =
                                                AdServerUrl.newDefaultInstance(
                                                        appContext,
                                                        adRequestParam.appInfo,
                                                        adRequestParam.device,
                                                        adIdProvider.adId(),
                                                        placementId,
                                                        noRtb,
                                                        status,
                                                        childDirected);
                                    }
                                } catch (Exception e) {
                                    LogUtils.e("AdClient failed to create the ad URL.", e);

                                    handler.onComplete(
                                            Result.failure(VAMPException.unknownError()));
                                    return;
                                }
                                LogUtils.d("AdClient have created the ad URL.");
                                LogUtils.devLog("serverUrl: " + serverUrl.url);
                                QALogger.logLoadEvent(placementId);

                                handler.onComplete(Result.success(serverUrl));
                            })
                    .then(
                            (result, handler) -> {
                                AdServerUrl serverUrl = null;
                                try {
                                    serverUrl = (AdServerUrl) result.unwrap();
                                } catch (Optional.NotPresentException e) {
                                    // Failed to get the ad server URL
                                }

                                assert serverUrl != null;

                                LogUtils.d("AdClient starts requesting.");

                                httpClient.get(
                                        serverUrl.url,
                                        new IHttpClientListener() {
                                            @Override
                                            public void onSuccess(
                                                    @NonNull HttpResponse httpResponse) {
                                                LogUtils.d("HTTP request succeeded.");

                                                if (!httpResponse.isSuccess()) {
                                                    LogUtils.d(
                                                            "statusCode is not 2xx. "
                                                                    + httpResponse.getStatusCode());

                                                    handler.onComplete(
                                                            Result.failure(
                                                                    VAMPException.serverError()));
                                                    return;
                                                }

                                                HttpContent content = httpResponse.getContent();
                                                if (content == null) {
                                                    LogUtils.d("The response data is null.");

                                                    handler.onComplete(
                                                            Result.failure(
                                                                    VAMPException.serverError()));
                                                    return;
                                                }

                                                try {
                                                    Response response =
                                                            Response.newInstance(
                                                                    content.readAsString());
                                                    handler.onComplete(Result.success(response));
                                                } catch (Response.CanNotInstantiateException e) {
                                                    LogUtils.d(e.getMessage());
                                                    handler.onComplete(
                                                            Result.failure(
                                                                    VAMPException.serverError()));
                                                } catch (Response.NoAdException e) {
                                                    LogUtils.d("Received NoAd.");
                                                    handler.onComplete(
                                                            Result.failure(
                                                                    VAMPException.noAdNetwork()));
                                                } catch (IOException e) {
                                                    LogUtils.d(e.toString());
                                                    handler.onComplete(
                                                            Result.failure(
                                                                    VAMPException.unknownError()));
                                                }
                                            }

                                            @Override
                                            public void onFail(String errorMsg) {
                                                LogUtils.e("HTTP request failed. " + errorMsg);

                                                handler.onComplete(
                                                        Result.failure(
                                                                VAMPException.serverError()));
                                            }
                                        });
                            })
                    .run(
                            result -> {
                                if (result.error.isPresent()) {
                                    VAMPError error;
                                    try {
                                        error = ((VAMPException) result.error.unwrap()).code;
                                    } catch (Optional.NotPresentException e) {
                                        error = VAMPError.UNKNOWN;
                                    }

                                    LogUtils.d("AdClient failed to request.: error: " + error);
                                    completion.onCompete(null, error);
                                } else {
                                    LogUtils.d("AdClient finished requesting.");
                                    Response response;
                                    try {
                                        response = (Response) result.data.unwrap();
                                    } catch (Optional.NotPresentException e) {
                                        response = null;
                                    }
                                    completion.onCompete(response, null);
                                }
                            });
        }

        /** Sequencerのresultに渡すパラメータ */
        private static final class AdRequestParam {
            public AdRequestParam() {}

            boolean isConsentRequired;

            @NonNull Optional<SSCoreDevice> device = Optional.empty();

            @NonNull Optional<SSCoreAppInfo> appInfo = Optional.empty();
        }
    }

    private AdClient() {}

    /**
     * デフォルトのインスタンスを生成します
     *
     * @param appContext アプリケーションコンテキスト
     * @param adIdProvider ADIDプロバイダ
     * @param deviceProvider デバイスプロバイダ
     * @param appInfoProvider アプリ情報プロバイダ
     * @param requireUserConsent ユーザ同意確認ハンドラ
     */
    @NonNull
    static IAdClient newClient(
            @NonNull final Context appContext,
            @NonNull final SSCoreAdIdProvidable adIdProvider,
            @NonNull final SSCoreDeviceProvidable deviceProvider,
            @NonNull final SSCoreAppInfoProvidable appInfoProvider,
            @NonNull final ConsentManager.IRequireUserConsent requireUserConsent) {
        return new Client(
                appContext,
                HttpClient.newInstance(),
                adIdProvider,
                deviceProvider,
                appInfoProvider,
                requireUserConsent);
    }

    /**
     * デフォルトのインスタンスを生成します
     *
     * @param appContext アプリケーションコンテキスト
     * @param httpClient HTTPクライアント
     * @param adIdProvider ADIDプロバイダ
     * @param deviceProvider デバイスプロバイダ
     * @param appInfoProvider アプリ情報プロバイダ
     * @param requireUserConsent ユーザ同意確認ハンドラ
     */
    @VisibleForTesting
    @NonNull
    static IAdClient newClient(
            @NonNull final Context appContext,
            @NonNull final IHttpClient httpClient,
            @NonNull final SSCoreAdIdProvidable adIdProvider,
            @NonNull final SSCoreDeviceProvidable deviceProvider,
            @NonNull final SSCoreAppInfoProvidable appInfoProvider,
            @NonNull final ConsentManager.IRequireUserConsent requireUserConsent) {
        return new Client(
                appContext,
                httpClient,
                adIdProvider,
                deviceProvider,
                appInfoProvider,
                requireUserConsent);
    }
}
