package jp.supership.vamp.core.vast;

import android.text.TextUtils;

import java.io.Serializable;
import java.util.ArrayList;

public class VASTCompanion implements Serializable {

    private int width;
    private int height;
    // private String type;
    // private String staticResource;
    //    private String mIframeResource;     // 未対応
    private String htmlResource;
    private String clickThroughURLString;
    private ArrayList<String> clickTrackingURLStrings;
    // extension
    // private EXTENSION_TYPE extensionType = EXTENSION_TYPE.NORMAL;  // 拡張タイプ
    private String imageURLString;

    public VASTCompanion() {
        clickTrackingURLStrings = new ArrayList<>();
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public String getClickThroughURLString() {
        return clickThroughURLString;
    }

    public void setClickThroughURLString(String clickThroughURLString) {
        this.clickThroughURLString = clickThroughURLString;
    }

    public ArrayList<String> getClickTrackingURLStrings() {
        return clickTrackingURLStrings;
    }

    public VASTEndCard getEndCard() {
        if (!TextUtils.isEmpty(imageURLString)) {
            return new VASTEndCard(imageURLString);
        }

        return null;
    }

    public void setImageURLString(String imageURLString) {
        this.imageURLString = imageURLString;
    }

    public void setHtmlResource(String htmlResource) {
        this.htmlResource = htmlResource;
    }

    public String getHtmlResource() {
        return this.htmlResource;
    }
}
