package jp.supership.vamp;

import androidx.annotation.NonNull;

/** VAMPErrorを内部的にExceptionとして扱うためのクラスです */
class VAMPException extends Exception {
    /** エラーコード */
    @NonNull public final VAMPError code;

    public VAMPException(@NonNull final VAMPError code, @NonNull final String message) {
        super(message);
        this.code = code;
    }

    public VAMPException(@NonNull final VAMPError code) {
        super();
        this.code = code;
    }

    @NonNull
    public static VAMPException notSupportedOSVersion() {
        return new VAMPException(VAMPError.NOT_SUPPORTED_OS_VERSION);
    }

    @NonNull
    public static VAMPException unknownError() {
        return new VAMPException(VAMPError.UNKNOWN);
    }

    @NonNull
    public static VAMPException serverError() {
        return new VAMPException(VAMPError.SERVER_ERROR);
    }

    @NonNull
    public static VAMPException noAdNetwork() {
        return new VAMPException(VAMPError.NO_ADNETWORK);
    }

    @NonNull
    public static VAMPException needConnection() {
        return new VAMPException(VAMPError.NEED_CONNECTION);
    }

    @NonNull
    public static VAMPException mediationTimeout() {
        return new VAMPException(VAMPError.MEDIATION_TIMEOUT);
    }

    @NonNull
    public static VAMPException userCancel() {
        return new VAMPException(VAMPError.USER_CANCEL);
    }

    @NonNull
    public static VAMPException noAdStock() {
        return new VAMPException(VAMPError.NO_ADSTOCK);
    }

    @NonNull
    public static VAMPException adNetworkError() {
        return new VAMPException(VAMPError.ADNETWORK_ERROR);
    }

    @NonNull
    public static VAMPException settingError() {
        return new VAMPException(VAMPError.SETTING_ERROR);
    }

    @NonNull
    public static VAMPException notLoadedAd() {
        return new VAMPException(VAMPError.NOT_LOADED_AD);
    }

    @NonNull
    public static VAMPException invalidParameter() {
        return new VAMPException(VAMPError.INVALID_PARAMETER);
    }

    @NonNull
    public static VAMPException requestTimeout() {
        return new VAMPException(VAMPError.REQUEST_TIMEOUT);
    }
}
