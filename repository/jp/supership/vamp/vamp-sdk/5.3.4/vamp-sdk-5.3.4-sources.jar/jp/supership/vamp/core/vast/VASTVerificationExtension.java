package jp.supership.vamp.core.vast;

import android.text.TextUtils;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import jp.supership.vamp.core.utils.VAMPList;

public final class VASTVerificationExtension extends VASTExtension {
    @Nullable public final String vendor;
    @Nullable public final VASTJavaScriptResource javaScriptResource;
    @Nullable public final String verificationParameters;
    @NonNull private final VAMPList<VASTTracking> trackings;

    public VASTVerificationExtension(
            @Nullable final String vendor,
            @Nullable final VASTJavaScriptResource javaScriptResource,
            @Nullable final String verificationParameters,
            @NonNull final VAMPList<VASTTracking> trackings) {
        if (!TextUtils.isEmpty(vendor)) {
            assert vendor != null;
            this.vendor = vendor.trim();
        } else {
            this.vendor = null;
        }

        if (!TextUtils.isEmpty(verificationParameters)) {
            assert verificationParameters != null;
            this.verificationParameters = verificationParameters.trim();
        } else {
            this.verificationParameters = null;
        }

        this.javaScriptResource = javaScriptResource;
        this.trackings = trackings;
    }

    @NonNull
    public VAMPList<VASTTracking> getTrackings() {
        VAMPList<VASTTracking> list = new VAMPList<>();
        for (VASTTracking tracking : trackings) {
            list.add(
                    new VASTTracking(
                            tracking.event, tracking.url, tracking.offset, tracking.getCount()));
        }
        return list;
    }
}
