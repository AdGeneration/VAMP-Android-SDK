package jp.supership.vamp.core.http;

import androidx.annotation.Nullable;

import java.io.Closeable;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.util.Map;

public class HttpResponse implements Closeable {
    private Map header;
    private int statusCode;
    private String message;
    private HttpContent content;

    public boolean isSuccess() {
        return statusCode == HttpURLConnection.HTTP_OK
                || statusCode == HttpURLConnection.HTTP_NOT_MODIFIED;
    }

    @Nullable
    public Map getHeader() {
        return header;
    }

    public void setHeader(Map header) {
        this.header = header;
    }

    public int getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(int statusCode) {
        this.statusCode = statusCode;
    }

    @Nullable
    public String getMessage() {
        return message;
    }

    public void setMessage(@Nullable String message) {
        this.message = message;
    }

    public void setContent(@Nullable HttpContent content) {
        this.content = content;
    }

    @Nullable
    public HttpContent getContent() {
        return content;
    }

    @Override
    public void close() throws IOException {
        if (content != null) {
            content.close();
        }
    }
}
