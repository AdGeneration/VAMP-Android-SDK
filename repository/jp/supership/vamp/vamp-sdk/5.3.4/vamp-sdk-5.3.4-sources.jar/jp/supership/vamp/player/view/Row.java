package jp.supership.vamp.player.view;

import android.content.Context;
import android.graphics.Color;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;

final class Row extends FrameLayout {

    private Row(@NonNull Context context) {
        super(context);

        setBackgroundColor(Color.TRANSPARENT);
    }

    /** Viewを生成し、`parent`に追加します */
    @NonNull
    static Row addTo(@NonNull final LinearLayout parent, @NonNull final Context context) {
        final Row view = new Row(context);
        final LayoutParams params =
                new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        parent.addView(view, params);
        return view;
    }
}
