package jp.supership.vamp;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

/** Activityのライフサイクルにバインドした広告の表示に関するイベント通知の仕組みを提供します。 */
public final class VAMPActivityEventDispatcher extends VAMPEventDispatcher {
    @NonNull
    private static final String PLACEMENT_ID_KEY_PREFIX =
            "jp.supership.vamp.VAMPActivityEventDispatcher.PLACEMENT_ID.";

    @NonNull
    private static final VAMPActivityEventDispatcher instance = new VAMPActivityEventDispatcher();

    /**
     * シングルトンインスタンスを返します。
     *
     * @return {@link VAMPActivityEventDispatcher}のインスタンス
     */
    @NonNull
    public static VAMPActivityEventDispatcher getInstance() {
        return instance;
    }

    private VAMPActivityEventDispatcher() {
        super();
    }

    /**
     * Activity#onCreateメソッドでこのメソッドを呼び出してください。 {@link VAMPRewardedAdListener}を指定した場合は、
     * このインスタンスに登録されVAMPイベントを受け取ることができます。
     *
     * @param savedInstanceState If the activity is being re-initialized after previously being shut
     *     down then this Bundle contains the data it most recently supplied in
     *     onSaveInstanceState(Bundle). Note: Otherwise it is null.
     * @param placementId 広告枠ID
     * @param listener {@link VAMPRewardedAdListener}
     * @return this
     */
    @SuppressWarnings("UnusedReturnValue")
    public VAMPActivityEventDispatcher onCreate(
            @Nullable final Bundle savedInstanceState,
            @NonNull final String placementId,
            @Nullable final VAMPRewardedAdListener listener) {
        addListener(placementId, listener);

        if (savedInstanceState == null) {
            return this;
        }

        // 状態復元フラグが存在する場合はActivity再生成でありメッセージ送信する
        final String savedPlacementId =
                savedInstanceState.getString(PLACEMENT_ID_KEY_PREFIX + placementId);

        if (savedPlacementId == null) {
            return this;
        }

        // Activity破棄後のonDestroy-onCreate間で受信したメッセージを一斉に送信
        flush(placementId);
        return this;
    }

    /**
     * Activity#onDestroyメソッドでこのメソッドを呼び出してください。 このメソッドを呼び出すと、このインスタンスに登録されているリスナーは解除されます。
     *
     * @param placementId 広告枠ID
     * @return this
     */
    @SuppressWarnings("UnusedReturnValue")
    public VAMPActivityEventDispatcher onDestroy(@NonNull final String placementId) {
        removeListener(placementId);
        return this;
    }

    /**
     * Activity#onSaveInstanceStateメソッドでこのメソッドを呼び出してください。
     *
     * @param outState Bundle in which to place your saved state. This value cannot be null.
     * @param placementId 広告枠ID
     * @return this
     */
    @SuppressWarnings("UnusedReturnValue")
    public VAMPActivityEventDispatcher onSaveInstanceState(
            @NonNull final Bundle outState, @NonNull final String placementId) {
        // 状態復元フラグを記録
        outState.putString(PLACEMENT_ID_KEY_PREFIX + placementId, placementId);
        return this;
    }
}
