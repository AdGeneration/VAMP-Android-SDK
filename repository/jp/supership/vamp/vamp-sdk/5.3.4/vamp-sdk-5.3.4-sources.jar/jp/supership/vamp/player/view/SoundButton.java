package jp.supership.vamp.player.view;

import android.content.Context;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;

import androidx.annotation.NonNull;

/**
 * 音量アイコンは現在の状態を表します
 *
 * <p>sound onアイコン: 音声が流れている状態を表します sound offアイコン: 音声が流れていない状態を表します
 */
final class SoundButton extends FrameLayout {
    interface Listener {
        void onMute();

        void onUnmute();
    }

    private static final String ASSET_PATH_SOUND_OFF = "adgp_vamp_soundoff.png";
    private static final String ASSET_PATH_SOUND_ON = "adgp_vamp_soundon.png";
    private static final int BUTTON_SIZE = 30;

    private final ImageView soundOffButton;
    private final ImageView soundOnButton;

    private SoundButton(
            @NonNull final Context context, final float density, @NonNull final Listener listener) {
        super(context);

        setBackgroundColor(Color.TRANSPARENT);

        soundOffButton = newImageView(context, ASSET_PATH_SOUND_OFF);
        addView(soundOffButton, layoutParamsOfSoundButton(density));
        soundOffButton.setOnClickListener(
                new OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        listener.onUnmute();
                    }
                });

        soundOnButton = newImageView(context, ASSET_PATH_SOUND_ON);
        addView(soundOnButton, layoutParamsOfSoundButton(density));
        soundOnButton.setOnClickListener(
                new OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        listener.onMute();
                    }
                });
    }

    /** Viewを生成し、`parent`に追加します */
    @NonNull
    static SoundButton addTo(
            @NonNull final ViewGroup parent,
            @NonNull final Context context,
            final float density,
            final int gravity,
            @NonNull final Listener listener) {
        final SoundButton button = new SoundButton(context, density, listener);
        final LayoutParams params =
                new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
        params.gravity = gravity;
        parent.addView(button, params);
        return button;
    }

    /** サウンドON状態にします */
    void unmute() {
        soundOnButton.setVisibility(VISIBLE);
        soundOffButton.setVisibility(INVISIBLE);
    }

    /** サウンドOFF状態にします */
    void mute() {
        soundOnButton.setVisibility(INVISIBLE);
        soundOffButton.setVisibility(VISIBLE);
    }

    @NonNull
    private static FrameLayout.LayoutParams layoutParamsOfSoundButton(float density) {
        LayoutParams params =
                new LayoutParams((int) (BUTTON_SIZE * density), (int) (BUTTON_SIZE * density));
        params.gravity = Gravity.CENTER;
        return params;
    }

    @NonNull
    private static ImageView newImageView(@NonNull Context context, @NonNull String path) {
        ImageView view = new ImageView(context);
        view.setBackgroundColor(Color.TRANSPARENT);
        view.setVisibility(INVISIBLE);
        try {
            ViewUtils.setImageFromAssets(context, view, path);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return view;
    }
}
