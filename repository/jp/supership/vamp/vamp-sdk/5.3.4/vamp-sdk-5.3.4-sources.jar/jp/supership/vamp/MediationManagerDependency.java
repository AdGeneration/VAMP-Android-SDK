package jp.supership.vamp;

import android.app.Activity;
import android.content.Context;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import jp.supership.sscore.vamp.adid.SSCoreAdIdProvidable;
import jp.supership.sscore.vamp.adid.SSCoreAdIdProvider;
import jp.supership.sscore.vamp.adid.SSCoreAdInfoLoader;
import jp.supership.sscore.vamp.cloudconfig.SSCoreCloudConfigLoader;
import jp.supership.sscore.vamp.device.SSCoreAppInfoProvider;
import jp.supership.sscore.vamp.device.SSCoreDeviceProvider;
import jp.supership.sscore.vamp.device.SSCoreReachability;
import jp.supership.sscore.vamp.type.Optional;
import jp.supership.vamp.core.http.HttpClient;

final class MediationManagerDependency {
    interface IResolver {
        /** MediationManagerインスタンスを生成します */
        @NonNull
        MediationManager newInstance(
                @NonNull Activity activity,
                @NonNull String placementId,
                @Nullable MediationManager.Listener listener);
    }

    /** デフォルトのインスタンス生成器 */
    private static final class Resolver implements IResolver {
        @NonNull
        @Override
        public MediationManager newInstance(
                @NonNull final Activity activity,
                @NonNull final String placementId,
                @Nullable final MediationManager.Listener listener) {
            final Context context = activity.getApplicationContext();

            final SSCoreAdIdProvidable adIdProvider =
                    new SSCoreAdIdProvider(SSCoreAdInfoLoader.getInstance(context));

            final AdClient.IAdClient adClient =
                    AdClient.newClient(
                            context,
                            adIdProvider,
                            new SSCoreDeviceProvider(context),
                            new SSCoreAppInfoProvider(context),
                            ConsentManager.RequireUserConsent.getInstance(context));

            final SSCoreReachability.Reachable2 reachability =
                    new SSCoreReachability.Reachability(context);

            final SdkAvailability.IAvailabilityChecker availabilityChecker =
                    new SdkAvailability.AvailabilityChecker(Optional.of(context), reachability);

            final CloudLogger.ICloudLogger cloudLogger =
                    new CloudLogger.DefaultCloudLogger(
                            context,
                            HttpClient.newInstance(),
                            SSCoreCloudConfigLoader.newLoader(context),
                            new SSCoreDeviceProvider(context),
                            new SSCoreAppInfoProvider(context));

            return new MediationManager(
                    adClient, availabilityChecker, cloudLogger, activity, placementId, listener);
        }
    }

    @NonNull private static IResolver resolver = new Resolver();

    static void setResolver(@NonNull final Optional<IResolver> resolverOpt) {
        synchronized (MediationManagerDependency.class) {
            try {
                resolver = resolverOpt.unwrap();
            } catch (Optional.NotPresentException e) {
                resolver = new Resolver();
            }
        }
    }

    @NonNull
    static IResolver getResolver() {
        return resolver;
    }
}
