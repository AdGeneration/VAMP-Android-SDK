package jp.supership.vamp.core.http;

import androidx.annotation.NonNull;

public enum HttpMethod {
    GET("GET"),
    POST("POST"),
    DELETE("DELETE"),
    PUT("PUT");

    @NonNull private final String value;

    HttpMethod(@NonNull String value) {
        this.value = value;
    }

    @Override
    @NonNull
    public String toString() {
        return value;
    }
}
