package jp.supership.vamp;

import androidx.annotation.Nullable;

import jp.supership.vamp.mediation.Adapter;

import java.util.ArrayList;

public interface AdapterProviding {
    @Nullable
    Adapter getAdapter(String adNetworkName) throws AdapterNotFoundException;

    ArrayList<Adapter> getSupportedAdapters();
}
