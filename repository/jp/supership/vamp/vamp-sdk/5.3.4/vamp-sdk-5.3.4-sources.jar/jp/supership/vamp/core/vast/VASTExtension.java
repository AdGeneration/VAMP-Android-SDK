package jp.supership.vamp.core.vast;

import java.io.Serializable;

public class VASTExtension implements Serializable {

    private String type;

    public void setType(String type) {
        this.type = type;
    }

    public String getType() {
        return type;
    }
}
