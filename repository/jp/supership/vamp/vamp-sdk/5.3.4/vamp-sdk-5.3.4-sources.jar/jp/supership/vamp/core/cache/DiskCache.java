package jp.supership.vamp.core.cache;

import android.content.Context;
import android.os.Environment;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import jp.supership.vamp.core.logging.LogUtils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Locale;

/** Created by masaki.ando on 2019/03/12. */
public class DiskCache implements Cacheable {

    private static final String CACHE_DIRECTORY_NAME = "jp.supership.vamp.diskCache";
    private static final Object LOCK_OBJECT = new Object();

    private final File cacheDir;

    public static synchronized DiskCache newInstance(Context context) throws CacheException {
        return new DiskCache(context);
    }

    private DiskCache(Context context) throws CacheException {
        if (context == null) {
            throw new CacheException("Given `context` is null.");
        }

        File dir = null;

        if (Environment.MEDIA_MOUNTED.equals(Environment.getExternalStorageState())) {
            dir = context.getExternalCacheDir();
        } else {
            dir = context.getCacheDir();
        }

        if (dir != null) {
            cacheDir = new File(dir.getAbsolutePath() + File.separator + CACHE_DIRECTORY_NAME);

            if (!cacheDir.exists()) {
                if (!cacheDir.mkdirs()) {
                    throw new CacheException("Cache directory not created.");
                }
            }
        } else {
            throw new CacheException("Cache directory not found.");
        }
    }

    @Nullable
    @Override
    public CacheData retrieveData(@NonNull String key) throws CacheException {
        CacheData cacheData = null;

        synchronized (LOCK_OBJECT) {
            ObjectInputStream ois = null;

            try {
                File file = new File(cacheDir, toSha1(key));
                ois = new ObjectInputStream(new FileInputStream(file));
                CacheData tmp = (CacheData) ois.readObject();

                if (tmp != null && tmp.isValid()) {
                    cacheData = tmp;
                } else {
                    if (file.exists()) {
                        file.delete();
                    }
                }
            } catch (Exception e) {
                throw new CacheException(e.getMessage());
            } finally {
                try {
                    if (ois != null) {
                        ois.close();
                    }
                } catch (IOException e) {
                    LogUtils.devLog(e.getMessage());
                }
            }
        }

        return cacheData;
    }

    @Override
    public boolean storeData(@NonNull CacheData cacheData, @NonNull String key)
            throws CacheException {
        synchronized (LOCK_OBJECT) {
            ObjectOutputStream oos = null;

            try {
                File file = new File(cacheDir, toSha1(key));
                oos = new ObjectOutputStream(new FileOutputStream(file));
                oos.writeObject(cacheData);
            } catch (Exception e) {
                throw new CacheException(e.getMessage());
            } finally {
                try {
                    if (oos != null) {
                        oos.close();
                    }
                } catch (IOException e) {
                }
            }
        }

        return true;
    }

    public String retrieveFilePath(String key) {
        try {
            return toSha1(key);
        } catch (NoSuchAlgorithmException | UnsupportedEncodingException e) {
            LogUtils.e(e.getMessage());
        }

        return null;
    }

    private static String toSha1(String string)
            throws NoSuchAlgorithmException, UnsupportedEncodingException {
        StringBuilder stringBuilder = new StringBuilder();

        MessageDigest digest = MessageDigest.getInstance("SHA-1");
        byte[] bytes = string.getBytes("UTF-8");
        digest.update(bytes, 0, bytes.length);
        bytes = digest.digest();

        for (final byte b : bytes) {
            stringBuilder.append(String.format("%02X", b));
        }

        return stringBuilder.toString().toLowerCase(Locale.US);
    }
}
