package jp.supership.vamp;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class GlobalAdapterProvider {

    @Nullable private static AdapterProviding adapterProvider = null;

    @NonNull
    public static AdapterProviding getProvider() {
        synchronized (GlobalAdapterProvider.class) {
            if (adapterProvider == null) {
                adapterProvider = new AdapterProvider();
            }

            return adapterProvider;
        }
    }

    public static void injectProvider(AdapterProviding provider) {
        synchronized (GlobalAdapterProvider.class) {
            adapterProvider = provider;
        }
    }
}
