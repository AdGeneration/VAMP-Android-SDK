package jp.supership.vamp.core.vast;

import android.content.Context;
import android.text.TextUtils;

import jp.supership.vamp.core.cache.DiskLruCache;
import jp.supership.vamp.core.error.VAMPInternalError;
import jp.supership.vamp.core.http.HttpClient;
import jp.supership.vamp.core.http.HttpMethod;
import jp.supership.vamp.core.http.HttpRequest;
import jp.supership.vamp.core.http.HttpResponse;
import jp.supership.vamp.core.http.IHttpClient;
import jp.supership.vamp.core.http.IHttpClientListener;
import jp.supership.vamp.core.logging.LogUtils;

import java.io.Serializable;
import java.net.MalformedURLException;
import java.net.URL;

public class VASTEndCard implements Serializable {
    public interface ILoadListener {
        void onCompleted(VASTEndCard endCard, VAMPInternalError error);
    }

    /** 単位: 秒 */
    private static final int REQUEST_CONNECTION_TIMEOUT = 5000;
    /** 単位: 秒 */
    private static final int REQUEST_READ_TIMEOUT = 300000;

    private String urlString;

    private int attributeWidth;
    private int attributeHeight;

    public VASTEndCard(String urlString) {
        this.urlString = urlString;
    }

    public boolean isLoaded(Context context) {
        return !TextUtils.isEmpty(getImageFilePath(context));
    }

    public void load(final Context context, final ILoadListener listener) {
        LogUtils.devLog("load endcard.");

        URL url = null;
        try {
            url = new URL(urlString);
        } catch (MalformedURLException e) {
            e.printStackTrace();

            if (listener != null) {
                listener.onCompleted(null, null);
            }
            return;
        }

        HttpRequest httpRequest =
                new HttpRequest(url)
                        .setMethod(HttpMethod.GET)
                        .setReadTimeout(REQUEST_READ_TIMEOUT)
                        .setConnectionTimeout(REQUEST_CONNECTION_TIMEOUT);

        IHttpClient httpClient = HttpClient.getInstance();
        httpClient.send(
                httpRequest,
                new IHttpClientListener() {
                    @Override
                    public void onSuccess(HttpResponse response) {
                        if (!response.isSuccess() || response.getContent() == null) {
                            if (listener != null) {
                                listener.onCompleted(
                                        null,
                                        new VAMPInternalError(
                                                VAMPInternalError.Code.NETWORK_ERROR,
                                                "statusCode:" + response.getStatusCode()));
                            }

                            return;
                        }

                        try {
                            DiskLruCache cache = DiskLruCache.newInstance(context);
                            cache.storeData(response.getContent().data, urlString);
                            // success
                            if (listener != null) {
                                listener.onCompleted(VASTEndCard.this, null);
                            }

                        } catch (Exception e) {
                            LogUtils.devLog(e.getMessage());
                            if (listener != null) {
                                listener.onCompleted(
                                        null,
                                        new VAMPInternalError(
                                                VAMPInternalError.Code.IO_ERROR, e.getMessage()));
                            }
                        }
                    }

                    @Override
                    public void onFail(String errorMsg) {
                        if (listener != null) {
                            listener.onCompleted(
                                    null,
                                    new VAMPInternalError(
                                            VAMPInternalError.Code.NETWORK_ERROR, errorMsg));
                        }
                    }
                });
    }

    public void setAttributeHeight(int attributeHeight) {
        this.attributeHeight = attributeHeight;
    }

    public void setAttributeWidth(int attributeWidth) {
        this.attributeWidth = attributeWidth;
    }

    public String getUrlString() {
        return urlString;
    }

    public String getImageFilePath(Context context) {
        try {
            return DiskLruCache.newInstance(context).retrieveFilePath(urlString);
        } catch (Exception e) {
            LogUtils.devLog(e.getMessage());
            return null;
        }
    }
}
