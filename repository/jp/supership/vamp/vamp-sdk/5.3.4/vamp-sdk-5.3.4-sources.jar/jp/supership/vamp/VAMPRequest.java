package jp.supership.vamp;

import androidx.annotation.NonNull;

/** このクラスは、広告のロードリクエストのコンフィグレーションを表します。 */
public final class VAMPRequest {
    @NonNull final RequestTimeout requestTimeout;

    private VAMPRequest(@NonNull final RequestTimeout requestTimeout) {
        this.requestTimeout = requestTimeout;
    }

    /**
     * リクエストタイムアウトの時間を取得します。
     *
     * @return タイムアウト値。単位は秒です
     */
    public int getRequestTimeout() {
        return requestTimeout.timeInSeconds;
    }

    /** VAMPRequestのBuilder */
    public static final class Builder {
        @NonNull private RequestTimeout requestTimeout = RequestTimeout.newDefault();

        /** コンストラクタ */
        public Builder() {}

        /**
         * ロードリクエストのタイムアウト値を秒数で設定します。
         *
         * @param requestTimeoutInSeconds リクエストのタイムアウト値 (30〜120秒で設定可能。デフォルトは60秒)
         * @return Builderオブジェクト
         */
        @NonNull
        public Builder setRequestTimeout(int requestTimeoutInSeconds) {
            this.requestTimeout = new RequestTimeout(requestTimeoutInSeconds);
            return this;
        }

        /**
         * VAMPRequestオブジェクトを生成します。
         *
         * @return VAMPRequestオブジェクト
         */
        @NonNull
        public VAMPRequest build() {
            return new VAMPRequest(requestTimeout);
        }
    }
}
