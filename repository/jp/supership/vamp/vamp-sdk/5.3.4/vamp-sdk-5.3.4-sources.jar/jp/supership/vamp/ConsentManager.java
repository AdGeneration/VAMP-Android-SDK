package jp.supership.vamp;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.annotation.VisibleForTesting;

import jp.supership.sscore.vamp.cloudconfig.SSCoreCloudConfigLoadable;
import jp.supership.sscore.vamp.cloudconfig.SSCoreCloudConfigLoader;
import jp.supership.sscore.vamp.type.Optional;
import jp.supership.vamp.core.logging.LogUtils;

import java.util.ArrayList;

final class ConsentManager {
    interface OnRequireListener {
        void onRequired(boolean isRequired);
    }

    interface IRequireUserConsent {
        /** 個人情報取得においてユーザの同意が必要か判定します */
        void check(@NonNull OnRequireListener listener);
    }

    /** ユーザ同意確認ハンドラ */
    static final class RequireUserConsent implements IRequireUserConsent {
        private static RequireUserConsent instance = null;

        @NonNull private final LocationService.IFetchLocation locationService;
        @NonNull private final SSCoreCloudConfigLoadable cloudConfigLoader;
        @NonNull private final ArrayList<OnRequireListener> listeners = new ArrayList<>();

        @VisibleForTesting
        RequireUserConsent(
                @NonNull final LocationService.IFetchLocation locationService,
                @NonNull final SSCoreCloudConfigLoadable cloudConfigLoader) {
            this.locationService = locationService;
            this.cloudConfigLoader = cloudConfigLoader;
        }

        /**
         * シングルトンインスタンスを返します
         *
         * @param appContext アプリケーションコンテキスト
         */
        static synchronized RequireUserConsent getInstance(@NonNull Context appContext) {
            if (instance == null) {
                instance =
                        new RequireUserConsent(
                                LocationService.FetchLocation.getInstance(Optional.of(appContext)),
                                SSCoreCloudConfigLoader.newLoader(appContext));
            }
            return instance;
        }

        @Override
        public void check(@NonNull final OnRequireListener listener) {
            if (isRequesting()) {
                LogUtils.d("RequireUserConsent is already requesting and waits for the response.");

                listeners.add(listener);
                return;
            }

            listeners.add(listener);

            LogUtils.d("RequireUserConsent starts requesting the location.");

            // 地域情報を取得
            locationService.fetch(
                    new LocationService.LocationFetchListener() {
                        @Override
                        public void onLocationFetched(
                                @NonNull final LocationService.Location location) {
                            LogUtils.d("RequireUserConsent finished requesting the location.");
                            LogUtils.d("RequireUserConsent starts requesting the cloud config.");

                            // EU圏リストを取得
                            cloudConfigLoader.loadCloudConfig(
                                    result -> {
                                        LogUtils.d(
                                                "RequireUserConsent finished requesting the"
                                                        + " cloud config. ["
                                                        + result.data.isPresent()
                                                        + "]");

                                        ArrayList<String> countryCodes;
                                        try {
                                            countryCodes =
                                                    result.data.unwrap().euCountryCodes.codes();
                                        } catch (Optional.NotPresentException e) {
                                            LogUtils.d(
                                                    "RequireUserConsent failed to get EU"
                                                            + " country codes.");

                                            // 国コードリストが取得できなかった場合は安全策としてtrueにする
                                            notifyAndClear(true);
                                            return;
                                        }

                                        // タイムアウトなどで国コードが取得できなかった場合は安全策として対象エリアに含める
                                        countryCodes.add(VAMPLocation.UNKNOWN_COUNTRY_CODE);

                                        final boolean isEUAccess =
                                                countryCodes.contains(
                                                        location.getCountryCode().toUpperCase());

                                        LogUtils.d(
                                                "RequireUserConsent completed to get the"
                                                        + " location.: countryCode: "
                                                        + location.getCountryCode()
                                                        + " isEUAccess: "
                                                        + isEUAccess);
                                        LogUtils.devLog("" + countryCodes);

                                        notifyAndClear(isEUAccess);
                                    });
                        }
                    });
        }

        private boolean isRequesting() {
            return !listeners.isEmpty();
        }

        private void notifyAndClear(boolean isRequired) {
            for (OnRequireListener l : listeners) {
                l.onRequired(isRequired);
            }

            listeners.clear();

            LogUtils.d("RequireUserConsent finished.");
        }
    }

    private ConsentManager() {}
}
