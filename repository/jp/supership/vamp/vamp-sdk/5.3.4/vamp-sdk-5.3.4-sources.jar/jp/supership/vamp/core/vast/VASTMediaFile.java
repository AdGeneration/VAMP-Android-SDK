package jp.supership.vamp.core.vast;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import jp.supership.sscore.vamp.type.Optional;
import jp.supership.vamp.core.cache.CacheException;
import jp.supership.vamp.core.cache.DiskLruCache;
import jp.supership.vamp.core.error.VAMPInternalError;
import jp.supership.vamp.core.http.HttpClient;
import jp.supership.vamp.core.http.HttpMethod;
import jp.supership.vamp.core.http.HttpRequest;
import jp.supership.vamp.core.http.HttpResponse;
import jp.supership.vamp.core.http.IHttpClient;
import jp.supership.vamp.core.http.IHttpClientListener;
import jp.supership.vamp.core.logging.LogUtils;

import java.io.Serializable;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Arrays;
import java.util.List;

public final class VASTMediaFile implements Serializable {
    public interface ILoadListener {
        void onCompleted(Optional<String> videoFileUrl, Optional<VAMPInternalError> error);
    }

    public interface ILoadOrFallbackListener {
        void onCompleted(@NonNull String videoFileOrNetworkUrl);
    }

    /** インスタンスを生成できません。詳細はmessageを参照してください */
    public static final class CanNotInstantiateException extends Exception {
        CanNotInstantiateException(String message) {
            super(message);
        }
    }

    /** 単位: MB */
    private static final int MAX_VIDEO_SIZE = 25 * 1024 * 1024;
    /** 単位: 秒 */
    private static final int REQUEST_CONNECTION_TIMEOUT = 5000;
    /** 単位: 秒 */
    private static final int REQUEST_READ_TIMEOUT = 300000;

    @NonNull public final String networkUrl;
    @Nullable public final String delivery;
    @NonNull public final String mimeType;
    public final int bitrate;
    public final int width;
    public final int height;

    private static final List<String> VIDEO_MIME_TYPES = Arrays.asList("video/mp4", "video/3gpp");

    VASTMediaFile(
            @NonNull final String networkUrl,
            @Nullable final String delivery,
            @Nullable final String mimeType,
            final int bitrate,
            final int width,
            final int height)
            throws CanNotInstantiateException {
        try {
            new URL(networkUrl);
        } catch (MalformedURLException e) {
            throw new CanNotInstantiateException(e.toString());
        }

        if (mimeType == null) {
            throw new CanNotInstantiateException("mimeType is null.");
        } else if (!VIDEO_MIME_TYPES.contains(mimeType)) {
            throw new CanNotInstantiateException("Unsupported mime type: " + mimeType);
        }

        if (width <= 0) {
            throw new CanNotInstantiateException("Illegal size. width must be greater than 0.");
        }

        if (height <= 0) {
            throw new CanNotInstantiateException("Illegal size. height must be greater than 0.");
        }

        if (!VideoAnalyzer.getAnalyzer().isSupportedSize(width, height)) {
            throw new CanNotInstantiateException("Unsupported size: w=" + width + " h=" + height);
        }

        this.networkUrl = networkUrl;
        this.delivery = delivery;
        this.mimeType = mimeType;
        this.bitrate = bitrate;
        this.width = width;
        this.height = height;
    }

    public boolean isLoaded(Context context) {
        try {
            return DiskLruCache.newInstance(context).cachedDataExists(networkUrl);
        } catch (CacheException e) {
            LogUtils.devLog(e.getMessage());
            return false;
        }
    }

    public void loadMediaFile(
            @NonNull final Context context, @Nullable final VASTMediaFile.ILoadListener listener) {
        LogUtils.devLog("videoFileUrl(network): " + networkUrl);

        final String key = networkUrl;

        try {
            if (isLoaded(context)) {
                LogUtils.devLog("The media file is already loaded.");
                String path = DiskLruCache.newInstance(context).retrieveFilePath(key);
                if (listener != null) {
                    listener.onCompleted(Optional.of(path), Optional.<VAMPInternalError>empty());
                }
                return;
            }
        } catch (CacheException e) {
            LogUtils.devLog(e.getMessage());
        }

        final HttpRequest request =
                new HttpRequest(networkUrl)
                        .setMethod(HttpMethod.GET)
                        .setConnectionTimeout(REQUEST_CONNECTION_TIMEOUT)
                        .setReadTimeout(REQUEST_READ_TIMEOUT);

        IHttpClient httpClient = HttpClient.getInstance();
        httpClient.send(
                request,
                new IHttpClientListener() {
                    @Override
                    public void onSuccess(HttpResponse response) {
                        if (response == null) {
                            if (listener != null) {
                                listener.onCompleted(
                                        Optional.<String>empty(),
                                        Optional.of(
                                                new VAMPInternalError(
                                                        VAMPInternalError.Code.NETWORK_ERROR,
                                                        "invalid response.")));
                            }
                            return;
                        }

                        if (!response.isSuccess()
                                || response.getContent() == null
                                || response.getContent().contentLength <= 0) {
                            if (listener != null) {
                                listener.onCompleted(
                                        Optional.<String>empty(),
                                        Optional.of(
                                                new VAMPInternalError(
                                                        VAMPInternalError.Code.NETWORK_ERROR,
                                                        response.getStatusCode()
                                                                + " "
                                                                + response.getMessage())));
                            }
                            return;
                        }

                        if (response.getContent().contentLength > MAX_VIDEO_SIZE) {
                            if (listener != null) {
                                listener.onCompleted(
                                        Optional.<String>empty(),
                                        Optional.of(
                                                new VAMPInternalError(
                                                        VAMPInternalError.Code.EXCEED_FILE_SIZE,
                                                        "Video exceeded max download size.")));
                            }
                            return;
                        }

                        try {
                            DiskLruCache cache = DiskLruCache.newInstance(context);
                            cache.storeData(response.getContent().data, key);

                            String videoFileUrl = cache.retrieveFilePath(key);

                            if (!VideoAnalyzer.getAnalyzer().isSupportedMedia(videoFileUrl)) {
                                // TODO: キャッシュの削除
                                if (listener != null) {
                                    listener.onCompleted(
                                            Optional.<String>empty(),
                                            Optional.of(
                                                    new VAMPInternalError(
                                                            VAMPInternalError.Code.FILE_NOT_FOUND,
                                                            "The media file is not supported.")));
                                }
                                return;
                            }

                            LogUtils.devLog("videoFileUrl(local): " + videoFileUrl);

                            if (listener != null) {
                                listener.onCompleted(
                                        Optional.of(videoFileUrl),
                                        Optional.<VAMPInternalError>empty());
                            }
                        } catch (CacheException e) {
                            if (listener != null) {
                                listener.onCompleted(
                                        Optional.<String>empty(),
                                        Optional.of(
                                                new VAMPInternalError(
                                                        VAMPInternalError.Code.IO_ERROR,
                                                        e.getMessage())));
                            }
                        }
                    }

                    @Override
                    public void onFail(String errorMessage) {
                        if (listener != null) {
                            listener.onCompleted(
                                    Optional.<String>empty(),
                                    Optional.of(
                                            new VAMPInternalError(
                                                    VAMPInternalError.Code.NETWORK_ERROR,
                                                    errorMessage)));
                        }
                    }
                });
    }

    public void loadMediaFileOrFallback(
            @NonNull final Context context, @Nullable final ILoadOrFallbackListener listener) {
        loadMediaFile(
                context,
                new ILoadListener() {
                    @Override
                    public void onCompleted(
                            Optional<String> videoFileUrl, Optional<VAMPInternalError> error) {
                        String url = videoFileUrl.orElse(networkUrl);
                        try {
                            LogUtils.devLog(error.unwrap().message);
                        } catch (Optional.NotPresentException ignored) {
                        }

                        if (listener != null) {
                            listener.onCompleted(url);
                        }
                    }
                });
    }
}
