package jp.supership.vamp.core.cache;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.HashMap;

/** Created by masaki.ando on 2019/03/12. */
public class MemoryCache implements Cacheable {

    private static final MemoryCache cache = new MemoryCache();

    private final HashMap<String, CacheData> map = new HashMap<>();

    public static MemoryCache getInstance() {
        return cache;
    }

    private MemoryCache() {}

    @Nullable
    @Override
    public synchronized CacheData retrieveData(@NonNull String key) throws CacheException {
        if (map.containsKey(key)) {
            CacheData cacheData = map.get(key);

            if (cacheData != null && cacheData.isValid()) {
                return cacheData;
            } else {
                map.remove(key);
            }
        }

        return null;
    }

    @Override
    public synchronized boolean storeData(@NonNull CacheData cacheData, @NonNull String key)
            throws CacheException {
        map.put(key, cacheData);

        return true;
    }
}
