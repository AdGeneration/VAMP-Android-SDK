package jp.supership.vamp;

import android.app.Activity;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.VisibleForTesting;

import jp.supership.sscore.vamp.timer.SSCoreScheduledTimer;
import jp.supership.sscore.vamp.timer.SSCoreTimerSchedulable;
import jp.supership.sscore.vamp.type.Optional;
import jp.supership.vamp.core.logging.LogUtils;
import jp.supership.vamp.core.utils.VAMPMap;
import jp.supership.vamp.mediation.AdNetworkErrorInfo;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TimerTask;

/** Created by masaki.ando on 2018/03/19. */
final class MediationManager implements Mediation.Listener {
    interface Listener {
        void onStartedLoading(@NonNull String adNetworkName);

        void onLoaded(@NonNull String adNetworkName, @Nullable VAMPError error);

        void onReceived();

        void onFailedToShow(@NonNull VAMPError error);

        void onFailedToLoad(@NonNull VAMPError error);

        void onOpened();

        void onCompleted();

        void onClosed(boolean adClicked);

        void onExpired();
    }

    @NonNull private final AdClient.IAdClient adClient;
    @NonNull private final SdkAvailability.IAvailabilityChecker availabilityChecker;
    @NonNull private final CloudLogger.ICloudLogger cloudLogger;
    @NonNull private final Context applicationContext;
    /** Activityインスタンスは画面が閉じられるなどにより破棄される可能性があります。 なるべく依存しないようにしましょう */
    @NonNull private final WeakReference<Activity> activity_dangerousInstance;

    @VisibleForTesting @NonNull String placementId;
    @NonNull MediationState state = MediationState.idle();
    @Nullable private final Listener listener;
    @NonNull private Optional<MediationContainer> mediationContainer = Optional.empty();
    /** 有効期限タイマー */
    @NonNull private final SSCoreTimerSchedulable expirationTimer = new SSCoreScheduledTimer();
    /** 広告リクエストタイマー */
    @NonNull private final SSCoreTimerSchedulable requestTimer = new SSCoreScheduledTimer();
    /** ロード時間計測オブジェクト */
    @NonNull private Optional<Benchmark> loadTimeMeasurement = Optional.empty();
    /** 表示時間計測オブジェクト */
    @NonNull private Optional<Benchmark> playbackTimeMeasurement = Optional.empty();

    @NonNull private Optional<MediationResponseInfo.Builder> responseInfo = Optional.empty();

    MediationManager(
            @NonNull final AdClient.IAdClient adClient,
            @NonNull final SdkAvailability.IAvailabilityChecker availabilityChecker,
            @NonNull final CloudLogger.ICloudLogger cloudLogger,
            @NonNull final Activity activity,
            @NonNull final String placementId,
            @Nullable final Listener listener) {
        this.adClient = adClient;
        this.availabilityChecker = availabilityChecker;
        this.cloudLogger = cloudLogger;
        this.applicationContext = activity.getApplicationContext();
        this.activity_dangerousInstance = new WeakReference<>(activity);
        this.listener = listener;
        this.placementId = placementId.trim();

        QALogger.setQATestMode(applicationContext);
        AdapterVersionPrint.printList();
    }

    boolean isReady() {
        if (!state.isLoaded()) {
            return false;
        }

        return mediationContainer
                .flatMap(MediationContainer::getCurrentMediation)
                .map(Mediation::isReady)
                .orElse(false);
    }

    @NonNull
    VAMPResponseInfo getResponseInfo() {
        return responseInfo.orElse(new MediationResponseInfo.Builder()).build();
    }

    void load(@NonNull final VAMPRequest request) throws MediationState.NotChangedException {
        state = state.changed(MediationState.Value.LOADING);

        try {
            availabilityChecker.check(Optional.of(placementId));
        } catch (SdkAvailability.UnavailableException e) {
            failedToLoad(e.error, new VAMPMap().add(e.errorReason));
            return;
        }

        setRequestTimer(request.requestTimeout);

        loadTimeMeasurement = Optional.of(Benchmark.start("loadTime"));

        LogUtils.d("Start requesting an ad.");

        adClient.request(
                placementId,
                (response, error) -> {
                    if (error != null) {
                        failedToLoad(error, new VAMPMap().add("HTTP request failed."));
                        return;
                    }

                    if (response == null) {
                        failedToLoad(VAMPError.UNKNOWN, new VAMPMap().add("response is null."));
                        return;
                    }

                    final Activity activity = getActivity();
                    if (activity == null) {
                        failedToLoad(
                                VAMPError.INVALID_PARAMETER,
                                new VAMPMap().add("Activity was destroyed."));
                        return;
                    }

                    final ArrayList<AdResponse> adResponses = response.results;
                    final ArrayList<Mediation> mediationList = new ArrayList<>();
                    for (AdResponse adResponse : adResponses) {
                        try {
                            mediationList.add(
                                    new Mediation.Builder()
                                            .withListener(MediationManager.this)
                                            .withMediationTimeout(
                                                    VAMPDebugUtils.newInstance()
                                                            .mediationTimeout
                                                            .orElse(MediationTimeout.newDefault()))
                                            .build(
                                                    applicationContext,
                                                    activity,
                                                    adResponse,
                                                    request));
                        } catch (Exception e) {
                            LogUtils.w("build adapter failed. " + e.getMessage());
                        }
                    }

                    mediationContainer = Optional.of(new MediationContainer(mediationList));

                    final MediationResponseInfo.Builder respInfo =
                            new MediationResponseInfo.Builder()
                                    .withAdapterResponseList(
                                            mediationContainer
                                                    .map(MediationContainer::getAdapterResponseList)
                                                    .maybe())
                                    .withSeqId(
                                            adResponses.size() > 0
                                                    ? adResponses.get(0).getSeqId()
                                                    : null);
                    responseInfo = Optional.of(respInfo);

                    final ArrayList<String> adNetworkNames = new ArrayList<>();
                    for (Mediation mediation : mediationList) {
                        adNetworkNames.add(mediation.getAdNetworkName());
                    }

                    cloudLogger.send(
                            baseLogItem()
                                    .setListener("load")
                                    .setEvent(CloudLogger.CloudLogEvent.ADNETWORK_LIST)
                                    .setAdNetworkList(String.join(",", adNetworkNames)));

                    QALogger.logWeightEvent(adNetworkNames);

                    if (VAMP.isDebugMode()) {
                        final ArrayList<Map<String, String>> debugLogs = new ArrayList<>();
                        for (Mediation ad : mediationList) {
                            final Map<String, String> debugLog = new LinkedHashMap<>();
                            debugLog.put("adnw", ad.getAdNetworkName());
                            debugLog.put("version", ad.getAdNetworkVersion());
                            debugLog.put("ready", "" + ad.isReady());
                            debugLogs.add(debugLog);
                        }

                        final JSONArray jsonArray = new JSONArray();
                        for (Map<String, String> map : debugLogs) {
                            jsonArray.put(new JSONObject(map));
                        }

                        try {
                            LogUtils.d("Ad network list: " + jsonArray.toString(4));
                        } catch (JSONException ignored) {
                        }
                    }

                    new Handler(Looper.getMainLooper())
                            .post(
                                    () -> {
                                        if (loadAdOrStop()) {
                                            failedToLoad(
                                                    VAMPError.NO_ADSTOCK,
                                                    new VAMPMap()
                                                            .add(
                                                                    "Failed to load all adnetwork."
                                                                            + " (empty)"));
                                        }
                                    });
                });
    }

    void show(@Nullable final Activity activity) {
        if (!isReady()) {
            failedToShow(VAMPError.NOT_LOADED_AD);
            return;
        }

        try {
            state = state.changed(MediationState.Value.BEGIN_PLAYBACK);
        } catch (MediationState.NotChangedException e) {
            LogUtils.d(e.getMessage());
            return;
        }

        try {
            availabilityChecker.check(Optional.of(placementId));
        } catch (SdkAvailability.UnavailableException e) {
            LogUtils.w(e.errorReason);
            failedToShow(e.error);
            return;
        }

        // Viewを操作するのでバックグラウンド実行されたとしても確実にUIスレッドで実行する
        new Handler(Looper.getMainLooper())
                .post(
                        () -> {
                            if (activity == null
                                    || activity.isFinishing()
                                    || activity.isDestroyed()) {
                                final String errMsg = "activity is null or already finished.";
                                LogUtils.e(errMsg);
                                failedToShow(VAMPError.INVALID_PARAMETER);

                                cloudLogger.send(
                                        baseLogItem()
                                                .setError(VAMPError.INVALID_PARAMETER, errMsg)
                                                .setListener("show"));
                                return;
                            }

                            clearExpirationTimer();

                            try {
                                final Mediation ad =
                                        mediationContainer
                                                .flatMap(MediationContainer::getCurrentMediation)
                                                .unwrap();

                                QALogger.logShowEvent(ad.getAdNetworkName());

                                playbackTimeMeasurement =
                                        Optional.of(Benchmark.start("playbackTime"));

                                ad.show(activity);
                            } catch (Optional.NotPresentException e) {
                                LogUtils.e("Failed to show because the ad is not present.");
                                destroyManager();
                            }
                        });
    }

    void destroyManager() {
        try {
            state = state.changed(MediationState.Value.FINISHED);
        } catch (MediationState.NotChangedException ignored) {
        }

        mediationContainer.ifPresent(MediationContainer::destroyContainer);
        mediationContainer = Optional.empty();

        clearExpirationTimer();
        clearRequestTimer();

        activity_dangerousInstance.clear();
    }

    /**
     * @return 破棄されていないActivityの場合はActivityインスタンスを返します。 それ以外はnullを返します
     */
    @Nullable
    private Activity getActivity() {
        Activity activity = activity_dangerousInstance.get();
        if (activity == null || activity.isFinishing() || activity.isDestroyed()) {
            return null;
        } else {
            return activity;
        }
    }

    /** 広告をロードします。ロードする広告がない場合はtrueを返します。 広告がある場合はロード開始の成功/失敗に関わらずfalseを返します */
    private boolean loadAdOrStop() {
        final Mediation ad;
        try {
            ad = mediationContainer.flatMap(MediationContainer::getCurrentMediation).unwrap();
        } catch (Optional.NotPresentException e) {
            return true;
        }

        final String name = ad.getAdNetworkName();

        LogUtils.d(String.format("Start loading %s.", name));

        cloudLogger.send(
                logItem(ad)
                        .setEvent(CloudLogger.CloudLogEvent.LOAD_ADNETWORK)
                        .setListener("loadAdOrStop"));

        if (listener != null) {
            listener.onStartedLoading(name);
        }

        ad.load(applicationContext, getActivity());

        return false;
    }

    private void setExpirationTimer() {
        clearExpirationTimer();

        final ExpirationTime expirationTime =
                VAMPDebugUtils.newInstance().expirationTime.orElse(ExpirationTime.newDefault());

        LogUtils.d(
                "MediationManager starts the expiration timer: "
                        + expirationTime.timeInMilliseconds
                        + "ms");

        expirationTimer.cancelAndSchedule(expirationTime.timeInMilliseconds,
                new ExpirationTimerTask(this));
    }

    private void clearExpirationTimer() {
        LogUtils.d("MediationManager stops the expiration timer.");

        expirationTimer.cancelIfScheduled();
    }

    private void setRequestTimer(@NonNull final RequestTimeout requestTimeout) {
        LogUtils.devLog("set request timer.");
        clearRequestTimer();

        requestTimer.cancelAndSchedule(requestTimeout.timeInMilliseconds(),
                new RequestTimerTask(this));
    }

    private void clearRequestTimer() {
        LogUtils.devLog("clear request timer.");

        requestTimer.cancelIfScheduled();
    }

    @NonNull
    private CloudLogger.CloudLogItem baseLogItem() {
        return new CloudLogger.CloudLogItem()
                .setAdId(placementId)
                .setState(state)
                .setSeqId(getResponseInfo().getSeqID());
    }

    @NonNull
    private CloudLogger.CloudLogItem logItem(@NonNull final Mediation mediation) {
        return baseLogItem()
                .setAdNetworkName(mediation.getAdNetworkName())
                .setAdNetworkVersion(mediation.getAdNetworkVersion())
                .setAdNetworkAdIdentifiers(mediation.getAdNetworkAdIdentifiers())
                .setAdapterVersion(mediation.getAdapterVersion());
    }

    @Override
    public void sendLogEvent(
            @NonNull final Mediation ad, @Nullable final AdNetworkErrorInfo errorInfo) {
        if (errorInfo == null) return;

        final CloudLogger.CloudLogItem item =
                logItem(ad)
                        .setListener(errorInfo.getMethodName())
                        .setError(errorInfo.getError(), errorInfo.getErrorMessage())
                        .setAdNetworkErrorCode(errorInfo.getAdNetworkErrorCode())
                        .setAdNetworkErrorMessage(errorInfo.getAdNetworkErrorMessage());

        if (state.isShowing() && playbackTimeMeasurement.isPresent()) {
            final double showSec = playbackTimeMeasurement.forced().getElapsedTimeInSeconds();
            item.setShowSec(showSec);
        }

        cloudLogger.send(item);
    }

    @Override
    public void onLoadSuccess(@NonNull final Mediation mediation) {
        try {
            state = state.changed(MediationState.Value.LOADED);
        } catch (MediationState.NotChangedException e) {
            LogUtils.d(e.getMessage());
            return;
        }

        try {
            responseInfo.unwrap().withAdNetworkName(mediation.getAdNetworkName());
        } catch (Optional.NotPresentException ignored) {
        }

        LogUtils.d("Loaded " + mediation.getAdNetworkName());

        QALogger.logReceiveEvent(mediation.getAdNetworkName());

        cloudLogger.send(
                logItem(mediation)
                        .setEvent(CloudLogger.CloudLogEvent.RECEIVE)
                        .setListener("onLoadSuccess")
                        .setLoadSec(
                                loadTimeMeasurement.isPresent()
                                        ? loadTimeMeasurement.forced().getElapsedTimeInSeconds()
                                        : 0));

        if (listener != null) {
            listener.onLoaded(mediation.getAdNetworkName(), null);
            listener.onReceived();
        }

        setExpirationTimer();
        clearRequestTimer();
    }

    @Override
    public void onFailed(@NonNull final Mediation mediation, @NonNull final VAMPError error) {
        if (state.isLoading()) {
            LogUtils.d("Failed to load " + mediation.getAdNetworkName());

            QALogger.logAdNetworkFailEvent(mediation.getAdNetworkName(), error, null);

            if (listener != null) {
                listener.onLoaded(mediation.getAdNetworkName(), error);
            }

            if (error != VAMPError.MEDIATION_TIMEOUT) {
                mediationContainer.ifPresent(MediationContainer::nextMediation);

                if (loadAdOrStop()) {
                    failedToLoad(
                            VAMPError.NO_ADSTOCK,
                            new VAMPMap().add("Failed to load all adnetwork."));
                }
            } else {
                // タイムアウトエラーならば中断する.
                // 回線状況が悪い中でADNWのロードを続けるのは悪循環になるため.
                // ただし,一応のケアとしてVAST広告のロードを試みる
                // (通信は発生するが,VAST広告は在庫が担保されているので待ち続ければロード成功する.ただ,時間がかかれば結局タイムアウトしてしまう...)
                mediationContainer.ifPresent(MediationContainer::nextVASTMediation);

                if (loadAdOrStop()) {
                    failedToLoad(VAMPError.MEDIATION_TIMEOUT, new VAMPMap());
                }
            }
        } else if (state.isBeginPlayback() || state.isShowing()) {
            failedToShow(error);
        }
    }

    @Override
    public void onVideoStart(@NonNull final Mediation mediation) {
        try {
            state = state.changed(MediationState.Value.SHOWING);
        } catch (MediationState.NotChangedException e) {
            LogUtils.d(e.getMessage());
            return;
        }

        cloudLogger.send(
                logItem(mediation)
                        .setEvent(CloudLogger.CloudLogEvent.OPEN)
                        .setListener("onVideoStart"));

        if (listener != null) {
            listener.onOpened();
        }
    }

    @Override
    public void onVideoComplete(@NonNull final Mediation mediation) {
        // CloseとCompleteはどちらが先に呼ばれるか不定のため条件は2つ用意しておく
        if (!(state.isShowing() || state.isFinished())) {
            LogUtils.d("The state is not SHOWING or DESTROYED (closed).");
            return;
        }
        // Completeは1回だけ発火されること
        try {
            state = state.compareAndSetOnComplete();
        } catch (MediationState.NotChangedException e) {
            LogUtils.d(e.getMessage());
            return;
        }

        QALogger.logCompleteEvent(mediation.getAdNetworkName());

        cloudLogger.send(
                logItem(mediation)
                        .setEvent(CloudLogger.CloudLogEvent.COMPLETE)
                        .setListener("onVideoComplete"));

        if (listener != null) {
            listener.onCompleted();
        }
    }

    @Override
    public void onAdClosed(@NonNull final Mediation mediation, final boolean adClicked) {
        // Closeはどのような状態でも必ず発火されること。また1回だけ発火されること
        try {
            state = state.compareAndSetOnClose();
        } catch (MediationState.NotChangedException e) {
            LogUtils.d(e.getMessage());
            return;
        }

        QALogger.logCloseEvent(mediation.getAdNetworkName());

        cloudLogger.send(
                logItem(mediation)
                        .setEvent(CloudLogger.CloudLogEvent.CLOSE)
                        .setListener("onAdClosed")
                        .setAdClicked(Optional.of(adClicked)));

        if (listener != null) {
            listener.onClosed(adClicked);
        }

        destroyManager();
    }

    private void onExpired() {
        if (state.isLoaded()) {
            mediationContainer
                    .flatMap(MediationContainer::getCurrentMediation)
                    .ifPresent(
                            mediation ->
                                    cloudLogger.send(
                                            logItem(mediation)
                                                    .setEvent(CloudLogger.CloudLogEvent.EXPIRE)
                                                    .setListener("onExpired")));

            if (listener != null) {
                listener.onExpired();
            }
        }

        destroyManager();
    }

    private void failedToLoad(
            @NonNull final VAMPError error, @NonNull final VAMPMap errorMessages) {
        if (!state.isLoading()) {
            LogUtils.d("The state is not loading.");
            return;
        }

        LogUtils.d("Failed to load: " + error + ", " + errorMessages);

        final String adNetworkName =
                mediationContainer
                        .flatMap(MediationContainer::getCurrentMediation)
                        .map(Mediation::getAdNetworkName)
                        .orElse("");
        QALogger.logAdNetworkFailEvent(adNetworkName, error, errorMessages.toString());

        cloudLogger.send(
                baseLogItem()
                        .setEvent(CloudLogger.CloudLogEvent.LOAD_FAILURE)
                        .setListener("failedToLoad")
                        .setLoadSec(
                                loadTimeMeasurement.isPresent()
                                        ? loadTimeMeasurement.forced().getElapsedTimeInSeconds()
                                        : 0));

        if (listener != null) {
            listener.onFailedToLoad(error);
        }

        destroyManager();
    }

    private void failedToShow(@NonNull final VAMPError error) {
        LogUtils.d("Failed to show: " + error);

        QALogger.logFailEvent(getResponseInfo().getAdNetworkName(), error);

        if (listener != null) {
            listener.onFailedToShow(error);
        }

        destroyManager();
    }

    private static final class ExpirationTimerTask extends TimerTask {
        @NonNull private final Handler handler = new Handler();
        @NonNull private final WeakReference<MediationManager> managerRef;

        ExpirationTimerTask(@NonNull final MediationManager manager) {
            managerRef = new WeakReference<>(manager);
        }

        @Override
        public void run() {
            handler.post(
                    () -> {
                        MediationManager manager = managerRef.get();

                        if (manager == null) {
                            cancel();
                            return;
                        }

                        LogUtils.d("Expired.");

                        manager.onExpired();
                        cancel();
                    });
        }
    }

    private static final class RequestTimerTask extends TimerTask {
        @NonNull private final Handler handler = new Handler();
        @NonNull private final WeakReference<MediationManager> managerRef;

        RequestTimerTask(@NonNull final MediationManager manager) {
            managerRef = new WeakReference<>(manager);
        }

        @Override
        public void run() {
            handler.post(
                    () -> {
                        MediationManager manager = managerRef.get();

                        if (manager == null) {
                            cancel();
                            return;
                        }

                        LogUtils.d("Request Timeout.");

                        manager.failedToLoad(VAMPError.REQUEST_TIMEOUT, new VAMPMap());
                        cancel();
                    });
        }
    }
}
