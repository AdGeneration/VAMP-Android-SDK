package jp.supership.vamp.player.view;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Color;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import jp.supership.sscore.vamp.adreport.SSCoreAdReport;
import jp.supership.sscore.vamp.adreport.SSCoreAdReportConfigException;
import jp.supership.sscore.vamp.adreport.SSCoreAdReportListener;
import jp.supership.sscore.vamp.adreport.view.SSCoreAdReportButton;
import jp.supership.sscore.vamp.type.Optional;
import jp.supership.sscore.vamp.type.Result;
import jp.supership.vamp.core.logging.LogUtils;
import jp.supership.vamp.core.vast.VASTObject;
import jp.supership.vamp.core.vast.VASTPMPCreativeExtension;
import jp.supership.vamp.measurement.Obstruction;
import jp.supership.vamp.player.LandingPage;
import jp.supership.vamp.player.VAMPPlayerAd;
import jp.supership.vamp.utils.LocaleUtils;

/** 音声ボタンなどのコントロールUI */
public final class ControlView extends FrameLayout {
    interface Listener extends SoundButton.Listener, IMarkButton.Listener, CountDownView.Listener {
        void onClose();

        void onLinkTextClick();

        /** 広告をクリックしたときに呼ばれます。(画面全体がクリック領域です) */
        void onAdClick();

        /** インストールボタンが押されたときに呼ばれます */
        void onInstallButtonClick();
    }

    private static final ClickableAreaView.Key KEY_CLICK = new ClickableAreaView.Key("click");
    private static final ClickableAreaView.Key KEY_INSTALL = new ClickableAreaView.Key("install");
    private static final String DEFAULT_PRIVACY_TEXT = "Privacy Policy";
    private static final int LINK_TEXT_PADDING = 5;
    private static final float HEADER_PADDING_X_PORTRAIT = 15.f;
    private static final float HEADER_PADDING_Y_PORTRAIT = 15.f;
    private static final float HEADER_PADDING_X_LANDSCAPE = 15.f;
    private static final float HEADER_PADDING_Y_LANDSCAPE = 18.f;
    private static final float FOOTER_PADDING_X_PORTRAIT = 15.f;
    private static final float FOOTER_PADDING_Y_PORTRAIT = 15.f;
    private static final float FOOTER_PADDING_X_LANDSCAPE = 15.f;
    private static final float FOOTER_PADDING_Y_LANDSCAPE = 18.f;

    @NonNull private final IMarkButton iMarkButton;
    @NonNull private final CountDownView countDownView;
    @NonNull private final SoundButton soundButton;
    @NonNull private final Row headerView;
    @NonNull private final Row footerView;
    @NonNull private final CloseButton closeButton;
    @NonNull private Optional<SSCoreAdReportButton> adReportButton = Optional.empty();
    /** もっと見るボタン */
    @NonNull private final Optional<LinkTextButton> linkTextButton;

    @NonNull private final ClickableAreaView clickableArea;
    /**
     * LP用インストールボタン
     *
     * <p>このボタンが存在するときは`linkTextButton`は非表示にします
     */
    @NonNull private final Optional<LinkTextButton> installTextButton;

    @NonNull private final InstallButtonTitle installButtonTitle;

    private ControlView(
            @NonNull final Context context,
            @Nullable final String privacyText,
            @Nullable final String iMarkImageFilePath,
            final boolean isAutoInstall,
            @NonNull final VAMPPlayerAd ad,
            @NonNull final Listener listener,
            @NonNull final SSCoreAdReportListener adReportListener) {
        super(context);

        setMotionEventSplittingEnabled(false);
        setBackgroundColor(Color.TRANSPARENT);
        setLayerType(LAYER_TYPE_HARDWARE, null);
        setDescendantFocusability(FOCUS_BLOCK_DESCENDANTS);

        final DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
        final float density = displayMetrics.density;

        LinearLayout linearLayout = new LinearLayout(context);
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        addView(linearLayout, layoutParamsOfFullScreenContent());

        headerView = Row.addTo(linearLayout, context);

        clickableArea =
                ClickableAreaView.addTo(
                        linearLayout,
                        context,
                        KEY_CLICK,
                        new ClickableAreaView.Listener() {
                            @Override
                            public void onClick(@NonNull ClickableAreaView.Key key) {
                                if (KEY_CLICK.equals(key)) {
                                    listener.onAdClick();
                                } else if (KEY_INSTALL.equals(key)) {
                                    listener.onInstallButtonClick();
                                }
                            }
                        });

        footerView = Row.addTo(linearLayout, context);

        soundButton =
                SoundButton.addTo(
                        headerView,
                        context,
                        density,
                        Gravity.TOP | Gravity.START,
                        new SoundButton.Listener() {
                            @Override
                            public void onMute() {
                                listener.onMute();
                            }

                            @Override
                            public void onUnmute() {
                                listener.onUnmute();
                            }
                        });

        closeButton =
                CloseButton.addTo(
                        headerView,
                        context,
                        CloseButton.ICON_CLOSE_CIRCLE,
                        density,
                        Gravity.TOP | Gravity.END,
                        new CloseButton.Listener() {
                            @Override
                            public void onClick() {
                                listener.onClose();
                            }
                        });
        // 初期状態は隠した状態
        closeButton.setVisibility(INVISIBLE);

        countDownView =
                CountDownView.addTo(
                        headerView,
                        context,
                        ad.canSkip(),
                        density,
                        Gravity.TOP | Gravity.END,
                        new CountDownView.Listener() {
                            @Override
                            public void onSkip() {
                                listener.onSkip();
                            }
                        });

        final boolean hasPrivacyText = !TextUtils.isEmpty(privacyText);
        final String iMarkText = hasPrivacyText ? privacyText : DEFAULT_PRIVACY_TEXT;
        iMarkButton =
                IMarkButton.addTo(
                        footerView,
                        context,
                        iMarkImageFilePath,
                        iMarkText,
                        hasPrivacyText,
                        density,
                        Gravity.BOTTOM,
                        new IMarkButton.Listener() {
                            @Override
                            public void onOptOutLinkClick() {
                                listener.onOptOutLinkClick();
                            }
                        });

        SSCoreAdReportButton.addTo(
                footerView,
                context,
                density,
                Gravity.BOTTOM,
                adReportListener,
                new SSCoreAdReportButton.Listener() {
                    @Override
                    public void onConfigured(
                            @NonNull
                                    Result<SSCoreAdReportButton, SSCoreAdReportConfigException>
                                            result) {
                        if (!result.isSuccess()) {
                            LogUtils.e("Failed to show ad report button. result: " + result);
                            return;
                        }

                        ControlView.this.adReportButton = result.data;
                    }

                    @Override
                    public void onClicked(@NonNull SSCoreAdReport adReport) {
                        adReport.showAdReportView(context, ControlView.this, density);
                    }
                });

        final String linkText = ad.getLinkText();
        if (!TextUtils.isEmpty(linkText)) {
            LinkTextButton button =
                    LinkTextButton.addTo(
                            footerView,
                            context,
                            linkText,
                            LINK_TEXT_PADDING,
                            Gravity.END | Gravity.BOTTOM,
                            new LinkTextButton.Listener() {
                                @Override
                                public void onClick() {
                                    listener.onLinkTextClick();
                                }
                            });
            linkTextButton = Optional.of(button);
        } else {
            linkTextButton = Optional.empty();
        }

        final VASTObject vastObject = ad.vastObject;
        final VASTPMPCreativeExtension pmp = vastObject.getPmpExtension();

        if (pmp != null) {
            if (ad.selectedClickThrough.isPresent()) {
                installButtonTitle =
                        new InstallButtonTitle(pmp.getCtaButtonText(), pmp.getCtaButtonTextExtra());
            } else {
                installButtonTitle = InstallButtonTitle.empty();
            }
        } else {
            final Optional<LandingPage> lp = ad.selectedLandingPage;
            if (lp.isPresent() && lp.forced().isAutoInstallAvailable()) {
                installButtonTitle = InstallButtonTitle.newDefault();
            } else {
                installButtonTitle = InstallButtonTitle.empty();
            }
        }

        if (installButtonTitle.isEmpty()) {
            installTextButton = Optional.empty();
        } else {
            final String text = installButtonTitle.get(isAutoInstall);

            if (pmp != null) {
                final int padding = (int) (LINK_TEXT_PADDING + 6 * calcScaleFactor(context, pmp));
                LinkTextButton button =
                        LinkTextButton.addTo(
                                this,
                                context,
                                text,
                                padding,
                                Gravity.END | Gravity.BOTTOM,
                                new LinkTextButton.Listener() {
                                    @Override
                                    public void onClick() {
                                        listener.onInstallButtonClick();
                                    }
                                });
                button.setBackgroundForState(isAutoInstall);
                installTextButton = Optional.of(button);

                if (!pmp.isButtonEnableOnPlaying()) {
                    button.setVisibility(INVISIBLE);
                }
            } else {
                LinkTextButton button =
                        LinkTextButton.addTo(
                                this,
                                context,
                                text,
                                LINK_TEXT_PADDING,
                                Gravity.END | Gravity.BOTTOM,
                                new LinkTextButton.Listener() {
                                    @Override
                                    public void onClick() {
                                        listener.onInstallButtonClick();
                                    }
                                });
                button.setBackgroundForState(isAutoInstall);
                installTextButton = Optional.of(button);
            }

            // インストールボタンが存在するとき、linkTextButtonは重なってしまうため非表示
            if (installTextButton.isPresent()) {
                try {
                    linkTextButton.unwrap().setVisibility(INVISIBLE);
                } catch (Optional.NotPresentException ignored) {
                }
            }
        }

        changeLayout(getResources().getConfiguration().orientation);
    }

    /** Viewを生成し、`parent`に追加します */
    @NonNull
    static ControlView addTo(
            @NonNull final ViewGroup parent,
            @NonNull final Context context,
            @Nullable final String privacyText,
            @Nullable final String iMarkImageFilePath,
            final boolean isAutoInstall,
            @NonNull final VAMPPlayerAd ad,
            @NonNull final Listener listener,
            @NonNull final SSCoreAdReportListener adReportListener) {
        final ControlView view =
                new ControlView(
                        context,
                        privacyText,
                        iMarkImageFilePath,
                        isAutoInstall,
                        ad,
                        listener,
                        adReportListener);
        parent.addView(view, layoutParamsOfFullScreenContent());
        return view;
    }

    @NonNull
    private static LayoutParams layoutParamsOfFullScreenContent() {
        final LayoutParams params =
                new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
        params.gravity = Gravity.CENTER;
        return params;
    }

    public void changeLayout(int orientation) {
        final DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
        final float density = displayMetrics.density;

        if (orientation == Configuration.ORIENTATION_PORTRAIT) {
            headerView.setPadding(
                    (int) (HEADER_PADDING_X_PORTRAIT * density),
                    (int) (HEADER_PADDING_Y_PORTRAIT * density),
                    (int) (HEADER_PADDING_X_PORTRAIT * density),
                    0);
            footerView.setPadding(
                    (int) (FOOTER_PADDING_X_PORTRAIT * density),
                    0,
                    (int) (FOOTER_PADDING_X_PORTRAIT * density),
                    (int) (FOOTER_PADDING_Y_PORTRAIT * density));
        } else {
            headerView.setPadding(
                    (int) (HEADER_PADDING_X_LANDSCAPE * density),
                    (int) (HEADER_PADDING_Y_LANDSCAPE * density),
                    (int) (HEADER_PADDING_X_LANDSCAPE * density),
                    0);
            footerView.setPadding(
                    (int) (FOOTER_PADDING_X_LANDSCAPE * density),
                    0,
                    (int) (FOOTER_PADDING_X_LANDSCAPE * density),
                    (int) (FOOTER_PADDING_Y_LANDSCAPE * density));
        }
    }

    public void setAutoInstall(final boolean isAutoInstall) {
        try {
            LinkTextButton button = installTextButton.unwrap();
            button.setText(installButtonTitle.get(isAutoInstall));
            button.setBackgroundForState(isAutoInstall);
        } catch (Optional.NotPresentException ignored) {
        }
    }

    @Nullable
    public Obstruction getObstruction(@NonNull Obstruction.ObstructedViewType type) {
        switch (type) {
            case HEADER_VIEW:
                // 上部ボタンエリア
                return new Obstruction(headerView, type);
            case FOOTER_VIEW:
                // 下部ボタンエリア
                return new Obstruction(footerView, type);
            case COUNT_DOWN_VIEW:
                // 秒数カウント
                return new Obstruction(countDownView, type);
            case IMARK_BUTTON:
                // iマーク
                return new Obstruction(iMarkButton, type);
            case ADREPORT_BUTTON:
                // AdReportボタン
                if (adReportButton.isPresent()) {
                    return new Obstruction(adReportButton.forced(), type);
                }
            case SOUND_BUTTON_AREA:
                // サウンドON・OFFボタンエリア
                return new Obstruction(soundButton, type);
            case CLOSE_BUTTON:
                // 閉じるボタン
                return new Obstruction(closeButton, type);
            default:
                return null;
        }
    }

    /** サウンドON状態にします */
    void unmute() {
        soundButton.unmute();
    }

    /** サウンドOFF状態にします */
    void mute() {
        soundButton.mute();
    }

    /**
     * 再生残り時間表示を更新します
     *
     * @param count 次のカウント
     * @param showSkipButton trueならばスキップボタンを表示します
     */
    void updateCount(int count, boolean showSkipButton) {
        countDownView.updateCount(count);

        if (showSkipButton) {
            countDownView.showSkipButton();
        }
    }

    void showEndCard(boolean isEndCardClickable) {
        // カウントダウン非表示
        countDownView.setVisibility(INVISIBLE);
        // サウンドON・OFF非表示
        soundButton.setVisibility(INVISIBLE);
        // iマーク表示
        iMarkButton.setVisibility(VISIBLE);
        // 閉じるボタン表示
        closeButton.setVisibility(VISIBLE);
        // AdReportボタン表示
        adReportButton.ifPresent(value -> value.setVisibility(VISIBLE));

        if (!isEndCardClickable) {
            clickableArea.setVisibility(INVISIBLE);
            try {
                linkTextButton.unwrap().setVisibility(INVISIBLE);
            } catch (Optional.NotPresentException ignored) {
            }
        } else if (installTextButton.isPresent()) {
            clickableArea.setKey(KEY_INSTALL);
        } else {
            // もっと見るボタン表示
            try {
                linkTextButton.unwrap().setVisibility(VISIBLE);
            } catch (Optional.NotPresentException ignored) {
            }
        }

        try {
            installTextButton.unwrap().setVisibility(VISIBLE);
        } catch (Optional.NotPresentException ignored) {
        }
    }

    void hideEndCard() {
        // カウントダウン表示
        countDownView.setVisibility(VISIBLE);
        // サウンドON・OFF表示
        soundButton.setVisibility(VISIBLE);
        // iマーク表示
        iMarkButton.setVisibility(VISIBLE);
        // AdReportボタン表示
        adReportButton.ifPresent(value -> value.setVisibility(VISIBLE));
        // 閉じるボタン非表示
        closeButton.setVisibility(INVISIBLE);

        if (installTextButton.isPresent()) {
            clickableArea.setKey(KEY_CLICK);
        }

        // もっと見るボタン非表示
        try {
            linkTextButton.unwrap().setVisibility(INVISIBLE);
        } catch (Optional.NotPresentException ignored) {
        }
    }

    private static float calcScaleFactor(
            @NonNull final Context context, @NonNull final VASTPMPCreativeExtension pmp) {
        float scaleFactor;
        switch (pmp.getCtaButtonHSize()) {
            case VASTPMPCreativeExtension.CTA_BUTTON_HSIZE_SMALL:
                scaleFactor = 1.5f;
                break;
            case VASTPMPCreativeExtension.CTA_BUTTON_HSIZE_MIDDLE:
                scaleFactor = 2.5f;
                break;
            case VASTPMPCreativeExtension.CTA_BUTTON_HSIZE_LARGE:
                scaleFactor = 3.f;
                break;
            case VASTPMPCreativeExtension.CTA_BUTTON_HSIZE_XLARGE:
                scaleFactor = 3.5f;
                break;
            case VASTPMPCreativeExtension.CTA_BUTTON_HSIZE_DEFAULT:
            default:
                scaleFactor = 2.f;
        }

        final DisplayMetrics metrics = context.getResources().getDisplayMetrics();
        if (metrics != null) {
            if (metrics.heightPixels > metrics.widthPixels) {
                scaleFactor *= (metrics.heightPixels / 1920.f);
            } else {
                scaleFactor *= (metrics.widthPixels / 1920.f);
            }
        }

        return scaleFactor;
    }

    private static final class InstallButtonTitle {
        private static final String TITLE_OFF_EN = "GET";
        private static final String TITLE_ON_EN = "GET";
        private static final String TITLE_OFF_JP = "入手";
        private static final String TITLE_ON_JP = "広告の後に移動します";

        /** 自動遷移無効時のタイトル */
        @NonNull private final String off;
        /** 自動遷移有効時のタイトル */
        @NonNull private final String on;

        InstallButtonTitle(@Nullable final String off, @Nullable final String on) {
            this.off = off != null ? off : "";
            this.on = on != null ? on : "";
        }

        @NonNull
        static InstallButtonTitle empty() {
            return new InstallButtonTitle("", "");
        }

        @NonNull
        static InstallButtonTitle newDefault() {
            if (LocaleUtils.isJapanese()) {
                return new InstallButtonTitle(TITLE_OFF_JP, TITLE_ON_JP);
            } else {
                return new InstallButtonTitle(TITLE_OFF_EN, TITLE_ON_EN);
            }
        }

        boolean isEmpty() {
            return TextUtils.isEmpty(off) || TextUtils.isEmpty(on);
        }

        @NonNull
        String get(boolean isOn) {
            return isOn ? on : off;
        }
    }
}
