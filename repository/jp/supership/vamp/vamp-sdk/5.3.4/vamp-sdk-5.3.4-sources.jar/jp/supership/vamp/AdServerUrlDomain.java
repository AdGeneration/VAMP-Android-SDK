package jp.supership.vamp;

final class AdServerUrlDomain {
    private interface IAdServerUrlDomain {
        /** アドサーバ・ドメイン */
        String domain();

        /** アドサーバURL */
        String adUrlString();
    }

    private static final class ProductionServerDomain implements IAdServerUrlDomain {

        @Override
        public String domain() {
            return "d.socdm.com";
        }

        @Override
        public String adUrlString() {
            return "https://" + domain() + "/adsv/v1";
        }
    }

    private static final class DevelopmentServerDomain implements IAdServerUrlDomain {

        @Override
        public String domain() {
            return "api-test.scaleout.jp";
        }

        @Override
        public String adUrlString() {
            return "https://" + domain() + "/adsv/v1";
        }
    }

    private static AdServerUrlDomain instance = null;

    private final IAdServerUrlDomain domainObject;

    private AdServerUrlDomain(IAdServerUrlDomain domainObject) {
        this.domainObject = domainObject;
    }

    static synchronized AdServerUrlDomain getInstance() {
        if (instance == null) {
            instance =
                    new AdServerUrlDomain(
                            BuildConfig.DEV_SERVER
                                    ? new DevelopmentServerDomain()
                                    : new ProductionServerDomain());
        }

        return instance;
    }

    /** アドサーバ・ドメイン */
    String domain() {
        return domainObject.domain();
    }

    /** アドサーバURL */
    String adUrlString() {
        return domainObject.adUrlString();
    }
}
