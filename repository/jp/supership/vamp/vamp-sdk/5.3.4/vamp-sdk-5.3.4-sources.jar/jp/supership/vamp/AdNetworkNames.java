package jp.supership.vamp;

import androidx.annotation.NonNull;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class AdNetworkNames {
    public static final String VAMP_ADNETWORK_NAME_ADMOB = "AdMob";
    public static final String VAMP_ADNETWORK_NAME_APPLOVIN = "AppLovin";
    public static final String VAMP_ADNETWORK_NAME_IRONSOURCE = "IronSource";
    public static final String VAMP_ADNETWORK_NAME_MAIO = "maio";
    public static final String VAMP_ADNETWORK_NAME_PANGLE = "Pangle";
    public static final String VAMP_ADNETWORK_NAME_UNITYADS = "UnityAds";
    public static final String VAMP_ADNETWORK_NAME_LINE = "LINEAds";
    public static final String VAMP_ADNETWORK_NAME_VAMP = "VAMP";

    private static final Map<String, String> adnwNameMap = new HashMap<>();

    static {
        adnwNameMap.put("AdmobMediation", VAMP_ADNETWORK_NAME_ADMOB);
        adnwNameMap.put("AppLovinMediation", VAMP_ADNETWORK_NAME_APPLOVIN);
        adnwNameMap.put("ironSourceMediation", VAMP_ADNETWORK_NAME_IRONSOURCE);
        adnwNameMap.put("MaioMediation", VAMP_ADNETWORK_NAME_MAIO);
        adnwNameMap.put("PangleMediation", VAMP_ADNETWORK_NAME_PANGLE);
        adnwNameMap.put("UnityAdsMediation", VAMP_ADNETWORK_NAME_UNITYADS);
        adnwNameMap.put("FIVEMediation", VAMP_ADNETWORK_NAME_LINE);
        adnwNameMap.put("VASTMediation", VAMP_ADNETWORK_NAME_VAMP);
    }

    public static String getAdNetworkName(@NonNull String mediationClassName) {
        String[] splits = mediationClassName.split("\\.");
        if (splits.length <= 0) {
            return "";
        }

        String className = splits[splits.length - 1];

        if (adnwNameMap.containsKey(className)) {
            return adnwNameMap.get(className);
        }

        return className.replace("Mediation", "").trim();
    }

    public static List<String> getAdNetworkNames() {
        return new ArrayList<>(adnwNameMap.values());
    }
}
