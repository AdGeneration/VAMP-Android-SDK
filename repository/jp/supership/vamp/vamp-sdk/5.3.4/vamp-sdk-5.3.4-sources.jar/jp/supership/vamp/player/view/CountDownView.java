package jp.supership.vamp.player.view;

import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import jp.supership.vamp.R;

import java.io.IOException;
import java.io.InputStream;
import java.util.Locale;

/**
 * カウントダウン表示UI。 コンストラクタ引数の`canSkip`にtrueを指定することでスキップボタンを有効にします (showSkipButtonメソッドを呼ぶまで表示はされません)。
 *
 * <p>Created by masaki.ando on 2018/07/02.
 */
final class CountDownView extends FrameLayout {
    interface Listener {
        void onSkip();
    }

    private static final int COUNTDOWN_VIEW_SIZE = 30;

    private final TextView countDownTextView;
    @Nullable private final SkipButton skipButton;
    private final float density;

    private CountDownView(
            @NonNull final Context context,
            final float density,
            final boolean canSkip,
            @NonNull final Listener listener) {
        super(context);

        this.density = density;

        setBackgroundResource(R.drawable.jp_supership_vamp_count_down_style);

        LinearLayout linearLayout = new LinearLayout(context);
        linearLayout.setOrientation(LinearLayout.HORIZONTAL);
        linearLayout.setLayoutParams(
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT));
        addView(linearLayout);

        countDownTextView = new TextView(context);
        countDownTextView.setTypeface(Typeface.SANS_SERIF, Typeface.BOLD);
        countDownTextView.setTextColor(Color.WHITE);
        countDownTextView.setTextSize(14);
        countDownTextView.setGravity(Gravity.CENTER);
        countDownTextView.setLayoutParams(
                new LayoutParams(
                        (int) (COUNTDOWN_VIEW_SIZE * density),
                        (int) (COUNTDOWN_VIEW_SIZE * density)));
        linearLayout.addView(countDownTextView);

        if (canSkip) {
            skipButton = new SkipButton(context, density);
            linearLayout.addView(skipButton);
            skipButton.setOnClickListener(
                    new OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            listener.onSkip();
                        }
                    });
            skipButton.setVisibility(GONE);
        } else {
            skipButton = null;
        }
    }

    /** Viewを生成し、`parent`に追加します */
    @NonNull
    static CountDownView addTo(
            @NonNull final ViewGroup parent,
            @NonNull final Context context,
            final boolean skipEnabled,
            final float density,
            final int gravity,
            @NonNull final Listener listener) {
        final CountDownView view = new CountDownView(context, density, skipEnabled, listener);
        final LayoutParams params =
                new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
        params.gravity = gravity;
        parent.addView(view, params);
        return view;
    }

    void updateCount(int count) {
        countDownTextView.setText(String.format(Locale.getDefault(), "%d", count));
    }

    void showSkipButton() {
        if (skipButton == null || skipButton.getVisibility() == VISIBLE) {
            return;
        }

        PropertyValuesHolder animA = PropertyValuesHolder.ofFloat("alpha", 0, 1.f);
        ObjectAnimator animator1 = ObjectAnimator.ofPropertyValuesHolder(skipButton, animA);
        animator1.setDuration(400);
        animator1.start();

        final ValueAnimator animator2 =
                ValueAnimator.ofInt(
                        countDownTextView.getLayoutParams().height,
                        (int) (COUNTDOWN_VIEW_SIZE * 1.5 * density));
        final ViewGroup.LayoutParams params = countDownTextView.getLayoutParams();
        animator2.addUpdateListener(
                new ValueAnimator.AnimatorUpdateListener() {
                    @Override
                    public void onAnimationUpdate(ValueAnimator animation) {
                        params.width = (int) animator2.getAnimatedValue();
                        countDownTextView.setLayoutParams(params);
                    }
                });

        animator2.setDuration(400);
        animator2.start();

        final ValueAnimator animator3 =
                ValueAnimator.ofInt(
                        countDownTextView.getPaddingLeft(),
                        (int) (COUNTDOWN_VIEW_SIZE * 0.3 * density));
        animator3.addUpdateListener(
                new ValueAnimator.AnimatorUpdateListener() {
                    @Override
                    public void onAnimationUpdate(ValueAnimator animation) {
                        countDownTextView.setPadding((int) animator3.getAnimatedValue(), 0, 0, 0);
                    }
                });

        animator3.setDuration(400);
        animator3.start();

        skipButton.setVisibility(VISIBLE);
    }

    private static final class SkipButton extends ImageView {
        private static final int BUTTON_SIZE = 30;

        SkipButton(@NonNull final Context context, final float density) {
            super(context);

            FrameLayout.LayoutParams params =
                    new FrameLayout.LayoutParams(
                            (int) (BUTTON_SIZE * density), (int) (BUTTON_SIZE * density));
            setLayoutParams(params);

            InputStream is = null;
            try {
                is = context.getResources().getAssets().open("adgp_vamp_skip.png");
                setImageBitmap(BitmapFactory.decodeStream(is));
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                if (is != null) {
                    try {
                        is.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }
}
