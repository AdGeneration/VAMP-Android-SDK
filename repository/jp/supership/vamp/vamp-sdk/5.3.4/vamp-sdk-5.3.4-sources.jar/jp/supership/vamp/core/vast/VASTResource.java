package jp.supership.vamp.core.vast;

import android.content.Context;
import android.text.TextUtils;

import jp.supership.vamp.core.cache.DiskLruCache;
import jp.supership.vamp.core.error.VAMPInternalError;
import jp.supership.vamp.core.http.HttpClient;
import jp.supership.vamp.core.http.HttpMethod;
import jp.supership.vamp.core.http.HttpRequest;
import jp.supership.vamp.core.http.HttpResponse;
import jp.supership.vamp.core.http.IHttpClient;
import jp.supership.vamp.core.http.IHttpClientListener;
import jp.supership.vamp.core.logging.LogUtils;

import java.io.Serializable;
import java.net.MalformedURLException;
import java.net.URL;

public class VASTResource implements Serializable {
    public interface ILoadListener {
        void onCompleted(VASTResource resource, VAMPInternalError error);
    }

    /** 単位: 秒 */
    private static final int REQUEST_CONNECTION_TIMEOUT = 5000;
    /** 単位: 秒 */
    private static final int REQUEST_READ_TIMEOUT = 300000;

    private String creativeType;
    private String urlString;

    public VASTResource(String creativeType, String file) {
        this.creativeType = creativeType;
        this.urlString = file;
    }

    public String getCreativeType() {
        return creativeType;
    }

    public boolean isLoaded(Context context) {
        return !TextUtils.isEmpty(getImageFilePath(context));
    }

    public void load(final Context context, final ILoadListener listener) {
        LogUtils.devLog("load resource:." + urlString);

        URL url = null;
        try {
            url = new URL(urlString);
        } catch (MalformedURLException e) {
            e.printStackTrace();

            if (listener != null) {
                listener.onCompleted(
                        null,
                        new VAMPInternalError(
                                VAMPInternalError.Code.UNKNOWN, "invalid resource url."));
            }
            return;
        }

        HttpRequest httpRequest =
                new HttpRequest(url)
                        .setMethod(HttpMethod.GET)
                        .setReadTimeout(REQUEST_READ_TIMEOUT)
                        .setConnectionTimeout(REQUEST_CONNECTION_TIMEOUT);

        IHttpClient httpClient = HttpClient.getInstance();
        httpClient.send(
                httpRequest,
                new IHttpClientListener() {
                    @Override
                    public void onSuccess(HttpResponse response) {
                        if (!response.isSuccess() || response.getContent() == null) {
                            if (listener != null) {
                                listener.onCompleted(
                                        null,
                                        new VAMPInternalError(
                                                VAMPInternalError.Code.NETWORK_ERROR,
                                                "statusCode:" + response.getStatusCode()));
                            }

                            return;
                        }

                        try {
                            DiskLruCache cache = DiskLruCache.newInstance(context);
                            cache.storeData(response.getContent().data, urlString);
                            // success
                            if (listener != null) {
                                listener.onCompleted(VASTResource.this, null);
                            }

                        } catch (Exception e) {
                            LogUtils.devLog(e.getMessage());
                            if (listener != null) {
                                listener.onCompleted(
                                        null,
                                        new VAMPInternalError(
                                                VAMPInternalError.Code.IO_ERROR, e.getMessage()));
                            }
                        }
                    }

                    @Override
                    public void onFail(String errorMsg) {
                        if (listener != null) {
                            listener.onCompleted(
                                    null,
                                    new VAMPInternalError(
                                            VAMPInternalError.Code.NETWORK_ERROR, errorMsg));
                        }
                    }
                });
    }

    public String getUrlString() {
        return urlString;
    }

    public String getImageFilePath(Context context) {
        try {
            return DiskLruCache.newInstance(context).retrieveFilePath(urlString);
        } catch (Exception e) {
            LogUtils.devLog(e.getMessage());
            return null;
        }
    }
}
