package jp.supership.vamp.player.view;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;

final class LinkTextButton extends TextView implements View.OnClickListener {
    interface Listener {
        void onClick();
    }

    private static final int MARGIN = 5;
    private static final int MIN_WIDTH = 120;

    private final float density;
    private final float scale;
    @NonNull private final Listener listener;

    private LinkTextButton(
            @NonNull final Context context,
            @NonNull final String text,
            final int padding,
            @NonNull final Listener listener) {
        super(context);

        setText(text);
        setTextColor(Color.WHITE);
        setOnClickListener(this);

        final DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
        final float density = displayMetrics.density;

        float scale;
        final float minSize = Math.min(displayMetrics.widthPixels, displayMetrics.heightPixels);
        // 最小値が200ピクセル以下だと異常値(?)
        if (minSize > 200.f) {
            scale = minSize / 480.f;
            // タブレット対応のためのフォントサイズをピクセル指定に
            setTextSize(TypedValue.COMPLEX_UNIT_PX, 15.f * scale);
        } else {
            scale = 1.f;
            // 正常値が取れなかった場合はsp指定のまま
            setTextSize(12);
        }

        final int pad = (int) Math.floor(padding * density); // paddingはscaleを掛けない
        setPadding(pad * 2, pad, pad * 2, pad);
        setGravity(Gravity.CENTER);
        setMinWidth((int) (MIN_WIDTH * scale));

        this.density = density;
        this.scale = scale;
        this.listener = listener;

        setBackgroundForState(false);
    }

    /** Viewを生成し、`parent`に追加します */
    @NonNull
    static LinkTextButton addTo(
            @NonNull final ViewGroup parent,
            @NonNull final Context context,
            @NonNull final String text,
            final int padding,
            final int gravity,
            @NonNull final Listener listener) {
        final LinkTextButton button = new LinkTextButton(context, text, padding, listener);
        final FrameLayout.LayoutParams params =
                new FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.WRAP_CONTENT,
                        FrameLayout.LayoutParams.WRAP_CONTENT);
        params.gravity = gravity;
        final int mar = (int) Math.floor(MARGIN * button.density * button.scale);
        params.setMargins(mar, mar, mar, mar);
        parent.addView(button, params);
        return button;
    }

    @Override
    public void onClick(View v) {
        listener.onClick();
    }

    void setBackgroundForState(final boolean isOn) {
        // Reset
        ViewUtils.setBackground(this, null);

        GradientDrawable gd = new GradientDrawable();
        gd.setShape(GradientDrawable.RECTANGLE);
        gd.setCornerRadius(7.5f * scale);

        if (isOn) {
            gd.setStroke(3, Color.WHITE);
            gd.setColor(Color.rgb(194, 209, 234));
            setTextColor(Color.BLACK);
        } else {
            gd.setColor(Color.rgb(41, 98, 255));
            setTextColor(Color.WHITE);
        }

        ViewUtils.setBackground(this, gd);
    }
}
