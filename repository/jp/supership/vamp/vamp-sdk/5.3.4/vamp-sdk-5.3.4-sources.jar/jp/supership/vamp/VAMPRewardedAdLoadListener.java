package jp.supership.vamp;

import androidx.annotation.NonNull;

public interface VAMPRewardedAdLoadListener {
    /**
     * 広告表示が可能になると通知されます。
     *
     * @param placementId 広告枠ID
     */
    void onReceived(@NonNull String placementId);

    /**
     * 広告の取得に失敗すると通知されます。<br>
     *
     * <p>例) 広告取得時のタイムアウトや、全てのアドネットワークの在庫がない場合など。<br>
     *
     * <p>EU圏からのアクセスの場合（{@link VAMPError#NO_ADNETWORK}）が発生します。 2018-05-23現在 ※将来変更するかもしれません
     *
     * @param placementId 広告枠ID
     * @param error {@link VAMPError}
     */
    void onFailedToLoad(@NonNull String placementId, @NonNull VAMPError error);
}
