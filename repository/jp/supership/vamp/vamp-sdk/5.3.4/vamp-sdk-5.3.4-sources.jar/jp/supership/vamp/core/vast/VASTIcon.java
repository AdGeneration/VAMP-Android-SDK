package jp.supership.vamp.core.vast;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Map;

public class VASTIcon implements Serializable {
    private String program;
    private int height;
    private int width;
    private int xPosition;
    private int yPosition;
    private String apiFramework;
    private VASTResource staticResource;
    private String clickThroughURL;
    private ArrayList<VASTTracking> clickTrackings = new ArrayList<>();

    public VASTIcon(String apiFramework) {
        this.apiFramework = apiFramework;
    }

    public String getProgram() {
        return program;
    }

    public void setProgram(String program) {
        this.program = program;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public int getXPosition() {
        return xPosition;
    }

    public void setXPosition(int xPosition) {
        this.xPosition = xPosition;
    }

    public int getYPosition() {
        return yPosition;
    }

    public void setYPosition(int yPosition) {
        this.yPosition = yPosition;
    }

    public void setStaticResource(VASTResource staticResource) {
        this.staticResource = staticResource;
    }

    public VASTResource getStaticResource() {
        return staticResource;
    }

    public String getClickThroughURL() {
        return clickThroughURL;
    }

    public void setClickThroughURL(String clickThroughURL) {
        this.clickThroughURL = clickThroughURL;
    }

    public ArrayList<VASTTracking> getClickTrackings() {
        return clickTrackings;
    }

    public boolean isAdg() {
        return apiFramework.equals("adg");
    }

    public void sendTrackings(
            Map<String, String> headers, final VASTObject.VASTEventListener listener) {
        if (clickTrackings != null) {
            for (VASTTracking tracking : clickTrackings) {
                tracking.send(headers, listener);
            }
        }
    }
}
