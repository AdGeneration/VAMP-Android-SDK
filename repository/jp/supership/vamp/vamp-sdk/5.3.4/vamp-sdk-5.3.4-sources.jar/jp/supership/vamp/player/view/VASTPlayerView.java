package jp.supership.vamp.player.view;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;

import jp.supership.sscore.vamp.adreport.SSCoreAdReport;
import jp.supership.sscore.vamp.adreport.SSCoreAdReportException;
import jp.supership.sscore.vamp.adreport.SSCoreAdReportListener;
import jp.supership.sscore.vamp.adreport.SSCoreAdditionalParameterKey;
import jp.supership.sscore.vamp.type.Optional;
import jp.supership.vamp.VAMP;
import jp.supership.vamp.core.cache.CacheException;
import jp.supership.vamp.core.cache.DiskLruCache;
import jp.supership.vamp.core.logging.LogUtils;
import jp.supership.vamp.core.utils.Strings;
import jp.supership.vamp.player.ExternalAppLauncher;
import jp.supership.vamp.player.VAMPCreativeInfo;
import jp.supership.vamp.player.VAMPPlayerAd;
import jp.supership.vamp.player.VAMPPlayerError;
import jp.supership.vamp.utils.LocaleUtils;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/** Created by yumiko.ishii on 2017/04/12. */
public final class VASTPlayerView extends FrameLayout implements VideoView.VideoViewListener {
    public interface Listener extends ControlView.Listener {
        void onPrepared(); // 再生準備完了

        /**
         * @param currentTime [millisecond]
         * @param duration [millisecond]
         */
        void onProgress(int currentTime, int duration);

        /** 再生完了したときに呼ばれます */
        void onCompleted(int duration);

        void onError(@NonNull VAMPPlayerError error);

        void onPaused(int currentTime, int duration);

        void onResumed();

        void onBuffering(int percent);

        void onEndCardWebViewShown();
    }

    private static final String TOAST_MESSAGE_LINK_COPY_JP = "リンクをコピーしました。";
    private static final String TOAST_MESSAGE_LINK_COPY_EN = "Link copied.";

    @NonNull public final VideoView videoView;
    @NonNull public final ControlView controlView;
    @NonNull private final Optional<EndCardViewInterface> endCardView;
    @Nullable private final Listener listener;

    public VASTPlayerView(
            @NonNull final Context context,
            @NonNull final String videoFileOrNetworkUrl,
            @Nullable final String endCardImageFilePath,
            @Nullable final String privacyText,
            @Nullable final String iMarkImageFilePath,
            final boolean isAutoInstall,
            @NonNull final VAMPPlayerAd ad,
            @Nullable final Listener listener) {
        super(context);

        this.listener = listener;

        setBackgroundColor(Color.BLACK);
        setLayerType(LAYER_TYPE_HARDWARE, null);
        setMotionEventSplittingEnabled(false); // タッチイベントの分割無効
        setDescendantFocusability(FOCUS_BLOCK_DESCENDANTS); // フォーカスさせない

        videoView = new VideoView(context);
        videoView.setVideoViewListener(this);
        videoView.setVideoURL(videoFileOrNetworkUrl);
        addView(videoView, layoutParamsOfFullScreenContent());

        endCardView =
                new EndCardView()
                        .withImageView(Optional.of(endCardImageFilePath))
                        .withWebView(
                                ad.selectedLandingPage,
                                new EndCardWebView.Listener() {
                                    @Override
                                    public void onClose() {
                                        if (listener != null) {
                                            listener.onClose();
                                        }
                                    }

                                    @Override
                                    public void onMenuItemClick(int itemId) {
                                        EndCardViewInterface view;
                                        try {
                                            view = endCardView.unwrap();
                                        } catch (Optional.NotPresentException e) {
                                            return;
                                        }

                                        EndCardWebView endCardWebView;
                                        if (view instanceof EndCardWebView) {
                                            endCardWebView = (EndCardWebView) view;
                                        } else {
                                            return;
                                        }

                                        switch (itemId) {
                                            case EndCardWebView.MENU_ITEM_RELOAD:
                                                endCardWebView.reload();
                                                break;
                                            case EndCardWebView.MENU_ITEM_LINK_COPY:
                                                Strings.copyClipboard(
                                                        context, endCardWebView.getCurrentPage());
                                                Toast.makeText(
                                                                context,
                                                                LocaleUtils.isJapanese()
                                                                        ? TOAST_MESSAGE_LINK_COPY_JP
                                                                        : TOAST_MESSAGE_LINK_COPY_EN,
                                                                Toast.LENGTH_SHORT)
                                                        .show();
                                                break;
                                            case EndCardWebView.MENU_ITEM_OPEN_ANOTHER_APP:
                                                try {
                                                    // 外部ブラウザで開く
                                                    ExternalAppLauncher.startApp(
                                                            context,
                                                            endCardWebView.getCurrentPage());
                                                } catch (ExternalAppLauncher.NotLaunchException e) {
                                                    LogUtils.e(e.toString());
                                                }
                                                break;
                                        }
                                    }
                                })
                        .addTo(this, context);
        try {
            // 初期状態は非表示
            endCardView.unwrap().hide();
        } catch (Optional.NotPresentException ignored) {
        }

        controlView =
                ControlView.addTo(
                        this,
                        context,
                        privacyText,
                        iMarkImageFilePath,
                        isAutoInstall,
                        ad,
                        new ControlView.Listener() {
                            @Override
                            public void onClose() {
                                if (listener != null) {
                                    listener.onClose();
                                }
                            }

                            @Override
                            public void onLinkTextClick() {
                                if (listener != null) {
                                    listener.onLinkTextClick();
                                }
                            }

                            @Override
                            public void onAdClick() {
                                if (listener != null) {
                                    listener.onAdClick();
                                }
                            }

                            @Override
                            public void onInstallButtonClick() {
                                if (listener != null) {
                                    listener.onInstallButtonClick();
                                }
                            }

                            @Override
                            public void onSkip() {
                                if (listener != null) {
                                    listener.onSkip();
                                }
                            }

                            @Override
                            public void onOptOutLinkClick() {
                                if (listener != null) {
                                    listener.onOptOutLinkClick();
                                }
                            }

                            @Override
                            public void onMute() {
                                mute();
                            }

                            @Override
                            public void onUnmute() {
                                unmute();
                            }
                        },
                        new SSCoreAdReportListener() {
                            @Override
                            @NonNull
                            public Optional<Map<SSCoreAdditionalParameterKey, String>>
                                    getAdditionalParametersForAdReport() {
                                // ADG(ディスプレイ広告) SDKと分別するために"vamp"プレフィックスを付与する
                                final String sdkVer = "vamp" + VAMP.SDKVersion().replace("v", "");
                                String adNetworkName = ad.getAdNetworkName();
                                String placementId = ad.getPlacementId().orElse("");
                                String movieUrl = ad.selectedMediaFile.networkUrl;

                                VAMPCreativeInfo creativeInfo = ad.getCreativeInfo().maybe();

                                return Optional.of(
                                        new HashMap<SSCoreAdditionalParameterKey, String>() {
                                            {
                                                put(
                                                        SSCoreAdditionalParameterKey.SDK_VERSION,
                                                        sdkVer);
                                                put(
                                                        SSCoreAdditionalParameterKey.PLACEMENT_ID,
                                                        placementId);
                                                put(
                                                        SSCoreAdditionalParameterKey.ADNETWORK_NAME,
                                                        adNetworkName);
                                                put(
                                                        SSCoreAdditionalParameterKey.MOVIE_URL,
                                                        movieUrl);
                                                put(
                                                        SSCoreAdditionalParameterKey.VAST,
                                                        ad.vastObject.getOriginalXml());
                                                put(
                                                        SSCoreAdditionalParameterKey.CRID,
                                                        creativeInfo != null
                                                                ? creativeInfo.crid
                                                                : "");
                                                put(
                                                        SSCoreAdditionalParameterKey.ADNETWORK_ID,
                                                        creativeInfo != null
                                                                ? creativeInfo.adNetworkId
                                                                : "");
                                                put(
                                                        SSCoreAdditionalParameterKey.DSP_ID,
                                                        creativeInfo != null
                                                                ? creativeInfo.dspId
                                                                : "");
                                                put(
                                                        SSCoreAdditionalParameterKey.SEAT,
                                                        creativeInfo != null
                                                                ? creativeInfo.seat
                                                                : "");

                                                put(SSCoreAdditionalParameterKey.ADOMAIN, "");
                                            }
                                        });
                            }

                            @Override
                            public void onOpenedAdReportView() {
                                ad.pause();
                            }

                            @Override
                            public void onSentAdReport(
                                    @NonNull Optional<SSCoreAdReportException> error) {
                                boolean isJA =
                                        Locale.getDefault()
                                                .toString()
                                                .toLowerCase(Locale.US)
                                                .equals("ja");
                                if (error.isPresent()) {
                                    LogUtils.e("Failed to send ad report.", error.forced());
                                    final String en = "Failed to send.";
                                    final String ja = "送信失敗";
                                    Toast.makeText(context, isJA ? ja : en, Toast.LENGTH_SHORT)
                                            .show();
                                } else {
                                    LogUtils.d("Succeeded to send ad report.");
                                    final String en = "Successfully sent.";
                                    final String ja = "送信完了";
                                    Toast.makeText(context, isJA ? ja : en, Toast.LENGTH_SHORT)
                                            .show();
                                }
                            }

                            @Override
                            public void onClosedAdReportView(
                                    @NonNull SSCoreAdReport ssCoreAdReport) {
                                ssCoreAdReport
                                        .adReportView()
                                        .ifPresent(ViewUtils::removeFromParent);
                                ad.resume();
                            }
                        });
    }

    /**
     * AudioStreamType設定
     *
     * @param streamtype （AudioManagerに定義されているSTREAM_MUSIC、STREAM_RING、STREAM_ALARM等のタイプ）
     */
    public void setAudioStreamType(int streamtype) {
        videoView.setAudioStreamType(streamtype);
    }

    @RequiresApi(Build.VERSION_CODES.LOLLIPOP)
    public void setAudioContentType(int contentType) {
        videoView.setAudioContentType(contentType);
    }

    public void destroy() {
        videoView.destroy();

        try {
            endCardView.unwrap().destroy();
        } catch (Optional.NotPresentException ignored) {
        }

        ViewUtils.clearChild(this);
    }

    /** 再生中かどうか取得 */
    public boolean isPlaying() {
        return videoView.isPlaying();
    }

    /**
     * 総再生時間取得
     *
     * @return duration
     */
    public float getDuration() {
        return videoView.getDuration();
    }

    public void showEndCard(boolean isEndCardClickable) {
        controlView.showEndCard(isEndCardClickable);

        videoView.setSeekEndCaptureVisibility(VISIBLE);
        videoView.seekTo(0);

        try {
            endCardView.unwrap().show();

            if (endCardView.unwrap().getWebView().isPresent()) {
                // WebViewの場合はUIより前面に全体表示するため、controlViewを非表示にする
                controlView.setVisibility(INVISIBLE);

                if (listener != null) {
                    listener.onEndCardWebViewShown();
                }

                LogUtils.d("Show endCardWebView.");
            } else {
                LogUtils.d("Show endCardImageView.");
            }
        } catch (Optional.NotPresentException ignored) {
        }
    }

    public void hideEndCard() {
        controlView.hideEndCard();

        videoView.setSeekEndCaptureVisibility(INVISIBLE);

        try {
            endCardView.unwrap().hide();

            if (endCardView.unwrap().getWebView().isPresent()) {
                controlView.setVisibility(VISIBLE);
            }
        } catch (Optional.NotPresentException ignored) {
        }
    }

    /** 再生開始 */
    public void resume(int pos) {
        videoView.seekTo(pos);
        videoView.start();

        if (listener != null) {
            listener.onResumed();
        }
    }

    /** 一時停止 */
    public void pause() {
        if (!videoView.isPlaying()) {
            return;
        }

        videoView.pause();

        if (listener != null) {
            listener.onPaused(videoView.getCurrentPosition(), videoView.getDuration());
        }
    }

    /** サウンドON状態にします */
    public void unmute() {
        videoView.unmute();
        controlView.unmute();

        if (listener != null) {
            listener.onUnmute();
        }
    }

    /** サウンドOFF状態にします */
    public void mute() {
        videoView.mute();
        controlView.mute();

        if (listener != null) {
            listener.onMute();
        }
    }

    /**
     * 再生残り時間表示を更新します
     *
     * @param count 次のカウント
     * @param showSkipButton trueならばスキップボタンを表示します
     */
    public void updateCount(int count, boolean showSkipButton) {
        controlView.updateCount(count, showSkipButton);
    }

    public void setSeekEndCapture(final Context context, final String fileNetworkUrl) {
        // キャプチャした画像キーは動画ファイルのpathから生成
        final String seekEndImageKey = fileNetworkUrl + ".jpg";

        if (videoView.isPlaybackEnded()) {
            LogUtils.devLog("isPlaybackEnded=true");
            // 再生終了時のキャプチャ画像を取得しキャッシュする
            Bitmap bitmap = videoView.getCapture();
            try {
                DiskLruCache diskLruCache = DiskLruCache.newInstance(context);

                if (!diskLruCache.storeData(bitmap, seekEndImageKey)) {
                    LogUtils.e(VAMPPlayerError.CACHE_SERVICE_ERROR.toString());
                }

                videoView.setSeekEndCaptureURL(diskLruCache.retrieveFilePath(seekEndImageKey));
            } catch (CacheException e) {
                LogUtils.devLog(e.getMessage());
            }
        } else {
            LogUtils.devLog("isPlaybackEnded=false");
            // 再生途中の場合は動画を最後まで進めてキャプチャを撮る
            // ただし、MediaPlayer#seekToメソッドが指定した位置からずれる不具合がある
            // -> 遅延処理することで若干改善されそう
            new Handler(Looper.getMainLooper())
                    .post(
                            new Runnable() {
                                @Override
                                public void run() {
                                    // 動画を最後まで進める
                                    videoView.seekTo(videoView.getDuration());

                                    // 再生終了時のキャプチャ画像を取得しキャッシュする
                                    Bitmap bitmap = videoView.getCapture();
                                    try {
                                        final DiskLruCache diskLruCache =
                                                DiskLruCache.newInstance(context);

                                        if (!diskLruCache.storeData(bitmap, seekEndImageKey)) {
                                            LogUtils.e(
                                                    VAMPPlayerError.CACHE_SERVICE_ERROR.toString());
                                        }

                                        videoView.setSeekEndCaptureURL(
                                                diskLruCache.retrieveFilePath(seekEndImageKey));
                                    } catch (CacheException e) {
                                        LogUtils.devLog(e.getMessage());
                                    }
                                }
                            });
        }
    }

    public void seekToEnd() {
        videoView.seekToEnd();
    }

    public boolean canEndCardWebViewGoBack() {
        try {
            return endCardView.unwrap().getWebView().unwrap().canGoBack();
        } catch (Optional.NotPresentException e) {
            return false;
        }
    }

    public void endCardWebViewGoBack() {
        try {
            endCardView.unwrap().getWebView().unwrap().goBack();
        } catch (Optional.NotPresentException ignored) {
        }
    }

    @Override
    public void onPrepared() {
        unmute();

        videoView.seekTo(0);

        if (listener != null) {
            listener.onPrepared();
        }
    }

    @Override
    public void onCompleted() {
        if (listener != null) {
            listener.onCompleted(videoView.getDuration());
        }
    }

    /**
     * @param pos [millisecond]
     * @param duration [millisecond]
     */
    @Override
    public void onProgress(int pos, int duration) {
        if (listener != null) {
            listener.onProgress(pos, duration);
        }
    }

    @Override
    public void onError(@NonNull VAMPPlayerError error) {
        if (listener != null) {
            listener.onError(error);
        }
    }

    @Override
    public void onBuffering(int percent) {
        if (listener != null) {
            listener.onBuffering(percent);
        }
    }

    @NonNull
    private static LayoutParams layoutParamsOfFullScreenContent() {
        final LayoutParams params =
                new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
        params.gravity = Gravity.CENTER;
        return params;
    }
}
