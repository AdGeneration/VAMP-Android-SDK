package jp.supership.vamp;

import androidx.annotation.Nullable;

public interface VAMPAdapterResponseInfo {
    /**
     * アドネットワーク名を取得します。
     *
     * @return アドネットワークの名前
     */
    @Nullable
    String getAdNetworkName();

    /**
     * Adapterのクラス名を取得します。
     *
     * @return Adapterのクラス名
     */
    @Nullable
    String getClassName();

    /**
     * 広告のロードにかかった時間を取得します。
     *
     * @return ロードにかかった時間
     */
    long getLatencyMillis();

    /**
     * AdIDを取得します。
     *
     * @return AdID
     */
    @Nullable
    String getAdId();

    /**
     * CreativeIDを取得します。
     *
     * @return CreativeID
     */
    @Nullable
    String getCreativeId();

    /**
     * AdNetworkIDを取得します。
     *
     * @return AdNetworkID
     */
    @Nullable
    String getAdNetworkId();

    /**
     * DSP IDを取得します。
     *
     * @return DSP ID
     */
    @Nullable
    String getDspId();

    /**
     * seatを取得します。
     *
     * @return seat
     */
    @Nullable
    String getSeat();
}
