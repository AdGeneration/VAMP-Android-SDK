package jp.supership.vamp;

import android.content.Context;
import android.text.TextUtils;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import jp.supership.sscore.vamp.cloudconfig.SSCoreCloudConfigLoadable;
import jp.supership.sscore.vamp.device.SSCoreAppInfo;
import jp.supership.sscore.vamp.device.SSCoreAppInfoProvidable;
import jp.supership.sscore.vamp.device.SSCoreDevice;
import jp.supership.sscore.vamp.device.SSCoreDeviceProvidable;
import jp.supership.sscore.vamp.sequence.Sequencer;
import jp.supership.sscore.vamp.type.Optional;
import jp.supership.sscore.vamp.type.Result;
import jp.supership.vamp.core.http.HttpMethod;
import jp.supership.vamp.core.http.HttpRequest;
import jp.supership.vamp.core.http.HttpResponse;
import jp.supership.vamp.core.http.IHttpClient;
import jp.supership.vamp.core.http.IHttpClientListener;
import jp.supership.vamp.core.logging.LogUtils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;

final class CloudLogger {
    enum CloudLogEvent {
        UNKNOWN,
        ADNETWORK_LIST,
        LOAD_ADNETWORK,
        RECEIVE,
        LOAD_FAILURE,
        EXPIRE,
        OPEN,
        COMPLETE,
        CLOSE;

        @NonNull
        public String toString() {
            switch (this) {
                case ADNETWORK_LIST:
                    return "AdRequest";
                case LOAD_ADNETWORK:
                    return "LoadStart";
                case RECEIVE:
                    return "Receive";
                case LOAD_FAILURE:
                    return "LoadFailure";
                case EXPIRE:
                    return "Expire";
                case OPEN:
                    return "Open";
                case COMPLETE:
                    return "Complete";
                case CLOSE:
                    return "Close";
                default:
                    return "Unknown";
            }
        }
    }

    /**
     * {@link VAMPError}オブジェクトをクラウドログ用の文字列コードに変換します。 このコードはiOS SDKと共通です
     *
     * @param error {@link VAMPError}オブジェクト
     * @return クラウドログ用の文字列コード
     */
    @NonNull
    private static String errorToString(@NonNull final VAMPError error) {
        switch (error) {
            case NOT_SUPPORTED_OS_VERSION:
                return "NOT_SUPPORTED_OS_VERSION";
            case SERVER_ERROR:
                return "SERVER_ERROR";
            case NO_ADNETWORK:
                return "NO_ADNETWORK";
            case NEED_CONNECTION:
                return "NEED_CONNECTION";
            case MEDIATION_TIMEOUT:
                return "MEDIATION_TIMEOUT";
            case USER_CANCEL:
                return "USER_CANCEL";
            case NO_ADSTOCK:
                return "NO_ADSTOCK";
            case ADNETWORK_ERROR:
                return "ADNETWORK_ERROR";
            case SETTING_ERROR:
                return "SETTING_ERROR";
            case NOT_LOADED_AD:
                return "NOT_LOADED_AD";
            case INVALID_PARAMETER:
                return "INVALID_PARAMETER";
            case FREQUENCY_CAPPED:
                return "FREQUENCY_CAPPED";
            case REQUEST_TIMEOUT:
                return "REQUEST_TIMEOUT";
            default:
                return "UNKNOWN";
        }
    }

    private static final String KEY_DEVICE = "device";
    private static final String KEY_OS = "os";
    private static final String KEY_OS_VERSION = "osv";
    private static final String KEY_PACKAGE = "package";
    private static final String KEY_DATA = "data";
    private static final String KEY_APP_VERSION = "appv";
    private static final String KEY_TEST_MODE = "test_mode";
    private static final String KEY_DEBUG_MODE = "debug_mode";
    private static final String KEY_DISPLAY_ORIENTATION = "do";
    private static final String KEY_NETWORK = "network";
    private static final String KEY_CONFIG = "config";

    /** CloudLoggerの処理においてエラーが発生しました。詳細はmessageを参照してください */
    static class CloudLoggerException extends Exception {
        CloudLoggerException(@NonNull final String message) {
            super(message);
        }
    }

    interface ICloudLogger {
        void send(@NonNull CloudLogItem item);
    }

    static class DefaultCloudLogger implements ICloudLogger {
        private static final String TOKEN_KEY = "X-Vamp-Token";
        private static final String TOKEN_VALUE =
                "VamlkzMymCQAjeHl6PHUMshDqgWWBWDKDTw5hluodZLhYcmp";

        @Nullable private final Context context;
        @NonNull private final IHttpClient httpClient;
        @NonNull private final SSCoreCloudConfigLoadable cloudConfigLoader;
        @NonNull private final SSCoreDeviceProvidable deviceProvider;
        @NonNull private final SSCoreAppInfoProvidable appInfoProvider;

        DefaultCloudLogger(
                @Nullable final Context context,
                @NonNull final IHttpClient httpClient,
                @NonNull final SSCoreCloudConfigLoadable cloudConfigLoader,
                @NonNull final SSCoreDeviceProvidable deviceProvider,
                @NonNull final SSCoreAppInfoProvidable appInfoProvider) {
            this.context = context;
            this.httpClient = httpClient;
            this.cloudConfigLoader = cloudConfigLoader;
            this.deviceProvider = deviceProvider;
            this.appInfoProvider = appInfoProvider;
        }

        @Override
        public void send(@NonNull final CloudLogItem item) {
            try {
                checkContext();
                checkAvailable();
            } catch (CloudLoggerException e) {
                LogUtils.e(e.toString());
            }

            final String[] endpoint = new String[1];
            final String[] configVersion = new String[1];
            final SSCoreDevice[] device = new SSCoreDevice[1];
            final SSCoreAppInfo[] appInfo = new SSCoreAppInfo[1];
            new Sequencer(
                            completable ->
                                    cloudConfigLoader.loadCloudConfig(
                                            configResult -> {
                                                try {
                                                    endpoint[0] =
                                                            configResult.data.unwrap()
                                                                    .cloudLogInfo
                                                                    .endpoint;
                                                    configVersion[0] =
                                                            configResult
                                                                    .data
                                                                    .unwrap()
                                                                    .version
                                                                    .toString();
                                                    completable.onComplete(Result.success());
                                                } catch (Optional.NotPresentException e) {
                                                    completable.onComplete(
                                                            Result.failure(
                                                                    new CloudLoggerException(
                                                                            "CloudLogger failed to"
                                                                                    + " fetch the"
                                                                                    + " endpoint"
                                                                                    + " URL.")));
                                                }
                                            }))
                    .then(
                            (result, completion) -> {
                                deviceProvider.provideDevice(
                                        deviceResult -> {
                                            deviceResult.data.ifPresentOrElse(
                                                    dev -> {
                                                        device[0] = dev;
                                                        completion.onComplete(Result.success());
                                                    },
                                                    () -> {
                                                        completion.onComplete(
                                                                Result.failure(
                                                                        new CloudLoggerException(
                                                                                "CloudLogger failed"
                                                                                    + " to fetch"
                                                                                    + " the device"
                                                                                    + " info.")));
                                                    });
                                        });
                            })
                    .then(
                            ((result, completion) -> {
                                appInfoProvider.provideAppInfo(
                                        appInfoResult -> {
                                            appInfoResult.data.ifPresentOrElse(
                                                    app -> {
                                                        appInfo[0] = app;
                                                        completion.onComplete(Result.success());
                                                    },
                                                    () -> {
                                                        completion.onComplete(
                                                                Result.failure(
                                                                        new CloudLoggerException(
                                                                                "CloudLogger failed"
                                                                                    + " to fetch"
                                                                                    + " the app"
                                                                                    + " info.")));
                                                    });
                                        });
                            }))
                    .then(
                            (result, completion) -> {
                                final JSONObject jsonObj = new JSONObject();
                                try {
                                    jsonObj.put(KEY_DEVICE, device[0].modelName);
                                    jsonObj.put(KEY_OS, device[0].os.toLowerCase());
                                    jsonObj.put(KEY_OS_VERSION, device[0].osVersion);
                                    jsonObj.put(KEY_NETWORK, device[0].networkType);

                                    if (device[0].orientation.isPresent()) {
                                        jsonObj.put(
                                                KEY_DISPLAY_ORIENTATION,
                                                device[0].orientation.forced().value);
                                    }

                                    jsonObj.put(KEY_PACKAGE, appInfo[0].appId);
                                    jsonObj.put(KEY_APP_VERSION, appInfo[0].appVersion);

                                    jsonObj.put(KEY_TEST_MODE, VAMP.isTestMode());
                                    jsonObj.put(KEY_DEBUG_MODE, VAMP.isDebugMode());

                                    final JSONArray jsonArr = new JSONArray();
                                    jsonArr.put(new JSONObject(item.toMap()));
                                    jsonObj.put(KEY_DATA, jsonArr);
                                    jsonObj.put(KEY_CONFIG, configVersion[0]);
                                } catch (JSONException e) {
                                    completion.onComplete(
                                            Result.failure(new CloudLoggerException(e.toString())));
                                    return;
                                }

                                HashMap<String, String> headers = new HashMap<>();
                                headers.put("Content-Type", "application/json");
                                headers.put(TOKEN_KEY, TOKEN_VALUE);

                                HttpRequest httpRequest =
                                        new HttpRequest(endpoint[0])
                                                .setMethod(HttpMethod.POST)
                                                .setRequestBody(jsonObj.toString())
                                                .setRequestProperty(headers);

                                LogUtils.devLog("CloudLogger sends logs.\n" + jsonObj);

                                httpClient.send(
                                        httpRequest,
                                        new IHttpClientListener() {
                                            @Override
                                            public void onSuccess(HttpResponse response) {
                                                completion.onComplete(Result.success(response));
                                            }

                                            @Override
                                            public void onFail(String errorMsg) {
                                                completion.onComplete(
                                                        Result.failure(
                                                                new CloudLoggerException(
                                                                        errorMsg)));
                                            }
                                        });
                            })
                    .run(
                            result -> {
                                if (result.error.isPresent()) {
                                    try {
                                        CloudLoggerException e =
                                                (CloudLoggerException) result.error.unwrap();
                                        LogUtils.devLog(
                                                "CloudLogger sent logs.\nerror: " + e.getMessage());
                                    } catch (Optional.NotPresentException e) {
                                        LogUtils.devLog(
                                                "CloudLogger sent logs.\nerror: Unknown Error.");
                                    }
                                } else {
                                    int statusCode = 0;
                                    HttpResponse response = null;
                                    try {
                                        response = (HttpResponse) result.data.unwrap();
                                    } catch (Optional.NotPresentException e) {
                                        LogUtils.devLog(
                                                "CloudLogger sent logs.\n"
                                                        + "error: Unknown Error.");
                                    }

                                    if (response != null) {
                                        statusCode = response.getStatusCode();
                                    }
                                    LogUtils.devLog(
                                            "CloudLogger sent logs.\nresponseCode: " + statusCode);
                                }
                            });
        }

        private void checkContext() throws CloudLoggerException {
            if (context == null) {
                throw new CloudLoggerException("CloudLogger doesn't have available context.");
            }
        }

        private void checkAvailable() throws CloudLoggerException {
            if (VAMPPrivacySettings.getConsentStatus()
                    == VAMPPrivacySettings.ConsentStatus.DENIED) {
                throw new CloudLoggerException(
                        "CloudLogger is not available. The consent status is denied.");
            }

            if (VAMPPrivacySettings.getChildDirected() == VAMPPrivacySettings.ChildDirected.TRUE) {
                throw new CloudLoggerException(
                        "CloudLogger is not available. The user is COPPA target.");
            }

            if (VAMPPrivacySettings.getUnderAgeOfConsent()
                    == VAMPPrivacySettings.UnderAgeOfConsent.TRUE) {
                throw new CloudLoggerException(
                        "CloudLogger is not available. The user's age is under of consent.");
            }
        }
    }

    private CloudLogger() {}

    static final class CloudLogItem {
        private static final String KEY_AD_ID = "adid";
        private static final String KEY_VAMP_SDK_VERSION = "vamp_sdk_v";
        private static final String KEY_VAMP_STATUS = "vamp_status";
        private static final String KEY_VAMP_LISTENER = "vamp_listener";
        private static final String KEY_ADNETWORK_SDK_NAME = "adnw_name";
        private static final String KEY_ADNETWORK_SDK_VERSION = "adnw_sdk_v";
        private static final String KEY_ADNETWORK_AD_ID = "adnw_id";
        private static final String KEY_ERROR = "error";
        private static final String KEY_ERROR_MESSAGE = "error_msg";
        private static final String KEY_ADNETWORK_ERROR_CODE = "adnw_error_code";
        private static final String KEY_ADNETWORK_ERROR_MESSAGE = "adnw_error_msg";
        private static final String KEY_DATETIME = "datetime_utc";
        private static final String KEY_LOAD_SEC = "load_sec";
        private static final String KEY_SHOW_SEC = "show_sec";
        private static final String KEY_SEQ_ID = "seqid";
        private static final String KEY_REWARD_KEY = "reward_key";
        private static final String KEY_EVENT = "event";
        private static final String KEY_ADNETWORK_LIST = "adnw_list";
        private static final String KEY_ADAPTER_VERSION = "vamp_adapter_v";
        private static final String KEY_CLOSE_AD_CLICKED = "close_ad_clicked";

        @NonNull private final HashMap<String, Object> map = new HashMap<>();

        CloudLogItem() {
            setSdkVersion(VAMP.SDKVersion());
            setDateTimeUtc(new Date());
            setRewardKey(RewardKey.getAppUserKey());
        }

        private void setSdkVersion(@Nullable final String ver) {
            if (!TextUtils.isEmpty(ver)) {
                map.put(KEY_VAMP_SDK_VERSION, ver);
            }
        }

        private void setDateTimeUtc(@NonNull final Date date) {
            final SimpleDateFormat sdf =
                    new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US);
            sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
            map.put(KEY_DATETIME, sdf.format(date));
        }

        private void setRewardKey(@Nullable final RewardKey rewardKey) {
            if (rewardKey != null) {
                map.put(KEY_REWARD_KEY, rewardKey.value);
            }
        }

        @NonNull
        CloudLogItem setAdId(@Nullable final String adId) {
            map.put(KEY_AD_ID, TextUtils.isEmpty(adId) ? "" : adId);
            return this;
        }

        @NonNull
        CloudLogItem setState(@Nullable final MediationState state) {
            if (state != null) {
                map.put(KEY_VAMP_STATUS, state.toString());
            }
            return this;
        }

        @NonNull
        CloudLogItem setListener(@Nullable final String listener) {
            if (!TextUtils.isEmpty(listener)) {
                map.put(KEY_VAMP_LISTENER, listener);
            }
            return this;
        }

        @NonNull
        CloudLogItem setAdNetworkVersion(@Nullable final String ver) {
            if (!TextUtils.isEmpty(ver)) {
                map.put(KEY_ADNETWORK_SDK_VERSION, ver);
            }
            return this;
        }

        @NonNull
        CloudLogItem setAdNetworkName(@Nullable final String name) {
            if (!TextUtils.isEmpty(name)) {
                map.put(KEY_ADNETWORK_SDK_NAME, name);
            }
            return this;
        }

        @NonNull
        CloudLogItem setAdNetworkAdIdentifiers(@Nullable final List<String> adIds) {
            final List<String> ids = adIds == null ? new ArrayList<>() : adIds;
            map.put(KEY_ADNETWORK_AD_ID, ids);
            return this;
        }

        /** VAMP SDKに定義されているエラーコードをセットします */
        @NonNull
        CloudLogItem setError(@Nullable final VAMPError error) {
            if (error != null) {
                map.put(KEY_ERROR, errorToString(error));
            }
            return this;
        }

        /**
         * VAMP SDKに定義されているエラーコードおよびVAMP SDKが生成したエラーメッセージをセットします。 エラーコードがnullの場合はエラーメッセージもセットされません
         */
        @NonNull
        CloudLogItem setError(
                @Nullable final VAMPError error, @Nullable final String errorMessage) {
            if (error != null) {
                setError(error);

                if (!TextUtils.isEmpty(errorMessage)) {
                    map.put(KEY_ERROR_MESSAGE, errorMessage);
                }
            }
            return this;
        }

        /** アドネットワークSDKが返すエラーコードをセットします */
        @NonNull
        CloudLogItem setAdNetworkErrorCode(@Nullable final String code) {
            if (!TextUtils.isEmpty(code)) {
                map.put(KEY_ADNETWORK_ERROR_CODE, code);
            }
            return this;
        }

        /** アドネットワークSDKが返すエラーメッセージをセットします */
        @NonNull
        CloudLogItem setAdNetworkErrorMessage(@Nullable final String msg) {
            if (!TextUtils.isEmpty(msg)) {
                map.put(KEY_ADNETWORK_ERROR_MESSAGE, msg);
            }
            return this;
        }

        @NonNull
        CloudLogItem setLoadSec(final double loadSec) {
            if (loadSec > 0) {
                final DecimalFormat df = new DecimalFormat("0.00");
                map.put(KEY_LOAD_SEC, df.format(loadSec));
            }
            return this;
        }

        @NonNull
        CloudLogItem setShowSec(final double showSec) {
            if (showSec > 0) {
                final DecimalFormat df = new DecimalFormat("0.00");
                map.put(KEY_SHOW_SEC, df.format(showSec));
            }
            return this;
        }

        @NonNull
        CloudLogItem setSeqId(@Nullable final String seqId) {
            if (!TextUtils.isEmpty(seqId)) {
                map.put(KEY_SEQ_ID, seqId);
            }
            return this;
        }

        @NonNull
        CloudLogItem setEvent(@Nullable final CloudLogEvent event) {
            if (event != null) {
                map.put(KEY_EVENT, event.toString());
            }
            return this;
        }

        @NonNull
        CloudLogItem setAdNetworkList(@Nullable final String adNetworkList) {
            if (!TextUtils.isEmpty(adNetworkList)) {
                map.put(KEY_ADNETWORK_LIST, adNetworkList);
            }
            return this;
        }

        @NonNull
        CloudLogItem setAdapterVersion(@Nullable final String ver) {
            if (!TextUtils.isEmpty(ver)) {
                map.put(KEY_ADAPTER_VERSION, ver);
            }
            return this;
        }

        /**
         * @param adClicked 広告がクリックされている場合はOptional.of(true)、 クリックされていない場合はOptional.of(false)、
         *     クリック情報がない場合はOptional.empty()を指定します
         */
        @NonNull
        CloudLogItem setAdClicked(@NonNull final Optional<Boolean> adClicked) {
            try {
                boolean clicked = adClicked.unwrap();
                map.put(KEY_CLOSE_AD_CLICKED, "" + clicked);
            } catch (Optional.NotPresentException ignored) {
            }
            return this;
        }

        @NonNull
        Map<String, Object> toMap() {
            return new HashMap<>(map);
        }
    }
}
