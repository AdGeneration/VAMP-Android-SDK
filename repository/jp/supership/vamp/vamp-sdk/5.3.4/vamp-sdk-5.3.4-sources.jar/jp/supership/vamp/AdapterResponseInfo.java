package jp.supership.vamp;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import jp.supership.sscore.vamp.type.Optional;

final class AdapterResponseInfo implements VAMPAdapterResponseInfo {
    @Nullable private final String adId;
    @Nullable private final String adNetworkName;
    /** アダプタクラス名 */
    @Nullable private final String className;

    @Nullable private final String creativeId;
    @Nullable private final String adNetworkId;
    @Nullable private final String dspId;
    @Nullable private final String seat;
    private long startLoadingTime;
    @NonNull private Optional<Long> latencyMillis = Optional.empty();

    static class Builder {
        @Nullable private String adId;
        @Nullable private String adNetworkName;
        /** アダプタクラス名 */
        @Nullable private String className;

        @Nullable private String creativeId;
        @Nullable private String adNetworkId;
        @Nullable private String dspId;
        @Nullable private String seat;

        public Builder withAdId(@Nullable final String adId) {
            this.adId = adId;
            return this;
        }

        public Builder withAdNetworkName(@Nullable final String adNetworkName) {
            this.adNetworkName = adNetworkName;
            return this;
        }

        public Builder withClassName(@Nullable final String className) {
            this.className = className;
            return this;
        }

        public Builder withCreativeId(@Nullable final String creativeId) {
            this.creativeId = creativeId;
            return this;
        }

        public Builder withAdNetworkId(@Nullable final String adNetworkId) {
            this.adNetworkId = adNetworkId;
            return this;
        }

        public Builder withDspId(@Nullable final String dspId) {
            this.dspId = dspId;
            return this;
        }

        public Builder withSeat(@Nullable final String seat) {
            this.seat = seat;
            return this;
        }

        @NonNull
        public AdapterResponseInfo build() {
            return new AdapterResponseInfo(
                    adId, adNetworkName, className, creativeId, adNetworkId, dspId, seat);
        }
    }

    private AdapterResponseInfo(
            @Nullable final String adId,
            @Nullable final String adNetworkName,
            @Nullable final String className,
            @Nullable final String creativeId,
            @Nullable final String adNetworkId,
            @Nullable final String dspId,
            @Nullable final String seat) {
        this.adId = adId;
        this.adNetworkName = adNetworkName;
        this.className = className;
        this.creativeId = creativeId;
        this.adNetworkId = adNetworkId;
        this.dspId = dspId;
        this.seat = seat;
    }

    void startLoading() {
        startLoadingTime = System.currentTimeMillis();
    }

    void finishLoading() {
        if (latencyMillis.isEmpty()) {
            latencyMillis = Optional.of(System.currentTimeMillis() - startLoadingTime);
        }
    }

    @Nullable
    @Override
    public String getAdNetworkName() {
        return adNetworkName;
    }

    @Nullable
    @Override
    public String getAdId() {
        return adId;
    }

    @Nullable
    @Override
    public String getClassName() {
        return className;
    }

    @Nullable
    @Override
    public String getCreativeId() {
        return creativeId;
    }

    @Nullable
    @Override
    public String getAdNetworkId() {
        return adNetworkId;
    }

    @Nullable
    @Override
    public String getDspId() {
        return dspId;
    }

    @Nullable
    @Override
    public String getSeat() {
        return seat;
    }

    @Override
    public long getLatencyMillis() {
        return latencyMillis.orElse(0L);
    }
}
