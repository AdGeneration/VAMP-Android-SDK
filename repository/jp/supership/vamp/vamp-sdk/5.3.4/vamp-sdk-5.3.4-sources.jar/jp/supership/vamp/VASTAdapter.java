package jp.supership.vamp;

import android.app.Activity;
import android.content.Context;
import android.text.TextUtils;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import jp.supership.sscore.vamp.device.SSCoreReachability;
import jp.supership.sscore.vamp.sequence.Sequencer;
import jp.supership.sscore.vamp.type.Optional;
import jp.supership.sscore.vamp.type.Result;
import jp.supership.vamp.core.error.VAMPInternalError;
import jp.supership.vamp.core.error.VAMPInternalException;
import jp.supership.vamp.core.utils.VAMPMap;
import jp.supership.vamp.core.vast.VASTMediaFile;
import jp.supership.vamp.core.vast.VASTObject;
import jp.supership.vamp.measurement.OmSdkLoader;
import jp.supership.vamp.mediation.AdNetworkErrorInfo;
import jp.supership.vamp.mediation.Adapter;
import jp.supership.vamp.mediation.AdapterConfiguration;
import jp.supership.vamp.mediation.AdapterEventListener;
import jp.supership.vamp.mediation.Event;
import jp.supership.vamp.player.EndCard;
import jp.supership.vamp.player.VAMPCreativeInfo;
import jp.supership.vamp.player.VAMPPlayer;
import jp.supership.vamp.player.VAMPPlayerAd;
import jp.supership.vamp.player.VAMPPlayerError;
import jp.supership.vamp.player.VAMPPlayerListener;
import jp.supership.vamp.player.VAMPPlayerReport;

import java.net.URL;
import java.util.Collections;
import java.util.List;

public final class VASTAdapter implements Adapter {
    private enum RewardState {
        UNDETERMINED,
        COMPLETED,
        USER_CANCELED
    }

    @NonNull public static final String ADNETWORK_NAME = "VAMPAds";

    @NonNull private final String adapterName = VASTAdapter.class.getSimpleName();
    @NonNull private final VAMPLogger logger = new VAMPLogger(adapterName);
    @Nullable private AdapterConfiguration adapterConfiguration = null;
    @NonNull private Optional<VAMPPlayerAd> vampPlayerAd = Optional.empty();
    @Nullable private VAMPPlayer player = null;
    @NonNull private RewardState rewardState = RewardState.UNDETERMINED;
    @Nullable private AdapterEventListener adapterListener = null;
    @Nullable private VAMPCreativeInfo creativeInfo = null;

    @NonNull
    private String getVASTXML() {
        return adapterConfiguration != null ? adapterConfiguration.getVastXml() : "";
    }

    @Nullable
    private URL getLandingURL() {
        return adapterConfiguration != null ? adapterConfiguration.getLandingUrl() : null;
    }

    public void setCreativeInfo(@NonNull final VAMPCreativeInfo creativeInfo) {
        this.creativeInfo = creativeInfo;
    }

    @Override
    public boolean isSupported() {
        return VAMP.isSupported();
    }

    @NonNull
    @Override
    public String getAdNetworkName() {
        final VAMPPlayerAd playerAd;
        try {
            playerAd = vampPlayerAd.unwrap();
        } catch (Optional.NotPresentException e) {
            return ADNETWORK_NAME;
        }

        return playerAd.getAdNetworkName();
    }

    @NonNull
    @Override
    public List<String> getAdNetworkAdIdentifiers() {
        final VAMPPlayerAd playerAd;
        try {
            playerAd = vampPlayerAd.unwrap();
        } catch (Optional.NotPresentException e) {
            return Collections.emptyList();
        }

        final String adId = playerAd.vastObject.getAdId();
        if (!TextUtils.isEmpty(adId)) {
            return Collections.singletonList(adId);
        } else {
            return Collections.emptyList();
        }
    }

    @NonNull
    @Override
    public String getAdapterVersion() {
        return VAMP.SDKVersion();
    }

    @NonNull
    @Override
    public String getAdNetworkVersion() {
        return VAMP.SDKVersion();
    }

    @Override
    public boolean isReady() {
        return vampPlayerAd.isPresent();
    }

    @Override
    public boolean prepare(
            @NonNull final Context context,
            @NonNull final AdapterConfiguration configuration,
            @Nullable final AdapterEventListener listener) {
        this.adapterConfiguration = configuration;
        this.adapterListener = listener;

        return true;
    }

    @Override
    public void load(@NonNull final Context applicationContext) {
        final String vastXML = getVASTXML();
        final URL actualLandingURL = getLandingURL();

        if (TextUtils.isEmpty(vastXML)) {
            logger.e("VAST xml is empty.");

            if (adapterListener != null) {
                adapterListener.onEvent(
                        Event.newNullOrEmptyParameterErrorEvent(
                                "load", Collections.singletonList("vastXML")));
            }
            return;
        }

        final boolean privacyProtection =
                (VAMPPrivacySettings.getConsentStatus() == VAMPPrivacySettings.ConsentStatus.DENIED
                        || VAMPPrivacySettings.getChildDirected()
                                == VAMPPrivacySettings.ChildDirected.TRUE
                        || VAMPPrivacySettings.getUnderAgeOfConsent()
                                == VAMPPrivacySettings.UnderAgeOfConsent.TRUE);

        logger.d(
                "privacyProtection="
                        + privacyProtection
                        + " (isChildDirected="
                        + VAMPPrivacySettings.getChildDirected()
                        + " getUnderAgeOfConsent="
                        + VAMPPrivacySettings.getUnderAgeOfConsent()
                        + " consentStatus="
                        + VAMPPrivacySettings.getConsentStatus()
                        + ")");

        new Sequencer(
                        completable -> {
                            VASTObject.create(
                                    getVASTXML(),
                                    (vastObject, error) -> {
                                        completable.onComplete(Result.success(vastObject));
                                    });
                        })
                .then(
                        (result, completable) -> {
                            if (result.isEmpty()) {
                                completable.onComplete(Result.success());
                                return;
                            }

                            VASTObject vastObject;
                            try {
                                vastObject = (VASTObject) result.unwrap();
                            } catch (Optional.NotPresentException ignored) {
                                completable.onComplete(Result.success());
                                return;
                            }

                            VAMPPlayerAd.create(
                                    applicationContext,
                                    vastObject,
                                    actualLandingURL != null ? actualLandingURL.toString() : "",
                                    adapterConfiguration != null
                                            ? adapterConfiguration.getPlacementID()
                                            : "",
                                    creativeInfo,
                                    OmSdkLoader.getDefault(applicationContext),
                                    new SSCoreReachability.Reachability(applicationContext),
                                    (playerAd, error) -> {
                                        if (playerAd != null) {
                                            completable.onComplete(Result.success(playerAd));
                                        } else {
                                            completable.onComplete(
                                                    Result.failure(
                                                            new VAMPInternalException(error)));
                                        }
                                    });
                        })
                .run(
                        result -> {
                            VAMPPlayerAd playerAd;
                            try {
                                playerAd = (VAMPPlayerAd) result.data.unwrap();
                            } catch (Optional.NotPresentException ignored) {
                                playerAd = null;
                            }

                            if (playerAd == null) {
                                final AdNetworkErrorInfo.Builder errorInfo =
                                        new AdNetworkErrorInfo.Builder(
                                                        "load", VAMPError.ADNETWORK_ERROR)
                                                .setErrorMessage(getErrorMessage(null));

                                if (result.error.isPresent()) {
                                    VAMPInternalException error;
                                    try {
                                        error = (VAMPInternalException) result.error.unwrap();
                                    } catch (Optional.NotPresentException e) {
                                        error = null;
                                    }

                                    if (error != null) {
                                        final VAMPInternalError err =
                                                (VAMPInternalError) error.error;
                                        errorInfo.setAdNetworkErrorCode(err.code.name());
                                        errorInfo.setAdNetworkErrorMessage(err.message);
                                    }
                                }

                                if (adapterListener != null) {
                                    adapterListener.onEvent(
                                            new Event(Event.EVENT_FAIL, errorInfo.build()));
                                }

                                return;
                            }

                            vampPlayerAd = Optional.of(playerAd);

                            QALogger.logMovieEvent(playerAd.selectedMediaFile.networkUrl);
                            QALogger.logVASTEvent(
                                    playerAd.vastObject.getAdSystem(),
                                    playerAd.vastObject.getAdTitle(),
                                    playerAd.vastObject.getDurationString(),
                                    playerAd.selectedMediaFile.networkUrl);

                            if (adapterListener != null) {
                                adapterListener.onEvent(new Event(Event.EVENT_LOAD_SUCCESS));
                            }
                        });
    }

    @Override
    public void show(@NonNull final Context context) {
        if (!(context instanceof Activity)) {
            if (adapterListener != null) {
                adapterListener.onEvent(Event.newActivityNotFoundErrorEvent("show"));
            }

            return;
        }

        try {
            player = VAMPPlayer.show((Activity) context, vampPlayerAd.unwrap(), playerListener);
        } catch (Optional.NotPresentException ignored) {
        }
    }

    @Override
    public void destroy() {
        if (player != null) {
            player.release();
        }

        player = null;
        vampPlayerAd = Optional.empty();
    }

    private final VAMPPlayerListener playerListener =
            new VAMPPlayerListener() {
                @Override
                public void onBeginPlayback() {
                    logger.d("onBeginPlayback called.");

                    if (adapterListener != null) {
                        adapterListener.onEvent(new Event(Event.EVENT_OPEN));
                    }
                }

                @Override
                public void onEndPlayback(final boolean userCancel) {
                    logger.d("onEndPlayback called. userCancel=" + userCancel);

                    rewardState = userCancel ? RewardState.USER_CANCELED : RewardState.COMPLETED;
                }

                @Override
                public void onResumeVideo() {
                    logger.d("onResumeVideo called.");
                }

                @Override
                public void onPauseVideo() {
                    logger.d("onPauseVideo called.");
                }

                @Override
                public void onUnmuteVideo() {
                    logger.d("onUnmuteVideo called.");
                }

                @Override
                public void onMuteVideo() {
                    logger.d("onMuteVideo called.");
                }

                @Override
                public void onClick() {
                    logger.d("onClick called.");
                    if (adapterListener != null) {
                        adapterListener.onEvent(new Event(Event.EVENT_CLICK));
                    }
                }

                @Override
                public void onClose() {
                    logger.d("onClose called.");

                    // UserCancelフラグが立っていなくても
                    // Completeが発生していなければUserCancel扱いとする
                    if (rewardState != RewardState.COMPLETED) {
                        final VAMPMap map = new VAMPMap();
                        try {
                            VAMPPlayerAd playerAd = vampPlayerAd.unwrap();
                            map.add("AdSystem", playerAd.vastObject.getAdSystem());

                            VASTMediaFile mediaFile = playerAd.selectedMediaFile;
                            map.add("MediaFile", mediaFile.networkUrl);

                            map.add("AdTitle", playerAd.vastObject.getAdTitle());
                        } catch (Optional.NotPresentException ignored) {
                        }

                        if (adapterListener != null) {
                            final AdNetworkErrorInfo errorInfo =
                                    new AdNetworkErrorInfo.Builder("onClose", VAMPError.USER_CANCEL)
                                            .setErrorMessage(map.toString())
                                            .build();

                            adapterListener.onEvent(
                                    new Event(Event.EVENT_FAIL | Event.EVENT_CLOSE, errorInfo));
                        }
                    } else {
                        if (adapterListener != null) {
                            adapterListener.onEvent(
                                    new Event(Event.EVENT_COMPLETE | Event.EVENT_CLOSE));
                        }
                    }
                }

                @Override
                public void onFail(@Nullable final VAMPPlayerError error) {
                    final VAMPError vampError =
                            error == VAMPPlayerError.NEED_CONNECTION
                                    ? VAMPError.NEED_CONNECTION
                                    : VAMPError.ADNETWORK_ERROR;

                    final AdNetworkErrorInfo.Builder errorInfo =
                            new AdNetworkErrorInfo.Builder("onFail", vampError)
                                    .setErrorMessage(getErrorMessage(vampPlayerAd.maybe()));

                    if (error != null) {
                        errorInfo.setAdNetworkErrorCode(error.name());
                    }

                    if (adapterListener != null) {
                        adapterListener.onEvent(new Event(Event.EVENT_FAIL, errorInfo.build()));
                    }
                }

                @Nullable
                @Override
                public EndCard onShowEndCard(final Context context) {
                    logger.d("onShowEndCard called.");
                    return null;
                }
            };

    @NonNull
    private String getErrorMessage(@Nullable final VAMPPlayerAd ad) {
        String errorMessage = "";
        if (ad != null) {
            errorMessage += ("AdSystem:" + ad.vastObject.getAdSystem() + " ");
            errorMessage += ("MediaFile:" + ad.selectedMediaFile.networkUrl + " ");
            errorMessage += ("AdTitle:" + ad.vastObject.getAdTitle() + " ");
        }

        final VAMPPlayerReport report = VAMPPlayerReport.getLastError();
        if (report != null) {
            errorMessage +=
                    ("last error:class"
                            + report.getClassName()
                            + " line:"
                            + report.getLine()
                            + " msg:"
                            + report.getMessage()
                            + " code:"
                            + report.getErrorCode());
        }

        return errorMessage;
    }
}
