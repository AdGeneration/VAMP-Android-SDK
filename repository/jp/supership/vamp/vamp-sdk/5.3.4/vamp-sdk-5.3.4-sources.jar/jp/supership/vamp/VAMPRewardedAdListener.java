package jp.supership.vamp;

import androidx.annotation.NonNull;

public interface VAMPRewardedAdListener {
    /**
     * 広告の表示に失敗すると通知されます。<br>
     *
     * <p>例) 視聴完了する前にユーザがキャンセルするなど。
     *
     * @param placementId 広告枠ID
     * @param error {@link VAMPError}
     */
    void onFailedToShow(@NonNull String placementId, @NonNull VAMPError error);

    /**
     * インセンティブ付与が可能になると通知されます。<br>
     *
     * <p>※ユーザが途中で再生をスキップしたり、動画視聴をキャンセルすると発生しません。<br>
     *
     * <p>※アドネットワークによって発生タイミングが異なります。
     *
     * @param placementId 広告枠ID
     */
    void onCompleted(@NonNull String placementId);

    /**
     * 広告の表示が開始されると通知されます。
     *
     * @param placementId 広告枠ID
     */
    void onOpened(@NonNull String placementId);

    /**
     * 広告が閉じられると通知されます。<br>
     *
     * <p>ユーザキャンセルなどの場合も通知されるため、インセンティブ付与は {@link VAMPRewardedAdListener#onCompleted} で判定してください。
     *
     * @param placementId 広告枠ID
     * @param adClicked 広告がクリックされたかどうか
     */
    void onClosed(@NonNull String placementId, boolean adClicked);

    /**
     * RTBはロードが完了してから1時間経過すると、広告表示ができても無効扱いとなり、収益が発生しません。<br>
     *
     * <p>この通知を受け取ったらロードからやり直してください。<br>
     *
     * @param placementId 広告枠ID
     */
    void onExpired(@NonNull String placementId);
}
