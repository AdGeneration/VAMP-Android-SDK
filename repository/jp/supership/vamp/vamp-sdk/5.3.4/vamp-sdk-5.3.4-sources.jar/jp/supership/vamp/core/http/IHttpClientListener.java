package jp.supership.vamp.core.http;

public interface IHttpClientListener {
    void onSuccess(HttpResponse response);

    void onFail(String errorMsg);
}
