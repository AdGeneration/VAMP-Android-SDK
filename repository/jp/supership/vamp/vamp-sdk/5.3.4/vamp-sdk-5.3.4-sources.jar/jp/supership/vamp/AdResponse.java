package jp.supership.vamp;

import android.text.TextUtils;
import android.util.Xml;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import jp.supership.vamp.core.logging.LogUtils;
import jp.supership.vamp.utils.JsonUtils;

import org.json.JSONObject;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xmlpull.v1.XmlPullParser;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.StringReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

/** Created by yumiko.ishii on 2016/12/19. */
public final class AdResponse {
    /** インスタンスを生成できません。詳細はmessageを参照してください */
    static class CanNotInstantiateException extends Exception {
        CanNotInstantiateException(String message) {
            super(message);
        }
    }

    private static final String KEY_AD = "ad";
    private static final String KEY_BEACON = "beacon";
    private static final String KEY_BEACON_URL = "beaconurl";
    private static final String KEY_SCHEDULE_ID = "scheduleid";
    private static final String KEY_VAST = "vastxml";
    private static final String KEY_START = "start";
    private static final String KEY_COMPLETE = "complete";
    private static final String KEY_WEIGHT = "weight";
    private static final String KEY_CREATIVE_PARAMS = "creative_params";
    private static final String KEY_AD_PARAMS = "ad_params";
    private static final String KEY_CRID = "crid";
    private static final String KEY_ADNW_ID = "adnwid";
    private static final String KEY_DSP_ID = "dspid";
    private static final String KEY_SEAT = "seat";

    @NonNull public final String placementId;
    /** VAMPでは使用しない */
    @Deprecated public final String ad;
    /** beaconキーのimgタグ */
    @Deprecated private final String beacon;
    /** beaconurlキーのURL */
    private final String beaconUrl;
    /** VAMPでは使用しない */
    @Deprecated public final String scheduleId;

    public final String vastxml;
    public final String start;
    public final String complete;
    public final int weight;
    public final String crid;
    public final String adnwId;
    public final String dspId;
    public final String seat;
    public final JSONObject adParams;
    @NonNull public final CreativeParams creativeParams;

    public AdResponse(@NonNull final String placementId, @Nullable final JSONObject obj)
            throws CanNotInstantiateException {
        this.placementId = placementId;

        if (obj == null) {
            throw new CanNotInstantiateException("Given jsonObject is null.");
        }

        try {
            LogUtils.devLog("AdResponse: " + obj.toString(4));
        } catch (Exception ignored) {
        }

        ad = obj.optString(KEY_AD);
        beacon = obj.optString(KEY_BEACON);
        beaconUrl = obj.optString(KEY_BEACON_URL);
        scheduleId = obj.optString(KEY_SCHEDULE_ID);
        vastxml = obj.optString(KEY_VAST);
        start = obj.optString(KEY_START);
        complete = obj.optString(KEY_COMPLETE);
        weight = obj.optInt(KEY_WEIGHT);
        adParams = JsonUtils.fromJson(obj.optString(KEY_AD_PARAMS));
        crid = obj.optString(KEY_CRID);
        adnwId = obj.optString(KEY_ADNW_ID);
        dspId = obj.optString(KEY_DSP_ID);
        seat = obj.optString(KEY_SEAT);

        JSONObject creativeParamsObj = obj.optJSONObject(KEY_CREATIVE_PARAMS);
        try {
            creativeParams = new CreativeParams(creativeParamsObj, hasVastXml());
        } catch (CreativeParams.CanNotInstantiateException e) {
            throw new CanNotInstantiateException(e.getMessage());
        }
    }

    /**
     * レスポンスにvastxmlが含まれているか判定します
     *
     * @return vastxmlが含まれているならばtrue、含まれていないならばfalse
     */
    public boolean hasVastXml() {
        return !TextUtils.isEmpty(vastxml);
    }

    public boolean isVastAd() {
        return hasVastXml() && creativeParams.isVastMediation();
    }

    public String getBeaconUrl() {
        String beacon = getOriginBeaconUrl();

        if (!TextUtils.isEmpty(beacon)) {
            ArrayList<URL> impressions = getVastImpressions();
            for (URL url : impressions) {
                if (beacon.equals(url.toString())) {
                    // beaconがVASTのImpressionと同じURLなのでVAMPでは発火しないようにする
                    return "";
                }
            }
        }

        return beacon;
    }

    private ArrayList<URL> getVastImpressions() {
        ArrayList<URL> impressions = new ArrayList<>();

        if (!TextUtils.isEmpty(vastxml)) {
            try {
                DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
                InputStream is = new ByteArrayInputStream(vastxml.getBytes("utf-8"));
                Document dom = builder.parse(is);
                NodeList nodes = dom.getElementsByTagName("Impression");
                for (int i = 0; i < nodes.getLength(); i++) {
                    Node node = nodes.item(i);
                    impressions.add(new URL(node.getTextContent()));
                }
            } catch (Exception e) {
                LogUtils.devLog(e.getMessage());
            }
        }

        return impressions;
    }

    /**
     * [v2.0.4からの仕様] レスポンスJSONにbeaconurlが追加されたため、beaconUrlを優先して使います
     * ただし、まだJSONにbeaconurlが含まれていないケースもあるため、 安全策としてbeaconurlが無い場合は従来通りbeaconキーのURLを使います
     *
     * @return beacon URL
     */
    private String getOriginBeaconUrl() {
        if (!TextUtils.isEmpty(beaconUrl)) {
            return beaconUrl;
        }

        if (!TextUtils.isEmpty(beacon)) {
            // beacon分解
            // *ADGではwebviewに貼り付けてbeaconを発生させる仕様の為、
            // beaconはhtml形式になっている → VAMPで必要な部分だけ抜き取る
            XmlPullParser parser = Xml.newPullParser();
            try {
                parser.setInput(new StringReader(beacon));
                int eventType = parser.getEventType();
                while (eventType != XmlPullParser.END_DOCUMENT) {
                    if (eventType == XmlPullParser.START_TAG) {
                        if ("img".equals(parser.getName())) {
                            // imgタグがあればそこから取得したurlを返却
                            return parser.getAttributeValue(null, "src");
                        }
                    }
                    eventType = parser.next();
                }
            } catch (Exception e) {
                LogUtils.devLog(e.getMessage());
                // nothing
            }
        }
        // imgタグがなければbeaconをそのまま返却
        return beacon;
    }

    public String getSeqId() {
        Pattern pattern = Pattern.compile(".*seqid=([a-zA-Z0-9-]*).*");
        ArrayList<String> urls = new ArrayList<>(Arrays.asList(start, complete, getBeaconUrl()));

        for (int i = 0; i < urls.size(); ++i) {
            String url = urls.get(i);
            if (url != null) {
                Matcher matcher = pattern.matcher(url);

                if (matcher.find()) {
                    String result = matcher.group(1);

                    if (result != null && result.length() > 0) {
                        return result;
                    }
                }
            }
        }

        return "";
    }
}
