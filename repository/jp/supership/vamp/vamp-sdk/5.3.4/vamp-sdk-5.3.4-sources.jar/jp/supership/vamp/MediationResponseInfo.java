package jp.supership.vamp;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import jp.supership.sscore.vamp.type.Optional;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

final class MediationResponseInfo implements VAMPResponseInfo {
    static class Builder {
        @NonNull private Optional<String> adNetworkName = Optional.empty();
        @NonNull private Optional<String> seqId = Optional.empty();

        @NonNull
        private Optional<ArrayList<VAMPAdapterResponseInfo>> adapterResponseList = Optional.empty();

        @NonNull
        Builder withAdNetworkName(@Nullable final String name) {
            adNetworkName = Optional.of(name);
            return this;
        }

        @NonNull
        Builder withSeqId(@Nullable final String seqId) {
            this.seqId = Optional.of(seqId);
            return this;
        }

        @NonNull
        Builder withAdapterResponseList(@Nullable final ArrayList<VAMPAdapterResponseInfo> list) {
            adapterResponseList = Optional.of(list);
            return this;
        }

        @NonNull
        MediationResponseInfo build() {
            return new MediationResponseInfo(
                    adNetworkName.orElse(""),
                    seqId.maybe(),
                    adapterResponseList.orElse(new ArrayList<>()));
        }
    }

    /** ロードに成功したアドネットワーク名 */
    @NonNull private final String adNetworkName;

    @Nullable private final String seqId;
    @NonNull private final ArrayList<VAMPAdapterResponseInfo> adapterResponseInfos;

    private MediationResponseInfo(
            @NonNull final String adNetworkName,
            @Nullable final String seqId,
            @NonNull final ArrayList<VAMPAdapterResponseInfo> infos) {
        this.adNetworkName = adNetworkName;
        this.seqId = seqId;
        this.adapterResponseInfos = infos;
    }

    @Nullable
    @Override
    public String getSeqID() {
        return seqId;
    }

    @NonNull
    @Override
    public String getAdNetworkName() {
        return adNetworkName;
    }

    @NonNull
    @Override
    public ArrayList<VAMPAdapterResponseInfo> getAdapterResponseInfos() {
        return adapterResponseInfos;
    }

    @NonNull
    @Override
    public String toString() {
        try {
            JSONObject obj = new JSONObject().put("AdNetworkName", adNetworkName);

            if (seqId != null) {
                obj.put("SeqID", seqId);
            }

            JSONArray arr = new JSONArray();
            for (VAMPAdapterResponseInfo info : adapterResponseInfos) {
                HashMap<String, Object> infoMap = new HashMap<>();
                infoMap.put("AdID", info.getAdId());
                infoMap.put("AdNetworkName", info.getAdNetworkName());
                infoMap.put("ClassName", info.getClassName());
                infoMap.put("CreativeID", info.getCreativeId());
                infoMap.put("AdNetworkID", info.getAdNetworkId());
                infoMap.put("DSPID", info.getDspId());
                infoMap.put("Seat", info.getSeat());
                infoMap.put("LatencyMillis", info.getLatencyMillis());
                arr.put(new JSONObject(infoMap));
            }
            obj.put("AdapterResponseInfo", arr);

            return obj.toString(2);
        } catch (JSONException e) {
            e.printStackTrace();

            return "";
        }
    }
}
