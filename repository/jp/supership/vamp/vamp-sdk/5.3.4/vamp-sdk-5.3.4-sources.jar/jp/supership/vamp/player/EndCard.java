package jp.supership.vamp.player;

import android.app.Activity;

public interface EndCard {
    void show(Activity activity);

    void hide(Activity activity);
}
