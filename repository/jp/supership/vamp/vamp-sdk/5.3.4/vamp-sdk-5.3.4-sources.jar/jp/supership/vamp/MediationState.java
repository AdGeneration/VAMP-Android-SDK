package jp.supership.vamp;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

final class MediationState {
    enum Value {
        /** 初期状態 */
        IDLE,
        /** ロード中 */
        LOADING,
        /** ロード完了 */
        LOADED,
        /** 再生開始 */
        BEGIN_PLAYBACK,
        /** 表示中 */
        SHOWING,
        /** 破棄済み(終了状態) */
        FINISHED;

        @NonNull
        @Override
        public String toString() {
            switch (this) {
                case IDLE:
                    return "Idle";
                case LOADING:
                    return "Loading";
                case LOADED:
                    return "Loaded";
                case BEGIN_PLAYBACK:
                    return "BeginPlayback";
                case SHOWING:
                    return "Showing";
                case FINISHED:
                    return "Finished";
                default:
                    return "Unknown";
            }
        }
    }

    static final class NotChangedException extends Exception {
        private NotChangedException(
                @NonNull final MediationState.Value oldState,
                @NonNull final MediationState.Value newState) {
            super(oldState + " is not changed to " + newState);
        }

        private NotChangedException(@NonNull final String message) {
            super(message);
        }
    }

    @NonNull private final Value value;
    /**
     * Completeフラグ<br>
     * Complete状態とClose状態はどちらに先に遷移するか不定のため、{@link Value}とは別にフラグで管理します
     */
    private final boolean wasCompleted;
    /**
     * Closeフラグ<br>
     * Complete状態とClose状態はどちらに先に遷移するか不定のため、{@link Value}とは別にフラグで管理します
     */
    private final boolean wasClosed;

    private MediationState(@NonNull final Value value, boolean wasCompleted, boolean wasClosed) {
        this.value = value;
        this.wasCompleted = wasCompleted;
        this.wasClosed = wasClosed;
    }

    /** 初期状態を生成します */
    @NonNull
    static MediationState idle() {
        return new MediationState(Value.IDLE, false, false);
    }

    @NonNull
    @Override
    public String toString() {
        return value + "(completed=" + wasCompleted + ", closed=" + wasClosed + ")";
    }

    @Override
    public boolean equals(@Nullable final Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        MediationState state = (MediationState) o;
        return value == state.value;
    }

    @Override
    public int hashCode() {
        return value.hashCode();
    }

    /**
     * 指定した状態に遷移した新しいインスタンスを生成します。状態遷移ができない場合は例外を投げます
     *
     * @param next 次の状態
     * @return 新しいインスタンス
     * @throws NotChangedException 状態遷移ができない場合
     */
    @NonNull
    MediationState changed(@NonNull final MediationState.Value next) throws NotChangedException {
        final Value current = value;

        // 破棄状態はどの状態からでも遷移可能(FINISHED -> FINISHEDも可)
        if (next == Value.FINISHED) {
            return new MediationState(next, wasCompleted, wasClosed);
        }

        // 状態が変わっていない場合は例外を投げる
        if (next == current) {
            throw new NotChangedException(current, next);
        }

        // 現在の状態から次の状態にのみ遷移させる
        if (next.ordinal() == current.ordinal() + 1) {
            return new MediationState(next, wasCompleted, wasClosed);
        }

        // 遷移不可
        throw new NotChangedException(current, next);
    }

    /**
     * Completeフラグを立て、新しいインスタンスを生成します。既にCompleteフラグが立っている場合は例外を投げます
     *
     * @return 新しいインスタンス
     * @throws NotChangedException 既にCompleteフラグが立っている場合
     */
    @NonNull
    MediationState compareAndSetOnComplete() throws NotChangedException {
        if (wasCompleted) {
            throw new NotChangedException("Already completed");
        }
        return new MediationState(value, true, wasClosed);
    }

    /**
     * Closeフラグを立て、新しいインスタンスを生成します。既にCloseフラグが立っている場合は例外を投げます
     *
     * @return 新しいインスタンス
     * @throws NotChangedException 既にCloseフラグが立っている場合
     */
    @NonNull
    MediationState compareAndSetOnClose() throws NotChangedException {
        if (wasClosed) {
            throw new NotChangedException("Already closed");
        }
        return new MediationState(value, wasCompleted, true);
    }

    boolean isIdle() {
        return value == Value.IDLE;
    }

    boolean isLoading() {
        return value == Value.LOADING;
    }

    boolean isLoaded() {
        return value == Value.LOADED;
    }

    boolean isBeginPlayback() {
        return value == Value.BEGIN_PLAYBACK;
    }

    boolean isShowing() {
        return value == Value.SHOWING;
    }

    boolean isFinished() {
        return value == Value.FINISHED;
    }
}
