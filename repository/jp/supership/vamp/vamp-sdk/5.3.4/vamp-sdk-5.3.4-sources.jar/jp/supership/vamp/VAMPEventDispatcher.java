package jp.supership.vamp;

import android.os.Handler;
import android.os.Looper;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.VisibleForTesting;

import java.util.ArrayList;
import java.util.HashMap;

/** 広告の表示に関するイベント通知の仕組みを提供します。 */
public class VAMPEventDispatcher implements VAMPRewardedAdListener {
    private enum Event {
        FAILED_TO_SHOW,
        COMPLETED,
        OPENED,
        CLOSED,
        EXPIRED,
    }

    private static class Message {
        @NonNull final Event event;
        @NonNull final HashMap<String, Object> options;

        Message(@NonNull final Event event, @NonNull final HashMap<String, Object> options) {
            this.event = event;
            this.options = options;
        }

        Message(@NonNull final Event event) {
            this(event, new HashMap<>());
        }
    }

    @NonNull private static final VAMPEventDispatcher instance = new VAMPEventDispatcher();

    @NonNull private final HashMap<String, VAMPRewardedAdListener> listenerMap = new HashMap<>();
    /** メッセージBOX */
    @NonNull private final HashMap<String, ArrayList<Message>> messagesMap = new HashMap<>();

    /**
     * シングルトンインスタンスを返します。
     *
     * @return {@link VAMPEventDispatcher}のインスタンス
     */
    @NonNull
    public static VAMPEventDispatcher getInstance() {
        return instance;
    }

    protected VAMPEventDispatcher() {}

    /**
     * 指定した広告枠IDに関するVAMPイベントを受け取る{@link VAMPRewardedAdListener}を追加します。
     *
     * @param placementId 広告枠ID
     * @param listener {@link VAMPRewardedAdListener}
     * @return this
     */
    @SuppressWarnings("UnusedReturnValue")
    public VAMPEventDispatcher addListener(
            @NonNull final String placementId, @Nullable final VAMPRewardedAdListener listener) {
        if (listener != null) {
            listenerMap.put(placementId, listener);
        }
        return this;
    }

    /**
     * 指定した広告枠IDに関する{@link VAMPRewardedAdListener}を解除します。<br>
     * リスナーが追加されていない場合は何もしません。
     *
     * @param placementId 広告枠ID
     * @return this
     */
    @SuppressWarnings("UnusedReturnValue")
    public VAMPEventDispatcher removeListener(@NonNull final String placementId) {
        listenerMap.remove(placementId);
        return this;
    }

    @VisibleForTesting
    void removeAllListeners() {
        listenerMap.clear();
    }

    /**
     * 指定した広告枠IDに関するすべてのメッセージをリスナーに通知します。 リスナーに通知後、メッセージは破棄されます。 蓄積されているメッセージがない場合は何もしません。
     *
     * @param placementId 広告枠ID
     */
    public void flush(@NonNull final String placementId) {
        new Handler(Looper.getMainLooper())
                .post(
                        () -> {
                            final VAMPRewardedAdListener listener = listenerMap.get(placementId);
                            final ArrayList<Message> messages = messagesMap.get(placementId);

                            if (messages == null) {
                                return;
                            }

                            for (Message message : messages) {
                                switch (message.event) {
                                    case FAILED_TO_SHOW:
                                        final VAMPError error =
                                                (VAMPError) message.options.get("error");
                                        if (listener != null && error != null) {
                                            listener.onFailedToShow(placementId, error);
                                        }
                                        break;
                                    case COMPLETED:
                                        if (listener != null) {
                                            listener.onCompleted(placementId);
                                        }
                                        break;
                                    case OPENED:
                                        if (listener != null) {
                                            listener.onOpened(placementId);
                                        }
                                        break;
                                    case CLOSED:
                                        final Boolean adClicked =
                                                (Boolean) message.options.get("adClicked");
                                        if (listener != null) {
                                            listener.onClosed(
                                                    placementId, Boolean.TRUE.equals(adClicked));
                                        }
                                        break;
                                    case EXPIRED:
                                        if (listener != null) {
                                            listener.onExpired(placementId);
                                        }
                                        break;
                                }
                            }

                            // 全メッセージを送信したので破棄
                            messagesMap.remove(placementId);
                        });
    }

    void deleteAllMessages(@NonNull final String placementId) {
        messagesMap.remove(placementId);
    }

    @NonNull
    private ArrayList<Message> messagesOf(@NonNull final String placementId) {
        ArrayList<Message> messages = messagesMap.get(placementId);
        if (messages == null) {
            messages = new ArrayList<>();
        }
        return messages;
    }

    @Override
    public void onFailedToShow(@NonNull final String placementId, @NonNull final VAMPError error) {
        final VAMPRewardedAdListener listener = listenerMap.get(placementId);

        if (listener != null) {
            // 送信先がある場合は即時メッセージを送信
            listener.onFailedToShow(placementId, error);
        } else {
            // 送信先がない場合はメッセージBOXに一時格納
            final ArrayList<Message> messages = messagesOf(placementId);
            final HashMap<String, Object> options = new HashMap<>();
            options.put("error", error);
            messages.add(new Message(Event.FAILED_TO_SHOW, options));
            messagesMap.put(placementId, messages);
        }
    }

    @Override
    public void onCompleted(@NonNull final String placementId) {
        final VAMPRewardedAdListener listener = listenerMap.get(placementId);

        if (listener != null) {
            listener.onCompleted(placementId);
        } else {
            final ArrayList<Message> messages = messagesOf(placementId);
            messages.add(new Message(Event.COMPLETED));
            messagesMap.put(placementId, messages);
        }
    }

    @Override
    public void onOpened(@NonNull final String placementId) {
        final VAMPRewardedAdListener listener = listenerMap.get(placementId);

        if (listener != null) {
            listener.onOpened(placementId);
        } else {
            final ArrayList<Message> messages = messagesOf(placementId);
            messages.add(new Message(Event.OPENED));
            messagesMap.put(placementId, messages);
        }
    }

    @Override
    public void onClosed(@NonNull final String placementId, final boolean adClicked) {
        final VAMPRewardedAdListener listener = listenerMap.get(placementId);

        if (listener != null) {
            listener.onClosed(placementId, adClicked);
        } else {
            final ArrayList<Message> messages = messagesOf(placementId);
            final HashMap<String, Object> options = new HashMap<>();
            options.put("adClicked", adClicked);
            messages.add(new Message(Event.CLOSED, options));
            messagesMap.put(placementId, messages);
        }
    }

    @Override
    public void onExpired(@NonNull final String placementId) {
        final VAMPRewardedAdListener listener = listenerMap.get(placementId);

        if (listener != null) {
            listener.onExpired(placementId);
        } else {
            final ArrayList<Message> messages = messagesOf(placementId);
            messages.add(new Message(Event.EXPIRED));
            messagesMap.put(placementId, messages);
        }
    }
}
