package jp.supership.vamp.player.view;

import android.content.Context;
import android.graphics.Color;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;

final class ClickableAreaView extends FrameLayout implements View.OnClickListener {
    static final class Key {
        @NonNull final String name;

        Key(@NonNull final String name) {
            this.name = name;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            Key tag = (Key) o;
            return name.equals(tag.name);
        }

        @Override
        public int hashCode() {
            return name.hashCode();
        }
    }

    interface Listener {
        void onClick(@NonNull Key key);
    }

    @NonNull private final Listener listener;
    @NonNull private Key key;

    private ClickableAreaView(
            @NonNull final Context context,
            @NonNull final Key initKey,
            @NonNull final Listener listener) {
        super(context);

        this.listener = listener;
        this.key = initKey;

        setBackgroundColor(Color.TRANSPARENT);
        setVisibility(VISIBLE);
        setOnClickListener(this);
    }

    /** Viewを生成し、`parent`に追加します */
    @NonNull
    static ClickableAreaView addTo(
            @NonNull final LinearLayout parent,
            @NonNull final Context context,
            @NonNull final Key initKey,
            @NonNull final Listener listener) {
        final ClickableAreaView view = new ClickableAreaView(context, initKey, listener);
        final LinearLayout.LayoutParams params =
                new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0);
        params.weight = 1;
        parent.addView(view, params);
        return view;
    }

    void setKey(@NonNull final Key key) {
        this.key = key;
    }

    @Override
    public void onClick(View v) {
        listener.onClick(key);
    }
}
