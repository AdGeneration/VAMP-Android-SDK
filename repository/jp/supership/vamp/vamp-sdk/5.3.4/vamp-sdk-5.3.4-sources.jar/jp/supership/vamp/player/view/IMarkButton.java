package jp.supership.vamp.player.view;

import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.content.Context;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import jp.supership.vamp.R;

import java.io.File;

/**
 * iマークボタン。プライバシーポリシーおよびオプトアウトページへリンクするボタンです
 *
 * <p>Created by masaki.ando on 2017/12/12.
 */
final class IMarkButton extends FrameLayout implements View.OnClickListener {
    interface Listener {
        void onOptOutLinkClick();
    }

    private static final int IMARK_SIZE = 20;

    @NonNull private final LinearLayout linearLayout;
    @NonNull private final TextView textView;
    private final boolean showTextOnStart;
    @NonNull private final Listener listener;
    private int clickCount;

    private IMarkButton(
            @NonNull final Context context,
            @Nullable String filePath,
            @NonNull String text,
            final float density,
            final boolean showTextOnStart,
            @NonNull final Listener listener) {
        super(context);

        this.showTextOnStart = showTextOnStart;
        this.listener = listener;

        linearLayout = new LinearLayout(context);
        linearLayout.setOrientation(LinearLayout.HORIZONTAL);
        linearLayout.setLayoutParams(
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT));
        addView(linearLayout);

        File image = null;

        if (!TextUtils.isEmpty(filePath)) {
            image = new File(filePath);
        }

        if (image != null && image.exists()) {
            ImageView iMark = new ImageView(context);
            iMark.setImageBitmap(BitmapFactory.decodeFile(image.getPath()));
            iMark.setLayoutParams(
                    new LayoutParams((int) (IMARK_SIZE * density), (int) (IMARK_SIZE * density)));
            linearLayout.addView(iMark);
        } else {
            TextView iMark = new TextView(context);
            iMark.setText("i");
            iMark.setTypeface(Typeface.SANS_SERIF, Typeface.BOLD);
            iMark.setTextColor(Color.GRAY);
            iMark.setTextSize(12);
            iMark.setGravity(Gravity.CENTER);
            iMark.setLayoutParams(
                    new LayoutParams((int) (IMARK_SIZE * density), (int) (IMARK_SIZE * density)));
            iMark.setBackgroundResource(R.drawable.jp_supership_vamp_i_mark_style);
            linearLayout.addView(iMark);
        }

        textView = new TextView(context);
        textView.setText(text);
        textView.setTypeface(Typeface.SANS_SERIF, Typeface.NORMAL);
        textView.setTextColor(Color.GRAY);
        textView.setTextSize(12);
        textView.setGravity(Gravity.CENTER);
        textView.setLayoutParams(
                new LayoutParams(LayoutParams.WRAP_CONTENT, (int) (IMARK_SIZE * density)));
        textView.setPadding(
                (int) (IMARK_SIZE * 0.35 * density), 0, (int) (IMARK_SIZE * 0.5 * density), 0);
        linearLayout.addView(textView);
        textView.setVisibility(showTextOnStart ? VISIBLE : GONE);

        setOnClickListener(this);
    }

    /** Viewを生成し、`parent`に追加します */
    @NonNull
    static IMarkButton addTo(
            @NonNull final ViewGroup parent,
            @NonNull final Context context,
            @Nullable String filePath,
            @NonNull String text,
            final boolean showTextOnStart,
            final float density,
            final int gravity,
            @NonNull final Listener listener) {
        final IMarkButton button =
                new IMarkButton(context, filePath, text, density, showTextOnStart, listener);
        final LayoutParams params =
                new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
        params.gravity = gravity;
        parent.addView(button, params);
        return button;
    }

    @Override
    public void onClick(View v) {
        clickCount++;

        if (clickCount == 1) {
            textView.setVisibility(VISIBLE);
            linearLayout.setBackgroundResource(R.drawable.jp_supership_vamp_i_mark_style);

            if (!showTextOnStart) {
                PropertyValuesHolder animX =
                        PropertyValuesHolder.ofFloat("translationX", -100.f, 0);
                PropertyValuesHolder animA = PropertyValuesHolder.ofFloat("alpha", 0, 1.f);
                ObjectAnimator animator1 =
                        ObjectAnimator.ofPropertyValuesHolder(textView, animX, animA);
                animator1.setDuration(400);
                animator1.start();

                ObjectAnimator animator2 = ObjectAnimator.ofFloat(linearLayout, "alpha", 0, 1.f);
                animator2.setDuration(400);
                animator2.start();
            }
        } else if (clickCount >= 2) {
            listener.onOptOutLinkClick();
        }
    }
}
