package jp.supership.vamp.core.http;

import androidx.annotation.NonNull;
import androidx.annotation.VisibleForTesting;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

public class HttpContent implements Closeable {
    @NonNull public final InputStream data;
    public final int contentLength;

    public HttpContent(@NonNull InputStream in, int contentLength) throws IOException {
        data = cloneStream(in);
        this.contentLength = contentLength;
    }

    @VisibleForTesting
    public static HttpContent newInstance(@NonNull String data) throws IOException {
        byte[] byteArray = data.getBytes(StandardCharsets.UTF_8);
        InputStream in = new ByteArrayInputStream(byteArray);
        return new HttpContent(in, byteArray.length);
    }

    public String readAsString() throws IOException {
        InputStreamReader reader = new InputStreamReader(data);
        StringBuilder sb = new StringBuilder();
        char[] buf = new char[1024];
        int n;
        while (0 <= (n = reader.read(buf))) {
            sb.append(buf, 0, n);
        }
        return sb.toString();
    }

    @Override
    public void close() throws IOException {
        data.close();
    }

    private static InputStream cloneStream(@NonNull InputStream in) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buffer = new byte[1024];
        int len;
        while ((len = in.read(buffer)) > -1) {
            out.write(buffer, 0, len);
        }
        out.flush();

        return new ByteArrayInputStream(out.toByteArray());
    }
}
