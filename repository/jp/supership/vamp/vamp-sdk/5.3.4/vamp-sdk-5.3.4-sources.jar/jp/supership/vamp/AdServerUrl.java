package jp.supership.vamp;

import android.content.Context;
import android.text.TextUtils;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.VisibleForTesting;

import jp.supership.sscore.vamp.adid.SSCoreAdId;
import jp.supership.sscore.vamp.device.SSCoreAppInfo;
import jp.supership.sscore.vamp.device.SSCoreDevice;
import jp.supership.sscore.vamp.type.Optional;
import jp.supership.vamp.mediation.Adapter;
import jp.supership.vamp.mediation.RTBAdapter;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

final class AdServerUrl {
    /** インスタンスを生成できません。詳細はmessageを参照してください */
    public static final class CanNotInstantiateException extends Exception {
        CanNotInstantiateException(@NonNull String message) {
            super(message);
        }
    }

    private static final int SSPLOC_NUM = 99;
    /** 0: BrowserSDK 1: AndroidSDK 2: iOSSDK */
    private static final String SDK_TYPE = "1";

    private static final String SDK_NAME = "adg_vamp_android";

    @NonNull final String url;

    /** デフォルトのインスタンスを生成します */
    @NonNull
    static AdServerUrl newDefaultInstance(
            @NonNull final Context context,
            @NonNull final Optional<SSCoreAppInfo> appInfo,
            @NonNull final Optional<SSCoreDevice> device,
            @NonNull final Optional<SSCoreAdId> adId,
            @NonNull final String placementId,
            final boolean noRtb,
            @NonNull final VAMPPrivacySettings.ConsentStatus consentStatus,
            @NonNull final VAMPPrivacySettings.ChildDirected childDirected)
            throws CanNotInstantiateException {
        ArrayList<Adapter> supportedAdapters =
                GlobalAdapterProvider.getProvider().getSupportedAdapters();
        Map<String, String> adapterParams = new HashMap<>();
        for (Adapter adapter : supportedAdapters) {
            if (adapter instanceof RTBAdapter) {
                RTBAdapter rtbAdapter = (RTBAdapter) adapter;
                Map<String, String> map = rtbAdapter.collectParametersForAdRequest(context);
                if (map != null) {
                    adapterParams.putAll(map);
                }
            }
        }

        return new AdServerUrl(
                appInfo,
                device,
                BuildConfig.SDKVERSION,
                adId,
                placementId,
                Optional.<Double>empty(),
                Optional.<Double>empty(),
                noRtb,
                consentStatus,
                childDirected,
                adapterParams);
    }

    @VisibleForTesting
    AdServerUrl(
            @NonNull final Optional<SSCoreAppInfo> appInfo,
            @NonNull final Optional<SSCoreDevice> device,
            @NonNull final String sdkVersion,
            @NonNull final Optional<SSCoreAdId> adId,
            @NonNull final String placementId,
            @NonNull final Optional<Double> lat,
            @NonNull final Optional<Double> lon,
            final boolean noRtb,
            @NonNull final VAMPPrivacySettings.ConsentStatus consentStatus,
            @NonNull final VAMPPrivacySettings.ChildDirected childDirected,
            @Nullable final Map<String, String> adapterParams)
            throws CanNotInstantiateException {
        final StringBuilder sb = new StringBuilder(AdServerUrlDomain.getInstance().adUrlString());

        try {
            addParam(sb, "?", "posall", SSPLOC_NUM + "SSPLOC");
            addParam(sb, "&", "id", placementId);
            addParam(sb, "&", "sdktype", SDK_TYPE);
            addParam(sb, "&", "sdkver", sdkVersion);
            addParam(sb, "&", "sdkname", SDK_NAME);

            if (appInfo.isPresent()) {
                final SSCoreAppInfo app = appInfo.forced();
                addParam(sb, "&", "appname", app.appName);
                addParam(sb, "&", "appbundle", app.appId);
                addParam(sb, "&", "appver", app.appVersion);
            }

            if (device.isPresent()) {
                final SSCoreDevice dev = device.forced();
                addParam(sb, "&", "lang", dev.language);
                addParam(sb, "&", "locale", dev.locale);
                addParam(sb, "&", "tz", dev.timeZone);
                addParam(sb, "&", "networktype", dev.networkType);
                addParam(sb, "&", "carrier", dev.carrierNumber);
                addParam(sb, "&", "model", dev.modelName);
                addParam(sb, "&", "platform", dev.os);
                addParam(sb, "&", "platformv", dev.osVersion);
                addParam(sb, "&", "arch", dev.architecture);
                addParam(sb, "&", "bitness", "" + dev.bitness);

                if (dev.screenWidthInDp > 0) {
                    addParam(sb, "&", "dw", "" + dev.screenWidthInDp);
                }

                if (dev.screenHeightInDp > 0) {
                    addParam(sb, "&", "dh", "" + dev.screenHeightInDp);
                }

                if (dev.orientation.isPresent()) {
                    addParam(sb, "&", "do", dev.orientation.forced().value);
                }
            }

            final boolean isAccepted = consentStatus != VAMPPrivacySettings.ConsentStatus.DENIED;
            final boolean belowConsentAge = childDirected == VAMPPrivacySettings.ChildDirected.TRUE;

            if (isAccepted && !belowConsentAge) {
                try {
                    addParam(sb, "&", "advertising_id", adId.unwrap().value);
                } catch (Optional.NotPresentException ignored) {
                }
            }
            if (childDirected != VAMPPrivacySettings.ChildDirected.UNKNOWN) {
                addParam(sb, "&", "child_directed", belowConsentAge ? "1" : "0");
            }

            try {
                addParam(sb, "&", "lat", lat.unwrap().toString());
            } catch (Optional.NotPresentException ignored) {
            }

            try {
                addParam(sb, "&", "lon", lon.unwrap().toString());
            } catch (Optional.NotPresentException ignored) {
            }

            addParam(sb, "&", "t", "json3");

            if (!isAccepted || noRtb) {
                addParam(sb, "&", "nortb", "1");
            }

            if (adapterParams != null) {
                for (Map.Entry<String, String> entry : adapterParams.entrySet()) {
                    addParam(sb, "&", entry.getKey(), entry.getValue());
                }
            }

        } catch (UnsupportedEncodingException e) {
            throw new CanNotInstantiateException("Failed to encode. " + e);
        }

        url = sb.toString();
    }

    AdServerUrl(@NonNull final String url) throws CanNotInstantiateException {
        if (TextUtils.isEmpty(url)) {
            throw new CanNotInstantiateException("Given `url` is null or empty.");
        }

        this.url = url;
    }

    private static void addParam(
            @NonNull final StringBuilder sb,
            @NonNull final String separator,
            @NonNull final String key,
            @Nullable final String val)
            throws UnsupportedEncodingException {
        if (val == null) {
            return;
        }

        sb.append(separator).append(key).append("=").append(URLEncoder.encode(val, "utf-8"));
    }
}
