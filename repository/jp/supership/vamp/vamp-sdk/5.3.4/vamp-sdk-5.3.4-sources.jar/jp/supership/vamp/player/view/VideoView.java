package jp.supership.vamp.player.view;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.SurfaceTexture;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Handler;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;

import jp.supership.vamp.core.logging.LogUtils;
import jp.supership.vamp.player.VAMPPlayerError;
import jp.supership.vamp.player.VAMPPlayerReport;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.lang.ref.WeakReference;

/** Created by yumiko.ishii on 2017/04/07. */
public class VideoView extends FrameLayout {

    private PLAYER_STATE mCurrentState = PLAYER_STATE.IDLE;
    private PLAYER_STATE mTargetState = PLAYER_STATE.IDLE;

    private MediaPlayer mMediaPlayer;
    private SurfaceTexture mSurfaceTexture;

    private TextureView mTextureView;
    private VideoViewListener mVideoViewListener;
    private ImageView mSeekEndCaptureView;

    private String mUrl;
    private String mSeekEndUrl;
    private int mVideoWidth;
    private int mVideoHeight;
    private int mSeekWhenPrepared; // recording the seek position while preparing
    private int mCurrentBufferPercentage;
    private int mVideoRetries;

    private int mStreamType;
    private int contentType;

    private boolean mIsSeekEndCapture;
    private boolean mIsError;
    private boolean mAudioVolumeIsOn = false;

    private final Runner looper = new Runner(this);

    private static final int MAX_VIDEO_RETRIES = 1;
    private static final int VIDEO_VIEW_FILE_PERMISSION_ERROR = Integer.MIN_VALUE;

    private enum PLAYER_STATE {
        ERROR,
        IDLE,
        PREPARING,
        PREPARED,
        PLAYING,
        PAUSED,
        PLAYBACK_COMPLETED
    }

    public interface VideoViewListener {

        void onPrepared(); // 再生準備完了

        void onCompleted(); // 再生完了

        void onProgress(int pos, int duration); // 再生位置更新

        void onError(@NonNull VAMPPlayerError error); // エラー発生

        void onBuffering(int percent);
    }

    public VideoView(@NonNull Context context) {
        super(context);
        init(context);
    }

    private void init(Context context) {
        mCurrentState = PLAYER_STATE.IDLE;
        mTargetState = PLAYER_STATE.IDLE;

        mVideoWidth = 0;
        mVideoHeight = 0;
        mSeekWhenPrepared = 0;
        mCurrentBufferPercentage = 0;
        mVideoRetries = 0;
        mStreamType = AudioManager.STREAM_MUSIC;
        mIsSeekEndCapture = false;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            contentType = AudioAttributes.CONTENT_TYPE_MUSIC;
        }

        setLayerType(View.LAYER_TYPE_HARDWARE, null);
        setDescendantFocusability(ViewGroup.FOCUS_BLOCK_DESCENDANTS);
        setBackgroundColor(Color.TRANSPARENT);

        mTextureView = new TextureView(context);
        mTextureView.setSurfaceTextureListener(
                new TextureView.SurfaceTextureListener() {

                    @Override
                    public void onSurfaceTextureAvailable(
                            SurfaceTexture surface, int width, int height) {
                        mSurfaceTexture = surface;
                        if (mMediaPlayer != null && mSurfaceTexture != null) {
                            mMediaPlayer.setSurface(new Surface(mSurfaceTexture));
                        } else {
                            openVideo();
                        }
                    }

                    @Override
                    public void onSurfaceTextureSizeChanged(
                            SurfaceTexture surface, int width, int height) {
                        if (mMediaPlayer != null
                                && mTargetState == PLAYER_STATE.PLAYING
                                && (mVideoWidth == width && mVideoHeight == height)) {
                            if (mSeekWhenPrepared != 0) {
                                seekTo(mSeekWhenPrepared);
                            }
                        }
                    }

                    @Override
                    public boolean onSurfaceTextureDestroyed(SurfaceTexture surface) {
                        mSurfaceTexture = null;
                        release(true);
                        return false;
                    }

                    @Override
                    public void onSurfaceTextureUpdated(SurfaceTexture surface) {}
                });

        LayoutParams params =
                new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
        params.gravity = Gravity.CENTER;
        addView(mTextureView, params);

        // 再生終了時のキャプチャ画像表示用View
        // （※MediaPlayerのSeekTo()が指定した場所から微妙にずれる不具合があるので再生終了時の画像をキャプチャして表示する事で対応）
        mSeekEndCaptureView = new ImageView(context);
        mSeekEndCaptureView.setBackgroundColor(Color.BLACK);
        mSeekEndCaptureView.setVisibility(View.INVISIBLE);
        addView(mSeekEndCaptureView, params);

        setFocusable(true);
        setFocusableInTouchMode(true);
    }

    public void setVideoViewListener(VideoViewListener listener) {
        mVideoViewListener = listener;
    }

    @SuppressWarnings("deprecation")
    public void setAudioStreamType(int streamType) {
        mStreamType = streamType;
        if (mMediaPlayer != null) {
            mMediaPlayer.setAudioStreamType(mStreamType);
        }
    }

    @RequiresApi(Build.VERSION_CODES.LOLLIPOP)
    public void setAudioContentType(int contentType) {
        this.contentType = contentType;
        if (mMediaPlayer != null) {
            mMediaPlayer.setAudioAttributes(
                    new AudioAttributes.Builder().setContentType(contentType).build());
        }
    }

    public void setVideoURL(String url) {
        LogUtils.devLog("setVideoURL(" + url + ")");
        if (mUrl == null || !mUrl.equals(url)) {
            mUrl = url;
            mSeekWhenPrepared = 0;
            mCurrentBufferPercentage = 0;
            mVideoRetries = 0;
            openVideo();
        }
    }

    private void openVideo() {
        if (mUrl == null || mUrl.length() <= 0) {
            return;
        }
        reset(false);

        mMediaPlayer = new MediaPlayer();

        try {
            mMediaPlayer.setDataSource(mUrl);
            mMediaPlayer.setOnBufferingUpdateListener(mBufferingUpdateListener);
            mMediaPlayer.setOnCompletionListener(mCompletionListener);
            mMediaPlayer.setOnPreparedListener(mPreparedListener);
            mMediaPlayer.setOnSeekCompleteListener(mSeekCompleteListener);
            mMediaPlayer.setOnVideoSizeChangedListener(mVideoSizeChangedListener);
            mMediaPlayer.setOnErrorListener(mErrorListener);
            if (mSurfaceTexture != null) {
                mMediaPlayer.setSurface(new Surface(mSurfaceTexture));
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                setAudioContentType(contentType);
            } else {
                setAudioStreamType(mStreamType);
            }

            mMediaPlayer.prepareAsync();
            mCurrentState = PLAYER_STATE.PREPARING;
        } catch (Exception e) {
            LogUtils.e("openVideo() Exception:" + e.getMessage());
            mCurrentState = PLAYER_STATE.ERROR;
            mTargetState = PLAYER_STATE.ERROR;
            if (mVideoViewListener != null) {
                mVideoViewListener.onError(VAMPPlayerError.MEDIA_ERROR_UNKNOWN);
            }
            LogUtils.e(VAMPPlayerError.MEDIA_ERROR_UNKNOWN.toString(), e);
        }

        requestLayout();
        invalidate();
    }

    private void release(boolean cleartargetstate) {
        reset(cleartargetstate);
    }

    private void reset(boolean cleartargetstate) {
        mIsError = false;
        if (mMediaPlayer != null) {
            mMediaPlayer.setOnBufferingUpdateListener(null);
            mMediaPlayer.setOnCompletionListener(null);
            mMediaPlayer.setOnPreparedListener(null);
            mMediaPlayer.setOnSeekCompleteListener(null);
            mMediaPlayer.setOnVideoSizeChangedListener(null);
            mMediaPlayer.setOnErrorListener(null);
            mMediaPlayer.setSurface(null);
            mMediaPlayer.reset();
            mMediaPlayer.release();
            mMediaPlayer = null;
            mCurrentState = PLAYER_STATE.IDLE;
            if (cleartargetstate) {
                mTargetState = PLAYER_STATE.IDLE;
            }
        }

        looper.stop();
    }

    /**
     * キャプチャ取得
     *
     * @return
     */
    public Bitmap getCapture() {
        if (mTextureView != null) {
            return mTextureView.getBitmap(mVideoWidth, mVideoHeight);
        }
        return null;
    }

    /**
     * 再生終了画像表示設定
     *
     * @param visibility
     */
    public void setSeekEndCaptureVisibility(int visibility) {
        if (mSeekEndCaptureView != null) {
            if (mIsSeekEndCapture) {
                mSeekEndCaptureView.setVisibility(visibility);
            } else {
                mSeekEndCaptureView.setVisibility(View.INVISIBLE);
            }
        }
    }

    /**
     * 再生終了画像ファイル場所指定
     *
     * @param url
     */
    public void setSeekEndCaptureURL(String url) {
        if (mSeekEndUrl == null && !TextUtils.isEmpty(url)) {
            mSeekEndUrl = url;
            File image = new File(mSeekEndUrl);
            if (image.exists()) {
                mSeekEndCaptureView.setImageBitmap(BitmapFactory.decodeFile(image.getPath()));
                mIsSeekEndCapture = true;
            } else {
                LogUtils.devLog("image not exists");
                mSeekEndCaptureView.setImageBitmap(null);
                mIsSeekEndCapture = false;
            }
        }
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int width = getDefaultSize(mVideoWidth, widthMeasureSpec);
        int height = getDefaultSize(mVideoHeight, heightMeasureSpec);
        if (mVideoWidth > 0 && mVideoHeight > 0) {
            int widthSpecMode = MeasureSpec.getMode(widthMeasureSpec);
            int widthSpecSize = MeasureSpec.getSize(widthMeasureSpec);
            int heightSpecMode = MeasureSpec.getMode(heightMeasureSpec);
            int heightSpecSize = MeasureSpec.getSize(heightMeasureSpec);

            if (widthSpecMode == MeasureSpec.EXACTLY && heightSpecMode == MeasureSpec.EXACTLY) {
                // the size is fixed
                width = widthSpecSize;
                height = heightSpecSize;

                // for compatibility, we adjust size based on aspect ratio
                if (mVideoWidth * height < width * mVideoHeight) {
                    // Log.i("@@@", "image too wide, correcting");
                    width = height * mVideoWidth / mVideoHeight;
                } else if (mVideoWidth * height > width * mVideoHeight) {
                    // Log.i("@@@", "image too tall, correcting");
                    height = width * mVideoHeight / mVideoWidth;
                }
            } else if (widthSpecMode == MeasureSpec.EXACTLY) {
                // only the width is fixed, adjust the height to match aspect ratio if possible
                width = widthSpecSize;
                height = width * mVideoHeight / mVideoWidth;
                if (heightSpecMode == MeasureSpec.AT_MOST && height > heightSpecSize) {
                    // couldn't match aspect ratio within the constraints
                    height = heightSpecSize;
                }
            } else if (heightSpecMode == MeasureSpec.EXACTLY) {
                // only the height is fixed, adjust the width to match aspect ratio if possible
                height = heightSpecSize;
                width = height * mVideoWidth / mVideoHeight;
                if (widthSpecMode == MeasureSpec.AT_MOST && width > widthSpecSize) {
                    // couldn't match aspect ratio within the constraints
                    width = widthSpecSize;
                }
            } else {
                // neither the width nor the height are fixed, try to use actual video size
                width = mVideoWidth;
                height = mVideoHeight;
                if (heightSpecMode == MeasureSpec.AT_MOST && height > heightSpecSize) {
                    // too tall, decrease both width and height
                    height = heightSpecSize;
                    width = height * mVideoWidth / mVideoHeight;
                }
                if (widthSpecMode == MeasureSpec.AT_MOST && width > widthSpecSize) {
                    // too wide, decrease both width and height
                    width = widthSpecSize;
                    height = width * mVideoHeight / mVideoWidth;
                }
            }
        } // else: no size yet, just adopt the given spec sizes

        setMeasuredDimension(width, height);

        int childWidthMeasureSpec =
                MeasureSpec.makeMeasureSpec(getMeasuredWidth(), MeasureSpec.EXACTLY);
        int childHeightMeasureSpec =
                MeasureSpec.makeMeasureSpec(getMeasuredHeight(), MeasureSpec.EXACTLY);
        mTextureView.measure(childWidthMeasureSpec, childHeightMeasureSpec);
        mSeekEndCaptureView.measure(childWidthMeasureSpec, childHeightMeasureSpec);
    }

    /**
     * 再生中かどうか
     *
     * @return
     */
    public boolean isPlaying() {
        if (isInPlaybackState()) {
            return mMediaPlayer.isPlaying();
        }
        return false;
    }

    /**
     * 総再生時間取得
     *
     * @return
     */
    public int getDuration() {
        if (isInPlaybackState()) {
            return mMediaPlayer.getDuration();
        }
        return -1;
    }

    /**
     * 再生位置取得
     *
     * @return
     */
    public int getCurrentPosition() {
        if (isInPlaybackState()) {
            return mMediaPlayer.getCurrentPosition();
        }
        return 0;
    }

    /**
     * 再生位置設定
     *
     * @param pos
     */
    public void seekTo(int pos) {
        if (isInPlaybackState()) {
            mMediaPlayer.seekTo(pos);
            mSeekWhenPrepared = 0;
        } else {
            mSeekWhenPrepared = pos;
        }
    }

    /** 動画の最後まで再生を進めます。動画の最後まで進むため、Completeイベントが通知されます */
    public void seekToEnd() {
        // mMediaPlayer.seekTo(mMediaPlayer.getDuration())だと
        // 指定位置からずれる不具合があるため、
        // Complete通知を発行してしまいエンドカードを表示するように処理を進める
        mCompletionListener.onCompletion(mMediaPlayer);
    }

    private boolean isInPlaybackState() {
        return (mMediaPlayer != null
                && mCurrentState != PLAYER_STATE.ERROR
                && mCurrentState != PLAYER_STATE.IDLE
                && mCurrentState != PLAYER_STATE.PREPARING);
    }

    private void process() {
        if (isInPlaybackState() && mMediaPlayer.isPlaying()) {
            int duration = mMediaPlayer.getDuration();
            int currentPosition = mMediaPlayer.getCurrentPosition();

            if (mVideoViewListener != null) {
                mVideoViewListener.onProgress(currentPosition, duration);
            }
        }
    }

    private class Runner implements Runnable {

        private Thread thread = null;
        private Handler handler = null;
        boolean running = false;

        private WeakReference<VideoView> self;

        public Runner(VideoView player) {
            self = new WeakReference<>(player);
        }

        public void start() {
            if (thread == null) {
                thread = new Thread(this);
            }

            if (handler == null) {
                handler = new Handler();
            }

            try {
                thread.start();
                running = true;
            } catch (IllegalThreadStateException ignore) {
                // nothing to do
            }
        }

        public void stop() {
            running = false;
            thread = null;
        }

        @Override
        public void run() {
            while (running) {
                final VideoView player = self.get();
                if (player == null) {
                    stop();
                    return;
                }

                handler.post(
                        new Runnable() {

                            @Override
                            public void run() {
                                if (player == null) {
                                    return;
                                }

                                player.process();
                            }
                        });

                try {
                    Thread.sleep(100);
                } catch (InterruptedException ignore) {
                    // nothing to do
                }
            }
        }
    }

    private MediaPlayer.OnBufferingUpdateListener mBufferingUpdateListener =
            new MediaPlayer.OnBufferingUpdateListener() {

                @Override
                public void onBufferingUpdate(MediaPlayer mediaPlayer, int percent) {
                    LogUtils.d(toString() + ": Buffering... " + percent + "%");
                    mCurrentBufferPercentage = percent;
                    if (mVideoViewListener != null) {
                        mVideoViewListener.onBuffering(mCurrentBufferPercentage);
                    }

                    if (mCurrentBufferPercentage >= 100) {
                        mediaPlayer.setOnBufferingUpdateListener(null);
                    }
                }
            };

    private MediaPlayer.OnCompletionListener mCompletionListener =
            new MediaPlayer.OnCompletionListener() {

                @Override
                public void onCompletion(MediaPlayer mediaPlayer) {
                    if (mCurrentState != PLAYER_STATE.PLAYBACK_COMPLETED) {
                        mCurrentState = PLAYER_STATE.PLAYBACK_COMPLETED;
                        mTargetState = PLAYER_STATE.PLAYBACK_COMPLETED;
                        if (!mIsError) {
                            if (mVideoViewListener != null) {
                                mVideoViewListener.onCompleted();
                            }
                        } else {
                            // MediaPlayerの不具合（？）でonError発生後でもonCompletionが発生する事があるので、その場合はイベントを通知しない
                        }
                    }
                    looper.stop();
                }
            };

    private MediaPlayer.OnPreparedListener mPreparedListener =
            new MediaPlayer.OnPreparedListener() {

                @Override
                public void onPrepared(MediaPlayer mediaPlayer) {
                    LogUtils.devLog(toString() + ": OnPreparedListener");
                    mCurrentState = PLAYER_STATE.PREPARED;

                    mVideoWidth = mediaPlayer.getVideoWidth();
                    mVideoHeight = mediaPlayer.getVideoHeight();

                    int seekToPosition =
                            mSeekWhenPrepared; // mSeekWhenPrepared may be changed after seekTo()
                    // call
                    if (seekToPosition != 0) {
                        seekTo(seekToPosition);
                    }

                    if (mVideoWidth != 0 && mVideoHeight != 0) {
                        requestLayout();
                    }

                    if (mVideoViewListener != null) {
                        mVideoViewListener.onPrepared();
                    }
                }
            };

    private MediaPlayer.OnSeekCompleteListener mSeekCompleteListener =
            new MediaPlayer.OnSeekCompleteListener() {

                @Override
                public void onSeekComplete(MediaPlayer mediaPlayer) {
                    if (mTargetState == PLAYER_STATE.PLAYING) {
                        start();
                    }
                }
            };

    private MediaPlayer.OnVideoSizeChangedListener mVideoSizeChangedListener =
            new MediaPlayer.OnVideoSizeChangedListener() {

                @Override
                public void onVideoSizeChanged(MediaPlayer mediaPlayer, int width, int height) {
                    LogUtils.devLog(toString() + ": OnVideoSizeChangedListener");
                    mVideoWidth = mediaPlayer.getVideoWidth();
                    mVideoHeight = mediaPlayer.getVideoHeight();
                    if (mVideoWidth != 0 && mVideoHeight != 0) {
                        requestLayout();
                    }
                }
            };

    private MediaPlayer.OnErrorListener mErrorListener =
            new MediaPlayer.OnErrorListener() {

                @Override
                public boolean onError(MediaPlayer mediaPlayer, int what, int extra) {
                    LogUtils.devLog("MediaPlayer.onError what:" + what + " extra:" + extra);
                    if (retryMediaPlayer(mediaPlayer, what, extra)) {
                        mIsError = false;
                        return true;
                    } else {
                        mIsError = true;
                        mCurrentState = PLAYER_STATE.ERROR;
                        mTargetState = PLAYER_STATE.ERROR;
                        /* If an error handler has been supplied, use it and finish. */
                        if (mVideoViewListener != null) {
                            VAMPPlayerReport errorReport =
                                    new VAMPPlayerReport(
                                            new Throwable(),
                                            VAMPPlayerError.UNSPECIFIED,
                                            "what:" + what + " extra:" + extra);
                            VAMPPlayerReport.setLastError(errorReport);

                            mVideoViewListener.onError(VAMPPlayerError.UNSPECIFIED);
                        }

                        return false;
                    }
                }
            };

    private boolean retryMediaPlayer(
            final MediaPlayer mediaPlayer, final int what, final int extra) {
        LogUtils.d(toString() + ": retryMediaPlayer");
        // XXX
        // VideoView has a bug in versions lower than Jelly Bean, Api Level 16, Android 4.1
        // For api < 16, VideoView is not able to read files written to disk since it reads them in
        // a Context different from the Application and therefore does not have correct permission.
        // To solve this problem we obtain the video file descriptor ourselves with valid
        // permissions
        // and pass it to the underlying MediaPlayer in VideoView.
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.JELLY_BEAN
                && what == MediaPlayer.MEDIA_ERROR_UNKNOWN
                && extra == VIDEO_VIEW_FILE_PERMISSION_ERROR
                && mVideoRetries < MAX_VIDEO_RETRIES) {

            FileInputStream inputStream = null;
            try {
                mediaPlayer.reset();
                final File file = new File(mUrl);
                inputStream = new FileInputStream(file);
                mediaPlayer.setDataSource(inputStream.getFD());

                // XXX
                // VideoView has a callback registered with the MediaPlayer to set a flag when the
                // media file has been prepared. Start also sets a flag in VideoView indicating the
                // desired state is to play the video. Therefore, whichever method finishes last
                // will check both flags and begin playing the video.
                mediaPlayer.prepareAsync();
                return true;
            } catch (Exception e) {
                LogUtils.e(VAMPPlayerError.UNSPECIFIED.toString(), e);
                return false;
            } finally {
                if (inputStream != null) {
                    try {
                        inputStream.close();
                    } catch (IOException ignored) {
                    }
                }

                mVideoRetries++;
            }
        }
        return false;
    }

    public void start() {
        if (isInPlaybackState()) {
            looper.start();
            mMediaPlayer.start();
            mCurrentState = PLAYER_STATE.PLAYING;
            mTargetState = PLAYER_STATE.PLAYING;
        }
    }

    public void pause() {
        if (isInPlaybackState()) {
            if (mMediaPlayer.isPlaying()) {
                mMediaPlayer.pause();
                mCurrentState = PLAYER_STATE.PAUSED;
                looper.stop();
            }
        }
        mTargetState = PLAYER_STATE.PAUSED;
    }

    public boolean isVolume() {
        return mAudioVolumeIsOn;
    }

    public void unmute() {
        if (mMediaPlayer != null) {
            mMediaPlayer.setVolume(1, 1);
            mAudioVolumeIsOn = true;
        }
    }

    public void mute() {
        if (mMediaPlayer != null) {
            mMediaPlayer.setVolume(0, 0);
            mAudioVolumeIsOn = false;
        }
    }

    public void destroy() {
        release(false);
    }

    /**
     * 再生終了しているか判定します
     *
     * @return 再生終了しているならばtrue、それ以外ならfalse
     */
    public boolean isPlaybackEnded() {
        // getCurrentPositionが必ずしも正確な値を返すとは限らないため、誤差1秒を許容する
        return mMediaPlayer.getCurrentPosition() >= mMediaPlayer.getDuration() - 1000;
    }
}
