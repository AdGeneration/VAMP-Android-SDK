package jp.supership.vamp.core.http;

import android.os.AsyncTask;
import android.os.Handler;
import android.os.Looper;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import jp.supership.vamp.core.logging.LogUtils;
import jp.supership.vamp.core.utils.AsyncTaskUtils;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

class HttpClientImpl implements IHttpClient {

    @Override
    public void get(@NonNull String urlString, @Nullable IHttpClientListener listener) {
        try {
            URL url = new URL(urlString);
            get(url, listener);
        } catch (Exception e) {
            LogUtils.devLog(e.getMessage());
            if (listener != null) {
                listener.onFail(e.getMessage());
            }
        }
    }

    @Override
    public void get(@NonNull URL url, @Nullable IHttpClientListener listener) {
        HttpRequest request = new HttpRequest(url).setMethod(HttpMethod.GET);
        send(request, listener);
    }

    @Override
    public void send(
            @NonNull final HttpRequest request, @Nullable final IHttpClientListener listener) {
        AsyncTaskUtils.execute(new HttpURLConnectionTask(request, listener));
    }

    static class HttpURLConnectionTask extends AsyncTask<String, Void, Boolean> {
        private HttpRequest request;
        private IHttpClientListener listener;

        HttpURLConnectionTask(HttpRequest request, IHttpClientListener listener) {
            this.request = request;
            this.listener = listener;
        }

        @Override
        protected Boolean doInBackground(String... strings) {
            InputStream is = null;
            final HttpResponse response = new HttpResponse();
            HttpURLConnection httpURLConnection = null;

            try {
                httpURLConnection = request.newConnection();
                httpURLConnection.connect();

                final int responseCode = httpURLConnection.getResponseCode();
                String responseMessage = httpURLConnection.getResponseMessage();

                response.setStatusCode(responseCode);
                response.setMessage(responseMessage);

                if (responseCode == HttpURLConnection.HTTP_OK
                        || responseCode == HttpURLConnection.HTTP_NOT_MODIFIED) {

                    response.setHeader(httpURLConnection.getHeaderFields());
                    is = httpURLConnection.getInputStream();
                    if (is != null) {
                        HttpContent content =
                                new HttpContent(is, httpURLConnection.getContentLength());
                        response.setContent(content);
                    }

                    new Handler(Looper.getMainLooper())
                            .post(
                                    new Runnable() {
                                        @Override
                                        public void run() {
                                            if (listener != null) {
                                                listener.onSuccess(response);
                                            }

                                            try {
                                                response.close();
                                            } catch (Exception e) {
                                                LogUtils.devLog(e.getMessage());
                                            }
                                        }
                                    });

                } else {
                    new Handler(Looper.getMainLooper())
                            .post(
                                    new Runnable() {
                                        @Override
                                        public void run() {
                                            if (listener != null) {
                                                listener.onFail(
                                                        "Failed response code:" + responseCode);
                                            }

                                            try {
                                                response.close();
                                            } catch (Exception e) {
                                                LogUtils.devLog(e.getMessage());
                                            }
                                        }
                                    });
                }
            } catch (Exception e) {
                LogUtils.e(e.getMessage());
                try {
                    if (is != null) {
                        is.close();
                    }

                } catch (Exception ex) {
                    LogUtils.devLog(ex.getMessage());
                }

                final String message = e.getMessage();
                new Handler(Looper.getMainLooper())
                        .post(
                                new Runnable() {
                                    @Override
                                    public void run() {
                                        if (listener != null) {
                                            listener.onFail(message);
                                        }
                                    }
                                });
            } finally {
                try {
                    if (is != null) {
                        is.close();
                    }
                } catch (Exception e) {
                    LogUtils.devLog(e.getMessage());
                }

                if (httpURLConnection != null) {
                    httpURLConnection.disconnect();
                }
            }

            return null;
        }
    }
}
