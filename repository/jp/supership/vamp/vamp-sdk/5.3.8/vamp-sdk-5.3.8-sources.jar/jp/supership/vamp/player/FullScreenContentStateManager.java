//
//  Copyright © 2026 Supership Inc. All rights reserved.
//
package jp.supership.vamp.player;

final class FullScreenContentStateManager {
    private static final FullScreenContentStateManager instance =
            new FullScreenContentStateManager();

    private boolean destroyed;

    private FullScreenContentStateManager() {}

    /** シングルトンインスタンスを返します。 前提として、フルスクリーンコンテンツは同時に一つしか表示できないため、 シングルトンで状態を管理することができます */
    static FullScreenContentStateManager getInstance() {
        return instance;
    }

    /**
     * @return trueならば表示されたフルスクリーン広告は既に破棄されています
     */
    boolean isDestroyed() {
        return destroyed;
    }

    /** フルスクリーン広告の表示を開始するときに呼び出します */
    void present() {
        destroyed = false;
    }

    /** フルスクリーン広告を破棄するときに呼び出します */
    void destroy() {
        destroyed = true;
    }
}
