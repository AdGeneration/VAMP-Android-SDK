//
//  Copyright © 2026 Supership Inc. All rights reserved.
//
package jp.supership.vamp.utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class JsonUtils {

    /**
     * jsonをJSONObjectに変換する.
     *
     * @param json JSON文字列
     * @return JSONObject obj
     */
    public static JSONObject fromJson(String json) {
        try {
            if (json == null) {
                throw new JSONException("String is null");
            }
            return new JSONObject(json);
        } catch (JSONException e) {
            return new JSONObject();
        }
    }

    /**
     * JSONObjectをjsonに変換する.
     *
     * @param obj 対象のJSONObject
     * @return String json
     */
    public static String toJson(JSONObject obj) {
        return obj != null ? obj.toString() : "{}";
    }

    /**
     * JSONArrayをjsonに変換する.
     *
     * @param arr 対象のJsonArray
     * @return String json
     */
    public static String toJson(JSONArray arr) {
        return arr != null ? arr.toString() : "[]";
    }

    /**
     * JSONArrayをList<T>に変換する.
     *
     * @param arr 対象のJsonArray
     * @return ArrayList<T>
     */
    public static <T> ArrayList<T> jsonArrayToArrayList(JSONArray arr) throws JSONException {
        if (arr == null) {
            throw new JSONException("JSONArray is null.");
        }

        ArrayList<T> list = new ArrayList<>();

        for (int i = 0, len = arr.length(); i < len; i++) {
            try {
                T data = (T) arr.opt(i);
                if (data != null) {
                    list.add(data);
                }
            } catch (ClassCastException e) {
            }
        }

        return list;
    }

    /**
     * JSONObjectからIntegerを取り出す
     *
     * @param obj
     * @param key
     * @return Integer
     */
    public static Integer optInteger(JSONObject obj, String key) {
        try {
            return obj.optInt(key);
        } catch (NumberFormatException | NullPointerException e) {
            return null;
        }
    }

    /**
     * JSONArrayからIntegerを取り出す
     *
     * @param arr
     * @param index
     * @return Integer
     */
    public static Integer optInteger(JSONArray arr, int index) {
        try {
            return arr.optInt(index);
        } catch (NumberFormatException | NullPointerException e) {
            return null;
        }
    }

    /**
     * MapをJsonObjectに変換する
     *
     * @param map Map
     * @return JsonObject
     * @throws JSONException
     */
    public static JSONObject mapToJson(Map map) throws JSONException {
        if (map == null) {
            return null;
        }
        JSONObject obj = new JSONObject();
        for (Object key : map.keySet()) {
            if (key instanceof String) {
                Object value = map.get(key);
                if (value == null) {
                    obj.put((String) key, null);
                } else if (value instanceof Map) {
                    obj.put((String) key, mapToJson((Map) value));
                } else if (value instanceof Set) {
                    obj.put((String) key, setToJson((Set) value));
                } else if (value instanceof List) {
                    obj.put((String) key, listToJson((List) value));
                } else if (value instanceof Object[]
                        || value instanceof int[]
                        || value instanceof short[]
                        || value instanceof byte[]
                        || value instanceof char[]
                        || value instanceof long[]
                        || value instanceof boolean[]
                        || value instanceof float[]
                        || value instanceof double[]) {
                    obj.put((String) key, arrayToJson((Object[]) value));
                } else if (value instanceof Integer
                        || value instanceof Long
                        || value instanceof Float
                        || value instanceof Double
                        || value instanceof Short
                        || value instanceof Boolean
                        || value instanceof Byte
                        || value instanceof String) {
                    obj.put((String) key, value);
                }
            }
        }
        return obj;
    }

    public static Map<String, Object> toMap(JSONObject jsonObject) throws JSONException {
        Map<String, Object> map = new HashMap<>();
        Iterator<String> keys = jsonObject.keys();
        while (keys.hasNext()) {
            String key = keys.next();
            Object value = jsonObject.get(key);
            if (value instanceof JSONArray) {
                value = toList((JSONArray) value);
            } else if (value instanceof JSONObject) {
                value = toMap((JSONObject) value);
            }
            map.put(key, value);
        }
        return map;
    }

    public static List<Object> toList(JSONArray array) throws JSONException {
        List<Object> list = new ArrayList<>();
        for (int i = 0; i < array.length(); i++) {
            Object value = array.get(i);
            if (value instanceof JSONArray) {
                value = toList((JSONArray) value);
            } else if (value instanceof JSONObject) {
                value = toMap((JSONObject) value);
            }
            list.add(value);
        }
        return list;
    }

    private static JSONArray setToJson(Set set) throws JSONException {
        JSONArray arr = new JSONArray();
        for (Object value : set) {
            put(arr, value);
        }
        return arr;
    }

    private static JSONArray listToJson(List list) throws JSONException {
        JSONArray arr = new JSONArray();
        for (Object value : list) {
            put(arr, value);
        }
        return arr;
    }

    private static JSONArray arrayToJson(Object[] list) throws JSONException {
        JSONArray arr = new JSONArray();
        for (Object value : list) {
            put(arr, value);
        }
        return arr;
    }

    private static void put(JSONArray arr, Object value) throws JSONException {
        if (value instanceof Map) {
            arr.put(mapToJson((Map) value));
        } else if (value instanceof Set) {
            arr.put(setToJson((Set) value));
        } else if (value instanceof List) {
            arr.put(listToJson((List) value));
        } else if (value instanceof Object[]
                || value instanceof int[]
                || value instanceof short[]
                || value instanceof byte[]
                || value instanceof char[]
                || value instanceof long[]
                || value instanceof boolean[]) {
            arr.put(arrayToJson((Object[]) value));
        } else if (value instanceof Integer
                || value instanceof Long
                || value instanceof Float
                || value instanceof Double
                || value instanceof Short
                || value instanceof Boolean
                || value instanceof Byte
                || value instanceof String) {
            arr.put(value);
        }
    }

    public static String toJsonStr(String value) {
        if (value == null) {
            return null;
        }
        StringBuilder buf = new StringBuilder(value.length());
        for (int i = 0; i < value.length(); ++i) {
            char c = value.charAt(i);
            switch (c) {
                case '"':
                    buf.append("\\\"");
                    break;
                case '\\':
                    buf.append("\\\\");
                    break;
                case '\n':
                    buf.append("\\n");
                    break;
                case '\r':
                    buf.append("\\r");
                    break;
                case '\t':
                    buf.append("\\t");
                    break;
                case '\f':
                    buf.append("\\f");
                    break;
                case '\b':
                    buf.append("\\b");
                    break;
                default:
                    if ((c < ' ') || (c == '')) {
                        buf.append(" ");
                    } else {
                        buf.append(c);
                    }
            }
        }
        return buf.toString();
    }
}
