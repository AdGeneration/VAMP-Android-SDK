//
//  Copyright © 2026 Supership Inc. All rights reserved.
//
package jp.supership.vamp;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import java.io.PrintWriter;
import java.io.StringWriter;
import jp.supership.sscore.vamp.type.Optional;

final class UncaughtExceptionHandler implements Thread.UncaughtExceptionHandler {
    @NonNull
    private static final UncaughtExceptionHandler INSTANCE = new UncaughtExceptionHandler();

    @Nullable private static Optional<Thread.UncaughtExceptionHandler> defaultHandler;

    private UncaughtExceptionHandler() {}

    static void set() {
        if (!BuildConfig.DEV_LOG) {
            return;
        }

        synchronized (UncaughtExceptionHandler.class) {
            // 自身がセットされる前のデフォルトハンドラを保持しておく
            if (INSTANCE != Thread.getDefaultUncaughtExceptionHandler()) {
                defaultHandler = Optional.of(Thread.getDefaultUncaughtExceptionHandler());
            }

            Thread.setDefaultUncaughtExceptionHandler(INSTANCE);
        }
    }

    static void unset() {
        if (!BuildConfig.DEV_LOG) {
            return;
        }

        synchronized (UncaughtExceptionHandler.class) {
            // 保持していたデフォルトハンドラを復元する
            if (defaultHandler != null) {
                Thread.setDefaultUncaughtExceptionHandler(defaultHandler.maybe());
                defaultHandler = null;
            }
        }
    }

    @Override
    public void uncaughtException(
            @NonNull final Thread thread, @NonNull final Throwable throwable) {
        final StringWriter writer = new StringWriter();
        throwable.printStackTrace(new PrintWriter(writer));
        final String trace = writer.toString();
        QALogger.logCrashEvent(trace);

        synchronized (UncaughtExceptionHandler.class) {
            // 保持していたデフォルトハンドラを呼び出す
            if (defaultHandler == null) return;
            try {
                defaultHandler.unwrap().uncaughtException(thread, throwable);
            } catch (Optional.NotPresentException ignored) {
            }
        }
    }
}
