//
//  Copyright © 2026 Supership Inc. All rights reserved.
//
package jp.supership.vamp.utils;

import android.text.TextUtils;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

public class StringUtils {

    private static final String DEFAULT_ENCODING = "UTF-8";

    public static void extendRequestParam(StringBuilder sb, String s1, String s2) {
        if (sb != null && !TextUtils.isEmpty(s1)) {
            s2 = TextUtils.isEmpty(s2) ? "" : s2;
            sb.append((sb.length() == 0 ? "?" : "&")).append(s1).append("=").append(s2);
        }
    }

    /**
     * クエリ文字列をMap型に変換する
     *
     * @param query クエリ文字列
     * @return 変換したHashMap
     */
    public static Map<String, String> queryToMap(String query) {
        Map<String, String> result = new HashMap<>();
        String[] pairs = query.split("&");
        if (pairs != null && pairs.length > 0) {
            for (String pair : pairs) {
                String[] param = pair.split("=", 2);
                if (param != null && param.length == 2) {
                    result.put(param[0], param[1]);
                } else {
                    result.put(param[0], "");
                }
            }
        }
        return result;
    }

    public static String urlEncode(String value) {
        if (value == null) {
            return "";
        }
        try {
            return URLEncoder.encode(value, DEFAULT_ENCODING);
        } catch (UnsupportedEncodingException ex) {
            throw new RuntimeException(ex);
        }
    }
}
