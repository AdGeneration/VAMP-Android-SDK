//
//  Copyright © 2012-2016 Supership Inc. All rights reserved.
//
package jp.supership.vamp.core.eventbus.meta;

import jp.supership.vamp.core.eventbus.SubscriberMethod;

/**
 * Uses {@link SubscriberMethodInfo} objects to create {@link
 * jp.supership.vamp.core.eventbus.SubscriberMethod} objects on demand.
 */
public class SimpleSubscriberInfo extends AbstractSubscriberInfo {

    private final SubscriberMethodInfo[] methodInfos;

    public SimpleSubscriberInfo(
            Class subscriberClass,
            boolean shouldCheckSuperclass,
            SubscriberMethodInfo[] methodInfos) {
        super(subscriberClass, null, shouldCheckSuperclass);
        this.methodInfos = methodInfos;
    }

    @Override
    public synchronized SubscriberMethod[] getSubscriberMethods() {
        int length = methodInfos.length;
        SubscriberMethod[] methods = new SubscriberMethod[length];
        for (int i = 0; i < length; i++) {
            SubscriberMethodInfo info = methodInfos[i];
            methods[i] =
                    createSubscriberMethod(
                            info.methodName,
                            info.eventType,
                            info.threadMode,
                            info.priority,
                            info.sticky);
        }
        return methods;
    }
}
