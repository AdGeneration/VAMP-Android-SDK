//
//  Copyright © 2026 Supership Inc. All rights reserved.
//
package jp.supership.vamp.player.view;

import android.content.Context;
import android.graphics.BitmapFactory;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import java.io.IOException;
import java.io.InputStream;

/** Created by masaki.ando on 2018/07/02. */
final class CloseButton extends ImageView implements View.OnClickListener {
    interface Listener {
        void onClick();
    }

    static final String ICON_CLOSE_CIRCLE = "adgp_vamp_close.png";
    static final String ICON_CLOSE = "icon_close_white.png";

    private static final int BUTTON_SIZE = 30;

    @NonNull private final Listener listener;

    private CloseButton(
            @NonNull final Context context,
            @NonNull final String icon,
            @NonNull final Listener listener) {
        super(context);

        this.listener = listener;

        setOnClickListener(this);

        InputStream is = null;
        try {
            is = context.getResources().getAssets().open(icon);
            setImageBitmap(BitmapFactory.decodeStream(is));
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (is != null) {
                try {
                    is.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /** Viewを生成し、`parent`に追加します */
    @NonNull
    static CloseButton addTo(
            @NonNull final ViewGroup parent,
            @NonNull final Context context,
            @NonNull final String icon,
            final float density,
            final int gravity,
            @NonNull final Listener listener) {
        final CloseButton button = new CloseButton(context, icon, listener);
        final FrameLayout.LayoutParams params =
                new FrameLayout.LayoutParams(
                        (int) (BUTTON_SIZE * density), (int) (BUTTON_SIZE * density));
        params.gravity = gravity;
        parent.addView(button, params);
        return button;
    }

    @Override
    public void onClick(View v) {
        listener.onClick();
    }
}
