//
//  Copyright © 2026 Supership Inc. All rights reserved.
//
package jp.supership.vamp;

import android.content.Context;
import android.util.Log;
import androidx.annotation.NonNull;
import jp.supership.sscore.vamp.SSCoreKit;
import jp.supership.sscore.vamp.device.SSCoreAppInfoProvider;
import jp.supership.sscore.vamp.device.SSCoreDeviceProvider;
import jp.supership.sscore.vamp.rewardedad.SSCoreRewardedAdExpirationTime;
import jp.supership.sscore.vamp.rewardedad.SSCoreRewardedAdMediationTimeout;
import jp.supership.sscore.vamp.type.Optional;
import jp.supership.vamp.core.logging.LogUtils;

/** VAMP SDKの検証用ユーティリティ */
public final class VAMPDebugUtils {
    @NonNull final Optional<SSCoreRewardedAdExpirationTime> expirationTime;
    @NonNull final Optional<SSCoreRewardedAdMediationTimeout> mediationTimeout;

    @NonNull
    private static Optional<SSCoreRewardedAdExpirationTime> expirationTimeMemo = Optional.empty();

    @NonNull
    private static Optional<SSCoreRewardedAdMediationTimeout> mediationTimeoutMemo =
            Optional.empty();

    private VAMPDebugUtils(
            @NonNull final Optional<SSCoreRewardedAdExpirationTime> expirationTime,
            @NonNull final Optional<SSCoreRewardedAdMediationTimeout> mediationTimeout) {
        this.expirationTime = expirationTime;
        this.mediationTimeout = mediationTimeout;
    }

    @NonNull
    static synchronized VAMPDebugUtils newInstance() {
        return new VAMPDebugUtils(expirationTimeMemo, mediationTimeoutMemo);
    }

    /**
     * 広告のロードが完了した時点から、その広告が表示可能である期限をミリ秒で設定します
     *
     * @param time 有効期限 [ミリ秒]
     */
    public static synchronized void setExpirationTimeInMilliseconds(final long time) {
        expirationTimeMemo = Optional.of(new SSCoreRewardedAdExpirationTime(time));
    }

    /**
     * アドネットワークのロード処理のタイムアウトをミリ秒で設定します
     *
     * @param time タイムアウト [ミリ秒]
     */
    public static synchronized void setMediationTimeoutInMilliseconds(final long time) {
        mediationTimeoutMemo = Optional.of(new SSCoreRewardedAdMediationTimeout(time));
    }

    /** 検証用の設定をすべてリセットします */
    public static synchronized void reset() {
        expirationTimeMemo = Optional.empty();
        mediationTimeoutMemo = Optional.empty();
    }

    /**
     * SDKの詳細情報をログに出力します
     *
     * @param context コンテキスト
     */
    public static void logSDKDetails(@NonNull Context context) {
        final Context appContext = context.getApplicationContext();
        new SSCoreDeviceProvider(appContext)
                .provideDevice(
                        device -> {
                            new SSCoreAppInfoProvider(appContext)
                                    .provideAppInfo(
                                            appInfo -> {
                                                final StringBuilder sb = new StringBuilder();
                                                sb.append(
                                                        "----------------------------------------\n");
                                                sb.append("<SDK>\n");
                                                sb.append("VAMP: ")
                                                        .append(VAMP.SDKVersion())
                                                        .append("\n");
                                                sb.append("SSCore: ")
                                                        .append(SSCoreKit.VERSION_STRING)
                                                        .append(" debugBuild: ")
                                                        .append(SSCoreKit.DEBUG_BUILD)
                                                        .append("\n");

                                                sb.append(
                                                        AdapterVersionPrint
                                                                .getAdapterVersionsString());
                                                sb.append(
                                                        AdapterVersionPrint
                                                                .getAdNetworkVersionsString());
                                                sb.append("\n");

                                                device.data.ifPresent(
                                                        data -> {
                                                            sb.append("<Device Info>\n");
                                                            sb.append("Maker: ")
                                                                    .append(data.manufacturer)
                                                                    .append("\n");
                                                            sb.append("Model Name: ")
                                                                    .append(data.modelName)
                                                                    .append("\n");
                                                            sb.append("Brand: ")
                                                                    .append(data.brand)
                                                                    .append("\n");
                                                            sb.append("OS: ")
                                                                    .append(data.os)
                                                                    .append("\n");
                                                            sb.append("OS Version: ")
                                                                    .append(data.osVersion)
                                                                    .append("\n");
                                                            sb.append("API Level: ")
                                                                    .append(data.apiLevel)
                                                                    .append("\n");
                                                            sb.append("Architecture: ")
                                                                    .append(data.architecture)
                                                                    .append(" ")
                                                                    .append(data.bitness)
                                                                    .append("bit\n");
                                                            sb.append("Network Type: ")
                                                                    .append(data.networkType)
                                                                    .append("\n");
                                                            sb.append("Carrier Name: ")
                                                                    .append(data.carrierName)
                                                                    .append("\n");
                                                            sb.append("Carrier Number: ")
                                                                    .append(data.carrierNumber)
                                                                    .append("\n");
                                                            sb.append("ISO Country Code: ")
                                                                    .append(data.isoCountryCode)
                                                                    .append("\n");
                                                            sb.append("Language: ")
                                                                    .append(data.language)
                                                                    .append("\n");
                                                            sb.append("Locale: ")
                                                                    .append(data.locale)
                                                                    .append("\n");
                                                            sb.append("TZ: ")
                                                                    .append(data.timeZone)
                                                                    .append("\n");
                                                            sb.append("Screen Size (dp): ")
                                                                    .append(data.screenWidthInDp)
                                                                    .append("x")
                                                                    .append(data.screenHeightInDp)
                                                                    .append("\n");
                                                            sb.append("Screen Size (px): ")
                                                                    .append(
                                                                            data.screenWidthInPixels)
                                                                    .append("x")
                                                                    .append(
                                                                            data.screenHeightInPixels)
                                                                    .append("\n");
                                                            sb.append("Density: ")
                                                                    .append(data.density)
                                                                    .append("\n");
                                                            data.orientation.ifPresent(
                                                                    orientation -> {
                                                                        sb.append("Orientation: ")
                                                                                .append(orientation)
                                                                                .append("\n");
                                                                    });
                                                            sb.append("\n");
                                                        });

                                                appInfo.data.ifPresent(
                                                        data -> {
                                                            sb.append("<App Info>\n");
                                                            sb.append("App ID: ")
                                                                    .append(data.appId)
                                                                    .append("\n");
                                                            sb.append("App Name: ")
                                                                    .append(data.appName)
                                                                    .append("\n");
                                                            sb.append("App Version: ")
                                                                    .append(data.appVersion)
                                                                    .append("\n");
                                                            sb.append("App Version Code: ")
                                                                    .append(data.buildNumber)
                                                                    .append("\n");
                                                            sb.append("\n");
                                                        });

                                                sb.append("<Current Settings>\n");
                                                sb.append("Child Directed: ")
                                                        .append(
                                                                VAMPPrivacySettings
                                                                        .getChildDirected())
                                                        .append("\n");
                                                sb.append("Under Age of Consent: ")
                                                        .append(
                                                                VAMPPrivacySettings
                                                                        .getUnderAgeOfConsent())
                                                        .append("\n");
                                                sb.append("Consent Status: ")
                                                        .append(
                                                                VAMPPrivacySettings
                                                                        .getConsentStatus())
                                                        .append("\n");
                                                sb.append("Debug Mode: ")
                                                        .append(VAMP.isDebugMode())
                                                        .append("\n");
                                                sb.append("Test Mode: ")
                                                        .append(VAMP.isTestMode())
                                                        .append("\n");
                                                if (BuildConfig.DEV_SERVER) {
                                                    sb.append("Staging: ON\n");
                                                }
                                                if (BuildConfig.DEV_LOG) {
                                                    sb.append("VAMP Development Log: ON\n");
                                                }
                                                sb.append(
                                                        "----------------------------------------");
                                                Log.d(LogUtils.TAG, sb.toString());
                                            });
                        });
    }
}
