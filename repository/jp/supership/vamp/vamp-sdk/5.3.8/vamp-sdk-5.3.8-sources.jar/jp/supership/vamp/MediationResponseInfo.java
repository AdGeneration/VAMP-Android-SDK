//
//  Copyright © 2026 Supership Inc. All rights reserved.
//
package jp.supership.vamp;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;
import jp.supership.sscore.vamp.rewardedad.SSCoreRewardedAdMediationResponseInfo;
import jp.supership.sscore.vamp.rewardedad.SSCoreRewardedAdResponseInfo;
import jp.supership.sscore.vamp.type.Optional;

final class MediationResponseInfo implements VAMPResponseInfo {
    static class Builder {
        @NonNull private Optional<String> adNetworkName = Optional.empty();
        @NonNull private Optional<String> seqId = Optional.empty();

        @NonNull
        private Optional<ArrayList<AdapterResponseInfo>> adapterResponseList = Optional.empty();

        @NonNull
        Builder withAdNetworkName(@Nullable final String name) {
            adNetworkName = Optional.of(name);
            return this;
        }

        @NonNull
        Builder withSeqId(@Nullable final String seqId) {
            this.seqId = Optional.of(seqId);
            return this;
        }

        @NonNull
        Builder withAdapterResponseList(@Nullable final ArrayList<AdapterResponseInfo> list) {
            adapterResponseList = Optional.of(list);
            return this;
        }

        @NonNull
        MediationResponseInfo build() {
            final ArrayList<AdapterResponseInfo> adapterResponseInfos =
                    adapterResponseList.orElse(new ArrayList<>());

            final List<SSCoreRewardedAdMediationResponseInfo> infos = new ArrayList<>();
            for (AdapterResponseInfo info : adapterResponseInfos) {
                infos.add(info.getDelegate());
            }

            return new MediationResponseInfo(
                    new SSCoreRewardedAdResponseInfo(
                            seqId.maybe(), adNetworkName.orElse(""), infos),
                    adapterResponseInfos);
        }
    }

    @NonNull private final SSCoreRewardedAdResponseInfo delegate;

    /**
     * Builderが既に保持しているラップ済みのリスト。delegate.getAdapterResponseInfos()から
     * 都度再ラップし直す必要がないよう、Builder.build()から直接受け取ります
     */
    @NonNull private final ArrayList<VAMPAdapterResponseInfo> adapterResponseInfos;

    private MediationResponseInfo(
            @NonNull final SSCoreRewardedAdResponseInfo delegate,
            @NonNull final ArrayList<AdapterResponseInfo> adapterResponseInfos) {
        this.delegate = delegate;
        this.adapterResponseInfos = new ArrayList<>(adapterResponseInfos);
    }

    @Nullable
    @Override
    public String getSeqID() {
        return delegate.getSeqID();
    }

    @NonNull
    @Override
    public String getAdNetworkName() {
        final String adNetworkName = delegate.getAdNetworkName();
        return adNetworkName != null ? adNetworkName : "";
    }

    @NonNull
    @Override
    public ArrayList<VAMPAdapterResponseInfo> getAdapterResponseInfos() {
        // 呼び出し元が変更しても内部状態に影響しないよう、都度コピーを返します
        return new ArrayList<>(adapterResponseInfos);
    }

    @NonNull
    @Override
    public String toString() {
        return delegate.toString();
    }
}
