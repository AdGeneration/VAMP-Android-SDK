//
//  Copyright © 2026 Supership Inc. All rights reserved.
//
package jp.supership.vamp.player.view;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import androidx.annotation.NonNull;

public final class FullScreenContentView extends FrameLayout {
    @NonNull public final FrameLayout adView;

    private FullScreenContentView(@NonNull Context context) {
        super(context);

        setMotionEventSplittingEnabled(false);
        setBackgroundColor(Color.BLACK);

        adView = new FrameLayout(context);
        adView.setLayerType(LAYER_TYPE_HARDWARE, null);
        adView.setDescendantFocusability(FOCUS_BLOCK_DESCENDANTS);
        addView(adView, layoutParamsOfFullScreenContent());
    }

    /** Viewを生成し、`activity.setContentView`メソッドに引数として渡します */
    @NonNull
    public static FullScreenContentView setToActivity(@NonNull Activity activity) {
        final FullScreenContentView view = new FullScreenContentView(activity);
        activity.setContentView(view, layoutParamsOfFullScreenContent());
        return view;
    }

    public void setPlayerView(@NonNull final View view) {
        adView.addView(view, layoutParamsOfFullScreenContent());
    }

    public void destroy() {
        ViewUtils.clearChild(this);
    }

    @NonNull
    private static LayoutParams layoutParamsOfFullScreenContent() {
        final LayoutParams params =
                new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
        params.gravity = Gravity.CENTER;
        return params;
    }
}
