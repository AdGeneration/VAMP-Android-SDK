//
//  Copyright © 2026 Supership Inc. All rights reserved.
//
package jp.supership.vamp.core.vast;

public class VASTError {
    private Code code;
    private int internalCode;
    private String message;

    public enum Code {
        NETWORK_ERROR,
        XML_PARSE_ERROR,
        IO_ERROR
    }

    public VASTError(Code code) {
        this(code, "", 0);
    }

    public VASTError(Code code, String message) {
        this(code, message, 0);
    }

    public VASTError(Code code, String message, int internalCode) {
        this.code = code;
        this.message = message;
        this.internalCode = internalCode;
    }

    public Code getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }

    public int getInternalCode() {
        return internalCode;
    }
}
