//
//  Copyright © 2026 Supership Inc. All rights reserved.
//
package jp.supership.vamp.player.view;

import android.annotation.TargetApi;
import android.content.Context;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Build;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.List;
import jp.supership.sscore.vamp.type.Optional;
import jp.supership.vamp.core.logging.LogUtils;
import jp.supership.vamp.player.ExternalAppLauncher;
import jp.supership.vamp.player.LandingPage;
import jp.supership.vamp.utils.LocaleUtils;

/**
 * LP表示用WebViewエンドカード
 *
 * <p>Created by masaki.ando on 2022/11/14.
 */
final class EndCardWebView extends LinearLayout implements EndCardViewInterface {
    interface Listener {
        void onClose();

        void onMenuItemClick(int itemId);
    }

    static final int MENU_ITEM_RELOAD = 0;
    static final int MENU_ITEM_LINK_COPY = 1;
    static final int MENU_ITEM_OPEN_ANOTHER_APP = 2;

    @NonNull private final TitleView titleView;
    @NonNull private final WebView webView;

    private EndCardWebView(@NonNull final Context context, @NonNull final Listener listener) {
        super(context);

        setBackgroundColor(Color.WHITE);
        setOrientation(VERTICAL);

        titleView = new TitleView(context, listener);
        addView(titleView, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));

        webView = new WebView(context);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        webView.setFocusable(true);
        webView.requestFocus();
        webView.setWebViewClient(
                new WebViewClient() {
                    @TargetApi(Build.VERSION_CODES.N)
                    @Override
                    public boolean shouldOverrideUrlLoading(
                            WebView view, WebResourceRequest request) {
                        final String url = request.getUrl().toString();

                        titleView.setTitle("");
                        titleView.setSubtitle(url);

                        if (shouldOpenExternalApp(url)) {
                            return true;
                        }

                        return super.shouldOverrideUrlLoading(view, request);
                    }

                    @Override
                    public boolean shouldOverrideUrlLoading(WebView view, String url) {
                        titleView.setTitle("");
                        titleView.setSubtitle(url);

                        if (shouldOpenExternalApp(url)) {
                            return true;
                        }

                        return super.shouldOverrideUrlLoading(view, url);
                    }

                    private boolean shouldOpenExternalApp(@Nullable final String url) {
                        try {
                            final LandingPage lp = new LandingPage(url);
                            if (!lp.isWebContent()) {
                                ExternalAppLauncher.startApp(context, lp);
                                return true;
                            }
                            // WebコンテンツのときはこのままWebViewで開く
                        } catch (LandingPage.CanNotInstantiateException
                                | ExternalAppLauncher.NotLaunchException e) {
                            LogUtils.e(e.toString());
                        }

                        return false;
                    }
                });
        webView.setWebChromeClient(
                new WebChromeClient() {
                    @Override
                    public void onReceivedTitle(WebView view, String title) {
                        super.onReceivedTitle(view, title);
                        titleView.setTitle(title);
                    }
                });
        addView(webView, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
    }

    /** Viewを生成し、`parent`に追加します。生成できない場合はOptional.empty()を返します */
    @NonNull
    static Optional<EndCardWebView> addTo(
            @NonNull final ViewGroup parent,
            @NonNull final Context context,
            @NonNull final Optional<LandingPage> landingPage,
            @NonNull final Listener listener) {
        final LandingPage lp;
        try {
            lp = landingPage.unwrap();
        } catch (Optional.NotPresentException e) {
            return Optional.empty();
        }

        if (!lp.isWebContent()) {
            return Optional.empty();
        }

        final EndCardWebView webView = new EndCardWebView(context, listener);
        final LayoutParams params =
                new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
        params.gravity = Gravity.CENTER;
        parent.addView(webView, params);

        webView.loadUrl(lp.url);

        return Optional.of(webView);
    }

    /**
     * @return WebViewで現在開いているページのURLを返します
     */
    @NonNull
    String getCurrentPage() {
        return webView.getUrl();
    }

    private void loadUrl(@NonNull final String url) {
        titleView.setTitle("");
        titleView.setSubtitle(url);
        webView.loadUrl(url);
    }

    void reload() {
        webView.reload();
    }

    @Override
    public void show() {
        setVisibility(VISIBLE);
    }

    @Override
    public void hide() {
        setVisibility(INVISIBLE);
    }

    @Override
    public void destroy() {
        webView.stopLoading();
        webView.destroy();
        ViewUtils.clearChild(this);
    }

    @NonNull
    @Override
    public Optional<WebView> getWebView() {
        return Optional.of(webView);
    }

    private static final class TitleView extends LinearLayout {

        private static final List<String> OPTION_MENU_TITLES_JP =
                Arrays.asList("リロード", "リンクをコピー", "他のアプリで開く");
        private static final List<String> OPTION_MENU_TITLES_EN =
                Arrays.asList("Reload", "Copy link", "Open in another app");
        private static final int VIEW_HEIGHT = 48;
        private static final int TITLE_TEXT_SIZE = 15;
        private static final int SUBTITLE_TEXT_SIZE = 12;

        @NonNull private final TextView titleTextView;
        @NonNull private final TextView subtitleTextView;
        private final int viewHeight;
        @NonNull private final Listener listener;

        TitleView(@NonNull final Context context, @NonNull final Listener listener) {
            super(context);

            this.listener = listener;

            setBackgroundColor(Color.BLACK);
            setOrientation(HORIZONTAL);
            setGravity(Gravity.CENTER_VERTICAL);

            final DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
            final float density = displayMetrics.density;
            viewHeight = (int) Math.floor(VIEW_HEIGHT * density);

            MenuButton.addTo(
                    this,
                    context,
                    density,
                    new OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            popupMenu(v);
                        }
                    });

            final LinearLayout titleContainer = new LinearLayout(context);
            titleContainer.setOrientation(VERTICAL);
            final LayoutParams layoutParamsOfTitleContainer =
                    new LayoutParams(0, LayoutParams.WRAP_CONTENT);
            layoutParamsOfTitleContainer.weight = 1;
            layoutParamsOfTitleContainer.leftMargin = 24;
            addView(titleContainer, layoutParamsOfTitleContainer);

            titleTextView = createTitleTextView(context, TITLE_TEXT_SIZE);
            titleTextView.setVisibility(GONE);
            titleContainer.addView(titleTextView);

            subtitleTextView = createTitleTextView(context, SUBTITLE_TEXT_SIZE);
            subtitleTextView.setVisibility(GONE);
            titleContainer.addView(subtitleTextView);

            CloseButton.addTo(
                    this,
                    context,
                    CloseButton.ICON_CLOSE,
                    density,
                    Gravity.CENTER,
                    new CloseButton.Listener() {
                        @Override
                        public void onClick() {
                            listener.onClose();
                        }
                    });
        }

        @Override
        protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
            super.onMeasure(widthMeasureSpec, heightMeasureSpec);
            setMeasuredDimension(widthMeasureSpec, viewHeight);
        }

        void setTitle(@Nullable final String title) {
            if (!TextUtils.isEmpty(title)) {
                titleTextView.setText(title);
                titleTextView.setVisibility(VISIBLE);
            } else {
                titleTextView.setText("");
                titleTextView.setVisibility(GONE);
            }
        }

        void setSubtitle(@Nullable final String title) {
            if (!TextUtils.isEmpty(title)) {
                subtitleTextView.setText(title);
                subtitleTextView.setVisibility(VISIBLE);
            } else {
                subtitleTextView.setText("");
                subtitleTextView.setVisibility(GONE);
            }
        }

        private void popupMenu(View v) {
            PopupMenu popup = new PopupMenu(getContext(), v);
            Menu menu = popup.getMenu();
            final List<String> titles =
                    LocaleUtils.isJapanese() ? OPTION_MENU_TITLES_JP : OPTION_MENU_TITLES_EN;
            for (int i = 0; i < titles.size(); i++) {
                menu.add(0, i, Menu.NONE, titles.get(i));
            }
            popup.setOnMenuItemClickListener(
                    new PopupMenu.OnMenuItemClickListener() {
                        @Override
                        public boolean onMenuItemClick(MenuItem item) {
                            listener.onMenuItemClick(item.getItemId());
                            return true;
                        }
                    });
            popup.show();
        }

        @NonNull
        private static TextView createTitleTextView(
                @NonNull final Context context, final int textSize) {
            TextView view = new TextView(context);
            view.setTextColor(Color.WHITE);
            view.setTextSize(TypedValue.COMPLEX_UNIT_DIP, textSize);
            view.setSingleLine();
            view.setEllipsize(TextUtils.TruncateAt.END);
            return view;
        }
    }

    private static final class MenuButton extends ImageView {
        private static final int BUTTON_SIZE = 30;

        private MenuButton(
                @NonNull final Context context, @NonNull final OnClickListener listener) {
            super(context);

            setOnClickListener(listener);

            InputStream is = null;
            try {
                is = context.getResources().getAssets().open("icon_menu_white.png");
                setImageBitmap(BitmapFactory.decodeStream(is));
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                if (is != null) {
                    try {
                        is.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }

        /** Viewを生成し、`parent`に追加します */
        static void addTo(
                @NonNull final ViewGroup parent,
                @NonNull final Context context,
                final float density,
                @NonNull final OnClickListener listener) {
            final MenuButton button = new MenuButton(context, listener);
            final LayoutParams params =
                    new LayoutParams((int) (BUTTON_SIZE * density), (int) (BUTTON_SIZE * density));
            parent.addView(button, params);
        }
    }
}
