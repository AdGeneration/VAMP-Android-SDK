//
//  Copyright © 2026 Supership Inc. All rights reserved.
//
package jp.supership.vamp;

import androidx.annotation.Nullable;
import java.util.Collections;
import java.util.List;
import jp.supership.sscore.vamp.rewardedad.SSCoreAdNetworkNames;
import jp.supership.vamp.core.logging.LogUtils;
import jp.supership.vamp.mediation.Adapter;

final class AdapterVersionPrint {
    @Nullable private static String adapterVersionsString;
    @Nullable private static String adNetworkVersionsString;

    private AdapterVersionPrint() {}

    /**
     * インポートされているアダプタのバージョン番号一覧を取得します
     *
     * @return アダプタのバージョン番号一覧
     */
    static synchronized String getAdapterVersionsString() {
        if (adapterVersionsString == null) {
            final AdapterProvider adapterProvider = new AdapterProvider();

            final List<String> names = SSCoreAdNetworkNames.getAdNetworkNames();
            Collections.sort(names, String.CASE_INSENSITIVE_ORDER);

            final StringBuilder sb = new StringBuilder("\n");
            for (String name : names) {
                try {
                    final Adapter adapter = adapterProvider.getAdapter(name);
                    if (adapter == null) continue;

                    final String[] comps = adapter.getClass().getName().split("\\.");
                    final String className = comps[comps.length - 1];

                    sb.append(className)
                            .append(": ")
                            .append(adapter.getAdapterVersion())
                            .append("\n");
                } catch (Exception ignored) {
                }
            }

            adapterVersionsString = sb.toString();
        }

        return adapterVersionsString;
    }

    /**
     * インポートされているアドネットワークSDKのバージョン番号一覧を取得します
     *
     * @return アドネットワークSDKのバージョン番号一覧
     */
    static synchronized String getAdNetworkVersionsString() {
        if (adNetworkVersionsString == null) {
            final AdapterProvider adapterProvider = new AdapterProvider();

            final List<String> names = SSCoreAdNetworkNames.getAdNetworkNames();
            Collections.sort(names, String.CASE_INSENSITIVE_ORDER);

            final StringBuilder sb = new StringBuilder("\n");
            for (String name : names) {
                try {
                    final Adapter adapter = adapterProvider.getAdapter(name);
                    if (adapter == null) continue;

                    sb.append(name).append(": ").append(adapter.getAdNetworkVersion()).append("\n");
                } catch (Exception ignored) {
                }
            }

            adNetworkVersionsString = sb.toString();
        }

        return adNetworkVersionsString;
    }

    /** インポートされているアダプタのバージョン番号一覧をLogcatに出力します */
    static void printList() {
        LogUtils.d(getAdapterVersionsString() + getAdNetworkVersionsString());
    }
}
