//
//  Copyright © 2026 Supership Inc. All rights reserved.
//
package jp.supership.vamp.core.vast;

import android.text.TextUtils;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import java.io.Serializable;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import jp.supership.sscore.vamp.http.SSCoreHttp;
import jp.supership.sscore.vamp.http.SSCoreHttpClient;
import jp.supership.sscore.vamp.http.SSCoreHttpRequest;
import jp.supership.vamp.core.error.VAMPInternalError;
import jp.supership.vamp.core.logging.LogUtils;
import jp.supership.vamp.core.utils.Strings;

public class VASTTracking implements Serializable {
    @NonNull public final String event;
    @NonNull public final URL url;
    @Nullable public final String offset;
    private final long timeMilliSec;
    private final float percentage;
    private int count;

    private static final int VAMP_VAST_TRACKING_INVALID_VALUE = -1;

    public VASTTracking(@NonNull final String event, @NonNull final URL url) {
        this(event, url, null);
    }

    public VASTTracking(
            @NonNull final String event, @NonNull final URL url, @Nullable final String offset) {
        this(event, url, offset, 0);
    }

    public VASTTracking(
            @NonNull final String event,
            @NonNull final URL url,
            @Nullable final String offset,
            int count) {
        LogUtils.devLog("VASTTracking(" + event + ", " + url + ", " + offset + ", " + count + ")");
        this.event = event;
        this.url = url;
        this.offset = offset;
        this.count = count;

        int time = VAMP_VAST_TRACKING_INVALID_VALUE;
        float per = VAMP_VAST_TRACKING_INVALID_VALUE;
        if (!TextUtils.isEmpty(offset)) {
            assert offset != null;
            try {
                if (Strings.isAbsoluteTracker(offset)) {
                    Integer t = Strings.parseAbsoluteOffset(offset);
                    if (t != null) {
                        time = t;
                    }
                }

                if (Strings.isPercentageTracker(offset)) {
                    per = Float.parseFloat(offset.replace("%", ""));
                }
            } catch (Exception e) {
                LogUtils.e("VASTTracking#offset parse error");
            }
        }
        timeMilliSec = time;
        percentage = per;

        LogUtils.devLog("timeMilliSec:" + timeMilliSec + " percentage:" + percentage);
    }

    public boolean reachedTime(long currentTimeMilliSec, float currentPercentage) {
        return (timeMilliSec != VAMP_VAST_TRACKING_INVALID_VALUE
                        && currentTimeMilliSec >= timeMilliSec)
                || (this.percentage != VAMP_VAST_TRACKING_INVALID_VALUE
                        && currentPercentage >= this.percentage);
    }

    public void send(
            @Nullable Map<String, String> headers,
            @Nullable final VASTObject.VASTEventListener listener) {
        send(SSCoreHttp.newClient(), headers, listener);
    }

    public boolean isDone() {
        return false;
    }

    public int getCount() {
        return count;
    }

    void send(
            @NonNull SSCoreHttpClient httpClient,
            @Nullable Map<String, String> headers,
            @Nullable final VASTObject.VASTEventListener listener) {
        if (isDone()) {
            LogUtils.d("Already done. " + event);
            return;
        }

        count++;

        LogUtils.devLog("send " + event + " event.");

        if (headers == null) {
            headers = new HashMap<>();
        }

        SSCoreHttpRequest httpRequest;
        try {
            httpRequest =
                    new SSCoreHttpRequest.Builder(url.toString())
                            .withMethod(SSCoreHttpRequest.Method.GET)
                            .withHeaders(new SSCoreHttpRequest.Headers(headers))
                            .build();
        } catch (MalformedURLException | SSCoreHttpRequest.InvalidRequestParameterException e) {
            LogUtils.devLog("send " + event + " failed. url:" + url + " message:" + e.getMessage());
            return;
        }

        httpClient.request(
                httpRequest,
                result -> {
                    if (result.isSuccess()) {
                        if (listener != null) {
                            listener.onComplete(url, null);
                        }
                    } else {
                        final String errorMessage =
                                result.error.map(Throwable::getMessage).orElse("Unknown error");

                        final int statusCodeMessage =
                                result.data.map(response -> response.statusCode).orElse(0);

                        final String message = statusCodeMessage + ", " + errorMessage;

                        if (listener != null) {
                            listener.onComplete(
                                    url,
                                    new VAMPInternalError(
                                            VAMPInternalError.Code.NETWORK_ERROR, message));
                        }

                        LogUtils.devLog(
                                "send " + event + " failed. url:" + url + " message:" + message);
                    }
                });
    }
}
