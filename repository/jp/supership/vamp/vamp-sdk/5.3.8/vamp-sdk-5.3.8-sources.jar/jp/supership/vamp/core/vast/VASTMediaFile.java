//
//  Copyright © 2026 Supership Inc. All rights reserved.
//
package jp.supership.vamp.core.vast;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import java.io.Serializable;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Arrays;
import java.util.List;
import jp.supership.sscore.vamp.cache.SSCoreFileCache;
import jp.supership.sscore.vamp.cache.SSCoreFileCacheException;
import jp.supership.sscore.vamp.http.SSCoreHttp;
import jp.supership.sscore.vamp.http.SSCoreHttpClient;
import jp.supership.sscore.vamp.http.SSCoreHttpRequest;
import jp.supership.sscore.vamp.http.SSCoreHttpResponse;
import jp.supership.sscore.vamp.type.Optional;
import jp.supership.vamp.core.error.VAMPInternalError;
import jp.supership.vamp.core.logging.LogUtils;

public final class VASTMediaFile implements Serializable {
    public interface ILoadListener {
        void onCompleted(
                @NonNull Optional<String> videoFileUrl, @NonNull Optional<VAMPInternalError> error);
    }

    public interface ILoadOrFallbackListener {
        void onCompleted(@NonNull String videoFileOrNetworkUrl);
    }

    /** インスタンスを生成できません。詳細はmessageを参照してください */
    public static final class CanNotInstantiateException extends Exception {
        CanNotInstantiateException(String message) {
            super(message);
        }
    }

    /** 単位: MB */
    private static final int MAX_VIDEO_SIZE = 25 * 1024 * 1024;

    /** 単位: 秒 */
    private static final int REQUEST_CONNECTION_TIMEOUT = 5;

    /** 単位: 秒 */
    private static final int REQUEST_READ_TIMEOUT = 300;

    @NonNull public final String networkUrl;
    @Nullable public final String delivery;
    @NonNull public final String mimeType;
    public final int bitrate;
    public final int width;
    public final int height;

    private static final List<String> VIDEO_MIME_TYPES = Arrays.asList("video/mp4", "video/3gpp");

    VASTMediaFile(
            @NonNull final String networkUrl,
            @Nullable final String delivery,
            @Nullable final String mimeType,
            final int bitrate,
            final int width,
            final int height)
            throws CanNotInstantiateException {
        try {
            new URL(networkUrl);
        } catch (MalformedURLException e) {
            throw new CanNotInstantiateException(e.toString());
        }

        if (mimeType == null) {
            throw new CanNotInstantiateException("mimeType is null.");
        } else if (!VIDEO_MIME_TYPES.contains(mimeType)) {
            throw new CanNotInstantiateException("Unsupported mime type: " + mimeType);
        }

        if (width <= 0) {
            throw new CanNotInstantiateException("Illegal size. width must be greater than 0.");
        }

        if (height <= 0) {
            throw new CanNotInstantiateException("Illegal size. height must be greater than 0.");
        }

        if (!VideoAnalyzer.getAnalyzer().isSupportedSize(width, height)) {
            throw new CanNotInstantiateException("Unsupported size: w=" + width + " h=" + height);
        }

        this.networkUrl = networkUrl;
        this.delivery = delivery;
        this.mimeType = mimeType;
        this.bitrate = bitrate;
        this.width = width;
        this.height = height;
    }

    public boolean isLoaded(Context context) {
        try {
            return SSCoreFileCache.getInstance(context).cachedDataExists(networkUrl);
        } catch (SSCoreFileCacheException e) {
            LogUtils.devLog(e.getMessage());
            return false;
        }
    }

    public void loadMediaFile(
            @NonNull final Context context, @Nullable final VASTMediaFile.ILoadListener listener) {
        LogUtils.devLog("videoFileUrl(network): " + networkUrl);

        final String key = networkUrl;

        try {
            if (isLoaded(context)) {
                LogUtils.devLog("The media file is already loaded.");
                String path = SSCoreFileCache.getInstance(context).retrieveFilePath(key);
                if (listener != null) {
                    listener.onCompleted(Optional.of(path), Optional.<VAMPInternalError>empty());
                }
                return;
            }
        } catch (SSCoreFileCacheException e) {
            LogUtils.devLog(e.getMessage());
        }

        SSCoreHttpRequest httpRequest;
        try {
            httpRequest =
                    new SSCoreHttpRequest.Builder(networkUrl)
                            .withMethod(SSCoreHttpRequest.Method.GET)
                            .withReadTimeout(
                                    SSCoreHttpRequest.Timeout.inSeconds(REQUEST_READ_TIMEOUT))
                            .withConnectTimeout(
                                    SSCoreHttpRequest.Timeout.inSeconds(REQUEST_CONNECTION_TIMEOUT))
                            .build();
        } catch (MalformedURLException | SSCoreHttpRequest.InvalidRequestParameterException e) {
            if (listener != null) {
                listener.onCompleted(
                        Optional.empty(),
                        Optional.of(
                                new VAMPInternalError(
                                        VAMPInternalError.Code.UNKNOWN,
                                        "error: " + e.getMessage())));
            }
            return;
        }

        // TODO: httpClientを外から渡せるようにする
        final SSCoreHttpClient httpClient = SSCoreHttp.newClient();
        httpClient.request(
                httpRequest,
                result -> {
                    if (!result.isSuccess()) {
                        final String errorMessage =
                                result.error.map(Throwable::getMessage).orElse("Unknown error");

                        if (listener != null) {
                            listener.onCompleted(
                                    Optional.empty(),
                                    Optional.of(
                                            new VAMPInternalError(
                                                    VAMPInternalError.Code.NETWORK_ERROR,
                                                    "error: " + errorMessage)));
                        }
                        return;
                    }

                    try {
                        final SSCoreHttpResponse response = result.data.unwrap();
                        final byte[] responseBody = response.readData().unwrap();

                        if (responseBody.length == 0) {
                            if (listener != null) {
                                listener.onCompleted(
                                        Optional.empty(),
                                        Optional.of(
                                                new VAMPInternalError(
                                                        VAMPInternalError.Code.NETWORK_ERROR,
                                                        response.statusCode
                                                                + " Response body is empty.")));
                            }
                            return;
                        }

                        if (responseBody.length > MAX_VIDEO_SIZE) {
                            if (listener != null) {
                                listener.onCompleted(
                                        Optional.<String>empty(),
                                        Optional.of(
                                                new VAMPInternalError(
                                                        VAMPInternalError.Code.EXCEED_FILE_SIZE,
                                                        "Video exceeded max download size.")));
                            }
                            return;
                        }

                        SSCoreFileCache cache = SSCoreFileCache.getInstance(context);
                        cache.store(responseBody, key);

                        String videoFileUrl = cache.retrieveFilePath(key);

                        LogUtils.devLog("videoFileUrl(local): " + videoFileUrl);

                        if (listener != null) {
                            listener.onCompleted(Optional.of(videoFileUrl), Optional.empty());
                        }
                    } catch (SSCoreFileCacheException e) {
                        if (listener != null) {
                            listener.onCompleted(
                                    Optional.empty(),
                                    Optional.of(
                                            new VAMPInternalError(
                                                    VAMPInternalError.Code.FILE_NOT_FOUND,
                                                    "The media file is not supported.")));
                        }
                    } catch (Optional.NotPresentException e) {
                        LogUtils.devLog(e.getMessage());
                        if (listener != null) {
                            listener.onCompleted(
                                    Optional.empty(),
                                    Optional.of(
                                            new VAMPInternalError(
                                                    VAMPInternalError.Code.UNKNOWN,
                                                    e.getMessage())));
                        }
                    }
                });
    }

    public void loadMediaFileOrFallback(
            @NonNull final Context context, @Nullable final ILoadOrFallbackListener listener) {
        loadMediaFile(
                context,
                new ILoadListener() {
                    @Override
                    public void onCompleted(
                            Optional<String> videoFileUrl, Optional<VAMPInternalError> error) {
                        String url = videoFileUrl.orElse(networkUrl);
                        try {
                            LogUtils.devLog(error.unwrap().message);
                        } catch (Optional.NotPresentException ignored) {
                        }

                        if (listener != null) {
                            listener.onCompleted(url);
                        }
                    }
                });
    }
}
