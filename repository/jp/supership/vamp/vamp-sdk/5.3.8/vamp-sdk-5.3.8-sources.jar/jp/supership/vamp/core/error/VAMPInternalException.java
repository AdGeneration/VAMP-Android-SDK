//
//  Copyright © 2026 Supership Inc. All rights reserved.
//
package jp.supership.vamp.core.error;

import androidx.annotation.NonNull;

/** VAMPInternalErrorをExceptionとして扱うためのクラスです */
public class VAMPInternalException extends Exception {
    /** エラーコード */
    @NonNull public final VAMPInternalError error;

    public VAMPInternalException(@NonNull final VAMPInternalError error) {
        super(error.message);
        this.error = error;
    }

    @NonNull
    public static VAMPInternalException fileNotFound(String message) {
        return new VAMPInternalException(
                new VAMPInternalError(VAMPInternalError.Code.FILE_NOT_FOUND, message));
    }
}
