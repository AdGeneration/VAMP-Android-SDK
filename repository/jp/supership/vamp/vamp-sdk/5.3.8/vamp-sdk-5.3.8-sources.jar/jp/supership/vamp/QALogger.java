//
//  Copyright © 2026 Supership Inc. All rights reserved.
//
package jp.supership.vamp;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.text.TextUtils;
import android.util.Log;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import jp.supership.vamp.core.utils.VAMPMap;

/** このクラスは、自動テスト用ログ出力クラスです */
final class QALogger {
    private static final String QATEST_LOAD = "[LOAD]";
    private static final String QATEST_WEIGHT = "[WEIGHT]";
    private static final String QATEST_RECEIVE = "[RECEIVE]";
    private static final String QATEST_SHOW = "[SHOW]";
    private static final String QATEST_COMPLETE = "[COMPLETE]";
    private static final String QATEST_CLOSE = "[CLOSE]";
    private static final String QATEST_ADNW_FAIL = "[ADNW FAIL]";
    private static final String QATEST_FAIL = "[FAIL]";
    private static final String QATEST_CRASH = "[CRASH]";
    private static final String QATEST_VAST = "[VAST]";
    private static final String QATEST_MOVIE = "[MOVIE]";

    private static final String TAG = "VAMPSDK";
    private static final String QATEST_TAG = "[QA]";
    private static final String QATEST_ENABLE = "vamp_qatest_enable";

    private static final AtomicBoolean testMode = new AtomicBoolean(false);

    static void setQATestMode(@NonNull final Context appContext) {
        // Reset
        testMode.set(false);

        try {
            final PackageManager pm = appContext.getPackageManager();
            final String packageName = appContext.getPackageName();
            final ApplicationInfo appInfo =
                    pm.getApplicationInfo(packageName, PackageManager.GET_META_DATA);

            if (appInfo.metaData.containsKey(QATEST_ENABLE)) {
                // AndroidManifest.xmlでvamp_qatest_enableがtrueに設定されていれば
                // 自動テスト用ログを有効にする
                testMode.set(appInfo.metaData.getBoolean(QATEST_ENABLE));
            }
        } catch (Exception ignored) {
        }
    }

    static void logLoadEvent(@NonNull final String placementId) {
        if (!BuildConfig.DEV_LOG) {
            return;
        }

        log(
                QATEST_LOAD,
                new VAMPMap()
                        .add("placementId", placementId)
                        .add("testmode", Boolean.toString(VAMP.isTestMode()))
                        .add("ver", VAMP.SDKVersion()));
    }

    static void logWeightEvent(@NonNull final List<String> adNetworkNames) {
        log(QATEST_WEIGHT, new VAMPMap().add("adnw", String.join(",", adNetworkNames)));
    }

    static void logReceiveEvent(@NonNull final String adNetworkName) {
        if (!BuildConfig.DEV_LOG) {
            return;
        }

        log(QATEST_RECEIVE, new VAMPMap().add("adnw", adNetworkName));
    }

    static void logShowEvent(@NonNull final String adNetworkName) {
        if (!BuildConfig.DEV_LOG) {
            return;
        }

        log(QATEST_SHOW, new VAMPMap().add("adnw", adNetworkName));
    }

    static void logCompleteEvent(@NonNull final String adNetworkName) {
        if (!BuildConfig.DEV_LOG) {
            return;
        }

        log(QATEST_COMPLETE, new VAMPMap().add("adnw", adNetworkName));
    }

    static void logCloseEvent(@NonNull final String adNetworkName) {
        if (!BuildConfig.DEV_LOG) {
            return;
        }

        log(QATEST_CLOSE, new VAMPMap().add("adnw", adNetworkName));
    }

    static void logAdNetworkFailEvent(
            @NonNull final String adNetworkName,
            @NonNull final VAMPError error,
            @Nullable final String detailMessage) {
        if (!BuildConfig.DEV_LOG) {
            return;
        }

        final VAMPMap args = new VAMPMap().add("adnw", adNetworkName).add("code", error.name());

        if (error == VAMPError.NO_ADSTOCK) {
            args.add("msg", "NoFill");
        } else if (!TextUtils.isEmpty(detailMessage)) {
            args.add("msg", detailMessage);
        }

        log(QATEST_ADNW_FAIL, args);
    }

    static void logFailEvent(@NonNull final String adNetworkName, @NonNull final VAMPError error) {
        if (!BuildConfig.DEV_LOG) {
            return;
        }

        log(QATEST_FAIL, new VAMPMap().add("code", error.name()).add("adnw", adNetworkName));
    }

    static void logCrashEvent(@Nullable final String traceMessage) {
        log(QATEST_CRASH, new VAMPMap().add("msg", traceMessage != null ? traceMessage : ""));
    }

    static void logVASTEvent(
            @Nullable final String adSystem,
            @Nullable final String adTitle,
            @Nullable final String duration,
            @Nullable final String mediaFileUrl) {
        if (!BuildConfig.DEV_LOG) {
            return;
        }

        log(
                QATEST_VAST,
                new VAMPMap()
                        .add("adsystem", adSystem != null ? adSystem : "")
                        .add("adtitle", adTitle != null ? adTitle : "")
                        .add("duration", duration != null ? duration : "")
                        .add("mediafile", mediaFileUrl != null ? mediaFileUrl : ""));
    }

    static void logMovieEvent(@NonNull final String networkUrl) {
        log(QATEST_MOVIE, new VAMPMap().add("url", networkUrl));
    }

    private static void log(@NonNull final String event, @NonNull final VAMPMap map) {
        if (!testMode.get()) {
            return;
        }

        Log.d(TAG, QATEST_TAG + event + map.toQueryString());
    }
}
