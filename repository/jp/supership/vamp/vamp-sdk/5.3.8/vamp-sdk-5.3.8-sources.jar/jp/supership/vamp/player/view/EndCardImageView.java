//
//  Copyright © 2026 Supership Inc. All rights reserved.
//
package jp.supership.vamp.player.view;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.FrameLayout;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import java.io.File;
import jp.supership.sscore.vamp.type.Optional;
import jp.supership.vamp.core.logging.LogUtils;

/**
 * 画像エンドカード
 *
 * <p>Created by masaki.ando on 2022/11/14.
 */
final class EndCardImageView extends ImageView implements EndCardViewInterface {
    /** インスタンスを生成できません。詳細はmessageを参照してください */
    private static final class CanNotInstantiateException extends Exception {
        CanNotInstantiateException(String message) {
            super(message);
        }
    }

    private EndCardImageView(
            @NonNull final Context context, @NonNull final Optional<String> imageFilePath)
            throws CanNotInstantiateException {
        super(context);

        setBackgroundColor(Color.BLACK);

        final String filePath = imageFilePath.orElse("");

        if (TextUtils.isEmpty(filePath)) {
            throw new CanNotInstantiateException("imageFilePath is null or empty.");
        }

        final File image = new File(filePath);
        if (!image.exists()) {
            throw new CanNotInstantiateException("The image file is not exist.");
        }
        setImageBitmap(BitmapFactory.decodeFile(image.getPath()));
    }

    /** Viewを生成し、`parent`に追加します。生成できない場合はOptional.empty()を返します */
    @NonNull
    static Optional<EndCardImageView> addTo(
            @NonNull final ViewGroup parent,
            @NonNull final Context context,
            @NonNull final Optional<String> imageFilePath) {
        try {
            final EndCardImageView view = new EndCardImageView(context, imageFilePath);
            final FrameLayout.LayoutParams params =
                    new FrameLayout.LayoutParams(
                            FrameLayout.LayoutParams.MATCH_PARENT,
                            FrameLayout.LayoutParams.MATCH_PARENT);
            params.gravity = Gravity.CENTER;
            parent.addView(view, params);
            return Optional.of(view);
        } catch (CanNotInstantiateException e) {
            LogUtils.devLog(e.getMessage());
            return Optional.empty();
        }
    }

    @Override
    public void show() {
        setVisibility(VISIBLE);
    }

    @Override
    public void hide() {
        setVisibility(INVISIBLE);
    }

    @Override
    public void destroy() {
        Drawable drawable = getDrawable();

        if (drawable instanceof BitmapDrawable) {
            Bitmap bitmap = ((BitmapDrawable) drawable).getBitmap();
            if (bitmap != null) {
                bitmap.recycle();
            }
        }

        setImageDrawable(null);
    }

    @NonNull
    @Override
    public Optional<WebView> getWebView() {
        return Optional.empty();
    }
}
