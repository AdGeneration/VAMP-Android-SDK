//
//  Copyright © 2026 Supership Inc. All rights reserved.
//
package jp.supership.vamp;

import androidx.annotation.NonNull;

public interface VAMPRewardedAdLoadAdvancedListener extends VAMPRewardedAdLoadListener {
    /**
     * アドネットワークごとの広告取得が開始されたときに通知されます。
     *
     * @param placementId 広告枠ID
     * @param adNetworkName アドネットワーク名
     */
    void onStartedLoading(@NonNull String placementId, @NonNull String adNetworkName);

    /**
     * アドネットワークごとの広告取得結果が通知されます。<br>
     * このイベントは、ロードの成功時、失敗時どちらの場合も通知されます。
     *
     * <p><s>このイベントをもとに{@link VAMPRewardedAd#show show}しないようご注意ください。<br>
     * {@link VAMPRewardedAd#show show}をする判定は、 {@link VAMPRewardedAdLoadListener#onReceived
     * onReceived}を 受け取ったタイミングで判定してください。</s><br>
     *
     * @param placementId 広告枠ID
     * @param adNetworkName アドネットワーク名
     * @param success loadに成功したかどうか
     * @param message メッセージ
     */
    void onLoaded(
            @NonNull String placementId,
            @NonNull String adNetworkName,
            boolean success,
            @NonNull String message);
}
