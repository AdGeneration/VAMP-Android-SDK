//
//  Copyright © 2026 Supership Inc. All rights reserved.
//
package jp.supership.vamp.core.vast;

import java.util.ArrayList;

public class VASTAPCExtension extends VASTExtension {

    private String service;
    private String adnw;
    private ArrayList<VASTEndCard> endCards;
    private String lpURLString;

    public VASTAPCExtension() {
        endCards = new ArrayList<>();
    }

    public boolean isApc() {
        return "adg".equals(service) && "apc".equals(getType());
    }

    public void setLpURLString(String lpURLString) {
        this.lpURLString = lpURLString;
    }

    public String getLpURLString() {
        return lpURLString;
    }

    public ArrayList<VASTEndCard> getEndCards() {
        return endCards;
    }

    public String getAdnw() {
        return adnw;
    }

    public void setAdnw(String adnw) {
        this.adnw = adnw;
    }

    public void setService(String service) {
        this.service = service;
    }
}
