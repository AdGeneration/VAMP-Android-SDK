//
//  Copyright © 2026 Supership Inc. All rights reserved.
//
package jp.supership.vamp;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import java.net.MalformedURLException;
import java.net.URL;
import jp.supership.sscore.vamp.adrequest.SSCoreAdhocPlacementResolving;
import jp.supership.sscore.vamp.type.Optional;
import jp.supership.vamp.core.logging.LogUtils;

final class AdhocPlacements implements SSCoreAdhocPlacementResolving {

    private static final String JSON_SERVER_URL_FORMAT =
            "https://d2dylwb3shzel1.cloudfront.net/adid/%s.json";
    private static final String ADHOC_PLACEMENTS_IDS_KEY = "jp.supership.vamp.ADHOC_PLACEMENT_IDS";

    @NonNull private final Optional<Context> appContext;

    public AdhocPlacements(@NonNull Context appContext) {
        this.appContext = Optional.of(appContext);
    }

    @Override
    public boolean useAdhoc(@NonNull String placementId) {
        ApplicationInfo info;

        try {
            Context context = appContext.unwrap();
            PackageManager pm = context.getPackageManager();
            info = pm.getApplicationInfo(context.getPackageName(), PackageManager.GET_META_DATA);
        } catch (PackageManager.NameNotFoundException | Optional.NotPresentException e) {
            return false;
        }

        if (info.metaData != null && info.metaData.containsKey(ADHOC_PLACEMENTS_IDS_KEY)) {
            String placementIds;

            try {
                placementIds = (String) info.metaData.get(ADHOC_PLACEMENTS_IDS_KEY);
            } catch (ClassCastException e) {
                placementIds = "" + info.metaData.getInt(ADHOC_PLACEMENTS_IDS_KEY);
            }

            if (placementIds != null) {
                String[] ids = placementIds.split(",");

                for (String id : ids) {
                    if (id.trim().equals(placementId)) {
                        return true;
                    }
                }
            }
        }

        return false;
    }

    @Nullable
    @Override
    public URL adhocURL(@NonNull String placementId) {
        if (!useAdhoc(placementId)) {
            return null;
        }
        try {
            return new URL(String.format(JSON_SERVER_URL_FORMAT, placementId));
        } catch (MalformedURLException e) {
            LogUtils.d("Adhoc URL is malformed. " + e.getMessage());
            return null;
        }
    }
}
