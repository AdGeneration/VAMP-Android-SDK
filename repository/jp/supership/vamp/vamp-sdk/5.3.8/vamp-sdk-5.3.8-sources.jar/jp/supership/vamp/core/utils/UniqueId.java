//
//  Copyright © 2026 Supership Inc. All rights reserved.
//
package jp.supership.vamp.core.utils;

import java.util.Random;
import java.util.UUID;

public class UniqueId {
    public static long random() {
        long id;
        Random rand = new Random();

        while (true) {
            id = rand.nextLong();

            if (id > 0) {
                break;
            }
        }

        return id;
    }

    public static String randomUUID() {
        UUID uuid = UUID.randomUUID();
        return uuid.toString();
    }
}
