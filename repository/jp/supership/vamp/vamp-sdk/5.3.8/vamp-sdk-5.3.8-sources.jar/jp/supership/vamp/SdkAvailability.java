//
//  Copyright © 2026 Supership Inc. All rights reserved.
//
package jp.supership.vamp;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.text.TextUtils;
import androidx.annotation.NonNull;
import jp.supership.sscore.vamp.device.SSCoreReachability;
import jp.supership.sscore.vamp.type.Optional;

final class SdkAvailability {
    /** VAMP SDKは利用不可の状態です */
    static final class UnavailableException extends Exception {
        /** 利用不可のときのエラータイプ */
        final VAMPError error;

        /** エラーの詳細な理由 */
        final String errorReason;

        UnavailableException(VAMPError error, String errorReason) {
            this.error = error;
            this.errorReason = errorReason;
        }
    }

    interface IAvailabilityChecker {
        /** VAMP SDKが利用可能か判定します。 利用不可のとき、UnavailableExceptionを投げます */
        void check(Optional<String> placementId) throws UnavailableException;
    }

    static final class AvailabilityChecker implements IAvailabilityChecker {
        /** Application context */
        @NonNull private final Optional<Context> appContext;

        @NonNull private final SSCoreReachability.Reachable2 reachability;

        AvailabilityChecker(
                @NonNull final Optional<Context> appContext,
                @NonNull final SSCoreReachability.Reachable2 reachability) {
            this.appContext = appContext;
            this.reachability = reachability;
        }

        @Override
        public void check(Optional<String> placementId) throws UnavailableException {
            if (!VAMP.isSupported()) {
                // サポート対象外のAndroid OSバージョン
                throw new UnavailableException(
                        VAMPError.NOT_SUPPORTED_OS_VERSION, "Not supported os version.");
            }

            if (appContext.isEmpty()) {
                // 参照できるContextがない
                throw new UnavailableException(
                        VAMPError.INVALID_PARAMETER,
                        "Application context is null. " + "VAMP must have application context.");
            }

            Context context = appContext.forced();

            if (context.checkCallingOrSelfPermission(Manifest.permission.INTERNET)
                            != PackageManager.PERMISSION_GRANTED
                    || context.checkCallingOrSelfPermission(
                                    Manifest.permission.ACCESS_NETWORK_STATE)
                            != PackageManager.PERMISSION_GRANTED) {
                // AndroidManifestにパーミッションがない
                throw new UnavailableException(
                        VAMPError.SETTING_ERROR,
                        "android.permission.INTERNET or "
                                + "android.permission.ACCESS_NETWORK_STATE "
                                + "missing in AndroidManifest.");
            }

            if (!reachability.isReachable()) {
                // インターネットに接続不可
                throw new UnavailableException(
                        VAMPError.NEED_CONNECTION, "Need network connection.");
            }

            // TODO: placementIdのチェックはもっと早い段階で済ませるべきかもしれない
            if (TextUtils.isEmpty(placementId.maybe())) {
                // placementIdがnullまたは空文字
                throw new UnavailableException(
                        VAMPError.INVALID_PARAMETER, "PlacementID is not set.");
            }
        }
    }

    private SdkAvailability() {}
}
