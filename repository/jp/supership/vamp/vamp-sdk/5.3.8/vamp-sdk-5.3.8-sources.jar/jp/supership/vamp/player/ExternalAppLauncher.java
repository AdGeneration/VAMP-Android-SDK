//
//  Copyright © 2026 Supership Inc. All rights reserved.
//
package jp.supership.vamp.player;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.text.TextUtils;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import jp.supership.sscore.vamp.type.Optional;

public final class ExternalAppLauncher {
    /** 外部アプリを起動できませんでした */
    public static final class NotLaunchException extends Exception {
        NotLaunchException(@NonNull final String message) {
            super(message);
        }
    }

    /**
     * 指定したURLを外部アプリで起動します
     *
     * @param context コンテキスト
     * @param url 起動するURL
     * @throws NotLaunchException 起動できるアプリがない場合
     */
    public static void startApp(@NonNull final Context context, @Nullable final String url)
            throws NotLaunchException {
        try {
            final LandingPage lp = new LandingPage(url);
            startApp(context, lp);
        } catch (LandingPage.CanNotInstantiateException e) {
            throw new NotLaunchException(e.toString());
        }
    }

    /**
     * 指定したランディングページを外部アプリで起動します
     *
     * @param context コンテキスト
     * @param lp 起動するWebページまたはアプリ
     * @throws NotLaunchException 起動できるアプリがない場合
     */
    public static void startApp(@NonNull final Context context, @NonNull final LandingPage lp)
            throws NotLaunchException {
        final Optional<LandingPage.IntentSchemeUri> intentSchemeUri = lp.intentSchemeUri();
        if (intentSchemeUri.isPresent()) {
            startAppWithIntentScheme(context, intentSchemeUri.forced());
            return;
        }

        final Intent intent =
                new Intent(Intent.ACTION_VIEW, lp.toUri())
                        .addCategory(Intent.CATEGORY_DEFAULT)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            startActivity(context, intent, lp.toUri());
        } catch (NotLaunchException e) {
            final Optional<String> fallbackUrl = lp.fallbackUrlIfCustomScheme();
            if (fallbackUrl.isPresent()) {
                // カスタムスキームで対象のアプリを起動できなかった場合、
                // Webスキームに変換してブラウザで開けないか試す
                final Uri uri = toUri(fallbackUrl.forced());
                final Intent browser =
                        new Intent(Intent.ACTION_VIEW, uri)
                                .addCategory(Intent.CATEGORY_DEFAULT)
                                .addCategory(Intent.CATEGORY_BROWSABLE)
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(context, browser, uri);
            } else {
                throw e;
            }
        }
    }

    /**
     * intentスキームを処理し、外部アプリを起動します
     *
     * @param context コンテキスト
     * @param intentSchemeUri intentスキームのURI
     * @throws NotLaunchException 起動できるアプリがない場合
     */
    private static void startAppWithIntentScheme(
            @NonNull final Context context,
            @NonNull final LandingPage.IntentSchemeUri intentSchemeUri)
            throws NotLaunchException {
        final String url;
        if ("line".equals(intentSchemeUri.scheme.orElse(""))) {
            url = "line:" + intentSchemeUri.schemeSpecificPart();
        } else {
            throw new NotLaunchException("Can't open this URL: " + intentSchemeUri);
        }

        final Uri appUri = toUri(url);
        final Intent intent =
                new Intent(intentSchemeUri.action, appUri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

        if (!TextUtils.isEmpty(intentSchemeUri.category.orElse(""))) {
            intent.addCategory(intentSchemeUri.category.forced());
        }

        try {
            // カスタムスキームなのでブラウザ以外のアプリで開く
            startNonBrowser(context, intent, appUri);
        } catch (NotLaunchException e) {
            // 起動できるアプリがなくpackageNameがある場合はGoogle Play Storeを開く
            final Uri storeUri;
            try {
                storeUri = intentSchemeUri.playStoreUri().unwrap();
            } catch (Optional.NotPresentException ignored) {
                throw e;
            }
            final Intent storeIntent =
                    new Intent(Intent.ACTION_VIEW, storeUri)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startNonBrowser(context, storeIntent, storeUri);
        }
    }

    /**
     * 外部アプリを起動します
     *
     * @param context コンテキスト
     * @param intent アプリ起動インテント
     * @param uri `intent`に関連付けたURI
     * @throws NotLaunchException 起動できるアプリがない場合
     */
    private static void startActivity(
            @NonNull final Context context, @NonNull final Intent intent, @NonNull final Uri uri)
            throws NotLaunchException {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            // Android 11以降ではQUERY_ALL_PACKAGESパーミッションなしでは
            // resolveActivityがnullを返すため、
            // デフォルトのアプリでこのURIを開くことができるものがないかトライし、
            // なければ(ActivityNotFoundExceptionが発生したら)例外を投げる
            //
            // QUERY_ALL_PACKAGES...
            // アプリ一覧取得権限。利用するためにはGoogleに申告が必須なためハードルが高い
            intent.addFlags(Intent.FLAG_ACTIVITY_REQUIRE_DEFAULT);
            try {
                context.startActivity(intent);
            } catch (ActivityNotFoundException e) {
                throw new NotLaunchException(
                        "An activity not found that can open this URL: " + uri);
            }
        } else {
            if (intent.resolveActivity(context.getPackageManager()) != null) {
                try {
                    context.startActivity(intent);
                } catch (ActivityNotFoundException e) {
                    throw new NotLaunchException("Failed to start this URL: " + uri);
                }
            } else {
                throw new NotLaunchException(
                        "An activity not resolved that can open this URL: " + uri);
            }
        }
    }

    /**
     * ブラウザを除く外部アプリを起動します。<br>
     * Android 11未満の端末のときは、ブラウザ判定をせずにインテントを処理できるアプリを起動します
     *
     * @param context コンテキスト
     * @param intent アプリ起動インテント
     * @param uri `intent`に関連付けたURI
     * @throws NotLaunchException 起動できるアプリがない場合
     */
    private static void startNonBrowser(
            @NonNull final Context context, @NonNull final Intent intent, @NonNull Uri uri)
            throws NotLaunchException {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            // ブラウザ以外で起動できるアプリに限定
            intent.addFlags(Intent.FLAG_ACTIVITY_REQUIRE_NON_BROWSER);
        }

        startActivity(context, intent, uri);
    }

    private static Uri toUri(@NonNull final String url) throws NotLaunchException {
        try {
            return Uri.parse(url);
        } catch (Exception e) {
            throw new NotLaunchException(e.toString());
        }
    }
}
