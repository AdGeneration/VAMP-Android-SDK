//
//  Copyright © 2026 Supership Inc. All rights reserved.
//
package jp.supership.vamp.player;

// FIXME: VASTAdapter <> Player(PlayerActivityとVideoView)間でエラーの授受のためstaticを介しているのをEBで返すように修正
// VideViewは直接VASTAdapterとやり取りせず、エラー情報をリスナー経由でPlayerActivityに渡す
// PlayerActivityからPlayerActivityEventにこのエラー情報を詰めてVASTAdapterへEB経由で送る
// このクラスはエラーコード+付加情報を格納するオブジェクト
public class VAMPPlayerReport {
    private String className;
    private String line;
    private String message;
    private VAMPPlayerError errorCode;

    private static final Object LOCK_OBJECT = new Object();
    private static VAMPPlayerReport lastError;

    public VAMPPlayerReport(Throwable throwable, VAMPPlayerError errorCode, String message) {
        this(throwable, errorCode);
        this.message = message;
    }

    public VAMPPlayerReport(Throwable throwable, VAMPPlayerError errorCode) {
        StackTraceElement element = throwable.getStackTrace()[0];
        className = element.getClassName();
        line = String.valueOf(element.getLineNumber());
        this.errorCode = errorCode;
    }

    public String getClassName() {
        return className;
    }

    public String getLine() {
        return line;
    }

    public String getMessage() {
        return message;
    }

    public VAMPPlayerError getErrorCode() {
        return errorCode;
    }

    public static VAMPPlayerReport getLastError() {
        VAMPPlayerReport report = lastError;
        setLastError(null);
        return report;
    }

    public static void setLastError(VAMPPlayerReport errorReport) {
        synchronized (LOCK_OBJECT) {
            lastError = errorReport;
        }
    }
}
