//
//  Copyright © 2026 Supership Inc. All rights reserved.
//
package jp.supership.vamp.player;

/** Created by sanojimaru on 15/05/21. */
public enum VAMPPlayerError {
    CACHE_SERVICE_ERROR,
    EXCEED_FILE_SIZE,
    FAILED_TO_PREPARE_MEDIA,
    FILE_NOT_FOUND,
    HARDWARE_ACCELERATION_DISABLED,
    HTTP_REQUEST_TIMEOUT,
    MEDIA_ERROR_UNKNOWN,
    MOVIE_FORCED_CLOSED,
    NEED_CONNECTION,
    NETWORK_ERROR,
    NO_AD,
    PARSE_ERROR,
    SERVER_ERROR,
    SETTING_ERROR,
    TIMEOUT,
    UNKNOWN,
    UNSPECIFIED,
    USER_CANCEL
}
