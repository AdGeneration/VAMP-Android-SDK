//
//  Copyright © 2026 Supership Inc. All rights reserved.
//
package jp.supership.vamp.core.utils;

import java.io.Serializable;
import java.util.ArrayList;

public class VAMPList<T> extends ArrayList<T> implements Serializable {
    public interface IFindListener<T> {
        boolean where(T result);
    }

    public T find(IFindListener<T> listener) {
        for (int i = 0; i < size(); ++i) {
            T o = get(i);
            if (listener != null && listener.where(o)) {
                return o;
            }
        }

        return null;
    }

    public VAMPList<T> select(IFindListener<T> listener) {
        VAMPList<T> result = new VAMPList<T>();
        for (int i = 0; i < size(); ++i) {
            T o = get(i);
            if (listener != null && listener.where(o)) {
                result.add(o);
            }
        }

        return result;
    }
}
