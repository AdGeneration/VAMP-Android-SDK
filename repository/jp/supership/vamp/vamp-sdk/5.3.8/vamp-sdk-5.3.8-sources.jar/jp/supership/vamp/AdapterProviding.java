//
//  Copyright © 2026 Supership Inc. All rights reserved.
//
package jp.supership.vamp;

import androidx.annotation.Nullable;
import java.util.ArrayList;
import jp.supership.vamp.mediation.Adapter;

public interface AdapterProviding {
    @Nullable
    Adapter getAdapter(String adNetworkName) throws AdapterNotFoundException;

    ArrayList<Adapter> getSupportedAdapters();
}
