//
//  Copyright © 2026 Supership Inc. All rights reserved.
//
package jp.supership.vamp.measurement;

import android.view.View;
import androidx.annotation.NonNull;
import com.iab.omid.library.supershipjp1.adsession.FriendlyObstructionPurpose;

public final class Obstruction {
    /** OM SDKに登録する障害物になりうるViewの種類 */
    public enum ObstructedViewType {
        /** 上部ボタンエリア */
        HEADER_VIEW,
        /** 下部ボタンエリア */
        FOOTER_VIEW,
        /** 秒数カウント */
        COUNT_DOWN_VIEW,
        /** iマーク */
        IMARK_BUTTON,
        /** サウンドON・OFFボタンエリア */
        SOUND_BUTTON_AREA,
        /** 閉じるボタン */
        CLOSE_BUTTON,
        /** AdReportボタン */
        ADREPORT_BUTTON
    }

    @NonNull public final View view;
    @NonNull public final ObstructedViewType type;

    public Obstruction(@NonNull final View view, @NonNull final ObstructedViewType type) {
        this.view = view;
        this.type = type;
    }

    /**
     * 障害物のカテゴリを返却します
     *
     * @return FriendlyObstructionPurpose
     */
    @NonNull
    FriendlyObstructionPurpose friendlyObstructionPurpose() {
        switch (type) {
            case FOOTER_VIEW:
            case HEADER_VIEW:
            case SOUND_BUTTON_AREA:
                return FriendlyObstructionPurpose.VIDEO_CONTROLS;
            case CLOSE_BUTTON:
                return FriendlyObstructionPurpose.CLOSE_AD;
            case IMARK_BUTTON:
            case COUNT_DOWN_VIEW:
            case ADREPORT_BUTTON:
            default:
                return FriendlyObstructionPurpose.OTHER;
        }
    }

    /**
     * an explanation for why this obstruction is part of the ad experience if not already obvious
     * from the FriendlyObstructionPurpose selected. Must be 50 characters or less and only contain
     * characters `A-z`,`0-9` or space.
     *
     * @return 詳細理由
     */
    @NonNull
    String friendlyObstructionDetailedReason() {
        switch (type) {
            case SOUND_BUTTON_AREA:
                return "For controlling the sound";
            case CLOSE_BUTTON:
                return "For controlling the close button";
            case IMARK_BUTTON:
                return "For controlling the information icon";
            case COUNT_DOWN_VIEW:
                return "For controlling the countdown";
            case ADREPORT_BUTTON:
                return "For controlling the ad report button";
            case FOOTER_VIEW:
            case HEADER_VIEW:
            default:
                return "Due to some unique technical limitations";
        }
    }
}
