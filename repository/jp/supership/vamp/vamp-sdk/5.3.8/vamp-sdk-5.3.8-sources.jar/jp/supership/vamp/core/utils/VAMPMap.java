//
//  Copyright © 2026 Supership Inc. All rights reserved.
//
package jp.supership.vamp.core.utils;

import java.util.HashMap;
import java.util.Map;

/** Created by yumiko.ishii on 2016/12/02. */
public class VAMPMap {
    private HashMap<String, String> map;

    public VAMPMap() {
        map = null;
    }

    public VAMPMap add(String value) {
        if (map == null) {
            map = new HashMap<String, String>();
        }
        map.put("param" + (map.size() + 1), value);
        return this;
    }

    public VAMPMap add(String key, String value) {
        if (map == null) {
            map = new HashMap<String, String>();
        }
        map.put(key, value);
        return this;
    }

    public String toQueryString() {
        if (map != null && map.size() > 0) {
            StringBuilder buffer = new StringBuilder();
            int ct = 0;
            for (Map.Entry<String, String> entry : map.entrySet()) {
                if (ct > 0) {
                    buffer.append("&");
                }
                buffer.append(entry.getKey());
                buffer.append("=");
                buffer.append(entry.getValue());
                ct++;
            }
            return buffer.toString();
        }
        return "";
    }

    @Override
    public String toString() {
        if (map != null && map.size() > 0) {
            StringBuilder buffer = new StringBuilder();
            int ct = 0;
            for (Map.Entry<String, String> entry : map.entrySet()) {
                if (ct > 0) {
                    buffer.append(", ");
                }
                buffer.append("{");
                buffer.append(entry.getValue());
                buffer.append("}");
                ct++;
            }
            return buffer.toString();
        }
        return "";
    }
}
