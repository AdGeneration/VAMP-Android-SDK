//
//  Copyright © 2026 Supership Inc. All rights reserved.
//
package jp.supership.vamp.core.utils;

import android.content.ClipData;
import android.content.ClipDescription;
import android.content.ClipboardManager;
import android.content.Context;
import android.text.TextUtils;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import java.io.IOException;
import java.io.InputStream;
import java.util.regex.Pattern;

/** Created by sanojimaru on 15/05/29. */
public class Strings {
    // Regex patterns
    private static Pattern percentagePattern = Pattern.compile("((\\d{1,2})|(100))%");
    //    private static Pattern absolutePattern =
    // Pattern.compile("\\d{2}:\\d{2}:\\d{2}(.\\d{3})?");
    private static Pattern absolutePattern =
            Pattern.compile("\\d{1,2}:\\d{1,2}:\\d{1,2}(.\\d{1,3})?");

    public static final String Empty = "";

    public static String fromStream(InputStream inputStream) throws IOException {
        int numberBytesRead = 0;
        StringBuilder out = new StringBuilder();
        byte[] bytes = new byte[4096];

        while (numberBytesRead != -1) {
            out.append(new String(bytes, 0, numberBytesRead));
            numberBytesRead = inputStream.read(bytes);
        }

        inputStream.close();

        return out.toString();
    }

    public static boolean isPercentageTracker(String progressValue) {
        return !TextUtils.isEmpty(progressValue)
                && percentagePattern.matcher(progressValue).matches();
    }

    public static boolean isAbsoluteTracker(String progressValue) {
        return !TextUtils.isEmpty(progressValue)
                && absolutePattern.matcher(progressValue).matches();
    }

    @Nullable
    public static Integer parseAbsoluteOffset(@NonNull String progressValue) {
        final String[] split = progressValue.split(":");
        if (split.length != 3) {
            return null;
        }

        return Integer.parseInt(split[0]) * 60 * 60 * 1000 // Hours
                + Integer.parseInt(split[1]) * 60 * 1000 // Minutes
                + (int) (Float.parseFloat(split[2]) * 1000);
    }

    public static Integer parsePercentageOffset(String offset, int videoDuration) {
        float percentage = Float.parseFloat(offset.replace("%", ""));
        return Math.round(videoDuration * percentage / 100f);
    }

    /**
     * クリップボードに文字列コピー
     *
     * @param text
     */
    public static void copyClipboard(Context context, String text) {
        ClipData.Item item = new ClipData.Item(text);
        String[] mimeType = new String[1];
        mimeType[0] = ClipDescription.MIMETYPE_TEXT_URILIST;
        ClipData cd = new ClipData(new ClipDescription("text_data", mimeType), item);
        ClipboardManager cm =
                (ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(cd);
    }
}
