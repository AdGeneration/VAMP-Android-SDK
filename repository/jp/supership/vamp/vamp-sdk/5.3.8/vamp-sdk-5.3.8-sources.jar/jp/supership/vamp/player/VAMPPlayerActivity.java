//
//  Copyright © 2026 Supership Inc. All rights reserved.
//
package jp.supership.vamp.player;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import jp.supership.sscore.vamp.adreport.SSCoreAdReport;
import jp.supership.sscore.vamp.adreport.SSCoreAdReportConfigException;
import jp.supership.sscore.vamp.adreport.SSCoreAdReportException;
import jp.supership.sscore.vamp.adreport.SSCoreAdReportListener;
import jp.supership.sscore.vamp.adreport.SSCoreAdditionalParameterKey;
import jp.supership.sscore.vamp.adreport.view.SSCoreAdReportButton;
import jp.supership.sscore.vamp.type.Optional;
import jp.supership.sscore.vamp.type.Result;
import jp.supership.sscore.vamp.video.base.SSCoreAdContext;
import jp.supership.sscore.vamp.video.base.SSCoreEndCardContext;
import jp.supership.sscore.vamp.video.base.SSCoreInfoContext;
import jp.supership.sscore.vamp.video.base.SSCoreObstructionViewType;
import jp.supership.sscore.vamp.video.base.SSCorePlayerError;
import jp.supership.sscore.vamp.video.vamp.SSCoreVideoRewardedAdView;
import jp.supership.sscore.vamp.video.vamp.SSCoreVideoRewardedAdViewListener;
import jp.supership.vamp.BuildConfig;
import jp.supership.vamp.VAMP;
import jp.supership.vamp.core.eventbus.EventBus;
import jp.supership.vamp.core.eventbus.Subscribe;
import jp.supership.vamp.core.eventbus.ThreadMode;
import jp.supership.vamp.core.logging.LogUtils;
import jp.supership.vamp.core.vast.VASTIcon;
import jp.supership.vamp.core.vast.VASTMediaFile;
import jp.supership.vamp.core.vast.VASTPMPCreativeExtension;
import jp.supership.vamp.measurement.NativeVideoMeasurementManager;
import jp.supership.vamp.measurement.Obstruction;
import jp.supership.vamp.measurement.VideoPlayerInfo;
import jp.supership.vamp.player.view.FullScreenContentView;

/** Created by yumiko.ishii on 2017/03/14. */
public class VAMPPlayerActivity extends Activity {
    private static final String CLASS_NAME = VAMPPlayerActivity.class.getSimpleName();
    private static final String EXTRA_DATA_AD = "jp.supership.vamp.player.EXTRA_DATA_AD";
    private static final String SAVED_DATA_AD = "jp.supership.vamp.player.SAVED_DATA_AD";
    private static final String OPTOUT_LINK = "https://supership.jp/optout/";

    @NonNull private Optional<FullScreenContentView> fullScreenContentView = Optional.empty();
    @NonNull private Optional<SSCoreVideoRewardedAdView> playerView = Optional.empty();
    @NonNull private Optional<VAMPPlayerAd> ad = Optional.empty();

    /** オーディオフォーカス状態 */
    private int audioFocusResult;

    @NonNull private Optional<NativeVideoMeasurementManager> measurementManager = Optional.empty();
    @NonNull private Optional<ScreenOffBroadcastReceiver> screenOffReceiver = Optional.empty();

    /** 現在のミュート状態（OM SDK VideoPlayerInfo 用） */
    private boolean isMuted = false;

    @Nullable private android.window.OnBackInvokedCallback onBackInvokedCallback;

    /**
     * WebViewエンドカードでロードするランディングページURLを返します。
     *
     * <p>非WebスキームのLPはWebViewでロードできないため画像エンドカードに委ねます（5.3.0と同じ判定）。
     *
     * @param landingPage 選択済みのランディングページ
     * @return WebコンテンツのLPならそのURL、それ以外はnull
     */
    @Nullable
    static String endCardWebViewUrlOf(@NonNull final Optional<LandingPage> landingPage) {
        final LandingPage lp;
        try {
            lp = landingPage.unwrap();
        } catch (Optional.NotPresentException e) {
            return null;
        }
        return lp.isWebContent() ? lp.url : null;
    }

    static void show(@NonNull final Activity activity, @NonNull final VAMPPlayerAd ad) {
        // バックグラウンドスレッドでshowメソッドが実行されたとしても確実にUIスレッドで表示する
        new Handler(Looper.getMainLooper())
                .post(
                        new Runnable() {
                            @Override
                            public void run() {
                                FullScreenContentStateManager.getInstance().present();

                                Intent intent =
                                        new Intent(activity, VAMPPlayerActivity.class)
                                                .setAction(Intent.ACTION_VIEW)
                                                .putExtra(EXTRA_DATA_AD, ad.serialized())
                                                .setFlags(Intent.FLAG_ACTIVITY_NO_USER_ACTION);
                                activity.startActivity(intent);
                            }
                        });
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LogUtils.d(CLASS_NAME + "#onCreate called.");

        // Activityの表示モード設定
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        hideNavigationBar();

        if (savedInstanceState != null) {
            // Activity復元時
            // onSaveInstanceStateで一時保存したデータを復元
            ad =
                    VAMPPlayerAd.from(
                            (VAMPPlayerAd.SerializableObject)
                                    savedInstanceState.getSerializable(SAVED_DATA_AD));
        } else {
            // Activity初期生成時
            Intent intent = getIntent();
            if (intent != null) {
                ad =
                        VAMPPlayerAd.from(
                                (VAMPPlayerAd.SerializableObject)
                                        intent.getSerializableExtra(EXTRA_DATA_AD));
            }
        }

        if (ad.isEmpty()) {
            VAMPPlayerReport report =
                    new VAMPPlayerReport(
                            new Throwable(), VAMPPlayerError.UNSPECIFIED, "vampPlayerAd == null");
            VAMPPlayerReport.setLastError(report);
            failed(VAMPPlayerError.UNSPECIFIED);
            return;
        }

        final VAMPPlayerAd ad = this.ad.forced();
        ad.setLogListener(
                new VAMPPlayerAd.ILogListener() {
                    @Override
                    public void onLog(@NonNull String log, @Nullable String devLog) {
                        LogUtils.d(log);
                        if (devLog != null) {
                            LogUtils.devLog(devLog);
                        }
                    }
                });

        // Activityが異常終了したかどうか判定できないため、
        // onDestroyが既に呼ばれている場合はActivityの復元を中断して終了
        if (FullScreenContentStateManager.getInstance().isDestroyed()) {
            LogUtils.d("The ad is already destroyed.");
            finish();
            return;
        }

        if (!EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().register(this);
        }

        screenOffReceiver =
                Optional.of(
                        ScreenOffBroadcastReceiver.register(
                                this,
                                new ScreenOffBroadcastReceiver.Listener() {
                                    @Override
                                    public void onScreenOn() {
                                        LogUtils.d(CLASS_NAME + "#onScreenOn called.");
                                        resume();
                                    }
                                }));

        audioFocusResult = AudioManager.AUDIOFOCUS_REQUEST_FAILED;

        final FullScreenContentView fullScreenContentView =
                FullScreenContentView.setToActivity(this);
        this.fullScreenContentView = Optional.of(fullScreenContentView);

        final VASTMediaFile mediaFile = ad.selectedMediaFile;
        // キャッシュファイルが削除されている可能性もあるため、ロード処理を再実行。
        // キャッシュがある場合は即時リターンされるため、複数回実行してもパフォーマンスに影響はない
        mediaFile.loadMediaFileOrFallback(
                this,
                new VASTMediaFile.ILoadOrFallbackListener() {
                    @Override
                    public void onCompleted(@NonNull final String videoFileOrNetworkUrl) {
                        // SSCoreHttpClient はワーカースレッドでコールバックするため、UI構築を main thread に戻す
                        runOnUiThread(
                                () -> {
                                    // post 中に Activity が破棄されている場合は中断する
                                    if (isFinishing() || isDestroyed()) {
                                        LogUtils.d(
                                                "Activity is finishing/destroyed, skip player"
                                                        + " initialization.");
                                        return;
                                    }

                                    LogUtils.d("Prepare to use video.");

                                    // エンドカードパス取得
                                    String endCardImagePath = null;
                                    try {
                                        endCardImagePath =
                                                ad.selectedEndCard
                                                        .unwrap()
                                                        .getImageFilePath(VAMPPlayerActivity.this);
                                    } catch (Optional.NotPresentException ignored) {
                                    }

                                    // iMarkボタン設定
                                    String iMarkFilePath = null;
                                    String privacyText = "";
                                    String iconClickThroughUrl = OPTOUT_LINK;
                                    try {
                                        final VASTIcon icon = ad.selectedIcon.unwrap();
                                        privacyText = icon.getProgram();
                                        if (icon.getStaticResource() != null) {
                                            iMarkFilePath =
                                                    icon.getStaticResource()
                                                            .getImageFilePath(
                                                                    VAMPPlayerActivity.this);
                                        }
                                        if (icon.getClickThroughURL() != null
                                                && icon.getClickThroughURL().startsWith("http")) {
                                            iconClickThroughUrl = icon.getClickThroughURL();
                                        }
                                    } catch (Optional.NotPresentException ignored) {
                                    }

                                    if (BuildConfig.DEV_LOG) {
                                        privacyText += ad.vastObject.getAdSystem();
                                    }

                                    // クリックスルーURL取得（consume不要）
                                    String clickThroughUrl = null;
                                    try {
                                        clickThroughUrl =
                                                ad.selectedClickThrough.unwrap().peekUrl();
                                    } catch (Optional.NotPresentException ignored) {
                                    }

                                    // ロケール別デフォルトテキスト
                                    boolean isJapanese =
                                            "ja".equals(Locale.getDefault().getLanguage());
                                    String defaultBtnText = isJapanese ? "入手" : "GET";
                                    String defaultBtnTextExtra = isJapanese ? "広告の後に移動します" : "GET";

                                    // PMPConfig構築
                                    SSCoreAdContext.PMPConfig pmpConfig = null;
                                    VASTPMPCreativeExtension pmpExtension =
                                            ad.vastObject.getPmpExtension();
                                    if (pmpExtension != null) {
                                        pmpConfig =
                                                new SSCoreAdContext.PMPConfig(
                                                        pmpExtension.getCtaButtonText(),
                                                        pmpExtension.getCtaButtonTextExtra(),
                                                        (float) pmpExtension.getCtaButtonHSize(),
                                                        pmpExtension.isButtonEnableOnPlaying());
                                    }

                                    // InstallButtonConfig構築
                                    SSCoreAdContext.InstallButtonConfig installButtonConfig = null;
                                    if (pmpExtension != null && clickThroughUrl != null) {
                                        // PMP: インストールボタンのURLはClickThrough URL
                                        installButtonConfig =
                                                new SSCoreAdContext.InstallButtonConfig(
                                                        clickThroughUrl,
                                                        defaultBtnText,
                                                        defaultBtnTextExtra,
                                                        false);
                                    } else {
                                        try {
                                            LandingPage landingPage =
                                                    ad.selectedLandingPage.unwrap();
                                            installButtonConfig =
                                                    new SSCoreAdContext.InstallButtonConfig(
                                                            landingPage.url,
                                                            defaultBtnText,
                                                            defaultBtnTextExtra,
                                                            landingPage.isAutoInstallAvailable());
                                        } catch (Optional.NotPresentException ignored) {
                                        }
                                    }

                                    // ランディングページURL取得（WebViewエンドカード用）
                                    String webViewUrl = endCardWebViewUrlOf(ad.selectedLandingPage);

                                    // Contextオブジェクト構築
                                    SSCoreEndCardContext endCardContext =
                                            new SSCoreEndCardContext(
                                                    endCardImagePath,
                                                    webViewUrl,
                                                    ad.getLinkText(),
                                                    webViewUrl != null);
                                    // iMarkButtonは常に表示（privacyTextが空の場合は"Privacy Policy"をデフォルト使用）
                                    String iMarkText =
                                            !privacyText.isEmpty() ? privacyText : "Privacy Policy";
                                    SSCoreInfoContext infoContext =
                                            new SSCoreInfoContext(
                                                    iMarkText,
                                                    iconClickThroughUrl,
                                                    iMarkFilePath,
                                                    null);
                                    SSCoreAdContext adContext =
                                            new SSCoreAdContext(
                                                    pmpConfig,
                                                    installButtonConfig,
                                                    clickThroughUrl,
                                                    ad.getLinkText());

                                    // SSCoreVideoRewardedAdView作成
                                    SSCoreVideoRewardedAdView playerView =
                                            SSCoreVideoRewardedAdView.create(
                                                    VAMPPlayerActivity.this,
                                                    Uri.parse(videoFileOrNetworkUrl),
                                                    endCardContext,
                                                    infoContext,
                                                    adContext,
                                                    false,
                                                    ad.canSkip(),
                                                    ad.getSkipOffset());
                                    playerView.setListener(vampPlayerListener);
                                    VAMPPlayerActivity.this.playerView = Optional.of(playerView);

                                    fullScreenContentView.setPlayerView(playerView);

                                    // AdReportボタンをfooterRowに追加
                                    final float density =
                                            getResources().getDisplayMetrics().density;
                                    SSCoreAdReportButton.addTo(
                                            playerView.getFooterRow(),
                                            VAMPPlayerActivity.this,
                                            density,
                                            Gravity.BOTTOM,
                                            new SSCoreAdReportListener() {
                                                @NonNull
                                                @Override
                                                public Optional<
                                                                Map<
                                                                        SSCoreAdditionalParameterKey,
                                                                        String>>
                                                        getAdditionalParametersForAdReport() {
                                                    final String sdkVer =
                                                            "vamp"
                                                                    + VAMP.SDKVersion()
                                                                            .replace("v", "");
                                                    final String adNetworkName =
                                                            ad.getAdNetworkName();
                                                    final String placementId =
                                                            ad.getPlacementId().orElse("");
                                                    final String movieUrl =
                                                            ad.selectedMediaFile.networkUrl;
                                                    final VAMPCreativeInfo creativeInfo =
                                                            ad.getCreativeInfo().maybe();
                                                    final Map<SSCoreAdditionalParameterKey, String>
                                                            params = new HashMap<>();
                                                    params.put(
                                                            SSCoreAdditionalParameterKey
                                                                    .SDK_VERSION,
                                                            sdkVer);
                                                    params.put(
                                                            SSCoreAdditionalParameterKey
                                                                    .PLACEMENT_ID,
                                                            placementId);
                                                    params.put(
                                                            SSCoreAdditionalParameterKey
                                                                    .ADNETWORK_NAME,
                                                            adNetworkName);
                                                    params.put(
                                                            SSCoreAdditionalParameterKey.MOVIE_URL,
                                                            movieUrl);
                                                    params.put(
                                                            SSCoreAdditionalParameterKey.VAST,
                                                            ad.vastObject.getOriginalXml());
                                                    params.put(
                                                            SSCoreAdditionalParameterKey.CRID,
                                                            creativeInfo != null
                                                                    ? creativeInfo.crid
                                                                    : "");
                                                    params.put(
                                                            SSCoreAdditionalParameterKey
                                                                    .ADNETWORK_ID,
                                                            creativeInfo != null
                                                                    ? creativeInfo.adNetworkId
                                                                    : "");
                                                    params.put(
                                                            SSCoreAdditionalParameterKey.DSP_ID,
                                                            creativeInfo != null
                                                                    ? creativeInfo.dspId
                                                                    : "");
                                                    params.put(
                                                            SSCoreAdditionalParameterKey.SEAT,
                                                            creativeInfo != null
                                                                    ? creativeInfo.seat
                                                                    : "");
                                                    params.put(
                                                            SSCoreAdditionalParameterKey.ADOMAIN,
                                                            "");
                                                    return Optional.of(params);
                                                }

                                                @Override
                                                public void onOpenedAdReportView() {
                                                    ad.pause();
                                                }

                                                @Override
                                                public void onSentAdReport(
                                                        @NonNull
                                                                Optional<SSCoreAdReportException>
                                                                        error) {
                                                    final boolean isJA =
                                                            "ja"
                                                                    .equals(
                                                                            Locale.getDefault()
                                                                                    .getLanguage());
                                                    if (error.isPresent()) {
                                                        LogUtils.e(
                                                                "Failed to send ad report.",
                                                                error.forced());
                                                        Toast.makeText(
                                                                        VAMPPlayerActivity.this,
                                                                        isJA
                                                                                ? "送信失敗"
                                                                                : "Failed to send.",
                                                                        Toast.LENGTH_SHORT)
                                                                .show();
                                                    } else {
                                                        LogUtils.d("Succeeded to send ad report.");
                                                        Toast.makeText(
                                                                        VAMPPlayerActivity.this,
                                                                        isJA
                                                                                ? "送信完了"
                                                                                : "Successfully"
                                                                                        + " sent.",
                                                                        Toast.LENGTH_SHORT)
                                                                .show();
                                                    }
                                                }

                                                @Override
                                                public void onClosedAdReportView(
                                                        @NonNull SSCoreAdReport ssCoreAdReport) {
                                                    final View adReportView =
                                                            ssCoreAdReport.adReportView().maybe();
                                                    if (adReportView != null
                                                            && adReportView.getParent()
                                                                    instanceof ViewGroup) {
                                                        ((ViewGroup) adReportView.getParent())
                                                                .removeView(adReportView);
                                                    }
                                                    ad.resume();
                                                }
                                            },
                                            new SSCoreAdReportButton.Listener() {
                                                @Override
                                                public void onConfigured(
                                                        @NonNull
                                                                Result<
                                                                                SSCoreAdReportButton,
                                                                                SSCoreAdReportConfigException>
                                                                        result) {
                                                    if (!result.isSuccess()) {
                                                        LogUtils.e(
                                                                "Failed to show ad report button."
                                                                        + " result: "
                                                                        + result);
                                                    }
                                                }

                                                @Override
                                                public void onClicked(
                                                        @NonNull SSCoreAdReport adReport) {
                                                    adReport.showAdReportView(
                                                            VAMPPlayerActivity.this,
                                                            playerView.getFooterRow(),
                                                            density);
                                                }
                                            });

                                    // OMSDKの計測開始（playerView設定後）
                                    startMeasurement(fullScreenContentView.adView);
                                });
                    }
                });

        // API 33+ では OnBackInvokedDispatcher を使用
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            onBackInvokedCallback = this::handleBackPressed;
            getOnBackInvokedDispatcher()
                    .registerOnBackInvokedCallback(
                            android.window.OnBackInvokedDispatcher.PRIORITY_DEFAULT,
                            onBackInvokedCallback);
        }
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);

        try {
            playerView.unwrap().changeLayout(newConfig.orientation);
        } catch (Optional.NotPresentException ignored) {
        }
    }

    @SuppressWarnings("deprecation")
    @Override
    public void onBackPressed() {
        // API 33 未満のフォールバック（API 33+ は OnBackInvokedDispatcher を使用）
        handleBackPressed();
    }

    private void handleBackPressed() {
        final VAMPPlayerAd ad;
        try {
            ad = this.ad.unwrap();
        } catch (Optional.NotPresentException e) {
            // 万が一、adがnullになっていてもバックキーで閉じられるようにしておく
            LogUtils.e("Back key pressed. Abnormal termination.");
            closeActivity();
            return;
        }

        if (!ad.isCompleted()) {
            // 動画再生中は何もしない(エンドカード表示後はバックキーで閉じれるようにする)
            return;
        }

        // WebViewエンドカード表示中はWebViewの前ページへ戻る
        try {
            SSCoreVideoRewardedAdView pv = playerView.unwrap();
            if (pv.canGoBack()) {
                pv.goBack();
                return;
            }
        } catch (Optional.NotPresentException ignored) {
        }

        closeActivity();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        LogUtils.d(CLASS_NAME + "#onSaveInstanceState called.");

        try {
            outState.putSerializable(SAVED_DATA_AD, ad.unwrap().serialized());
        } catch (Optional.NotPresentException ignored) {
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        LogUtils.d(CLASS_NAME + "#onResume called.");

        ScreenKeep.start(this);

        startAudioFocus();

        try {
            if (screenOffReceiver.unwrap().isScreenUnlocked()) {
                resume();
            }
        } catch (Optional.NotPresentException ignored) {
        }
    }

    @Override
    protected void onPause() {
        LogUtils.d(CLASS_NAME + "#onPause called.");

        ScreenKeep.stop(this);

        stopAudioFocus();
        pause();

        super.onPause();
    }

    @Override
    protected void onDestroy() {
        LogUtils.d(CLASS_NAME + "#onDestroy called.");

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
                && onBackInvokedCallback != null) {
            getOnBackInvokedDispatcher().unregisterOnBackInvokedCallback(onBackInvokedCallback);
            onBackInvokedCallback = null;
        }

        // Activityが異常終了した場合、closeActivity()が呼ばれない可能性があるため、
        // destroyIfNeeded()を呼んでおく
        destroyIfNeeded();

        super.onDestroy();
    }

    private void destroyIfNeeded() {
        if (FullScreenContentStateManager.getInstance().isDestroyed()) {
            return;
        }
        FullScreenContentStateManager.getInstance().destroy();

        postPlayerActivityEvent(new PlayerActivityEvent(PlayerActivityEvent.EVENT_CLOSE));

        sendMeasurementVideoEvent(NativeVideoMeasurementManager.VideoEvent.FINISH);

        try {
            playerView.unwrap().release();
            playerView = Optional.empty();
        } catch (Optional.NotPresentException ignored) {
        }

        try {
            fullScreenContentView.unwrap().destroy();
            fullScreenContentView = Optional.empty();
        } catch (Optional.NotPresentException ignored) {
        }

        try {
            screenOffReceiver.unwrap().unregister(this);
            screenOffReceiver = Optional.empty();
        } catch (Optional.NotPresentException ignored) {
        }

        if (EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().unregister(this);
        }
    }

    private void closeActivity() {
        LogUtils.d(CLASS_NAME + "#closeActivity called.");

        // Unity-Pluginで実行した時に動画再生中に画面を回転してから閉じると
        // onDestroy()が呼ばれず、クラッシュする端末があったため、
        // closeActivity()でもdestroyIfNeeded()を呼んでおく
        destroyIfNeeded();

        finish();
    }

    /** OM SDKのアドセッションを生成して計測を開始します */
    private void startMeasurement(@NonNull final View adView) {
        VAMPPlayerAd ad;
        try {
            ad = this.ad.unwrap();
        } catch (Optional.NotPresentException e) {
            return;
        }

        if (measurementManager.isPresent()) {
            LogUtils.devLog("measurementManager is already initialized.");
            return;
        }

        try {
            NativeVideoMeasurementManager manager =
                    new NativeVideoMeasurementManager(
                            getApplicationContext(),
                            ad.vastObject,
                            ad.getOmJsLibrary(),
                            adView,
                            getObstructions(ad));
            measurementManager = Optional.of(manager);
        } catch (NativeVideoMeasurementManager.CanNotInstantiateException e) {
            LogUtils.e("Can not create OM instance.: " + e.getMessage());
        }
    }

    /** OM SDKのロードイベントを送信します */
    private void sendMeasurementLoadedEvent() {
        final NativeVideoMeasurementManager manager;
        final VAMPPlayerAd ad;
        try {
            manager = measurementManager.unwrap();
            ad = this.ad.unwrap();
        } catch (Optional.NotPresentException e) {
            return;
        }
        manager.sendLoaded(ad.getSkipOffset() / 1000.f, ad.canSkip());
    }

    /**
     * OM SDKのビデオイベントを送信します
     *
     * @param event イベントタイプ
     */
    private void sendMeasurementVideoEvent(
            @NonNull final NativeVideoMeasurementManager.VideoEvent event) {
        final NativeVideoMeasurementManager manager;
        try {
            manager = measurementManager.unwrap();
        } catch (Optional.NotPresentException e) {
            return;
        }
        VideoPlayerInfo videoPlayerInfo;
        try {
            SSCoreVideoRewardedAdView pv = playerView.unwrap();
            videoPlayerInfo = new VideoPlayerInfo(pv.getDurationMs() / 1000.f, isMuted);
        } catch (Optional.NotPresentException e) {
            videoPlayerInfo = null;
        }
        manager.sendVideoEvent(event, videoPlayerInfo);
    }

    /** OM SDKのクリックイベントを通知します */
    private void sendMeasurementClickEvent(@NonNull String url) {
        final NativeVideoMeasurementManager manager;
        try {
            manager = measurementManager.unwrap();
        } catch (Optional.NotPresentException e) {
            return;
        }

        if (android.webkit.URLUtil.isNetworkUrl(url)) {
            manager.sendVideoEvent(NativeVideoMeasurementManager.VideoEvent.USER_INTERACTION_CLICK);
        } else {
            manager.sendVideoEvent(
                    NativeVideoMeasurementManager.VideoEvent.USER_INTERACTION_INVITATION_ACCEPTED);
        }
    }

    /** OM SDKに登録する障害物リストを生成します */
    @NonNull
    private ArrayList<Obstruction> getObstructions(@NonNull final VAMPPlayerAd ad) {
        final SSCoreVideoRewardedAdView playerView;
        try {
            playerView = this.playerView.unwrap();
        } catch (Optional.NotPresentException e) {
            return new ArrayList<>();
        }

        final ArrayList<Obstruction> obstructions = new ArrayList<>();

        if (ad.canSkip()) {
            final View v = playerView.getObstructionView(SSCoreObstructionViewType.COUNT_DOWN_VIEW);
            if (v != null) {
                obstructions.add(
                        new Obstruction(v, Obstruction.ObstructedViewType.COUNT_DOWN_VIEW));
            }
        } else {
            final View v = playerView.getObstructionView(SSCoreObstructionViewType.CLOSE_BUTTON);
            if (v != null) {
                obstructions.add(new Obstruction(v, Obstruction.ObstructedViewType.CLOSE_BUTTON));
            }
        }

        {
            final View v = playerView.getObstructionView(SSCoreObstructionViewType.IMARK_BUTTON);
            if (v != null) {
                obstructions.add(new Obstruction(v, Obstruction.ObstructedViewType.IMARK_BUTTON));
            }
        }

        {
            // AdReportButtonを含むフッター全体をobstructionとして登録
            final View v = playerView.getObstructionView(SSCoreObstructionViewType.FOOTER_VIEW);
            if (v != null) {
                obstructions.add(new Obstruction(v, Obstruction.ObstructedViewType.FOOTER_VIEW));
            }
        }

        {
            final View v = playerView.getObstructionView(SSCoreObstructionViewType.SOUND_BUTTON);
            if (v != null) {
                obstructions.add(
                        new Obstruction(v, Obstruction.ObstructedViewType.SOUND_BUTTON_AREA));
            }
        }

        return obstructions;
    }

    private void hideNavigationBar() {
        final View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);
    }

    /** オーディオフォーカス開始 */
    private void startAudioFocus() {
        AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            // TODO: usageはUSAGE_UNKNOWN?
            AudioFocusRequest audioFocusRequest =
                    new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                            .setAudioAttributes(
                                    new AudioAttributes.Builder()
                                            .setUsage(AudioAttributes.USAGE_UNKNOWN)
                                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                                            .build())
                            .setAcceptsDelayedFocusGain(true)
                            .setOnAudioFocusChangeListener(
                                    new AudioManager.OnAudioFocusChangeListener() {
                                        @Override
                                        public void onAudioFocusChange(int focusChange) {
                                            // nothing to do.
                                        }
                                    })
                            .build();
            am.requestAudioFocus(audioFocusRequest);
        } else {
            audioFocusResult =
                    am.requestAudioFocus(
                            audioFocusChangeListener,
                            AudioManager.STREAM_MUSIC,
                            AudioManager.AUDIOFOCUS_GAIN);
        }
    }

    /** オーディオフォーカス終了 */
    private void stopAudioFocus() {
        if (audioFocusResult == AudioManager.AUDIOFOCUS_REQUEST_GRANTED) {
            AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
            if (am != null) {
                am.abandonAudioFocus(audioFocusChangeListener);
            } else {
                LogUtils.devLog("AudioManager null.");
            }
        }
    }

    /** エラー終了します */
    private void failed(@NonNull final VAMPPlayerError error) {
        postPlayerActivityEvent(PlayerActivityEvent.failed(error));
        closeActivity();
    }

    private void play() {
        final VAMPPlayerAd ad;
        final SSCoreVideoRewardedAdView playerView;
        try {
            ad = this.ad.unwrap();
            playerView = this.playerView.unwrap();
        } catch (Optional.NotPresentException ignored) {
            return;
        }

        if (ad.isCompleted()) {
            return;
        }

        playerView.resume();
        sendMeasurementVideoEvent(NativeVideoMeasurementManager.VideoEvent.RESUME);
    }

    private void resume() {
        try {
            ad.unwrap().resume();
        } catch (Optional.NotPresentException ignored) {
        }
    }

    private void pause() {
        try {
            ad.unwrap().pause();
        } catch (Optional.NotPresentException ignored) {
        }
    }

    /**
     * 外部ブラウザでクリックスルーURLを開きます
     *
     * @param url クリックスルーURL
     * @param close trueの場合、外部ブラウザ起動後にこのActivityを閉じます
     */
    private void openClickThrough(@NonNull String url, boolean close) {
        sendTrackingEventClick(url);

        try {
            ExternalAppLauncher.startApp(this, url);
        } catch (ExternalAppLauncher.NotLaunchException ignored) {
        }

        if (close) {
            closeActivity();
        }
    }

    /** 外部アプリでランディングページを開きます */
    private void openLandingPage(@NonNull String landingPageUrl) {
        final VAMPPlayerAd ad;
        try {
            ad = this.ad.unwrap();
        } catch (Optional.NotPresentException e) {
            return;
        }

        ad.sendClickThrough();
        sendTrackingEventClick(landingPageUrl);

        try {
            ExternalAppLauncher.startApp(this, landingPageUrl);
        } catch (ExternalAppLauncher.NotLaunchException ignored) {
        }

        closeActivity();
    }

    private void postPlayerActivityEvent(@NonNull final PlayerActivityEvent event) {
        if (EventBus.getDefault().hasSubscriberForEvent(PlayerActivityEvent.class)) {
            EventBus.getDefault().post(event);
        }
    }

    private void sendTrackingEventClick(@NonNull String url) {
        final VAMPPlayerAd ad;
        try {
            ad = this.ad.unwrap();
        } catch (Optional.NotPresentException e) {
            return;
        }

        postPlayerActivityEvent(new PlayerActivityEvent(PlayerActivityEvent.EVENT_CLICK));
        ad.sendTrackingEventClick();
        sendMeasurementClickEvent(url);
    }

    /** SSCoreVideoRewardedAdViewListener実装 */
    private final SSCoreVideoRewardedAdViewListener vampPlayerListener =
            new SSCoreVideoRewardedAdViewListener() {
                @Override
                public void onPrepared(
                        @NonNull SSCoreVideoRewardedAdView playerView, int durationMs) {
                    LogUtils.d(CLASS_NAME + "#onPrepared called.");

                    final VAMPPlayerAd ad;
                    try {
                        ad = VAMPPlayerActivity.this.ad.unwrap();
                    } catch (Optional.NotPresentException e) {
                        return;
                    }

                    sendMeasurementLoadedEvent();

                    if (ad.getCurrentTime() <= 0) {
                        postPlayerActivityEvent(
                                new PlayerActivityEvent(PlayerActivityEvent.EVENT_BEGIN_PLAYBACK));
                        sendMeasurementVideoEvent(
                                NativeVideoMeasurementManager.VideoEvent.IMPRESSION);
                    }

                    resume();
                }

                @Override
                public void onProgress(
                        @NonNull SSCoreVideoRewardedAdView playerView,
                        int currentMs,
                        int durationMs) {
                    final VAMPPlayerAd ad;
                    try {
                        ad = VAMPPlayerActivity.this.ad.unwrap();
                    } catch (Optional.NotPresentException e) {
                        return;
                    }

                    ad.updatePlaybackTime(currentMs, durationMs);
                }

                @Override
                public void onCompleted(@NonNull SSCoreVideoRewardedAdView playerView) {
                    LogUtils.d(CLASS_NAME + "#onCompleted called.");

                    final VAMPPlayerAd ad;
                    try {
                        ad = VAMPPlayerActivity.this.ad.unwrap();
                    } catch (Optional.NotPresentException e) {
                        return;
                    }

                    ad.completePlayback(playerView.getDurationMs());
                }

                @Override
                public void onSkipped(@NonNull SSCoreVideoRewardedAdView playerView) {
                    LogUtils.d(CLASS_NAME + "#onSkipped called.");

                    sendMeasurementVideoEvent(NativeVideoMeasurementManager.VideoEvent.SKIPPED);
                }

                @Override
                public void onClosed(@NonNull SSCoreVideoRewardedAdView playerView) {
                    LogUtils.d(CLASS_NAME + "#onClosed called.");

                    closeActivity();
                }

                @Override
                public void onLinkTextTapped(@NonNull SSCoreVideoRewardedAdView playerView) {
                    LogUtils.d(CLASS_NAME + "#onLinkTextTapped called.");

                    final VAMPPlayerAd ad;
                    try {
                        ad = VAMPPlayerActivity.this.ad.unwrap();
                    } catch (Optional.NotPresentException e) {
                        return;
                    }

                    try {
                        final String url = ad.selectedClickThrough.unwrap().peekUrl();
                        openClickThrough(url, ad.isCompleted());
                    } catch (Optional.NotPresentException ignored) {
                    }
                }

                @Override
                public void onAdClicked(
                        @NonNull SSCoreVideoRewardedAdView playerView,
                        @NonNull String clickThroughUrl) {
                    LogUtils.d(CLASS_NAME + "#onAdClicked called.");

                    openClickThrough(clickThroughUrl, true);
                }

                @Override
                public void onInstallButtonClicked(
                        @NonNull SSCoreVideoRewardedAdView playerView,
                        @NonNull String landingPageUrl,
                        boolean isAutoInstall) {
                    LogUtils.d(CLASS_NAME + "#onInstallButtonClicked called.");

                    final VAMPPlayerAd ad;
                    try {
                        ad = VAMPPlayerActivity.this.ad.unwrap();
                    } catch (Optional.NotPresentException e) {
                        return;
                    }

                    // PMPは特殊仕様: clickThroughをブラウザで開く（sendClickThrough不要）
                    if (ad.vastObject.getPmpExtension() != null) {
                        openClickThrough(landingPageUrl, true);
                    } else {
                        openLandingPage(landingPageUrl);
                    }
                }

                @Override
                public void onIMarkClicked(
                        @NonNull SSCoreVideoRewardedAdView playerView, @NonNull String url) {
                    LogUtils.d(CLASS_NAME + "#onIMarkClicked called.");

                    // SSCoreが遷移を処理するため、トラッキングのみ実施
                    final VAMPPlayerAd ad;
                    try {
                        ad = VAMPPlayerActivity.this.ad.unwrap();
                    } catch (Optional.NotPresentException e) {
                        return;
                    }

                    ad.sendIMarkClickTracking();
                    sendMeasurementClickEvent(url);
                }

                @Override
                public boolean onCanSkip(@NonNull SSCoreVideoRewardedAdView playerView) {
                    return playerView.getCurrentMs() >= playerView.getAdjustedSkipOffsetMs();
                }

                @Override
                public void onMuteStateChanged(
                        @NonNull SSCoreVideoRewardedAdView playerView, boolean isMuted) {
                    LogUtils.d(CLASS_NAME + "#onMuteStateChanged called. isMuted=" + isMuted);

                    VAMPPlayerActivity.this.isMuted = isMuted;

                    final VAMPPlayerAd ad;
                    try {
                        ad = VAMPPlayerActivity.this.ad.unwrap();
                    } catch (Optional.NotPresentException e) {
                        return;
                    }

                    if (isMuted) {
                        ad.mute();
                        sendMeasurementVideoEvent(
                                NativeVideoMeasurementManager.VideoEvent.VOLUME_CHANGE_OFF);
                    } else {
                        ad.unmute();
                        sendMeasurementVideoEvent(
                                NativeVideoMeasurementManager.VideoEvent.VOLUME_CHANGE_ON);
                    }
                }

                @Override
                public void onEndCardWebViewShown(@NonNull SSCoreVideoRewardedAdView playerView) {
                    LogUtils.d(CLASS_NAME + "#onEndCardWebViewShown called.");

                    final VAMPPlayerAd ad;
                    try {
                        ad = VAMPPlayerActivity.this.ad.unwrap();
                    } catch (Optional.NotPresentException e) {
                        return;
                    }

                    // VAMP旧仕様: WebViewエンドカード表示 = 暗黙的クリック
                    ad.sendClickThrough();

                    try {
                        sendTrackingEventClick(ad.selectedClickThrough.unwrap().peekUrl());
                    } catch (Optional.NotPresentException ignored) {
                    }
                }

                @Override
                public void onBuffering(
                        @NonNull SSCoreVideoRewardedAdView playerView, int percent) {
                    final int currentMs = playerView.getCurrentMs();
                    final int durationMs = playerView.getDurationMs();
                    if (durationMs <= 0) {
                        return;
                    }
                    final int percentile = (currentMs * 100) / durationMs;
                    if (percentile < percent || percentile >= 100) {
                        sendMeasurementVideoEvent(
                                NativeVideoMeasurementManager.VideoEvent.BUFFER_END);
                    } else {
                        sendMeasurementVideoEvent(
                                NativeVideoMeasurementManager.VideoEvent.BUFFER_START);
                    }
                }

                @Override
                public void onError(
                        @NonNull SSCoreVideoRewardedAdView playerView,
                        @NonNull SSCorePlayerError error) {
                    LogUtils.d(CLASS_NAME + "#onError called.");

                    failed(VAMPPlayerError.UNSPECIFIED);
                }
            };

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEvent(@NonNull PlayerEvent event) {
        if (event.isClose()) {
            closeActivity();
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEvent(@NonNull AdEvent event) {
        final SSCoreVideoRewardedAdView playerView;
        try {
            playerView = this.playerView.unwrap();
        } catch (Optional.NotPresentException e) {
            return;
        }

        if (event.isResumeEvent()) {
            try {
                if (screenOffReceiver.unwrap().isScreenUnlocked()) {
                    play();
                }
            } catch (Optional.NotPresentException ignored) {
            }
        }

        if (event.isPauseEvent()) {
            playerView.pause();
            sendMeasurementVideoEvent(NativeVideoMeasurementManager.VideoEvent.PAUSE);
        }

        if (event.isStartEvent()) {
            sendMeasurementVideoEvent(NativeVideoMeasurementManager.VideoEvent.START);
        }

        if (event.isFirstQuartileEvent()) {
            sendMeasurementVideoEvent(NativeVideoMeasurementManager.VideoEvent.FIRST_QUARTILE);
        }

        if (event.isMidpointEvent()) {
            sendMeasurementVideoEvent(NativeVideoMeasurementManager.VideoEvent.MIDPOINT);
        }

        if (event.isThirdQuartileEvent()) {
            sendMeasurementVideoEvent(NativeVideoMeasurementManager.VideoEvent.THIRD_QUARTILE);
        }

        if (event.isCompleteEvent()) {
            ScreenKeep.stop(this);

            sendMeasurementVideoEvent(NativeVideoMeasurementManager.VideoEvent.COMPLETE);

            postPlayerActivityEvent(PlayerActivityEvent.playbackEnded(false));
        }
    }

    private final AudioManager.OnAudioFocusChangeListener audioFocusChangeListener =
            new AudioManager.OnAudioFocusChangeListener() {
                @Override
                public void onAudioFocusChange(int focusChange) {
                    // Nothing to do.
                }
            };
}
