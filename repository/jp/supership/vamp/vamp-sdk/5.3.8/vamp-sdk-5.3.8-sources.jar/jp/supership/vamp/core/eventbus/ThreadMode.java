//
//  Copyright © 2012-2016 Supership Inc. All rights reserved.
//
package jp.supership.vamp.core.eventbus;

/**
 * Each subscriber method has a thread mode, which determines in which thread the method is to be
 * called by EventBus. EventBus takes care of threading independently from the posting thread.
 *
 * @author Markus
 * @see EventBus#register(Object)
 */
public enum ThreadMode {
    /**
     * Subscriber will be called directly in the same thread, which is posting the event. This is
     * the default. Event delivery implies the least overhead because it avoids thread switching
     * completely. Thus this is the recommended mode for simple tasks that are known to complete in
     * a very short time without requiring the main thread. Event handlers using this mode must
     * return quickly to avoid blocking the posting thread, which may be the main thread.
     */
    POSTING,

    /**
     * On Android, subscriber will be called in Android's main thread (UI thread). If the posting
     * thread is the main thread, subscriber methods will be called directly, blocking the posting
     * thread. Otherwise the event is queued for delivery (non-blocking). Subscribers using this
     * mode must return quickly to avoid blocking the main thread. If not on Android, behaves the
     * same as {@link #POSTING}.
     */
    MAIN,

    /**
     * On Android, subscriber will be called in Android's main thread (UI thread). Different from
     * {@link #MAIN}, the event will always be queued for delivery. This ensures that the post call
     * is non-blocking.
     */
    MAIN_ORDERED,

    /**
     * On Android, subscriber will be called in a background thread. If posting thread is not the
     * main thread, subscriber methods will be called directly in the posting thread. If the posting
     * thread is the main thread, EventBus uses a single background thread, that will deliver all
     * its events sequentially. Subscribers using this mode should try to return quickly to avoid
     * blocking the background thread. If not on Android, always uses a background thread.
     */
    BACKGROUND,

    /**
     * Subscriber will be called in a separate thread. This is always independent from the posting
     * thread and the main thread. Posting events never wait for subscriber methods using this mode.
     * Subscriber methods should use this mode if their execution might take some time, e.g. for
     * network access. Avoid triggering a large number of long running asynchronous subscriber
     * methods at the same time to limit the number of concurrent threads. EventBus uses a thread
     * pool to efficiently reuse threads from completed asynchronous subscriber notifications.
     */
    ASYNC
}
