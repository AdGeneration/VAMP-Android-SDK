//
//  Copyright © 2026 Supership Inc. All rights reserved.
//
package jp.supership.vamp.player;

import android.content.Intent;
import android.net.Uri;
import android.text.TextUtils;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import java.io.Serializable;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import jp.supership.sscore.vamp.type.Optional;

public final class LandingPage implements Serializable {
    /** Google Play Storeアプリ起動URL */
    private static final String PLAY_STORE_SCHEME_URL = "market://details";

    /** Google Play StoreのappsカテゴリのScheme Specific Part */
    private static final String PLAY_STORE_APPS_SSP = "//play.google.com/store/apps/details?";

    /** LINEスタンプのScheme Specific Part */
    private static final String LINE_STAMP_SSP = "//store.line.me/stickershop/product/";

    /** LINEアプリ起動URL (スタンプ) */
    private static final String LINE_STAMP_SCHEME_URL = "line://shop/detail/";

    /** LINE着せ替えのScheme Specific Part */
    private static final String LINE_THEME_SSP = "//store.line.me/themeshop/product/";

    /** LINEアプリ起動URL (着せ替え) */
    private static final String LINE_THEME_SCHEME_URL = "line://shop/theme/detail";

    public enum SchemeType {
        WEB,
        INTENT,
        CUSTOM,
    }

    /** インスタンスを生成できません。詳細はmessageを参照してください */
    public static final class CanNotInstantiateException extends Exception {
        CanNotInstantiateException(String message) {
            super(message);
        }
    }

    @NonNull public final String url;
    @NonNull public final SchemeType schemeType;

    public LandingPage(@Nullable final String aUrl) throws CanNotInstantiateException {
        if (TextUtils.isEmpty(aUrl)) {
            throw new CanNotInstantiateException("url is null or empty.");
        }
        assert aUrl != null;

        url = convertUrl(aUrl);

        final Uri uri;
        try {
            uri = Uri.parse(url);
        } catch (Exception e) {
            throw new CanNotInstantiateException(e.toString());
        }

        final String scheme = uri.getScheme();
        if ("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme)) {
            schemeType = SchemeType.WEB;
        } else if ("intent".equalsIgnoreCase(scheme)) {
            schemeType = SchemeType.INTENT;
        } else if ("android-app".equalsIgnoreCase(scheme)
                || "market".equalsIgnoreCase(scheme)
                || // Play Store
                "line".equalsIgnoreCase(scheme)) { // LINE
            schemeType = SchemeType.CUSTOM;
        } else if ("file".equalsIgnoreCase(scheme)) {
            // fileスキームはセキュリティの観点から対応しない
            throw new CanNotInstantiateException("file scheme is not supported.");
        } else {
            throw new CanNotInstantiateException("Unhandled scheme.");
        }
    }

    @NonNull
    private static String convertUrl(@NonNull final String url) throws CanNotInstantiateException {
        // 現状、market://はappsカテゴリしか対応していないのでappsの時のみmarket://に変換
        if (url.contains(PLAY_STORE_APPS_SSP)) {
            final Uri uri;
            try {
                uri = Uri.parse(url);
            } catch (Exception e) {
                throw new CanNotInstantiateException(e.toString());
            }
            return PLAY_STORE_SCHEME_URL + "?" + uri.getEncodedQuery();
        }

        final int lineStampSspIdx = url.indexOf(LINE_STAMP_SSP);
        if (lineStampSspIdx != -1) {
            final String[] params =
                    url.substring(lineStampSspIdx + LINE_STAMP_SSP.length()).split("/", 2);
            if (params.length >= 1) {
                return LINE_STAMP_SCHEME_URL + params[0];
            }
        }

        final int lineThemeSspIdx = url.indexOf(LINE_THEME_SSP);
        if (lineThemeSspIdx != -1) {
            final String[] params =
                    url.substring(lineThemeSspIdx + LINE_THEME_SSP.length()).split("/", 2);
            if (params.length >= 1) {
                return LINE_THEME_SCHEME_URL + "?id=" + params[0];
            }
        }

        // http(s)://any-scheme://...のときhttp(s)://を除去
        final Pattern pattern = Pattern.compile("(https://|http://)\\w+://.*");
        final Matcher matcher = pattern.matcher(url);
        if (matcher.find()) {
            final String result = matcher.group(1);
            if (result != null) {
                return url.replace(result, "");
            }
        }

        return url;
    }

    @NonNull
    @Override
    public String toString() {
        return "LandingPage { url=" + url + " schemeType=" + schemeType + " }";
    }

    /**
     * `url`をUriオブジェクトに変換します。この変換は必ず成功することが保証されています
     *
     * @return Uriオブジェクト
     */
    @NonNull
    public Uri toUri() {
        return Uri.parse(url);
    }

    /**
     * Webコンテンツかどうかを返します
     *
     * @return Webコンテンツの場合はtrue
     */
    public boolean isWebContent() {
        return schemeType == SchemeType.WEB;
    }

    /**
     * 自動インストールが利用可能かどうかを返します
     *
     * @return 自動インストールが利用可能な場合はtrue
     */
    public boolean isAutoInstallAvailable() {
        return !isWebContent();
    }

    /**
     * カスタムスキームの場合、ブラウザで開けるようにURLを変換します。<br>
     * カスタムスキームではない、またはURL変換できない場合はOptional.empty()を返します。
     *
     * @return 変換後のURL
     */
    @NonNull
    Optional<String> fallbackUrlIfCustomScheme() {
        if (schemeType != SchemeType.CUSTOM) {
            return Optional.empty();
        }

        final String fallbackUrl;
        if (url.startsWith(PLAY_STORE_SCHEME_URL)) {
            final String param = url.replace(PLAY_STORE_SCHEME_URL + "?", "");
            fallbackUrl = "https:" + PLAY_STORE_APPS_SSP + param;
        } else if (url.startsWith(LINE_STAMP_SCHEME_URL)) {
            final String comp = url.replace(LINE_STAMP_SCHEME_URL, "");
            fallbackUrl = "https:" + LINE_STAMP_SSP + comp;
        } else if (url.startsWith(LINE_THEME_SCHEME_URL)) {
            final String comp = url.replace(LINE_THEME_SCHEME_URL + "?id=", "");
            fallbackUrl = "https:" + LINE_THEME_SSP + comp;
        } else {
            fallbackUrl = null;
        }
        return Optional.of(fallbackUrl);
    }

    /**
     * intentスキームであればIntentSchemeUriオブジェクトを生成し、それ以外であればOptional.empty()を返します
     *
     * @return IntentSchemeUriオブジェクト
     */
    @NonNull
    Optional<IntentSchemeUri> intentSchemeUri() {
        if (schemeType == SchemeType.INTENT) {
            return Optional.of(IntentSchemeUri.parse(toUri()));
        } else {
            return Optional.empty();
        }
    }

    /**
     * intentスキームの仕様は<br>
     * <a href="https://developer.chrome.com/docs/multidevice/android/intents/">Android Intents with
     * Chrome</a><br>
     * を参照してください
     */
    static final class IntentSchemeUri {
        private final @NonNull Uri uri;
        @NonNull final Optional<String> scheme;
        @NonNull final String action;
        @NonNull final Optional<String> packageName;
        @NonNull final Optional<String> category;

        private IntentSchemeUri(
                @NonNull final Uri uri,
                @Nullable final String scheme,
                @NonNull final String action,
                @Nullable final String packageName,
                @Nullable final String category) {
            this.uri = uri;
            this.scheme =
                    TextUtils.isEmpty(scheme) ? Optional.<String>empty() : Optional.of(scheme);
            this.action = action;
            this.packageName =
                    TextUtils.isEmpty(packageName)
                            ? Optional.<String>empty()
                            : Optional.of(packageName);
            this.category =
                    TextUtils.isEmpty(category) ? Optional.<String>empty() : Optional.of(category);
        }

        @NonNull
        private static IntentSchemeUri parse(@NonNull final Uri uri) {
            String scheme = null;
            String action = Intent.ACTION_VIEW;
            String packageName = null;
            String category = null;

            final String[] fragments = uri.getEncodedFragment().split(";");
            for (String fragment : fragments) {
                String[] comps = fragment.split("=");
                if (comps.length >= 2) {
                    switch (comps[0]) {
                        case "scheme":
                            scheme = comps[1];
                            break;
                        case "action":
                            action = comps[1];
                            break;
                        case "package":
                            packageName = comps[1];
                            break;
                        case "category":
                            category = comps[1];
                            break;
                            // case "component":
                            // componentはActivityを直指定できるため、セキュリティの観点から実装しない
                    }
                }
            }

            return new IntentSchemeUri(uri, scheme, action, packageName, category);
        }

        @NonNull
        @Override
        public String toString() {
            return "" + uri;
        }

        @NonNull
        String schemeSpecificPart() {
            return uri.getEncodedSchemeSpecificPart();
        }

        /** `packageName`がある場合はPlay StoreのURIを返し、ない場合はOptional.empty()を返します */
        @NonNull
        Optional<Uri> playStoreUri() {
            if (TextUtils.isEmpty(packageName.orElse(""))) {
                return Optional.empty();
            }

            try {
                return Optional.of(
                        Uri.parse(
                                LandingPage.PLAY_STORE_SCHEME_URL + "?id=" + packageName.forced()));
            } catch (Exception e) {
                return Optional.empty();
            }
        }
    }
}
