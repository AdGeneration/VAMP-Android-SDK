//
//  Copyright © 2026 Supership Inc. All rights reserved.
//
package jp.supership.vamp.player;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.text.TextUtils;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.VisibleForTesting;
import java.io.Serializable;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import jp.supership.sscore.vamp.device.SSCoreReachability;
import jp.supership.sscore.vamp.http.SSCoreHttp;
import jp.supership.sscore.vamp.sequence.Sequencer;
import jp.supership.sscore.vamp.type.Optional;
import jp.supership.sscore.vamp.type.Result;
import jp.supership.vamp.VASTAdapter;
import jp.supership.vamp.core.error.VAMPInternalError;
import jp.supership.vamp.core.error.VAMPInternalException;
import jp.supership.vamp.core.eventbus.EventBus;
import jp.supership.vamp.core.logging.LogUtils;
import jp.supership.vamp.core.utils.VAMPList;
import jp.supership.vamp.core.vast.VASTAPCExtension;
import jp.supership.vamp.core.vast.VASTCompanion;
import jp.supership.vamp.core.vast.VASTEndCard;
import jp.supership.vamp.core.vast.VASTIcon;
import jp.supership.vamp.core.vast.VASTMediaFile;
import jp.supership.vamp.core.vast.VASTMediaFileComparator;
import jp.supership.vamp.core.vast.VASTObject;
import jp.supership.vamp.core.vast.VASTResource;
import jp.supership.vamp.measurement.IOmSdkLoader;
import jp.supership.vamp.measurement.OnJsLibraryFetchListener;

public final class VAMPPlayerAd {
    enum State {
        DEFAULT,
        START,
        FIRST_QUARTILE,
        MIDPOINT,
        THIRD_QUARTILE,
        COMPLETE
    }

    public interface ICreateListener {
        void onComplete(@Nullable VAMPPlayerAd ad, @Nullable VAMPInternalError error);
    }

    interface ILogListener {
        /**
         * @param log 公開されるログ
         * @param devLog 開発用ログ(非公開ログ)
         */
        void onLog(@NonNull String log, @Nullable String devLog);
    }

    /** インスタンスを生成できません。詳細はmessageを参照してください */
    public static final class CanNotInstantiateException extends Exception {
        CanNotInstantiateException(String message) {
            super(message);
        }
    }

    @NonNull public final VASTObject vastObject;
    @NonNull public final VASTMediaFile selectedMediaFile;
    @NonNull public final Optional<VASTAPCExtension> selectedExtension;
    @NonNull public final Optional<VASTEndCard> selectedEndCard;
    @NonNull public final Optional<VASTIcon> selectedIcon;
    @NonNull public final Optional<LandingPage> selectedLandingPage;

    /** クリックスルーURL */
    @NonNull public final Optional<ClickThrough> selectedClickThrough;

    @NonNull private State state = State.DEFAULT;
    private float currentTime;
    private boolean isResuming;

    /** omsdk.js */
    @NonNull private Optional<String> omJsLibrary = Optional.empty();

    @Nullable private ILogListener logListener;

    @NonNull private Optional<String> placementId = Optional.empty();
    @NonNull private Optional<VAMPCreativeInfo> creativeInfo = Optional.empty();

    public static boolean isAvailable(@Nullable final Context context) {
        // 参照できるContextがない
        if (context == null) {
            LogUtils.w("VAMPAd must have application context.");
            return false;
        }

        // permission check(INTERNET)
        boolean permissionInternet =
                context.checkCallingOrSelfPermission(Manifest.permission.INTERNET)
                        == PackageManager.PERMISSION_GRANTED;
        if (!permissionInternet) {
            LogUtils.w("INTERNET permission not found.");
            return false;
        }

        // permission check(ACCESS_NETWORK_STATE)
        boolean permissionANS =
                context.checkCallingOrSelfPermission(Manifest.permission.ACCESS_NETWORK_STATE)
                        == PackageManager.PERMISSION_GRANTED;
        if (!permissionANS) {
            LogUtils.w("ACCESS_NETWORK_STATE permission not found.");
            return false;
        }
        return true;
    }

    public static void create(
            @Nullable final Context appContext,
            @Nullable final VASTObject vastObject,
            @Nullable final String actualLandingUrlString,
            @Nullable final String placementId,
            @Nullable final VAMPCreativeInfo creativeInfo,
            @NonNull final IOmSdkLoader omSdkLoader,
            @NonNull final SSCoreReachability.Reachable2 reachability,
            @NonNull final ICreateListener listener) {
        if (!isAvailable(appContext)) {
            listener.onComplete(
                    null,
                    new VAMPInternalError(VAMPInternalError.Code.SETTING_ERROR, "setting error."));
            return;
        }

        // TODO: ここでネットワーク接続状態を確認する必要あるか? MediationManagerクラスなど上位レイヤーで確認する方が適切?
        if (!reachability.isReachable()) {
            // ネットワークの接続がない
            LogUtils.w("Need network connection");
            listener.onComplete(
                    null,
                    new VAMPInternalError(
                            VAMPInternalError.Code.NEED_CONNECTION, "Need Connection"));
            return;
        }

        new Sequencer(
                        completable -> {
                            try {
                                final VAMPPlayerAd ad =
                                        new VAMPPlayerAd(vastObject, actualLandingUrlString);
                                ad.placementId = Optional.of(placementId);
                                ad.creativeInfo = Optional.of(creativeInfo);
                                completable.onComplete(Result.success(ad));
                            } catch (CanNotInstantiateException e) {
                                completable.onComplete(
                                        Result.failure(
                                                VAMPInternalException.fileNotFound(
                                                        e.getMessage())));
                            }
                        })
                .then(
                        (result, completable) -> {
                            final VAMPPlayerAd ad = (VAMPPlayerAd) result.maybe();
                            assert ad != null;
                            ad.selectedMediaFile.loadMediaFile(
                                    appContext,
                                    new VASTMediaFile.ILoadListener() {
                                        @Override
                                        public void onCompleted(
                                                Optional<String> videoFileUrl,
                                                Optional<VAMPInternalError> error) {
                                            try {
                                                final VAMPInternalError e = error.unwrap();
                                                completable.onComplete(
                                                        Result.failure(
                                                                new VAMPInternalException(e)));
                                            } catch (Optional.NotPresentException ignored) {
                                                // Success
                                                completable.onComplete(Result.success(ad));
                                            }
                                        }
                                    });
                        })
                .then(
                        (result, completable) -> {
                            final VAMPPlayerAd ad = (VAMPPlayerAd) result.maybe();
                            assert ad != null;

                            try {
                                ad.selectedEndCard
                                        .unwrap()
                                        .load(
                                                appContext,
                                                new VASTEndCard.ILoadListener() {
                                                    @Override
                                                    public void onCompleted(
                                                            VASTEndCard endCard,
                                                            VAMPInternalError error) {
                                                        if (error != null) {
                                                            completable.onComplete(
                                                                    Result.failure(
                                                                            new VAMPInternalException(
                                                                                    error)));
                                                        } else {
                                                            completable.onComplete(
                                                                    Result.success(ad));
                                                        }
                                                    }
                                                });
                            } catch (Optional.NotPresentException e) {
                                LogUtils.d("No EndCard.");
                                completable.onComplete(Result.success(ad));
                            }
                        })
                .then(
                        (result, completable) -> {
                            final VAMPPlayerAd ad = (VAMPPlayerAd) result.maybe();
                            assert ad != null;
                            try {
                                ad.selectedIcon
                                        .unwrap()
                                        .getStaticResource()
                                        .load(
                                                appContext,
                                                new VASTResource.ILoadListener() {
                                                    @Override
                                                    public void onCompleted(
                                                            VASTResource resource,
                                                            VAMPInternalError error) {
                                                        if (error != null) {
                                                            completable.onComplete(
                                                                    Result.failure(
                                                                            new VAMPInternalException(
                                                                                    error)));
                                                        } else {
                                                            completable.onComplete(
                                                                    Result.success(ad));
                                                        }
                                                    }
                                                });
                            } catch (Optional.NotPresentException e) {
                                LogUtils.d("No Icon.");
                                completable.onComplete(Result.success(ad));
                            }
                        })
                .then(
                        (result, completable) -> {
                            final VAMPPlayerAd ad = (VAMPPlayerAd) result.maybe();
                            assert ad != null;

                            if (ad.vastObject.getVerificationExtensions().isEmpty()) {
                                completable.onComplete(Result.success(ad));
                                return;
                            }

                            omSdkLoader.load(
                                    new OnJsLibraryFetchListener() {
                                        @Override
                                        public void onJsLibraryFetch(@NonNull Optional<String> js) {
                                            ad.omJsLibrary = js;
                                            completable.onComplete(Result.success(ad));
                                        }
                                    });
                        })
                .run(
                        result -> {
                            VAMPInternalException exception = null;
                            try {
                                exception = ((VAMPInternalException) result.error.unwrap());
                            } catch (Optional.NotPresentException ignored) {

                            }

                            listener.onComplete(
                                    (VAMPPlayerAd) result.data.maybe(),
                                    exception != null ? exception.error : null);
                        });
    }

    @VisibleForTesting
    public VAMPPlayerAd(
            @Nullable final VASTObject vastObject, @Nullable final String actualLandingUrlString)
            throws CanNotInstantiateException {
        if (vastObject == null) {
            throw new CanNotInstantiateException("vastObject is null.");
        }
        this.vastObject = vastObject.collectedObject();
        this.selectedMediaFile = selectBestMediaFileOfAd(this);
        this.selectedExtension = selectExtensionOfAd(this);
        this.selectedEndCard = selectEndCardOfAd(this);
        this.selectedLandingPage = selectLandingUrlOfAd(this, actualLandingUrlString);
        this.selectedClickThrough = selectClickThroughUrlOfAd(this);
        this.selectedIcon = selectIndustryIcon(vastObject);
    }

    private VAMPPlayerAd(@Nullable final SerializableObject object)
            throws CanNotInstantiateException {
        if (object == null) {
            throw new CanNotInstantiateException("SerializableObject is null.");
        }

        this.vastObject = object.vastObject;
        this.selectedMediaFile = object.selectedMediaFile;
        this.selectedExtension = Optional.of(object.selectedExtension);
        this.selectedEndCard = Optional.of(object.selectedEndCard);
        this.selectedIcon = Optional.of(object.selectedIcon);
        this.selectedLandingPage = Optional.of(object.selectedLandingPage);
        this.selectedClickThrough = Optional.of(object.selectedClickThrough);
        this.state = object.state;
        this.currentTime = object.currentTime;
        this.isResuming = object.isResuming;
        this.omJsLibrary = Optional.of(object.omJsLibrary);
        this.placementId = Optional.of(object.placementId);
        this.creativeInfo = Optional.of(object.creativeInfo);
    }

    @NonNull
    static Optional<VAMPPlayerAd> from(@Nullable final SerializableObject object) {
        try {
            return Optional.of(new VAMPPlayerAd(object));
        } catch (CanNotInstantiateException e) {
            return Optional.empty();
        }
    }

    void setLogListener(@Nullable final ILogListener listener) {
        logListener = listener;
    }

    @NonNull
    public String getLinkText() {
        final String linkText = vastObject.getLinkText();
        if (!TextUtils.isEmpty(linkText)) {
            return linkText;
        } else {
            return "";
        }
    }

    public boolean isLoaded(Context context) {
        final boolean isLoaded = selectedMediaFile.isLoaded(context);
        try {
            return isLoaded && selectedEndCard.unwrap().isLoaded(context);
        } catch (Optional.NotPresentException ignored) {
            return true;
        }
    }

    public boolean isNotStarted() {
        return state.ordinal() < State.START.ordinal();
    }

    public boolean isCompleted() {
        return state == State.COMPLETE;
    }

    public void setState(@NonNull State state) {
        // スキップした場合、間のステータスをスキップしてCOMPLETEに遷移する可能性があるため
        // COMPLETEのみ前ステータスに影響されない
        if (!(this.state.ordinal() + 1 == state.ordinal() || state == State.COMPLETE)) {
            return;
        }

        this.state = state;

        switch (state) {
            case START:
                if (EventBus.getDefault().hasSubscriberForEvent(AdEvent.class)) {
                    EventBus.getDefault().post(new AdEvent(AdEvent.EVENT_START));
                }

                vastObject.sendTrackingEventStart(
                        null,
                        new VASTObject.VASTEventListener() {
                            @Override
                            public void onComplete(URL url, VAMPInternalError error) {
                                logForSendTrackingEvent("start", url, error);
                            }
                        });
                break;
            case FIRST_QUARTILE:
                if (EventBus.getDefault().hasSubscriberForEvent(AdEvent.class)) {
                    EventBus.getDefault().post(new AdEvent(AdEvent.EVENT_FIRST_QUARTILE));
                }

                vastObject.sendTrackingEventFirstQuartile(
                        null,
                        new VASTObject.VASTEventListener() {
                            @Override
                            public void onComplete(URL url, VAMPInternalError error) {
                                logForSendTrackingEvent("first-quartile", url, error);
                            }
                        });
                break;
            case MIDPOINT:
                if (EventBus.getDefault().hasSubscriberForEvent(AdEvent.class)) {
                    EventBus.getDefault().post(new AdEvent(AdEvent.EVENT_MIDPOINT));
                }

                vastObject.sendTrackingEventMidpoint(
                        null,
                        new VASTObject.VASTEventListener() {
                            @Override
                            public void onComplete(URL url, VAMPInternalError error) {
                                logForSendTrackingEvent("midpoint", url, error);
                            }
                        });
                break;
            case THIRD_QUARTILE:
                if (EventBus.getDefault().hasSubscriberForEvent(AdEvent.class)) {
                    EventBus.getDefault().post(new AdEvent(AdEvent.EVENT_THIRD_QUARTILE));
                }

                vastObject.sendTrackingEventThirdQuartile(
                        null,
                        new VASTObject.VASTEventListener() {
                            @Override
                            public void onComplete(URL url, VAMPInternalError error) {
                                logForSendTrackingEvent("third-quartile", url, error);
                            }
                        });
                break;
            case COMPLETE:
                if (EventBus.getDefault().hasSubscriberForEvent(AdEvent.class)) {
                    EventBus.getDefault().post(new AdEvent(AdEvent.EVENT_COMPLETE));
                }

                vastObject.sendTrackingEventComplete(
                        null,
                        new VASTObject.VASTEventListener() {
                            @Override
                            public void onComplete(URL url, VAMPInternalError error) {
                                logForSendTrackingEvent("complete", url, error);
                            }
                        });
                break;
        }
    }

    public boolean updatePlaybackTime(int time, int duration) {
        if (!isResuming || isCompleted()) {
            LogUtils.devLog(
                    "isResuming:" + isResuming + " isCompleted:" + isCompleted() + " time:" + time);
            return false;
        }

        currentTime = time;

        double currentSec = time / 1000.0;
        double durationSec = duration / 1000.0;

        if (currentSec > 0 && isNotStarted()) {
            // キャンセル可能モードのときはIMPをCompleteのタイミングで発火させる.
            vastObject.sendTrackingEventImpression(
                    null,
                    new VASTObject.VASTEventListener() {
                        @Override
                        public void onComplete(URL url, VAMPInternalError error) {
                            logForSendTrackingEvent("impression", url, error);
                        }
                    });

            vastObject.sendTrackingEventCreativeView(
                    null,
                    new VASTObject.VASTEventListener() {
                        @Override
                        public void onComplete(URL url, VAMPInternalError error) {
                            logForSendTrackingEvent("creative-view", url, error);
                        }
                    });

            setState(State.START);
        }

        if (currentSec > durationSec * 0.25 && state.compareTo(State.FIRST_QUARTILE) < 0) {
            setState(State.FIRST_QUARTILE);
        }

        if (currentSec > durationSec * 0.5 && state.compareTo(State.MIDPOINT) < 0) {
            setState(State.MIDPOINT);
        }

        if (currentSec > durationSec * 0.75 && state.compareTo(State.THIRD_QUARTILE) < 0) {
            setState(State.THIRD_QUARTILE);
        }

        final double percentile = currentSec / durationSec;
        vastObject.sendTrackingEventProgress(
                null,
                new VASTObject.VASTEventListener() {
                    @Override
                    public void onComplete(URL url, VAMPInternalError error) {
                        logForSendTrackingEvent("progress", url, error);
                    }
                },
                (long) (currentSec * 1000),
                (float) (percentile * 100.0f));

        return true;
    }

    public void completePlayback(float duration) {
        if (isCompleted()) {
            return;
        }

        final double durationSec = duration / 1000;

        if (durationSec > 0) {
            // 再生終了間際だとプログレスが100%に達する前に状態遷移する可能性があるため,ここでも送信しておく.
            // ただし,プログラムで重複送信されないことが保証されていること
            vastObject.sendTrackingEventProgress(
                    null,
                    new VASTObject.VASTEventListener() {
                        @Override
                        public void onComplete(URL url, VAMPInternalError error) {
                            logForSendTrackingEvent("progress", url, error);
                        }
                    },
                    (long) (durationSec * 1000),
                    100.f);
        }

        setState(State.COMPLETE);
    }

    public void mute() {
        vastObject.sendTrackingEventMute(
                null,
                new VASTObject.VASTEventListener() {
                    @Override
                    public void onComplete(URL url, VAMPInternalError error) {
                        logForSendTrackingEvent("mute", url, error);
                    }
                });
    }

    public void unmute() {
        vastObject.sendTrackingEventUnmute(
                null,
                new VASTObject.VASTEventListener() {
                    @Override
                    public void onComplete(URL url, VAMPInternalError error) {
                        logForSendTrackingEvent("unmute", url, error);
                    }
                });
    }

    public void pause() {
        if (!isResuming) {
            return;
        }
        isResuming = false;

        vastObject.sendTrackingEventPause(
                null,
                new VASTObject.VASTEventListener() {
                    @Override
                    public void onComplete(URL url, VAMPInternalError error) {
                        logForSendTrackingEvent("pause", url, error);
                    }
                });

        if (EventBus.getDefault().hasSubscriberForEvent(AdEvent.class)) {
            EventBus.getDefault().post(new AdEvent(AdEvent.EVENT_PAUSE));
        }
    }

    public void resume() {
        if (isCompleted() || isResuming) {
            return;
        }
        isResuming = true;

        vastObject.sendTrackingEventResume(
                null,
                new VASTObject.VASTEventListener() {
                    @Override
                    public void onComplete(URL url, VAMPInternalError error) {
                        logForSendTrackingEvent("resume", url, error);
                    }
                });

        if (EventBus.getDefault().hasSubscriberForEvent(AdEvent.class)) {
            EventBus.getDefault().post(new AdEvent(AdEvent.EVENT_RESUME));
        }
    }

    @NonNull
    private static VASTMediaFile selectBestMediaFileOfAd(@NonNull final VAMPPlayerAd ad)
            throws CanNotInstantiateException {
        if (ad.vastObject.getMediaFiles() == null) {
            throw new CanNotInstantiateException("vastObject.mediaFiles is null.");
        }

        VAMPList<VASTMediaFile> mediaFiles = ad.vastObject.getMediaFiles();

        Collections.sort(mediaFiles, new VASTMediaFileComparator());

        if (mediaFiles.size() > 1) {
            return mediaFiles.get(1);
        } else if (mediaFiles.size() > 0) {
            return mediaFiles.get(0);
        }

        throw new CanNotInstantiateException("vastObject.mediaFiles is empty.");
    }

    @NonNull
    private static Optional<VASTAPCExtension> selectExtensionOfAd(@NonNull final VAMPPlayerAd ad) {
        if (ad.vastObject.getApcExtensions() != null
                && ad.vastObject.getApcExtensions().size() > 0) {
            return Optional.of(ad.vastObject.getApcExtensions().get(0));
        }

        return Optional.empty();
    }

    @NonNull
    private static Optional<VASTEndCard> selectEndCardOfAd(@NonNull final VAMPPlayerAd ad) {
        if (ad.vastObject.getCompanions() != null && ad.vastObject.getCompanions().size() > 0) {
            final VASTEndCard endCard = ad.vastObject.getCompanions().get(0).getEndCard();
            if (endCard != null) {
                return Optional.of(endCard);
            }
        }

        try {
            final VASTAPCExtension extension = ad.selectedExtension.unwrap();

            if (extension.isApc() && extension.getEndCards().size() > 0) {
                return Optional.of(extension.getEndCards().get(0));
            }
        } catch (Optional.NotPresentException ignored) {
        }

        return Optional.of(ad.vastObject.getEndCard());
    }

    @NonNull
    private static Optional<LandingPage> selectLandingUrlOfAd(
            @NonNull final VAMPPlayerAd ad, @Nullable final String actualLandingUrlString) {
        try {
            final VASTAPCExtension extension = ad.selectedExtension.unwrap();

            if (extension.isApc()) {
                return Optional.of(new LandingPage(extension.getLpURLString()));
            }
        } catch (Optional.NotPresentException | LandingPage.CanNotInstantiateException ignored) {
        }

        try {
            return Optional.of(new LandingPage(actualLandingUrlString));
        } catch (LandingPage.CanNotInstantiateException e) {
            return Optional.empty();
        }
    }

    /**
     * @return ClickThroughオブジェクトのOptional。 ClickThroughオブジェクトが生成できない場合はOptional.empty()を返します
     */
    @NonNull
    private static Optional<ClickThrough> selectClickThroughUrlOfAd(
            @NonNull final VAMPPlayerAd ad) {
        final VAMPList<VASTCompanion> companions = ad.vastObject.getCompanions();
        if (companions.size() > 0) {
            final String url = companions.get(0).getClickThroughURLString();
            try {
                return Optional.of(new ClickThrough(url, SSCoreHttp.newClient()));
            } catch (ClickThrough.CanNotInstantiateException ignored) {
            }
        }

        final String url = ad.vastObject.getClickThroughURLString();
        try {
            return Optional.of(new ClickThrough(url, SSCoreHttp.newClient()));
        } catch (ClickThrough.CanNotInstantiateException e) {
            return Optional.empty();
        }
    }

    @NonNull
    private static Optional<VASTIcon> selectIndustryIcon(@NonNull final VASTObject vastObject) {
        // VASTにapiFramework="adg"があれば優先する
        final ArrayList<VASTIcon> icons =
                vastObject
                        .getIcons()
                        .select(
                                new VAMPList.IFindListener<VASTIcon>() {
                                    @Override
                                    public boolean where(VASTIcon result) {
                                        return result.isAdg();
                                    }
                                });
        if (icons != null && icons.size() > 0) {
            return Optional.of(icons.get(0));
        }

        // closest(wrapperをたどっていく過程でもっともルートから離れたところにあるVASTの先頭を位置する)
        final VASTObject closest = vastObject.getClosestVASTObject();
        if (closest != null) {
            final ArrayList<VASTIcon> icons2 = closest.getIcons();
            if (icons2 != null && icons2.size() > 0) {
                return Optional.of(icons2.get(0));
            }
        }

        return Optional.empty();
    }

    void sendIMarkClickTracking() {
        try {
            selectedIcon
                    .unwrap()
                    .sendTrackings(
                            null,
                            new VASTObject.VASTEventListener() {
                                @Override
                                public void onComplete(URL url, VAMPInternalError error) {
                                    logForSendTrackingEvent("i-mark-click", url, error);
                                }
                            });
        } catch (Optional.NotPresentException ignored) {
        }
    }

    /** クリックスルーURLに対してHTTPリクエストを実行します */
    void sendClickThrough() {
        try {
            selectedClickThrough.unwrap().send();
        } catch (Optional.NotPresentException | ClickThrough.AlreadyConsumedException ignored) {
        }
    }

    /** トラッキングイベント(クリック)を送信します */
    void sendTrackingEventClick() {
        vastObject.sendTrackingEventClick(
                null,
                new VASTObject.VASTEventListener() {
                    @Override
                    public void onComplete(URL url, VAMPInternalError error) {
                        logForSendTrackingEvent("click", url, error);
                    }
                });
    }

    public float getCurrentTime() {
        return currentTime;
    }

    @NonNull
    public Optional<String> getOmJsLibrary() {
        return omJsLibrary;
    }

    /**
     * @return trueならば、この広告は動画視聴をスキップして、報酬受け取り可能状態に遷移できます
     */
    public boolean canSkip() {
        return vastObject.isPlayerCancelable();
    }

    public int getSkipOffset() {
        return vastObject.getSkipOffset();
    }

    @NonNull
    public String getAdNetworkName() {
        final String adNetworkName = VASTAdapter.ADNETWORK_NAME;
        try {
            final VASTAPCExtension extension = selectedExtension.unwrap();
            return String.format("%s(%s)", adNetworkName, extension.getAdnw());
        } catch (Optional.NotPresentException ignored) {
        }

        return String.format("%s(%s)", adNetworkName, vastObject.getAdSystem());
    }

    @NonNull
    public Optional<String> getPlacementId() {
        return placementId;
    }

    @NonNull
    public Optional<VAMPCreativeInfo> getCreativeInfo() {
        return creativeInfo;
    }

    /** IntentやBundleに格納できるようにSerializableインタフェースを実装したオブジェクトに変換します */
    @NonNull
    SerializableObject serialized() {
        return new SerializableObject(
                vastObject,
                selectedMediaFile,
                selectedExtension.maybe(),
                selectedEndCard.maybe(),
                selectedIcon.maybe(),
                selectedLandingPage.maybe(),
                selectedClickThrough.maybe(),
                state,
                currentTime,
                isResuming,
                omJsLibrary.maybe(),
                placementId.maybe(),
                creativeInfo.maybe());
    }

    private void logForSendTrackingEvent(
            @NonNull final String event,
            @Nullable final URL url,
            @Nullable final VAMPInternalError error) {
        if (logListener == null) {
            return;
        }

        final String errMsg = error != null ? " error=" + error.message : "";
        final String devLog = url != null ? url.toString() : null;
        logListener.onLog("Sent tracking event:" + event + errMsg, devLog);
    }

    static final class SerializableObject implements Serializable {
        @NonNull final VASTObject vastObject;
        @NonNull final VASTMediaFile selectedMediaFile;
        @Nullable final VASTAPCExtension selectedExtension;
        @Nullable final VASTEndCard selectedEndCard;
        @Nullable final VASTIcon selectedIcon;
        @Nullable final LandingPage selectedLandingPage;
        @Nullable final ClickThrough selectedClickThrough;
        @NonNull final VAMPPlayerAd.State state;
        final float currentTime;
        final boolean isResuming;
        @Nullable final String omJsLibrary;

        @Nullable final String placementId;
        @Nullable final VAMPCreativeInfo creativeInfo;

        SerializableObject(
                @NonNull final VASTObject vastObject,
                @NonNull final VASTMediaFile selectedMediaFile,
                @Nullable final VASTAPCExtension selectedExtension,
                @Nullable final VASTEndCard selectedEndCard,
                @Nullable final VASTIcon selectedIcon,
                @Nullable final LandingPage selectedLandingPage,
                @Nullable final ClickThrough selectedClickThrough,
                @NonNull final VAMPPlayerAd.State state,
                final float currentTime,
                final boolean isResuming,
                @Nullable final String omJsLibrary,
                @Nullable final String placementId,
                @Nullable final VAMPCreativeInfo creativeInfo) {
            this.vastObject = vastObject;
            this.selectedMediaFile = selectedMediaFile;
            this.selectedExtension = selectedExtension;
            this.selectedEndCard = selectedEndCard;
            this.selectedIcon = selectedIcon;
            this.selectedLandingPage = selectedLandingPage;
            this.selectedClickThrough = selectedClickThrough;
            this.state = state;
            this.currentTime = currentTime;
            this.isResuming = isResuming;
            this.omJsLibrary = omJsLibrary;
            this.placementId = placementId;
            this.creativeInfo = creativeInfo;
        }
    }
}
