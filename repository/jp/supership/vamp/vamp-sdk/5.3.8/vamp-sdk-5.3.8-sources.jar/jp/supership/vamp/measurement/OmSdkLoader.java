//
//  Copyright © 2026 Supership Inc. All rights reserved.
//
package jp.supership.vamp.measurement;

import android.content.Context;
import android.text.TextUtils;
import androidx.annotation.NonNull;
import androidx.annotation.VisibleForTesting;
import java.net.MalformedURLException;
import java.util.ArrayList;
import jp.supership.sscore.vamp.cache.SSCoreCache;
import jp.supership.sscore.vamp.cache.SSCoreCacheIO;
import jp.supership.sscore.vamp.cache.SSCoreCacheItem;
import jp.supership.sscore.vamp.cache.SSCoreCacheWritingException;
import jp.supership.sscore.vamp.cloudconfig.SSCoreCloudConfigLoadable;
import jp.supership.sscore.vamp.cloudconfig.SSCoreCloudConfigLoader;
import jp.supership.sscore.vamp.cloudconfig.SSCoreCloudConfigOmSdkUrl;
import jp.supership.sscore.vamp.http.SSCoreHttp;
import jp.supership.sscore.vamp.http.SSCoreHttpClient;
import jp.supership.sscore.vamp.http.SSCoreHttpRequest;
import jp.supership.sscore.vamp.type.Optional;
import jp.supership.vamp.core.logging.LogUtils;

public final class OmSdkLoader implements IOmSdkLoader {
    private static final String CACHE_KEY = "jp.supership.vamp.measurement.OMSdkInitializer_1.5.3";
    private static final int CACHE_TIME_SEC = 24 * 60 * 60; // 24h

    /** 初期化中フラグ */
    private boolean isInitializing;

    @NonNull private final ArrayList<OnJsLibraryFetchListener> listeners = new ArrayList<>();
    @NonNull private final SSCoreCloudConfigLoadable cloudConfigLoader;

    /** omsdk.jsをGETするHTTPクライアント */
    @NonNull private final SSCoreHttpClient httpClient;

    @NonNull private final Optional<SSCoreCacheIO> cacheHandler;

    private static OmSdkLoader instance = null;

    /**
     * デフォルトのインスタンスを返します
     *
     * @param appContext アプリケーションコンテキスト
     */
    public static synchronized OmSdkLoader getDefault(@NonNull final Context appContext) {
        if (instance == null) {
            Optional<SSCoreCacheIO> cacheHandler;
            try {
                SSCoreCacheIO cache = SSCoreCache.getDisk(appContext);
                cacheHandler = Optional.of(cache);
            } catch (RuntimeException e) {
                LogUtils.d("Failed to instantiate the cache handler.");
                cacheHandler = Optional.empty();
            }
            instance =
                    new OmSdkLoader(
                            SSCoreCloudConfigLoader.newLoader(appContext),
                            SSCoreHttp.newClient(),
                            cacheHandler);
        }
        return instance;
    }

    @VisibleForTesting
    public OmSdkLoader(
            @NonNull final SSCoreCloudConfigLoadable cloudConfigLoader,
            @NonNull final SSCoreHttpClient httpClient,
            @NonNull final Optional<SSCoreCacheIO> cacheHandler) {
        this.cloudConfigLoader = cloudConfigLoader;
        this.httpClient = httpClient;
        this.cacheHandler = cacheHandler;
    }

    @Override
    public void load(@NonNull final OnJsLibraryFetchListener listener) {
        final Optional<String> omSdkJs = jsLibraryCache();
        if (omSdkJs.isPresent()) {
            LogUtils.d("Use omsdk.js cache.");
            listener.onJsLibraryFetch(omSdkJs);
            return;
        }

        listeners.add(listener);

        if (isInitializing) {
            LogUtils.d("Initializing OM SDK...");
            return;
        }
        isInitializing = true;

        cloudConfigLoader.loadCloudConfig(
                result -> {
                    // クラウドコンフィグからomsdk.jsのURLを抽出
                    SSCoreCloudConfigOmSdkUrl omSdkUrl;
                    try {
                        omSdkUrl = result.data.unwrap().omSdkUrl;
                    } catch (Optional.NotPresentException e) {
                        LogUtils.d("omsdk URL not found.");

                        onFetched(Optional.<String>empty());
                        return;
                    }

                    // omsdk.jsをダウンロード
                    SSCoreHttpRequest httpRequest;
                    try {
                        httpRequest =
                                new SSCoreHttpRequest.Builder(omSdkUrl.value)
                                        .withMethod(SSCoreHttpRequest.Method.GET)
                                        .build();
                    } catch (MalformedURLException
                            | SSCoreHttpRequest.InvalidRequestParameterException e) {
                        LogUtils.d("Failed to get omsdk.js: " + e);

                        onFetched(Optional.empty());
                        return;
                    }

                    httpClient.request(
                            httpRequest,
                            requestResult -> {
                                if (!requestResult.isSuccess()) {
                                    String errorMessage =
                                            requestResult
                                                    .error
                                                    .map(Throwable::getMessage)
                                                    .orElse("Unknown error");

                                    LogUtils.d("Failed to get omsdk.js: " + errorMessage);

                                    onFetched(Optional.empty());
                                    return;
                                }

                                final String js;
                                try {
                                    js = requestResult.data.unwrap().readString().unwrap();
                                } catch (Optional.NotPresentException e) {
                                    LogUtils.d("Failed to get omsdk.js: omsdk.js is null.");
                                    onFetched(Optional.empty());
                                    return;
                                }

                                if (TextUtils.isEmpty(js)) {
                                    LogUtils.d("Failed to get omsdk.js: omsdk.js is null.");
                                    onFetched(Optional.empty());
                                    return;
                                }

                                SSCoreCacheItem cacheItem =
                                        new SSCoreCacheItem(
                                                js,
                                                SSCoreCacheItem.DurationForCacheValidity.inSeconds(
                                                        CACHE_TIME_SEC));
                                try {
                                    cacheHandler.unwrap().writeCache(cacheItem, CACHE_KEY);
                                } catch (SSCoreCacheWritingException
                                        | Optional.NotPresentException e) {
                                    LogUtils.d("Failed to create omsdk.js cache.");
                                }

                                onFetched(Optional.of(js));
                            });
                });
    }

    private void onFetched(@NonNull Optional<String> js) {
        for (OnJsLibraryFetchListener listener : listeners) {
            listener.onJsLibraryFetch(js);
        }

        listeners.clear();
        isInitializing = false;
    }

    @NonNull
    private Optional<String> jsLibraryCache() {
        try {
            SSCoreCacheItem cacheItem = cacheHandler.unwrap().cache(CACHE_KEY).unwrap();
            if (cacheItem.isExpired()) {
                throw new Exception("Invalid omsdk.js cache.");
            }
            return Optional.of((String) cacheItem.data().unwrap());
        } catch (Exception e) {
            LogUtils.d(e.getMessage());
            return Optional.empty();
        }
    }
}
