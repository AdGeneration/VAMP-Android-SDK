//
//  Copyright © 2026 Supership Inc. All rights reserved.
//
package jp.supership.vamp.utils;

import java.util.Locale;

public final class LocaleUtils {
    /**
     * 現在のロケールが日本語かどうかを返します
     *
     * @return 日本語の場合はtrue、それ以外はfalse
     */
    public static boolean isJapanese() {
        final Locale locale = Locale.getDefault();
        return locale.equals(Locale.JAPANESE) || locale.equals(Locale.JAPAN);
    }
}
