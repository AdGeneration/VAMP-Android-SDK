//
//  Copyright © 2026 Supership Inc. All rights reserved.
//
package jp.supership.vamp.measurement;

import android.content.Context;
import android.text.TextUtils;
import android.view.View;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.iab.omid.library.supershipjp1.Omid;
import com.iab.omid.library.supershipjp1.adsession.AdEvents;
import com.iab.omid.library.supershipjp1.adsession.AdSession;
import com.iab.omid.library.supershipjp1.adsession.AdSessionConfiguration;
import com.iab.omid.library.supershipjp1.adsession.AdSessionContext;
import com.iab.omid.library.supershipjp1.adsession.CreativeType;
import com.iab.omid.library.supershipjp1.adsession.ImpressionType;
import com.iab.omid.library.supershipjp1.adsession.Owner;
import com.iab.omid.library.supershipjp1.adsession.Partner;
import com.iab.omid.library.supershipjp1.adsession.VerificationScriptResource;
import com.iab.omid.library.supershipjp1.adsession.media.InteractionType;
import com.iab.omid.library.supershipjp1.adsession.media.MediaEvents;
import com.iab.omid.library.supershipjp1.adsession.media.PlayerState;
import com.iab.omid.library.supershipjp1.adsession.media.Position;
import com.iab.omid.library.supershipjp1.adsession.media.VastProperties;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import jp.supership.sscore.vamp.type.Optional;
import jp.supership.vamp.VAMP;
import jp.supership.vamp.core.error.VAMPInternalError;
import jp.supership.vamp.core.logging.LogUtils;
import jp.supership.vamp.core.utils.VAMPList;
import jp.supership.vamp.core.vast.VASTJavaScriptResource;
import jp.supership.vamp.core.vast.VASTObject;
import jp.supership.vamp.core.vast.VASTTracking;
import jp.supership.vamp.core.vast.VASTVerificationExtension;

/** ネイティブビデオ (NativeVideo) フォーマットの広告について OM SDKの計測およびトラッキングをおこなうクラス */
public final class NativeVideoMeasurementManager {
    /** インスタンスを生成できません。詳細はmessageを参照してください */
    public static final class CanNotInstantiateException extends Exception {
        CanNotInstantiateException(@NonNull String message) {
            super(message);
        }
    }

    /** トラッキングイベント */
    public enum VideoEvent {
        /** インプレッション開始 */
        IMPRESSION,
        /** 再生開始 */
        START,
        /** 25% */
        FIRST_QUARTILE,
        /** 50% */
        MIDPOINT,
        /** 75% */
        THIRD_QUARTILE,
        /** 100% */
        COMPLETE,
        /** 一時停止 */
        PAUSE,
        /** 再生再開 */
        RESUME,
        /** バッファリングにより再生を停止 */
        BUFFER_START,
        /** バッファリング後に再生を再開 */
        BUFFER_END,
        /** プレイヤーのボリュームをONに変更した */
        VOLUME_CHANGE_ON,
        /** プレイヤーのボリュームをOFFに変更した */
        VOLUME_CHANGE_OFF,
        /** 再生の早期終了 */
        SKIPPED,
        /** プレイヤーの破棄 */
        FINISH,
        /** プレイヤーの状態(minimized) */
        PLAYER_STATE_MINIMIZED,
        /** プレイヤーの状態 */
        PLAYER_STATE_COLLAPSED,
        /** プレイヤーの状態 */
        PLAYER_STATE_NORMAL,
        /** プレイヤーの状態 */
        PLAYER_STATE_EXPANDED,
        /** プレイヤーの状態(fullscreen) */
        PLAYER_STATE_FULLSCREEN,
        /** クリック操作(httpへの遷移) */
        USER_INTERACTION_CLICK,
        /** クリック操作(http以外への遷移) */
        USER_INTERACTION_INVITATION_ACCEPTED,
        // loadは別で引数が必要なためここでは管理しない
    }

    private static final String PARTNER_NAME = "Supershipjp1";
    private static final String NOT_EXECUTED = "verificationNotExecuted";

    @NonNull private final VASTObject vastObject;
    @NonNull private Optional<AdSession> adSession;
    @NonNull private final AdEvents adEvents;
    @NonNull private final MediaEvents mediaEvents;

    /** loadedイベントを送信済みかどうか */
    private boolean loadedEventFired;

    /**
     * 計測用インスタンスを生成し、計測可能状態にします。
     *
     * <p>バリデーションエラーが発生したときはCanNotInstantiateExceptionを投げ、 インスタンスは生成されません
     *
     * @param vastObject VASTオブジェクト
     * @param omidJsServiceContent omsdk.js
     * @param adView the view on which to track viewability.
     * @param obstructions 広告に関係がないView(閉じるボタンなどの装飾)のリスト
     * @throws CanNotInstantiateException バリデーションエラーが発生したとき
     */
    public NativeVideoMeasurementManager(
            @NonNull final Context appContext,
            @NonNull final VASTObject vastObject,
            @NonNull final Optional<String> omidJsServiceContent,
            @NonNull final View adView,
            @Nullable final List<Obstruction> obstructions)
            throws CanNotInstantiateException {
        final String js;
        try {
            js = omidJsServiceContent.unwrap();
        } catch (Optional.NotPresentException e) {
            throw new CanNotInstantiateException("omidJsServiceContent is null or empty.");
        }

        this.vastObject = vastObject;

        if (!Omid.isActive()) {
            try {
                Omid.activate(appContext);
            } catch (IllegalArgumentException e) {
                throw new CanNotInstantiateException("Can not activate OM SDK.");
            }
            LogUtils.d("OM SDK is activated.");

            Omid.updateLastActivity();
        }

        List<VerificationScriptResource> verificationScriptResources =
                createVerificationScriptResources(vastObject.getVerificationExtensions());

        // PartnerIDを取得する
        final Partner partner;
        try {
            partner = Partner.createPartner(PARTNER_NAME, VAMP.SDKVersion());
        } catch (IllegalArgumentException e) {
            throw new CanNotInstantiateException("Can not create the partner.");
        }

        final AdSessionContext adSessionContext;
        try {
            final String customReferenceData = "";
            // コンテンツ遷移先のURL
            final String contentUrl = vastObject.getClickThroughURLString();
            adSessionContext =
                    AdSessionContext.createNativeAdSessionContext(
                            partner,
                            js,
                            verificationScriptResources,
                            contentUrl,
                            customReferenceData);
        } catch (IllegalArgumentException e) {
            throw new CanNotInstantiateException("Can not create the context.");
        }

        final AdSessionConfiguration adSessionConfiguration;
        try {
            adSessionConfiguration =
                    AdSessionConfiguration.createAdSessionConfiguration(
                            CreativeType.VIDEO,
                            ImpressionType.VIEWABLE,
                            Owner.NATIVE,
                            Owner.NATIVE,
                            false);
        } catch (IllegalArgumentException e) {
            throw new CanNotInstantiateException("Can not create the configuration.");
        }

        final AdSession adSession;
        try {
            adSession = AdSession.createAdSession(adSessionConfiguration, adSessionContext);
        } catch (IllegalArgumentException e) {
            throw new CanNotInstantiateException("Can not create the ad session.");
        }

        try {
            adSession.registerAdView(adView);
        } catch (IllegalArgumentException e) {
            throw new CanNotInstantiateException(
                    "Can not set the the view on which to track viewability.");
        }

        final List<Obstruction> obstructionViews =
                obstructions != null ? obstructions : new ArrayList<Obstruction>();
        for (Obstruction obstruction : obstructionViews) {
            try {
                // If there are any native elements which you would consider to be part of the ad,
                // such as a close button, some logo text, or another decoration,
                // you should register them as friendly obstructions to prevent them
                // from counting towards coverage of the ad.
                // This applies to any ancestor or peer views in the view hierarchy
                // (all sub-views of the adView will be automatically treated as part of the ad):
                adSession.addFriendlyObstruction(
                        obstruction.view,
                        obstruction.friendlyObstructionPurpose(),
                        obstruction.friendlyObstructionDetailedReason());
            } catch (IllegalArgumentException e) {
                LogUtils.e("Can not register a friendly obstruction.", e);
            }
        }

        try {
            // You will use these instances to signal impression and playback events,
            // so you will want to hold on to them after you’ve created them.
            adEvents = AdEvents.createAdEvents(adSession);
            mediaEvents = MediaEvents.createMediaEvents(adSession);
        } catch (IllegalArgumentException | IllegalStateException e) {
            throw new CanNotInstantiateException("Can not create the event publisher instances.");
        }

        adSession.start();

        this.adSession = Optional.of(adSession);
    }

    @NonNull
    private static List<VerificationScriptResource> createVerificationScriptResources(
            @Nullable List<VASTVerificationExtension> list) throws CanNotInstantiateException {
        if (list == null || list.isEmpty()) {
            throw new CanNotInstantiateException(
                    "VASTVerificationExtension array is null or empty.");
        }

        final List<VerificationScriptResource> resources = new ArrayList<>();

        for (VASTVerificationExtension model : list) {
            if (model == null) {
                continue;
            }

            final VASTJavaScriptResource jsResource = model.javaScriptResource;
            final URL jsUrl = jsResource != null ? jsResource.javaScript : null;
            if (jsUrl == null) {
                continue;
            }

            final String vendor = model.vendor;
            final boolean hasVendor = !TextUtils.isEmpty(vendor);
            final String params = model.verificationParameters;
            final boolean hasParameter = !TextUtils.isEmpty(params);

            if (!hasVendor && !hasParameter) {
                resources.add(
                        VerificationScriptResource
                                .createVerificationScriptResourceWithoutParameters(jsUrl));
            } else if (hasVendor && !hasParameter) {
                // VerificationParameterがない場合はvendorは設定できない
                resources.add(
                        VerificationScriptResource
                                .createVerificationScriptResourceWithoutParameters(jsUrl));
            } else if (hasVendor) {
                resources.add(
                        VerificationScriptResource.createVerificationScriptResourceWithParameters(
                                vendor, jsUrl, params));
            }
        }

        return resources;
    }

    /** 計測を終了します */
    public void finishMeasurement() {
        try {
            adSession.unwrap().finish();
            adSession = Optional.empty();
        } catch (Optional.NotPresentException e) {
            LogUtils.d("The ad session is already disposed.");
        }
    }

    /** 広告に関係がないView(閉じるボタンなどの装飾)の登録を解除します */
    public void unregisterObstruction(@NonNull Obstruction obstruction) {
        try {
            adSession.unwrap().removeFriendlyObstruction(obstruction.view);
        } catch (IllegalArgumentException e) {
            LogUtils.e("Can not remove th friendly obstruction.", e);
        } catch (Optional.NotPresentException e) {
            LogUtils.d("The ad session is already disposed.");
        }
    }

    /** 広告に関係がないView(閉じるボタンなどの装飾)の登録を全て解除します */
    public void unregisterAllObstructions() {
        try {
            adSession.unwrap().removeAllFriendlyObstructions();
        } catch (IllegalArgumentException e) {
            LogUtils.e("Can not remove all friendly obstructions.", e);
        } catch (Optional.NotPresentException e) {
            LogUtils.d("The ad session is already disposed.");
        }
    }

    /**
     * 動画広告のロード完了イベントを送信します
     *
     * @param skipOffset スキップ可能になるまでの最低視聴時間
     * @param isSkippable 動画のスキップ可否
     */
    public void sendLoaded(final float skipOffset, final boolean isSkippable) {
        if (adSession.isEmpty()) {
            LogUtils.d("The ad session is already disposed.");
            return;
        }
        if (loadedEventFired) {
            LogUtils.d("OM SDK has already fired the loaded event.");
            return;
        }
        loadedEventFired = true;

        // VAMPの動画広告は常に自動再生ではない
        final boolean isAutoPlay = false;

        if (isSkippable) {
            // スキップ可能動画
            final VastProperties vProps =
                    VastProperties.createVastPropertiesForSkippableMedia(
                            Math.max(skipOffset, 0), isAutoPlay, Position.STANDALONE);
            try {
                adEvents.loaded(vProps);
                LogUtils.d("OM SDK has fired the loaded event for the skippable video.");
            } catch (Exception e) {
                LogUtils.e("OM SDK failed to fire the loaded event for the skippable video.", e);
                sendError();
            }
        } else {
            // スキップ不可動画
            final VastProperties vProps =
                    VastProperties.createVastPropertiesForNonSkippableMedia(
                            isAutoPlay, Position.STANDALONE);
            try {
                adEvents.loaded(vProps);
                LogUtils.d("OM SDK has fired the loaded event for the non-skippable video.");
            } catch (Exception e) {
                LogUtils.e(
                        "OM SDK failed to fire the loaded event for the non-skippable video.", e);
                sendError();
            }
        }
    }

    /** 動画イベントを送信します */
    public void sendVideoEvent(@NonNull final VideoEvent event) {
        sendVideoEvent(event, null);
    }

    /** 動画イベントを送信します */
    public void sendVideoEvent(
            @NonNull final VideoEvent event, @Nullable final VideoPlayerInfo info) {
        if (adSession.isEmpty()) {
            LogUtils.d("The ad session is already disposed.");
            return;
        }
        // 動画のロードが未完了ならトラッキングイベントを受け付けない
        if (!loadedEventFired) {
            LogUtils.d(
                    "The loaded event is not fired yet. The video event("
                            + event
                            + ") is canceled.");
            return;
        }

        try {
            switch (event) {
                    // インプレッション開始
                case IMPRESSION:
                    adEvents.impressionOccurred();
                    break;
                    // 再生開始
                case START:
                    if (info == null) {
                        LogUtils.d("The start event needs the video player info.");
                        return;
                    }
                    mediaEvents.start(info.duration, info.volume());
                    break;
                    // 25%
                case FIRST_QUARTILE:
                    mediaEvents.firstQuartile();
                    break;
                    // 50%
                case MIDPOINT:
                    mediaEvents.midpoint();
                    break;
                    // 75%
                case THIRD_QUARTILE:
                    mediaEvents.thirdQuartile();
                    break;
                    // 100%
                case COMPLETE:
                    mediaEvents.complete();
                    break;
                    // 一時停止
                case PAUSE:
                    mediaEvents.pause();
                    break;
                    // 再生再開
                case RESUME:
                    mediaEvents.resume();
                    break;
                    // バッファリングにより再生を停止
                case BUFFER_START:
                    mediaEvents.bufferStart();
                    break;
                    // バッファリング後に再生を再開
                case BUFFER_END:
                    mediaEvents.bufferFinish();
                    break;
                    // プレイヤーのボリュームをONに変更した
                case VOLUME_CHANGE_ON:
                    mediaEvents.volumeChange(1.0f);
                    break;
                    // プレイヤーのボリュームをOFFに変更した
                case VOLUME_CHANGE_OFF:
                    mediaEvents.volumeChange(0.0f);
                    break;
                    // 再生の早期終了
                case SKIPPED:
                    mediaEvents.skipped();
                    break;
                    // プレイヤーの破棄
                case FINISH:
                    finishMeasurement();
                    break;
                    // プレイヤーの状態変更
                case PLAYER_STATE_MINIMIZED:
                    mediaEvents.playerStateChange(PlayerState.MINIMIZED);
                    break;
                    // プレイヤーの状態変更
                case PLAYER_STATE_COLLAPSED:
                    mediaEvents.playerStateChange(PlayerState.COLLAPSED);
                    break;
                    // プレイヤーの状態変更
                case PLAYER_STATE_NORMAL:
                    mediaEvents.playerStateChange(PlayerState.NORMAL);
                    break;
                    // プレイヤーの状態変更
                case PLAYER_STATE_EXPANDED:
                    mediaEvents.playerStateChange(PlayerState.EXPANDED);
                    break;
                    // プレイヤーの状態変更
                case PLAYER_STATE_FULLSCREEN:
                    mediaEvents.playerStateChange(PlayerState.FULLSCREEN);
                    break;
                    // 広告タップ(http遷移)
                case USER_INTERACTION_CLICK:
                    mediaEvents.adUserInteraction(InteractionType.CLICK);
                    break;
                    // 広告タップ(http以外への遷移)
                case USER_INTERACTION_INVITATION_ACCEPTED:
                    mediaEvents.adUserInteraction(InteractionType.INVITATION_ACCEPTED);
                    break;
                default:
                    return;
            }
            LogUtils.d("OM SDK has fired the video event(" + event + ").");
        } catch (IllegalArgumentException | IllegalStateException e) {
            LogUtils.e("OM SDK failed to fire the video event(" + event + ").", e);
            sendError();
        }
    }

    /** エラー用のトラッキングURLへリクエストします */
    private void sendError() {
        final ArrayList<VASTVerificationExtension> verificationExtensions =
                vastObject.getVerificationExtensions();
        if (verificationExtensions == null) {
            return;
        }

        // VASTに含まれる各計測ベンダーのトラッキングイベントを検索
        for (VASTVerificationExtension model : verificationExtensions) {
            // 各計測ベンダーのverificationNotExecutedのURLを検索
            final VAMPList<VASTTracking> trackings = model.getTrackings();

            final VASTTracking tracking =
                    trackings.find(
                            new VAMPList.IFindListener<VASTTracking>() {
                                @Override
                                public boolean where(VASTTracking result) {
                                    return result != null && NOT_EXECUTED.equals(result.event);
                                }
                            });
            if (tracking == null) {
                continue;
            }

            // エラー用のURLへリクエストをおこなう
            tracking.send(
                    null,
                    new VASTObject.VASTEventListener() {
                        @Override
                        public void onComplete(URL url, VAMPInternalError error) {
                            if (error != null) {
                                final String errMsg = error.message;
                                LogUtils.d(
                                        "verificationNotExecuted request failed. "
                                                + errMsg
                                                + " url: "
                                                + url);
                            } else {
                                LogUtils.d(
                                        "verificationNotExecuted request succeeded. url: " + url);
                            }
                        }
                    });
        }
    }
}
