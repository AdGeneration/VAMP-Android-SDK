//
//  Copyright © 2026 Supership Inc. All rights reserved.
//
package jp.supership.vamp.player.view;

import android.webkit.WebView;
import androidx.annotation.NonNull;
import jp.supership.sscore.vamp.type.Optional;

/**
 * エンドカード・インタフェース
 *
 * <p>Created by masaki.ando on 2022/11/14.
 */
interface EndCardViewInterface {
    /** エンドカードを表示します */
    void show();

    /** エンドカードを隠します */
    void hide();

    /** エンドカードを破棄します。このメソッドにリソースの解放など必要な終了処理を記述します */
    void destroy();

    /**
     * @return WebViewオブジェクトを返します。オブジェクトがない場合はOptional.empty()を返します
     */
    @NonNull
    Optional<WebView> getWebView();
}
