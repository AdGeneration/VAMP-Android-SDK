//
//  Copyright © 2026 Supership Inc. All rights reserved.
//
package jp.supership.vamp;

import android.app.Activity;
import android.content.Context;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import java.util.Collections;
import jp.supership.sscore.vamp.adrequest.SSCoreAdRequestPlacementIDValidator;
import jp.supership.sscore.vamp.adrequest.SSCoreAdRequestValidation;
import jp.supership.sscore.vamp.adrequest.SSCoreAdRequestValidator;
import jp.supership.sscore.vamp.adrequest.SSCoreAdServerDomain;
import jp.supership.sscore.vamp.adrequest.SSCoreRewardedAdClient;
import jp.supership.sscore.vamp.cloudlogger.SSCoreCloudLoggable;
import jp.supership.sscore.vamp.cloudlogger.SSCoreCloudLogger;
import jp.supership.sscore.vamp.cloudlogger.SSCoreCloudLoggerSettings;
import jp.supership.sscore.vamp.device.SSCoreReachability;
import jp.supership.sscore.vamp.logger.SSCoreLogger;
import jp.supership.sscore.vamp.type.Optional;
import jp.supership.sscore.vamp.userconsent.SSCoreUserConsentManager;

final class AppOpenMediationManagerDependency {
    @NonNull
    private static final SSCoreAdRequestValidation VALIDATOR =
            new SSCoreAdRequestValidator(
                    Collections.singletonList(new SSCoreAdRequestPlacementIDValidator()));

    interface IResolver {
        /** MediationManagerインスタンスを生成します */
        @NonNull
        AppOpenMediationManager newInstance(
                @NonNull Activity activity,
                @NonNull String placementId,
                @Nullable AppOpenMediationManager.Listener listener);
    }

    /** デフォルトのインスタンス生成器 */
    private static final class Resolver implements AppOpenMediationManagerDependency.IResolver {
        @NonNull
        @Override
        public AppOpenMediationManager newInstance(
                @NonNull final Activity activity,
                @NonNull final String placementId,
                @Nullable final AppOpenMediationManager.Listener listener) {
            final Context context = activity.getApplicationContext();

            final SSCoreAdServerDomain domain =
                    BuildConfig.DEV_SERVER
                            ? SSCoreAdServerDomain.Staging.INSTANCE
                            : SSCoreAdServerDomain.Production.INSTANCE;

            final SSCoreRewardedAdClient adClient =
                    SSCoreRewardedAdClient.defaultInstance(
                            context,
                            domain,
                            VALIDATOR,
                            SSCoreUserConsentManager.createInstance(context),
                            new AdhocPlacements(context),
                            SSCoreLogger.DEFAULT);

            final SSCoreReachability.Reachable2 reachability =
                    new SSCoreReachability.Reachability(context);

            final SdkAvailability.IAvailabilityChecker availabilityChecker =
                    new SdkAvailability.AvailabilityChecker(Optional.of(context), reachability);

            final SSCoreCloudLoggable cloudLogger =
                    SSCoreCloudLogger.createProductionInstance(
                            context,
                            new SSCoreCloudLoggerSettings.Builder(VAMP.SDKVersion())
                                    .setTestMode(VAMP.isTestMode())
                                    .setDebugMode(VAMP.isDebugMode())
                                    .build());

            return new AppOpenMediationManager(
                    adClient,
                    availabilityChecker,
                    cloudLogger,
                    activity,
                    placementId,
                    listener,
                    AppOpenOptions.defaultOption());
        }
    }

    @NonNull
    private static AppOpenMediationManagerDependency.IResolver resolver =
            new AppOpenMediationManagerDependency.Resolver();

    static void setResolver(
            @NonNull final Optional<AppOpenMediationManagerDependency.IResolver> resolverOpt) {
        synchronized (AppOpenMediationManagerDependency.class) {
            try {
                resolver = resolverOpt.unwrap();
            } catch (Optional.NotPresentException e) {
                resolver = new AppOpenMediationManagerDependency.Resolver();
            }
        }
    }

    @NonNull
    static AppOpenMediationManagerDependency.IResolver getResolver() {
        return resolver;
    }
}
