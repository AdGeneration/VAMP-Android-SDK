//
//  Copyright © 2026 Supership Inc. All rights reserved.
//
package jp.supership.vamp.core.vast;

import android.content.Context;
import android.text.TextUtils;
import java.io.Serializable;
import java.net.MalformedURLException;
import jp.supership.sscore.vamp.cache.SSCoreFileCache;
import jp.supership.sscore.vamp.cache.SSCoreFileCacheException;
import jp.supership.sscore.vamp.http.SSCoreHttp;
import jp.supership.sscore.vamp.http.SSCoreHttpClient;
import jp.supership.sscore.vamp.http.SSCoreHttpRequest;
import jp.supership.sscore.vamp.http.SSCoreHttpResponse;
import jp.supership.sscore.vamp.type.Optional;
import jp.supership.vamp.core.error.VAMPInternalError;
import jp.supership.vamp.core.logging.LogUtils;

public class VASTResource implements Serializable {
    public interface ILoadListener {
        void onCompleted(VASTResource resource, VAMPInternalError error);
    }

    /** 単位: 秒 */
    private static final int REQUEST_CONNECTION_TIMEOUT = 5;

    /** 単位: 秒 */
    private static final int REQUEST_READ_TIMEOUT = 300;

    private String creativeType;
    private String urlString;

    public VASTResource(String creativeType, String file) {
        this.creativeType = creativeType;
        this.urlString = file;
    }

    public String getCreativeType() {
        return creativeType;
    }

    public boolean isLoaded(Context context) {
        return !TextUtils.isEmpty(getImageFilePath(context));
    }

    public void load(final Context context, final ILoadListener listener) {
        LogUtils.devLog("load resource:." + urlString);

        SSCoreHttpRequest httpRequest;
        try {
            httpRequest =
                    new SSCoreHttpRequest.Builder(urlString)
                            .withMethod(SSCoreHttpRequest.Method.GET)
                            .withReadTimeout(
                                    SSCoreHttpRequest.Timeout.inSeconds(REQUEST_READ_TIMEOUT))
                            .withConnectTimeout(
                                    SSCoreHttpRequest.Timeout.inSeconds(REQUEST_CONNECTION_TIMEOUT))
                            .build();
        } catch (MalformedURLException | SSCoreHttpRequest.InvalidRequestParameterException e) {
            if (listener != null) {
                listener.onCompleted(
                        null,
                        new VAMPInternalError(
                                VAMPInternalError.Code.UNKNOWN,
                                "Failed to build HttpRequest. " + e.getMessage()));
            }
            return;
        }

        // TODO: httpClientを外部から渡せるようにする
        SSCoreHttpClient httpClient = SSCoreHttp.newClient();
        httpClient.request(
                httpRequest,
                result -> {
                    if (!result.isSuccess()) {
                        final String errorMessage =
                                result.error.map(Throwable::getMessage).orElse("Unknown error");

                        final int statusCodeMessage =
                                result.data.map(response -> response.statusCode).orElse(0);

                        final String message = statusCodeMessage + ", " + errorMessage;

                        if (listener != null) {
                            listener.onCompleted(
                                    null,
                                    new VAMPInternalError(
                                            VAMPInternalError.Code.NETWORK_ERROR,
                                            "error: " + message));
                        }
                        return;
                    }

                    try {
                        SSCoreHttpResponse response = result.data.unwrap();
                        final byte[] responseBody = response.readData().unwrap();

                        SSCoreFileCache cache = SSCoreFileCache.getInstance(context);
                        cache.store(responseBody, urlString);
                        // success
                        if (listener != null) {
                            listener.onCompleted(VASTResource.this, null);
                        }
                    } catch (Optional.NotPresentException e) {
                        if (listener != null) {
                            listener.onCompleted(
                                    null,
                                    new VAMPInternalError(
                                            VAMPInternalError.Code.NETWORK_ERROR,
                                            "Invalid response. " + e.getMessage()));
                        }
                    } catch (SSCoreFileCacheException e) {
                        LogUtils.devLog(e.getMessage());
                        if (listener != null) {
                            listener.onCompleted(
                                    null,
                                    new VAMPInternalError(
                                            VAMPInternalError.Code.IO_ERROR, e.getMessage()));
                        }
                    }
                });
    }

    public String getUrlString() {
        return urlString;
    }

    public String getImageFilePath(Context context) {
        try {
            return SSCoreFileCache.getInstance(context).retrieveFilePath(urlString);
        } catch (Exception e) {
            LogUtils.devLog(e.getMessage());
            return null;
        }
    }
}
