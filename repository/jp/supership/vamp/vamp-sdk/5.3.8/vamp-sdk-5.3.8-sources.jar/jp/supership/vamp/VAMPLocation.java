//
//  Copyright © 2026 Supership Inc. All rights reserved.
//
package jp.supership.vamp;

import androidx.annotation.NonNull;

/** ユーザの位置情報（国コード、地域）を定義します。 */
public class VAMPLocation {
    public static final String UNKNOWN_COUNTRY_CODE = "99";

    @NonNull private final String countryCode;

    @NonNull private final String region;

    public VAMPLocation(@NonNull String countryCode, @NonNull String region) {
        this.countryCode = countryCode;
        this.region = region;
    }

    /**
     * ２文字の国コード（JP、USなど<a href="https://ja.wikipedia.org/wiki/ISO_3166-1">ISO3166-1</a>）を取得します。<br>
     * IPから国を判別できなかった、リクエストがタイムアウトしたなど、<br>
     * 正常に値が返せない場合は"99"が返却されます。<br>
     *
     * @return 国コード
     * @see <a
     *     href="https://gist.github.com/mukae-ss/9131fa350e09db77dbab247500c94750">UnityPluginで国判定するサンプル</a>
     *     <br>
     */
    @NonNull
    public String getCountryCode() {
        return countryCode;
    }

    /**
     * 地域コードを取得します。<br>
     *
     * <p>地域コードはISO_3166-2に準拠したコードを返します。<br>
     *
     * @return 地域コード
     * @see <a href="https://en.wikipedia.org/wiki/ISO_3166-2:JP">ISO_3166-2(JP)</a><br>
     * @see <a href="https://en.wikipedia.org/wiki/ISO_3166-2:US">ISO_3166-2(US)</a><br>
     */
    @NonNull
    public String getRegion() {
        return region;
    }
}
