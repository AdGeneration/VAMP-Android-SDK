//
//  Copyright © 2026 Supership Inc. All rights reserved.
//
package jp.supership.vamp.mediation;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import java.util.List;

public interface Adapter {
    /**
     * サポート対象OS (API Level)かどうかを返します。
     *
     * @return サポート対象OS (API Level)の場合はtrue、それ以外はfalseを返します
     */
    boolean isSupported();

    /**
     * アドネットワークのバージョン。
     *
     * @return アドネットワークSDKが返すバージョン
     */
    @NonNull
    String getAdNetworkVersion();

    /**
     * アドネットワーク名。
     *
     * @return アドネットワーク名
     */
    @NonNull
    String getAdNetworkName();

    /**
     * アドネットワークの広告枠ID。
     *
     * @return アドネットワークの広告枠ID
     */
    @NonNull
    List<String> getAdNetworkAdIdentifiers();

    /**
     * アダプタのバージョン。
     *
     * @return アダプタのバージョン
     */
    @NonNull
    String getAdapterVersion();

    /**
     * Adapterインスタンス生成時に呼ばれます。 パラメータが不正などの理由により初期化ができない場合はfalseを返してください。
     *
     * @param context コンテキスト
     * @param configuration アダプタのパラメータ
     * @param listener リスナー
     * @return 初期化に成功した場合はtrue、それ以外はfalseを返します
     */
    boolean prepare(
            @NonNull Context context,
            @NonNull AdapterConfiguration configuration,
            @Nullable AdapterEventListener listener);

    /**
     * 広告のロードを開始します。
     *
     * @param context コンテキスト
     */
    void load(@NonNull Context context);

    /**
     * 動画の再生準備ができているかどうかを返します。
     *
     * @return 動画の再生準備ができている場合はtrue、それ以外はfalseを返します
     */
    boolean isReady();

    /**
     * 広告を表示します。
     *
     * @param context コンテキスト
     */
    void show(@NonNull Context context);

    /** アダプタを破棄します。 */
    void destroy();
}
