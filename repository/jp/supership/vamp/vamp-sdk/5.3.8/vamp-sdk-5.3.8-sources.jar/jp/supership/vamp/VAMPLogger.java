//
//  Copyright © 2026 Supership Inc. All rights reserved.
//
package jp.supership.vamp;

import jp.supership.vamp.core.logging.LogUtils;

public class VAMPLogger {
    private String tag = "VAMPLogger";

    public VAMPLogger(String tag) {
        this.tag = tag;
    }

    public void v(String message) {
        LogUtils.v(formatLog(message), false);
    }

    public void d(String message) {
        LogUtils.d(formatLog(message), false);
    }

    public void i(String message) {
        LogUtils.i(formatLog(message), false);
    }

    public void w(String message) {
        LogUtils.w(formatLog(message), false);
    }

    public void w(String message, Throwable e) {
        LogUtils.w(formatLog(message), e, false);
    }

    public void e(String message) {
        LogUtils.e(formatLog(message), false);
    }

    public void e(String message, Throwable e) {
        LogUtils.e(formatLog(message), e, false);
    }

    private String formatLog(String message) {
        return String.format("[%s] %s", tag, message);
    }
}
