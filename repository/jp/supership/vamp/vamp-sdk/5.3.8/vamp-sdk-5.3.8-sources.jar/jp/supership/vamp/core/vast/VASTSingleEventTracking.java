//
//  Copyright © 2026 Supership Inc. All rights reserved.
//
package jp.supership.vamp.core.vast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import java.net.URL;

public class VASTSingleEventTracking extends VASTTracking {

    public VASTSingleEventTracking(@NonNull final String event, final @NonNull URL url) {
        super(event, url);
    }

    public VASTSingleEventTracking(
            @NonNull final String event, @NonNull final URL url, @Nullable final String offset) {
        super(event, url, offset);
    }

    public VASTSingleEventTracking(
            @NonNull final String event,
            @NonNull final URL url,
            @Nullable final String offset,
            int count) {
        super(event, url, offset, count);
    }

    @Override
    public boolean isDone() {
        return getCount() > 0;
    }
}
