//
//  Copyright © 2026 Supership Inc. All rights reserved.
//
package jp.supership.vamp.core.utils;

import androidx.annotation.NonNull;
import jp.supership.sscore.vamp.timer.SSCoreStopwatch;
import jp.supership.vamp.core.logging.LogUtils;

/** SSCoreStopwatchの計測結果を旧Benchmarkクラス相当のログ形式で出力するためのユーティリティ */
public final class StopwatchLogUtils {
    private StopwatchLogUtils() {}

    /** SSCoreStopwatchの計測結果を秒単位で返しつつ、旧Benchmarkクラス相当のログを出力します */
    public static double elapsedSecondsWithLog(
            @NonNull final String label, @NonNull final SSCoreStopwatch stopwatch) {
        final double elapsedSeconds = stopwatch.getElapsedTimeInSeconds();
        LogUtils.devLog("Benchmark[" + label + "] " + (long) (elapsedSeconds * 1000) + "ms");
        return elapsedSeconds;
    }
}
