//
//  Copyright © 2026 Supership Inc. All rights reserved.
//
package jp.supership.vamp;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import jp.supership.sscore.vamp.rewardedad.SSCoreRewardedAdMediationResponseInfo;

final class AdapterResponseInfo implements VAMPAdapterResponseInfo {
    @NonNull private final SSCoreRewardedAdMediationResponseInfo delegate;

    static class Builder {
        @Nullable private String adId;
        @Nullable private String adNetworkName;

        /** アダプタクラス名 */
        @Nullable private String className;

        @Nullable private String creativeId;
        @Nullable private String adNetworkId;
        @Nullable private String dspId;
        @Nullable private String seat;

        public Builder withAdId(@Nullable final String adId) {
            this.adId = adId;
            return this;
        }

        public Builder withAdNetworkName(@Nullable final String adNetworkName) {
            this.adNetworkName = adNetworkName;
            return this;
        }

        public Builder withClassName(@Nullable final String className) {
            this.className = className;
            return this;
        }

        public Builder withCreativeId(@Nullable final String creativeId) {
            this.creativeId = creativeId;
            return this;
        }

        public Builder withAdNetworkId(@Nullable final String adNetworkId) {
            this.adNetworkId = adNetworkId;
            return this;
        }

        public Builder withDspId(@Nullable final String dspId) {
            this.dspId = dspId;
            return this;
        }

        public Builder withSeat(@Nullable final String seat) {
            this.seat = seat;
            return this;
        }

        @NonNull
        public AdapterResponseInfo build() {
            return new AdapterResponseInfo(
                    new SSCoreRewardedAdMediationResponseInfo(
                            adNetworkName, className, adId, creativeId, dspId, adNetworkId, seat));
        }
    }

    AdapterResponseInfo(@NonNull final SSCoreRewardedAdMediationResponseInfo delegate) {
        this.delegate = delegate;
    }

    /** ラップしているSSCore側のインスタンスを返します(MediationResponseInfoからの集約に使用します) */
    @NonNull
    SSCoreRewardedAdMediationResponseInfo getDelegate() {
        return delegate;
    }

    void startLoading() {
        delegate.recordLoadStartTime();
    }

    void finishLoading() {
        delegate.recordLoadEndTime();
    }

    @Nullable
    @Override
    public String getAdNetworkName() {
        return delegate.getAdNetworkName();
    }

    @Nullable
    @Override
    public String getAdId() {
        return delegate.getAdID();
    }

    @Nullable
    @Override
    public String getClassName() {
        return delegate.getClassName();
    }

    @Nullable
    @Override
    public String getCreativeId() {
        return delegate.getCreativeID();
    }

    @Nullable
    @Override
    public String getAdNetworkId() {
        return delegate.getAdNetworkID();
    }

    @Nullable
    @Override
    public String getDspId() {
        return delegate.getDspID();
    }

    @Nullable
    @Override
    public String getSeat() {
        return delegate.getSeat();
    }

    @Override
    public long getLatencyMillis() {
        return delegate.getLatencyMillis();
    }
}
