//
//  Copyright © 2026 Supership Inc. All rights reserved.
//
package jp.supership.vamp.mediation;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import java.util.Map;

public interface RTBAdapter extends Adapter {
    @Nullable
    Map<String, String> collectParametersForAdRequest(@NonNull Context context);

    boolean isRTBRequest();
}
