//
//  Copyright © 2026 Supership Inc. All rights reserved.
//
package jp.supership.vamp;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import jp.supership.sscore.vamp.adrequest.SSCoreAdRequest;
import jp.supership.sscore.vamp.rewardedad.SSCoreRewardedAdRequestTimeout;
import jp.supership.vamp.core.logging.LogUtils;

/** このクラスは、広告のロードリクエストのコンフィグレーションを表します。 */
public final class VAMPRequest {
    @NonNull final SSCoreRewardedAdRequestTimeout requestTimeout;
    @Nullable final String contentUrl;

    private VAMPRequest(
            @NonNull final SSCoreRewardedAdRequestTimeout requestTimeout,
            @Nullable final String contentUrl) {
        this.requestTimeout = requestTimeout;
        this.contentUrl = contentUrl;
    }

    /**
     * リクエストタイムアウトの時間を取得します。
     *
     * @return タイムアウト値。単位は秒です
     */
    public int getRequestTimeout() {
        return requestTimeout.getTimeInSeconds();
    }

    /**
     * App Content URL を取得します。
     *
     * @return 設定されている App Content URL。未設定、空文字・空白のみ、または上限文字数超過により無効化された場合は null
     */
    @Nullable
    public String getContentUrl() {
        return contentUrl;
    }

    /** VAMPRequestのBuilder */
    public static final class Builder {
        @NonNull
        private SSCoreRewardedAdRequestTimeout requestTimeout =
                SSCoreRewardedAdRequestTimeout.newDefault();

        @Nullable private String contentUrl = null;

        /** コンストラクタ */
        public Builder() {}

        /**
         * ロードリクエストのタイムアウト値を秒数で設定します。
         *
         * @param requestTimeoutInSeconds リクエストのタイムアウト値 (30〜120秒で設定可能。デフォルトは60秒)
         * @return Builderオブジェクト
         */
        @NonNull
        public Builder setRequestTimeout(int requestTimeoutInSeconds) {
            this.requestTimeout = new SSCoreRewardedAdRequestTimeout(requestTimeoutInSeconds);
            return this;
        }

        /**
         * App Content URL を設定します。
         *
         * <p>アプリの主要コンテンツに一致するウェブサイトの URL を設定すると、コンテンツターゲティング用の {@code atp}
         * パラメータとして広告リクエストに付与されます。前後の空白は除去され、正規化・検証規則は {@link
         * SSCoreAdRequest#validateContentUrl(String)} に集約されており、この Builder はその結果を適用するだけです。
         *
         * <p>除去後の長さが上限（{@link SSCoreAdRequest#CONTENT_URL_MAX_LENGTH} UTF-16 code
         * unit）を超える場合は、{@code atp} を付与せず（{@link VAMPRequest#getContentUrl()} は {@code null}
         * になります）、戻り値として {@link VAMPError#INVALID_PARAMETER}
         * を返します。このエラーは設定時にのみ返るもので、広告のロードは中断しません（非ブロッキング。上限超過時は {@code atp} を送らずにリクエストを継続します）。iOS の
         * {@code -[VAMPRequest setContentURL:error:]} と同じ挙動です。
         *
         * <p>この {@code atp} は VAMP の広告リクエストサーバーにのみ送信されます。個々のメディエーション先アドネットワーク SDK（AdMob
         * 等）への伝播は別途対応予定です。
         *
         * @param contentUrl App Content URL（{@code null} を渡すと設定を解除します）
         * @return 設定に成功した場合（有効な URL・空文字・空白のみ・{@code null} での解除を含む）は {@code
         *     null}、上限文字数超過で設定されなかった場合は {@link VAMPError#INVALID_PARAMETER}
         */
        @Nullable
        public VAMPError setContentUrl(@Nullable String contentUrl) {
            SSCoreAdRequest.ContentUrlValidation validation =
                    SSCoreAdRequest.validateContentUrl(contentUrl);
            if (validation instanceof SSCoreAdRequest.ContentUrlValidation.Valid) {
                this.contentUrl =
                        ((SSCoreAdRequest.ContentUrlValidation.Valid) validation).getValue();
                return null;
            }
            this.contentUrl = null;
            if (validation instanceof SSCoreAdRequest.ContentUrlValidation.ExceededMaxLength) {
                LogUtils.w(
                        "contentUrl exceeds the maximum length ("
                                + SSCoreAdRequest.CONTENT_URL_MAX_LENGTH
                                + " UTF-16 code units). The value is ignored, but ad loading"
                                + " will continue.");
                return VAMPError.INVALID_PARAMETER;
            }
            return null;
        }

        /**
         * VAMPRequestオブジェクトを生成します。
         *
         * @return VAMPRequestオブジェクト
         */
        @NonNull
        public VAMPRequest build() {
            return new VAMPRequest(requestTimeout, contentUrl);
        }
    }
}
