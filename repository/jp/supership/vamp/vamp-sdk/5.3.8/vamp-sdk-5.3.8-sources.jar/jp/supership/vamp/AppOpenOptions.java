//
//  Copyright © 2026 Supership Inc. All rights reserved.
//
package jp.supership.vamp;

import androidx.annotation.NonNull;
import jp.supership.sscore.vamp.rewardedad.SSCoreAdNetworkNames;
import jp.supership.sscore.vamp.rewardedad.SSCoreRewardedAdMediationTimeout;
import jp.supership.sscore.vamp.type.Optional;

enum AppOpenExpirationPolicy {
    BY_NETWORK,
    FIXED
}

final class AppOpenOptions {
    /** 有効期限ポリシー デフォルト: BY_NETWORK */
    final AppOpenExpirationPolicy expirationPolicy;

    final SSCoreRewardedAdMediationTimeout mediationTimeout;
    final long fixedExpirationTimeInMilliSeconds;

    @NonNull
    public static AppOpenOptions defaultOption() {
        SSCoreRewardedAdMediationTimeout mediationTimeout;
        try {
            mediationTimeout = VAMPDebugUtils.newInstance().mediationTimeout.unwrap();
        } catch (Optional.NotPresentException e) {
            mediationTimeout = SSCoreRewardedAdMediationTimeout.newDefault();
        }

        return new AppOpenOptions(mediationTimeout, AppOpenExpirationPolicy.BY_NETWORK);
    }

    public AppOpenOptions(
            @NonNull SSCoreRewardedAdMediationTimeout mediationTimeout,
            @NonNull AppOpenExpirationPolicy expirationPolicy) {
        this.mediationTimeout = mediationTimeout;
        this.expirationPolicy = expirationPolicy;
        this.fixedExpirationTimeInMilliSeconds = 3600 * 1000;
    }

    public long getExpirationTimeInMilliSeconds(@NonNull String adNetworkName) {
        if (expirationPolicy == AppOpenExpirationPolicy.FIXED) {
            return fixedExpirationTimeInMilliSeconds;
        }

        long expirationTimeInMilliSeconds = 3600 * 1000;
        if (SSCoreAdNetworkNames.PANGLE.equals(adNetworkName)) {
            expirationTimeInMilliSeconds = 3600 * 1000;
        } else if (SSCoreAdNetworkNames.AD_MOB.equals(adNetworkName)) {
            expirationTimeInMilliSeconds = 14400 * 1000;
        }

        return expirationTimeInMilliSeconds;
    }
}
