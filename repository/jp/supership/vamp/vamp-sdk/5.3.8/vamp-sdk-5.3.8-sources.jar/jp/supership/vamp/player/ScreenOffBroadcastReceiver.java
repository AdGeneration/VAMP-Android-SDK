//
//  Copyright © 2026 Supership Inc. All rights reserved.
//
package jp.supership.vamp.player;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

/** 画面のON/OFF切り替え監視用レシーバ */
final class ScreenOffBroadcastReceiver extends BroadcastReceiver {
    interface Listener {
        void onScreenOn();
    }

    private boolean screenLocked;
    @Nullable private final Listener listener;

    private ScreenOffBroadcastReceiver(@Nullable final Listener listener) {
        this.listener = listener;
    }

    /**
     * レシーバを生成し、指定されたActivityに登録します
     *
     * @return 生成されたレシーバ
     */
    @NonNull
    static ScreenOffBroadcastReceiver register(
            @NonNull final Activity activity, @Nullable final Listener listener) {
        ScreenOffBroadcastReceiver receiver = new ScreenOffBroadcastReceiver(listener);

        IntentFilter filter = new IntentFilter();
        filter.addAction(Intent.ACTION_USER_PRESENT);
        filter.addAction(Intent.ACTION_SCREEN_OFF);

        activity.registerReceiver(receiver, filter);

        return receiver;
    }

    /** レシーバを解除します */
    void unregister(@NonNull final Activity activity) {
        activity.unregisterReceiver(this);
    }

    /**
     * @return 画面のロックが解除されている状態ならばtrueを返します
     */
    boolean isScreenUnlocked() {
        return !screenLocked;
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();

        if (Intent.ACTION_USER_PRESENT.equals(action)) {
            // *自動で画面オフになった場合
            // すぐに戻ろうとすると画面ロック解除イベントが発火しない可能性がある
            if (screenLocked) {
                if (listener != null) {
                    listener.onScreenOn();
                }
            }

            screenLocked = false;
        } else if (Intent.ACTION_SCREEN_OFF.equals(action)) {
            screenLocked = true;
        }
    }
}
