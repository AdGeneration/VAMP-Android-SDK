//
//  Copyright © 2026 Supership Inc. All rights reserved.
//
package jp.supership.vamp.measurement;

import androidx.annotation.NonNull;

/** OM SDKのomsdk.jsをダウンロードするインタフェース */
public interface IOmSdkLoader {
    void load(@NonNull OnJsLibraryFetchListener listener);
}
