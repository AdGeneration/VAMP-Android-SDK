//
//  Copyright © 2026 Supership Inc. All rights reserved.
//
package jp.supership.vamp;

public class AdapterNotFoundException extends Exception {
    public AdapterNotFoundException(String message) {
        super(message);
    }
}
