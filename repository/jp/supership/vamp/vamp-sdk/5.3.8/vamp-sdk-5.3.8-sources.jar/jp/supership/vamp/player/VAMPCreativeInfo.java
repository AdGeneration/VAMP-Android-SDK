//
//  Copyright © 2026 Supership Inc. All rights reserved.
//
package jp.supership.vamp.player;

import androidx.annotation.NonNull;
import java.io.Serializable;

public final class VAMPCreativeInfo implements Serializable {
    @NonNull public final String crid;
    @NonNull public final String adNetworkId;
    @NonNull public final String dspId;
    @NonNull public final String seat;

    public VAMPCreativeInfo(
            @NonNull final String crid,
            @NonNull final String adNetworkId,
            @NonNull final String dspId,
            @NonNull final String seat) {
        this.crid = crid;
        this.adNetworkId = adNetworkId;
        this.dspId = dspId;
        this.seat = seat;
    }
}
