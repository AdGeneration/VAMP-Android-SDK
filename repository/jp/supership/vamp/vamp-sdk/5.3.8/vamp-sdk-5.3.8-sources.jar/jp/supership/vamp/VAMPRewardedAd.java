//
//  Copyright © 2026 Supership Inc. All rights reserved.
//
package jp.supership.vamp;

import android.app.Activity;
import android.os.Handler;
import android.os.Looper;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.VisibleForTesting;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import jp.supership.sscore.vamp.rewardedad.SSCoreRewardedAdState;
import jp.supership.vamp.core.logging.LogUtils;

/** VAMPRewardedAd */
public class VAMPRewardedAd {
    @NonNull
    private static final ConcurrentHashMap<String, VAMPRewardedAd> rewardedAdMap =
            new ConcurrentHashMap<>();

    // ArrayListの場合、UnityでConcurrentModificationExceptionが発生する可能性があるため、
    // CopyOnWriteArrayListを代わりに使う
    @NonNull
    private static final CopyOnWriteArrayList<VAMPRewardedAdListener> rewardedAdListeners =
            new CopyOnWriteArrayList<>();

    /**
     * VAMPイベントを受け取る{@link VAMPRewardedAdListener}を追加します。<br>
     * 同じインスタンスは重複追加されません。
     *
     * @param listener {@link VAMPRewardedAdListener}
     */
    private static void addListener(@Nullable final VAMPRewardedAdListener listener) {
        if (listener != null) {
            // Reset
            rewardedAdListeners.remove(listener);
            rewardedAdListeners.add(listener);
        }
    }

    /**
     * 指定した{@link VAMPRewardedAdListener}を解除します。<br>
     * リスナーが追加されていない場合は何もしません。
     *
     * @param listener {@link VAMPRewardedAdListener}
     */
    private static void removeListener(@Nullable final VAMPRewardedAdListener listener) {
        if (listener != null) {
            rewardedAdListeners.remove(listener);
        }
    }

    /**
     * 指定した広告枠IDの広告を取得します。
     *
     * @param activity アクティビティ
     * @param placementId 広告枠ID
     * @param request VAMPRequestオブジェクト
     * @param listener {@link VAMPRewardedAdLoadListener}
     */
    public static void load(
            @NonNull final Activity activity,
            @NonNull final String placementId,
            @NonNull final VAMPRequest request,
            @Nullable final VAMPRewardedAdLoadListener listener) {
        // ディスパッチャーを登録 (重複登録されないため、何度呼び出ししてもOK)
        addListener(VAMPEventDispatcher.getInstance());
        addListener(VAMPActivityEventDispatcher.getInstance());

        final MediationManager.Listener internalListener =
                new MediationManager.Listener() {
                    @Override
                    public void onStartedLoading(@NonNull final String adNetworkName) {
                        if (listener instanceof VAMPRewardedAdLoadAdvancedListener) {
                            ((VAMPRewardedAdLoadAdvancedListener) listener)
                                    .onStartedLoading(placementId, adNetworkName);
                        }

                        LogUtils.d(
                                String.format(
                                        "VAMPRewardedAd(%s) started loading the ad of %s.",
                                        placementId, adNetworkName));
                    }

                    @Override
                    public void onLoaded(
                            @NonNull final String adNetworkName, @Nullable final VAMPError error) {
                        final boolean success;
                        final String message;
                        if (error != null) {
                            success = false;
                            message = error.toString();
                        } else {
                            success = true;
                            message = "success";
                        }

                        if (listener instanceof VAMPRewardedAdLoadAdvancedListener) {
                            ((VAMPRewardedAdLoadAdvancedListener) listener)
                                    .onLoaded(placementId, adNetworkName, success, message);
                        }

                        if (success) {
                            LogUtils.d(
                                    String.format(
                                            "VAMPRewardedAd(%s) loaded the ad of %s.",
                                            placementId, adNetworkName));
                        } else {
                            LogUtils.d(
                                    String.format(
                                            "VAMPRewardedAd(%s) failed to load the ad of %s because"
                                                    + " %s.",
                                            placementId, adNetworkName, message));
                        }
                    }

                    @Override
                    public void onReceived() {
                        // ロード成功のためrewardedAdオブジェクトを維持

                        deleteAllMessagesInDispatcher(placementId);

                        if (listener != null) {
                            listener.onReceived(placementId);
                        }

                        LogUtils.d(
                                String.format("VAMPRewardedAd(%s) received the ad.", placementId));
                    }

                    @Override
                    public void onFailedToLoad(@NonNull final VAMPError error) {
                        // ロード失敗のためrewardedAdオブジェクトを維持しない
                        rewardedAdMap.remove(placementId);

                        deleteAllMessagesInDispatcher(placementId);

                        if (listener != null) {
                            listener.onFailedToLoad(placementId, error);
                        }

                        LogUtils.d(
                                String.format(
                                        "VAMPRewardedAd(%s) failed to load because an error: %s"
                                                + " occurred.",
                                        placementId, error));
                    }

                    @Override
                    public void onFailedToShow(@NonNull final VAMPError error) {
                        for (VAMPRewardedAdListener listener : rewardedAdListeners) {
                            listener.onFailedToShow(placementId, error);
                        }

                        LogUtils.d(
                                String.format(
                                        "VAMPRewardedAd(%s) failed to show because an error: %s"
                                                + " occurred.",
                                        placementId, error));
                    }

                    @Override
                    public void onOpened() {
                        for (VAMPRewardedAdListener listener : rewardedAdListeners) {
                            listener.onOpened(placementId);
                        }

                        LogUtils.d(String.format("VAMPRewardedAd(%s) opened the ad.", placementId));
                    }

                    @Override
                    public void onCompleted() {
                        for (VAMPRewardedAdListener listener : rewardedAdListeners) {
                            listener.onCompleted(placementId);
                        }

                        LogUtils.d(
                                String.format(
                                        "VAMPRewardedAd(%s) completed to give the reward.",
                                        placementId));
                    }

                    @Override
                    public void onClosed(boolean adClicked) {
                        rewardedAdMap.remove(placementId);

                        for (VAMPRewardedAdListener listener : rewardedAdListeners) {
                            listener.onClosed(placementId, adClicked);
                        }

                        LogUtils.d(String.format("VAMPRewardedAd(%s) closed the ad.", placementId));
                    }

                    @Override
                    public void onExpired() {
                        rewardedAdMap.remove(placementId);

                        for (VAMPRewardedAdListener listener : rewardedAdListeners) {
                            listener.onExpired(placementId);
                        }

                        LogUtils.d(String.format("VAMPRewardedAd(%s) expired.", placementId));
                    }
                };

        VAMPRewardedAd theRewardedAd = rewardedAdMap.get(placementId);
        if (theRewardedAd != null && theRewardedAd.manager.state.isLoading()) {
            // ロード中の場合はスキップ
            LogUtils.d(String.format("VAMPRewardedAd(%s) is already loading.", placementId));

            // 引数に渡されたlistenerに通知されるように更新
            // (loadメソッドがロード中に重複して呼ばれた場合は最後にセットされたリスナーが有効)
            theRewardedAd.listener = internalListener;

            return;
        } else if (theRewardedAd != null
                && (theRewardedAd.manager.state.isBeginPlayback()
                        || theRewardedAd.manager.state.isShowing())) {
            // 表示中の場合もスキップ
            // (ロード中ではないため、引数に渡されたVAMPRewardedAdLoadListenerで
            // リスナーを更新する必要はない)
            LogUtils.d(
                    String.format(
                            "VAMPRewardedAd(%s) is showing now. Not permitted to load while showing"
                                    + " the ad.",
                            placementId));
            return;
        }

        if (theRewardedAd != null) {
            // ロード済みの場合は破棄(タイマーの解放を含む)。managerを破棄することで、このインスタンスは実質的に無効化される
            theRewardedAd.manager.destroyManager();
            theRewardedAd.listener = null;
            rewardedAdMap.remove(placementId);
        }

        final VAMPRewardedAd rewardedAd = new VAMPRewardedAd(activity, placementId);
        rewardedAd.listener = internalListener;

        rewardedAdMap.put(placementId, rewardedAd);

        try {
            rewardedAd.manager.load(request);
        } catch (SSCoreRewardedAdState.NotChangedException e) {
            LogUtils.d(e.getMessage());
        }
    }

    /**
     * 指定した広告枠IDの広告を表示する準備が完了している場合、 {@link VAMPRewardedAd}オブジェクトを返します。 それ以外の場合はnullを返します。
     *
     * @param placementId 広告枠ID
     * @return {@link VAMPRewardedAd}オブジェクト
     */
    @Nullable
    public static VAMPRewardedAd of(@NonNull final String placementId) {
        // rewardedAdオブジェクトはshowメソッドを実行するためのオブジェクトという位置づけのため、
        // ロードが完了していないならば、rewardedAdオブジェクトが存在する意味はないので、nullを返す
        VAMPRewardedAd rewardedAd = rewardedAdMap.get(placementId);
        if (rewardedAd != null && rewardedAd.manager.state.isLoaded()) {
            return rewardedAd;
        } else {
            return null;
        }
    }

    /**
     * 指定した広告枠IDのレスポンス情報を取得します。
     *
     * @param placementId 広告枠ID
     * @return {@link VAMPResponseInfo}オブジェクト
     */
    @Nullable
    public static VAMPResponseInfo getResponseInfo(@NonNull final String placementId) {
        VAMPRewardedAd rewardedAd = rewardedAdMap.get(placementId);
        if (rewardedAd == null) {
            return null;
        }

        return rewardedAd.manager.getResponseInfo();
    }

    /**
     * 新しい広告表示シーケンスが開始されるため、ディスパッチャーに溜まっているメッセージを破棄します。
     *
     * @param placementId 広告枠ID
     */
    private static void deleteAllMessagesInDispatcher(@NonNull final String placementId) {
        VAMPEventDispatcher.getInstance().deleteAllMessages(placementId);
        VAMPActivityEventDispatcher.getInstance().deleteAllMessages(placementId);
    }

    @VisibleForTesting
    static void removeAllInstances() {
        rewardedAdMap.clear();
    }

    @NonNull private final MediationManager manager;

    /** アプリ開発者に実行スレッドを意識して実装させるのは酷なので、 listenerメソッドは必ずMainスレッドで実行します */
    @NonNull private final Handler handler = new Handler(Looper.getMainLooper());

    @Nullable private MediationManager.Listener listener;

    /**
     * VAMPRewardedAdオブジェクトを初期化します。
     *
     * @param activity アクティビティ
     * @param placementID 広告枠ID
     */
    private VAMPRewardedAd(@NonNull final Activity activity, @NonNull final String placementID) {
        manager =
                MediationManagerDependency.getResolver()
                        .newInstance(
                                activity,
                                placementID,
                                new MediationManager.Listener() {
                                    @Override
                                    public void onStartedLoading(
                                            @NonNull final String adNetworkName) {
                                        handler.post(
                                                () -> {
                                                    if (listener != null) {
                                                        listener.onStartedLoading(adNetworkName);
                                                    }
                                                });
                                    }

                                    @Override
                                    public void onLoaded(
                                            @NonNull final String adNetworkName,
                                            @Nullable final VAMPError error) {
                                        handler.post(
                                                () -> {
                                                    if (listener != null) {
                                                        listener.onLoaded(adNetworkName, error);
                                                    }
                                                });
                                    }

                                    @Override
                                    public void onReceived() {
                                        handler.post(
                                                () -> {
                                                    if (listener != null) {
                                                        listener.onReceived();
                                                    }
                                                });
                                    }

                                    @Override
                                    public void onFailedToLoad(@NonNull final VAMPError error) {
                                        handler.post(
                                                () -> {
                                                    if (listener != null) {
                                                        listener.onFailedToLoad(error);
                                                    }
                                                });
                                    }

                                    @Override
                                    public void onOpened() {
                                        handler.post(
                                                () -> {
                                                    if (listener != null) {
                                                        listener.onOpened();
                                                    }
                                                });
                                    }

                                    @Override
                                    public void onFailedToShow(@NonNull final VAMPError error) {
                                        handler.post(
                                                () -> {
                                                    if (listener != null) {
                                                        listener.onFailedToShow(error);
                                                    }
                                                });
                                    }

                                    @Override
                                    public void onCompleted() {
                                        handler.post(
                                                () -> {
                                                    if (listener != null) {
                                                        listener.onCompleted();
                                                    }
                                                });
                                    }

                                    @Override
                                    public void onClosed(final boolean adClicked) {
                                        handler.post(
                                                () -> {
                                                    if (listener != null) {
                                                        listener.onClosed(adClicked);
                                                    }
                                                });
                                    }

                                    @Override
                                    public void onExpired() {
                                        handler.post(
                                                () -> {
                                                    if (listener != null) {
                                                        listener.onExpired();
                                                    }
                                                });
                                    }
                                });
    }

    /**
     * 広告を表示します。
     *
     * <p>※動画が再生されます。
     *
     * <p>show実行時には、{@link VAMPRewardedAdListener#onClosed}を受け取るまでは load を実行しないでください。
     *
     * @param activity アクティビティ
     */
    public void show(@NonNull final Activity activity) {
        manager.show(activity);
    }
}
