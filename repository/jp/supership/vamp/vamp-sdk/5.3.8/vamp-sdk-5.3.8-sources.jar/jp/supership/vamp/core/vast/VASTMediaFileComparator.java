//
//  Copyright © 2026 Supership Inc. All rights reserved.
//
package jp.supership.vamp.core.vast;

import androidx.annotation.NonNull;
import java.util.Comparator;

public final class VASTMediaFileComparator implements Comparator<VASTMediaFile> {

    @Override
    public int compare(@NonNull VASTMediaFile a, @NonNull VASTMediaFile b) {
        return a.bitrate - b.bitrate;
    }
}
