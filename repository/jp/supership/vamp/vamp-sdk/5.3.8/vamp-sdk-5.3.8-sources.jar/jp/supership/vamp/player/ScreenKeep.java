//
//  Copyright © 2026 Supership Inc. All rights reserved.
//
package jp.supership.vamp.player;

import android.app.Activity;
import android.view.WindowManager;
import androidx.annotation.NonNull;

/** 画面オンの状態維持設定をするユーティリティ */
final class ScreenKeep {
    /** 画面をオンのままにします(端末をスリープ状態に入らないようにします) */
    static void start(@NonNull final Activity activity) {
        activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    /** 画面オンの状態維持設定を解除します */
    static void stop(@NonNull final Activity activity) {
        activity.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }
}
