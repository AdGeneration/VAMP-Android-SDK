//
//  Copyright © 2012-2016 Supership Inc. All rights reserved.
//
package jp.supership.vamp.core.eventbus.meta;

/** Interface for generated indexes. */
public interface SubscriberInfoIndex {
    SubscriberInfo getSubscriberInfo(Class<?> subscriberClass);
}
