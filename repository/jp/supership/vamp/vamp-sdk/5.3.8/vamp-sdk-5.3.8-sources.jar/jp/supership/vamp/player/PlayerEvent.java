//
//  Copyright © 2026 Supership Inc. All rights reserved.
//
package jp.supership.vamp.player;

public class PlayerEvent {
    public static final int EVENT_CLOSE = 0x01;

    private final int event;

    public PlayerEvent(int event) {
        this.event = event;
    }

    public boolean isClose() {
        return (event & EVENT_CLOSE) != 0;
    }
}
