//
//  Copyright © 2026 Supership Inc. All rights reserved.
//
package jp.supership.vamp.player;

import android.text.TextUtils;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import java.io.Serializable;
import java.net.MalformedURLException;
import java.net.URL;
import jp.supership.sscore.vamp.http.SSCoreHttpClient;
import jp.supership.sscore.vamp.http.SSCoreHttpRequest;

final class ClickThrough implements Serializable {
    /** インスタンスを生成できません。詳細はmessageを参照してください */
    static final class CanNotInstantiateException extends Exception {
        CanNotInstantiateException(String message) {
            super(message);
        }
    }

    /**
     * 既にクリックスルーURLを消費済みです。<br>
     * sendメソッドによってHTTPリクエストを送信済みか、consumeメソッドによってURLを既に取り出している場合に発生します
     */
    static final class AlreadyConsumedException extends Exception {}

    @NonNull private final URL url;
    @NonNull private final SSCoreHttpClient httpClient;
    private boolean consumed;

    ClickThrough(@Nullable final String url, @NonNull SSCoreHttpClient httpClient)
            throws CanNotInstantiateException {
        if (TextUtils.isEmpty(url)) {
            throw new CanNotInstantiateException("url is null or empty.");
        }

        try {
            this.url = new URL(url);
        } catch (MalformedURLException e) {
            throw new CanNotInstantiateException(e.toString());
        }

        this.httpClient = httpClient;
    }

    @NonNull
    @Override
    public String toString() {
        return "ClickThrough { url=" + url + " consumed=" + consumed + " }";
    }

    /**
     * クリックスルーURLを1回だけ取り出せます
     *
     * @return クリックスルーURL
     * @throws AlreadyConsumedException consumeメソッドまたはsendメソッドを実行済みのときに発生します
     */
    @NonNull
    String consume() throws AlreadyConsumedException {
        if (consumed) {
            throw new AlreadyConsumedException();
        }

        consumed = true;
        return url.toString();
    }

    /**
     * クリックスルーURLに対してHTTPリクエストを送信します
     *
     * @throws AlreadyConsumedException consumeメソッドまたはsendメソッドを実行済みのときに発生します
     */
    void send() throws AlreadyConsumedException {
        String urlString = consume();
        try {
            SSCoreHttpRequest httpRequest =
                    new SSCoreHttpRequest.Builder(urlString)
                            .withMethod(SSCoreHttpRequest.Method.GET)
                            .build();
            httpClient.request(httpRequest, null);
        } catch (MalformedURLException | SSCoreHttpRequest.InvalidRequestParameterException e) {
            // エラーが発生してもconsumeは済みなので無視
        }
    }

    /**
     * クリックスルーURLを消費せずに取得します
     *
     * @return クリックスルーURLの文字列
     */
    @NonNull
    String peekUrl() {
        return url.toString();
    }

    /**
     * クリックスルーURLがhttp(s)プロトコルを使用しているかどうかを返します
     *
     * @return http(s)プロトコルを使用している場合はtrue、それ以外はfalse
     */
    boolean isHttpProtocol() {
        final String protocol = url.getProtocol();
        return protocol.equals("http") || protocol.equals("https");
    }
}
