//
//  Copyright © 2026 Supership Inc. All rights reserved.
//
package jp.supership.vamp.utils;

import android.graphics.Bitmap;
import androidx.annotation.Nullable;
import java.io.ByteArrayOutputStream;
import jp.supership.vamp.core.logging.LogUtils;

public class BitmapUtils {
    /**
     * BitmapをByteArrayに変換します
     *
     * @param bitmap 変換するBitmap
     * @param format 画像フォーマット
     * @param quality 圧縮品質 0-100
     * @return 変換されたByteArray、失敗時はnull
     */
    @Nullable
    public static byte[] toByteArray(Bitmap bitmap, Bitmap.CompressFormat format, int quality) {
        if (bitmap == null) {
            return null;
        }

        try (ByteArrayOutputStream stream = new ByteArrayOutputStream()) {
            if (bitmap.compress(format, quality, stream)) {
                return stream.toByteArray();
            }
            return null;
        } catch (Exception e) {
            LogUtils.e("Error during compression bitmap. " + e.getMessage());
            return null;
        }
    }

    /** BitmapをJPEG形式のByteArrayに変換（品質82） */
    @Nullable
    public static byte[] toByteArray(Bitmap bitmap) {
        return toByteArray(bitmap, Bitmap.CompressFormat.JPEG, 82);
    }
}
