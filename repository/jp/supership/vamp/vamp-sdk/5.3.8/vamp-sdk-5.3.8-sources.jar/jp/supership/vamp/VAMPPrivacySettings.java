//
//  Copyright © 2026 Supership Inc. All rights reserved.
//
package jp.supership.vamp;

import androidx.annotation.NonNull;

/** ユーザのプライバシーに関する設定を含んだクラス */
public final class VAMPPrivacySettings {
    /** ユーザの同意ステータスを定義 */
    public enum ConsentStatus {
        /** 不明 */
        UNKNOWN,
        /** ユーザの同意がある */
        ACCEPTED,
        /** ユーザが拒否した */
        DENIED
    }

    /** GDPRの対象ユーザで特定の年齢未満であるかどうかの定義 */
    public enum UnderAgeOfConsent {
        /** 不明 */
        UNKNOWN,
        /** 同意年齢未満のユーザに適した広告リクエストをする */
        TRUE,
        /** 同意年齢未満のユーザに適した広告リクエストをしない */
        FALSE,
    }

    /** 子供向けとして扱うかどかの定義 */
    public enum ChildDirected {
        /** 不明 */
        UNKNOWN,
        /** 子供向けとして扱う */
        TRUE,
        /** 子供向けとして扱わない */
        FALSE
    }

    /** EU圏からのアクセスかどうかを取得するためのリスナー */
    public interface UserConsentListener {
        /**
         * EU圏からのアクセスかどうかを通知します。
         *
         * @param isRequired EU圏からのアクセスならば<b>true</b>、そうでなければ<b>false</b>
         */
        void onRequired(boolean isRequired);
    }

    @NonNull private static ConsentStatus consentStatus = ConsentStatus.UNKNOWN;
    @NonNull private static ChildDirected childDirected = ChildDirected.UNKNOWN;
    @NonNull private static UnderAgeOfConsent underAgeOfConsent = UnderAgeOfConsent.UNKNOWN;

    /**
     * ユーザの同意ステータスを取得します。
     *
     * <p>{@link VAMPPrivacySettings#setConsentStatus(ConsentStatus)}で設定した値を返却します。
     *
     * @return 同意ステータス（{@link ConsentStatus} 参照）
     */
    @NonNull
    public static ConsentStatus getConsentStatus() {
        return consentStatus;
    }

    /**
     * ユーザの同意ステータスを設定します。
     *
     * <p>ユーザの同意がある場合は{@link ConsentStatus#ACCEPTED}を設定します。
     *
     * @param status 同意ステータス（{@link ConsentStatus} 参照）
     */
    public static synchronized void setConsentStatus(@NonNull final ConsentStatus status) {
        consentStatus = status;
    }

    /**
     * COPPA対象ユーザであるかどうかを取得します。
     *
     * <p>{@link VAMPPrivacySettings#setChildDirected(ChildDirected)}で設定した値を返却します。
     *
     * @return {@link VAMPPrivacySettings#setChildDirected(ChildDirected)}で設定した値
     */
    @NonNull
    public static ChildDirected getChildDirected() {
        return childDirected;
    }

    /**
     * COPPA対象ユーザであるかどうかを設定します。 これらの対象の国ユーザが特定の年齢未満の場合にはTRUEを設定してください。
     *
     * @param childDirected ユーザの年齢が特定の年齢未満かどうか
     */
    public static synchronized void setChildDirected(@NonNull final ChildDirected childDirected) {
        VAMPPrivacySettings.childDirected = childDirected;
    }

    /**
     * GDPRの対象ユーザで特定の年齢未満であるかどうかを取得します。
     *
     * @return 特定の年齢未満のユーザかどうか
     */
    @NonNull
    public static UnderAgeOfConsent getUnderAgeOfConsent() {
        return underAgeOfConsent;
    }

    /**
     * GDPRの対象ユーザで特定の年齢未満であるかどうかを設定します。
     *
     * @param underAgeOfConsent 特定の年齢未満のユーザかどうか
     */
    public static synchronized void setUnderAgeOfConsent(
            @NonNull final UnderAgeOfConsent underAgeOfConsent) {
        VAMPPrivacySettings.underAgeOfConsent = underAgeOfConsent;
    }
}
