//
//  Copyright © 2026 Supership Inc. All rights reserved.
//
package jp.supership.vamp.player.view;

import android.content.Context;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import jp.supership.sscore.vamp.type.Optional;
import jp.supership.vamp.player.LandingPage;

/**
 * リワード動画視聴後に表示するView
 *
 * <p>LP表示用WebViewエンドカードと画像エンドカードの両方が表示可能な場合はWebView版を優先します
 *
 * <p>Created by masaki.ando on 2022/11/14.
 */
final class EndCardView {
    @NonNull private Optional<String> imageFilePath = Optional.empty();
    @NonNull private Optional<LandingPage> landingPage = Optional.empty();
    @NonNull private Optional<EndCardWebView.Listener> webViewListener = Optional.empty();

    /** 画像エンドカードのパラメータを設定します */
    @NonNull
    EndCardView withImageView(@NonNull final Optional<String> imageFilePath) {
        this.imageFilePath = imageFilePath;
        return this;
    }

    /** LP用WebViewエンドカードのパラメータを設定します */
    @NonNull
    EndCardView withWebView(
            @NonNull final Optional<LandingPage> landingPage,
            @NonNull final EndCardWebView.Listener listener) {
        this.landingPage = landingPage;
        this.webViewListener = Optional.of(listener);
        return this;
    }

    /** Viewを生成し、`parent`に追加します。生成できない場合はOptional.empty()を返します */
    @NonNull
    Optional<EndCardViewInterface> addTo(
            @NonNull final ViewGroup parent, @NonNull final Context context) {
        final Optional<EndCardWebView> webView =
                EndCardWebView.addTo(
                        parent,
                        context,
                        landingPage,
                        webViewListener.orElse(
                                new EndCardWebView.Listener() {
                                    @Override
                                    public void onClose() {
                                        // Nothing to do.
                                    }

                                    @Override
                                    public void onMenuItemClick(int itemId) {
                                        // Nothing to do.
                                    }
                                }));

        if (webView.isPresent()) {
            final EndCardViewInterface view = webView.forced();
            return Optional.of(view);
        }

        final EndCardViewInterface view =
                EndCardImageView.addTo(parent, context, imageFilePath).maybe();
        return Optional.of(view);
    }
}
