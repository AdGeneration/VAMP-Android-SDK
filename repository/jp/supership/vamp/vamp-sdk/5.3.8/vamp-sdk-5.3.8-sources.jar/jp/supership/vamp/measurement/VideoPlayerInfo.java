//
//  Copyright © 2026 Supership Inc. All rights reserved.
//
package jp.supership.vamp.measurement;

public final class VideoPlayerInfo {
    /** 動画の再生時間 */
    public final float duration;

    /** ミュート状態かどうか */
    public final boolean isMute;

    public VideoPlayerInfo(float duration, boolean isMute) {
        this.duration = duration;
        this.isMute = isMute;
    }

    /** プレイヤーの音量を返します */
    public float volume() {
        return isMute ? 0.0f : 1.0f;
    }
}
