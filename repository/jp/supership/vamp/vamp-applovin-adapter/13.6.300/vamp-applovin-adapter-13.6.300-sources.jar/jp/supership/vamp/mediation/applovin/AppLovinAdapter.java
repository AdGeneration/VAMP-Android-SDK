//
//  Copyright © 2026 Supership Inc. All rights reserved.
//
package jp.supership.vamp.mediation.applovin;

import android.content.Context;
import android.os.Build;
import android.text.TextUtils;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.applovin.adview.AppLovinIncentivizedInterstitial;
import com.applovin.sdk.AppLovinAd;
import com.applovin.sdk.AppLovinAdClickListener;
import com.applovin.sdk.AppLovinAdDisplayListener;
import com.applovin.sdk.AppLovinAdLoadListener;
import com.applovin.sdk.AppLovinAdRewardListener;
import com.applovin.sdk.AppLovinAdVideoPlaybackListener;
import com.applovin.sdk.AppLovinErrorCodes;
import com.applovin.sdk.AppLovinMediationProvider;
import com.applovin.sdk.AppLovinPrivacySettings;
import com.applovin.sdk.AppLovinSdk;
import com.applovin.sdk.AppLovinSdkInitializationConfiguration;
import com.applovin.sdk.AppLovinSdkSettings;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import jp.supership.vamp.VAMPError;
import jp.supership.vamp.VAMPLogger;
import jp.supership.vamp.VAMPPrivacySettings;
import jp.supership.vamp.mediation.AdNetworkErrorInfo;
import jp.supership.vamp.mediation.Adapter;
import jp.supership.vamp.mediation.AdapterConfiguration;
import jp.supership.vamp.mediation.AdapterEventListener;
import jp.supership.vamp.mediation.Event;

public class AppLovinAdapter implements Adapter {

    private static final String ADNW_NAME = "AppLovin";

    private final String adapterName = AppLovinAdapter.class.getSimpleName();
    private final VAMPLogger logger = new VAMPLogger(adapterName);

    // Rewarded video globals.
    private static final List<String> LOADING_ZONE_ID = new ArrayList<>();
    private static final Object LOADING_ZONE_ID_LOCK = new Object();

    private AppLovinAd appLovinAd;

    private String sdkKey;
    private String zoneId;
    private boolean userCancel = false;
    private boolean userOverQuota = false; // 設定額超過
    private boolean userRewardRejected = false;
    private boolean userVerified = false;

    private AdapterConfiguration adapterConfiguration;
    private AdapterEventListener adapterListener;

    @Override
    public boolean isSupported() {
        // 公式の最小サポートOSは AppLovin SDK 13.6.3 以降 Android 7.0（API 24）だが、Oreo（8.0）とする
        // https://scaleout.backlog.jp/view/VIDEO_RWD-2476
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.O;
    }

    @NonNull
    @Override
    public String getAdNetworkName() {
        return ADNW_NAME;
    }

    @NonNull
    @Override
    public List<String> getAdNetworkAdIdentifiers() {
        if (!TextUtils.isEmpty(zoneId)) {
            return Collections.singletonList(zoneId);
        } else {
            return Collections.emptyList();
        }
    }

    @NonNull
    @Override
    public String getAdNetworkVersion() {
        // AppLovinSdk.VERSION は非定数フィールドのため参照時にクラス初期化が走る。
        // AppLovin SDK 13.6.3 以降は minSdk 24 で API 23 での初期化は保証外
        // （失敗すると Error 系になり呼び出し元の catch (Exception) を突き抜ける）ため参照しない
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) {
            return "";
        }
        return AppLovinSdk.VERSION;
    }

    @NonNull
    @Override
    public String getAdapterVersion() {
        return BuildConfig.VERSION_NAME;
    }

    @Override
    public boolean prepare(
            @NonNull final Context context,
            @NonNull final AdapterConfiguration configuration,
            @Nullable final AdapterEventListener listener) {
        this.adapterConfiguration = configuration;
        this.adapterListener = listener;

        sdkKey = adapterConfiguration.getAdID();

        Map<String, String> mediationParams = adapterConfiguration.getMediationParams();

        zoneId = mediationParams.get("zoneid");
        String placement = mediationParams.get("placement");

        if (sdkKey != null) sdkKey = sdkKey.trim();
        if (zoneId != null) zoneId = zoneId.trim();

        if (!TextUtils.isEmpty(placement)) {
            logger.e("Placements have been removed. Please configure zones and use them instead.");
        }

        if (TextUtils.isEmpty(sdkKey)) {
            logger.w("Invalid SDK Key.");
            return false;
        }

        if (TextUtils.isEmpty(zoneId)) {
            logger.w("Invalid zone ID.");
            return false;
        }

        setPrivacySettings(configuration);
        logger.d(
                String.format(
                        "%s is prepared. \n" + "sdkKey:%s\n" + "zoneId:%s\n",
                        adapterName, sdkKey, zoneId));
        return true;
    }

    @Override
    public void load(@NonNull final Context context) {

        AppLovinSdkInitializationConfiguration initConfig =
                AppLovinSdkInitializationConfiguration.builder(sdkKey)
                        .setMediationProvider(AppLovinMediationProvider.MAX)
                        .build();

        AppLovinSdk sdk = AppLovinSdk.getInstance(context);
        sdk.initialize(
                initConfig,
                config -> {
                    AppLovinSdkSettings settings = AppLovinSdk.getInstance(context).getSettings();
                    settings.setVerboseLogging(adapterConfiguration.isDebugMode());

                    synchronized (LOADING_ZONE_ID_LOCK) {
                        if (LOADING_ZONE_ID.contains(zoneId)) {
                            final String logMessage =
                                    "Cannot load multiple ads with the same zone ID.";
                            logger.w(logMessage);

                            if (adapterListener != null) {
                                adapterListener.onEvent(
                                        new Event(
                                                Event.EVENT_FAIL,
                                                new AdNetworkErrorInfo.Builder(
                                                                "load", VAMPError.ADNETWORK_ERROR)
                                                        .setAdNetworkErrorMessage(logMessage)
                                                        .build()));
                            }

                        } else {
                            sdk.getAdService().loadNextAdForZoneId(zoneId, adLoadListener);
                            LOADING_ZONE_ID.add(zoneId);
                        }
                    }
                });
    }

    @Override
    public boolean isReady() {
        return appLovinAd != null;
    }

    @Override
    public void show(@NonNull Context context) {
        AppLovinIncentivizedInterstitial incentivizedInterstitial =
                new AppLovinIncentivizedInterstitial();
        incentivizedInterstitial.show(
                appLovinAd,
                adRewardListener,
                adVideoPlaybackListener,
                adDisplayListener,
                adClickListener);
    }

    @Override
    public void destroy() {
        synchronized (LOADING_ZONE_ID_LOCK) {
            LOADING_ZONE_ID.remove(zoneId);
        }

        appLovinAd = null;
    }

    private void setPrivacySettings(AdapterConfiguration configuration) {
        if (configuration.getConsentStatus() != VAMPPrivacySettings.ConsentStatus.UNKNOWN) {
            final boolean hasUserConsent =
                    configuration.getConsentStatus() == VAMPPrivacySettings.ConsentStatus.ACCEPTED;
            AppLovinPrivacySettings.setHasUserConsent(hasUserConsent);

            if (configuration.isDebugMode()) {
                logger.d("hasUserConsent=" + AppLovinPrivacySettings.hasUserConsent());
            }
        }
    }

    private final AppLovinAdLoadListener adLoadListener =
            new AppLovinAdLoadListener() {
                @Override
                public void adReceived(AppLovinAd ad) {
                    logger.d("adReceived called. " + appLovinAdToString(ad));

                    if (ad.getZoneId().equals(zoneId)) {
                        appLovinAd = ad;
                        if (adapterListener != null) {
                            adapterListener.onEvent(new Event(Event.EVENT_LOAD_SUCCESS));
                        }
                    }
                }

                @Override
                public void failedToReceiveAd(int errorCode) {
                    final String methodName = "failedToReceiveAd";
                    logger.d(methodName + " called. errorCode=" + errorCodeToString(errorCode));

                    if (adapterListener != null) {
                        VAMPError vampError = VAMPError.ADNETWORK_ERROR;
                        if (errorCode == AppLovinErrorCodes.NO_FILL) {
                            vampError = VAMPError.NO_ADSTOCK;
                        }

                        adapterListener.onEvent(
                                new Event(
                                        Event.EVENT_FAIL,
                                        new AdNetworkErrorInfo.Builder(methodName, vampError)
                                                .setAdNetworkErrorCode(errorCodeToString(errorCode))
                                                .setAdNetworkErrorMessage(getDetailMessage())
                                                .build()));
                    }
                }
            };

    private final AppLovinAdRewardListener adRewardListener =
            new AppLovinAdRewardListener() {
                @Override
                public void userRewardVerified(AppLovinAd ad, Map<String, String> response) {
                    logger.d("userRewardVerified called. zoneId=" + ad.getZoneId());

                    // If you are using reward validation for incentivized videos, this method will
                    // be invoked if we contacted AppLovin successfully.
                    // This means that we will be pinging your currency endpoint shortly, so you may
                    // wish to refresh the user's coins from your server.
                    logger.d(appLovinAdToString(ad));

                    String currency = response.get("currency");
                    String amount = response.get("amount");

                    logger.d(String.format("currency=%s, amount=%s", currency, amount));

                    if (ad.getZoneId().equals(zoneId)) {
                        logger.d("userVerified = true");
                        userVerified = true;
                    }
                }

                @Override
                public void userOverQuota(AppLovinAd ad, Map<String, String> response) {
                    // 設定額超過
                    // This method will be invoked if the user has already received the maximum
                    // allocated rewards for the day.
                    logger.d("userOverQuota called. " + appLovinAdToString(ad));

                    if (ad.getZoneId().equals(zoneId)) {
                        userOverQuota = true;
                        logger.d("user over quota error.");
                    }
                }

                @Override
                public void userRewardRejected(AppLovinAd ad, Map<String, String> response) {
                    // ユーザーがリジェクト対象
                    // This method will be invoked if the user's reward was detected as fraudulent
                    // and not awarded.
                    logger.d("userRewardRejected called. " + appLovinAdToString(ad));

                    if (ad.getZoneId().equals(zoneId)) {
                        userRewardRejected = true;

                        logger.d("user rejected error.");
                    }
                }

                @Override
                public void validationRequestFailed(AppLovinAd ad, int errorCode) {
                    // This method will be invoked if we were unable to contact AppLovin, therefore
                    // no ping will be heading to your server.
                    logger.d("validationRequestFailed called. " + appLovinAdToString(ad));

                    final String errorCodeString = errorCodeToString(errorCode);

                    if (ad.getZoneId().equals(zoneId)) {
                        logger.d("errorCode:" + errorCodeString);

                        if (errorCode == AppLovinErrorCodes.INCENTIVIZED_USER_CLOSED_VIDEO) {
                            // user cancel.
                            userCancel = true;
                            logger.d("User Cancel");
                        }
                    }
                }
            };

    private final AppLovinAdVideoPlaybackListener adVideoPlaybackListener =
            new AppLovinAdVideoPlaybackListener() {
                @Override
                public void videoPlaybackBegan(AppLovinAd ad) {
                    // Triggered when a video begins playing in a video advertisement.
                    logger.d("videoPlaybackBegan called. " + appLovinAdToString(ad));
                }

                @Override
                public void videoPlaybackEnded(
                        AppLovinAd ad, double percentViewed, boolean fullyWatched) {
                    // Triggered when a video stops playing in a video advertisement.
                    // userVerifiedはAppLovin側のリワードの条件
                    logger.d(
                            String.format(
                                    Locale.US,
                                    "videoPlaybackEnded called. ad=%s, percentViewed=%.2f,"
                                            + " fullyWatched=%s",
                                    appLovinAdToString(ad),
                                    percentViewed,
                                    fullyWatched));

                    if (ad.getZoneId().equals(zoneId)) {
                        logger.d(getDetailMessage());

                        if (userVerified) {
                            if (!userCancel && !userOverQuota && !userRewardRejected) {
                                if (fullyWatched) {
                                    // 最後まで視聴完了（fullyWatchedがtrue）の時だけComplete
                                    if (adapterListener != null) {
                                        adapterListener.onEvent(new Event(Event.EVENT_COMPLETE));
                                    }
                                } else {
                                    logger.d("video fullyWatched : false.");
                                }
                            }
                        }
                    }
                }
            };

    private final AppLovinAdDisplayListener adDisplayListener =
            new AppLovinAdDisplayListener() {
                @Override
                public void adDisplayed(AppLovinAd ad) {
                    // This method is invoked when an ad is displayed inside of the AppLovinAdView
                    // or AppLovinInterstitialAdDialog.
                    logger.d("adDisplayed called. " + appLovinAdToString(ad));

                    if (ad.getZoneId().equals(zoneId)) {
                        if (adapterListener != null) {
                            adapterListener.onEvent(new Event(Event.EVENT_OPEN));
                        }
                    }
                }

                @Override
                public void adHidden(AppLovinAd ad) {
                    // This method is invoked when an ad is displayed inside of the AppLovinAdView
                    // or AppLovinInterstitialAdDialog.
                    final String methodName = "adHidden";
                    logger.d(methodName + " called. " + appLovinAdToString(ad));

                    if (ad.getZoneId().equals(zoneId)) {
                        logger.d(getDetailMessage());

                        if (userCancel) {
                            if (adapterListener != null) {
                                adapterListener.onEvent(
                                        new Event(
                                                Event.EVENT_FAIL | Event.EVENT_CLOSE,
                                                new AdNetworkErrorInfo.Builder(
                                                                methodName, VAMPError.USER_CANCEL)
                                                        .setAdNetworkErrorMessage(
                                                                getDetailMessage())
                                                        .build()));
                            }
                        } else if (userOverQuota || userRewardRejected) {
                            if (adapterListener != null) {
                                adapterListener.onEvent(
                                        new Event(
                                                Event.EVENT_FAIL | Event.EVENT_CLOSE,
                                                new AdNetworkErrorInfo.Builder(
                                                                methodName,
                                                                VAMPError.ADNETWORK_ERROR)
                                                        .setAdNetworkErrorMessage(
                                                                getDetailMessage())
                                                        .build()));
                            }
                        } else {
                            if (adapterListener != null) {
                                adapterListener.onEvent(new Event(Event.EVENT_CLOSE));
                            }
                        }
                    }
                }
            };

    private final AppLovinAdClickListener adClickListener =
            new AppLovinAdClickListener() {
                @Override
                public void adClicked(AppLovinAd ad) {
                    logger.d("adClicked called. " + appLovinAdToString(ad));

                    if (ad.getZoneId().equals(zoneId)) {
                        if (adapterListener != null) {
                            adapterListener.onEvent(new Event(Event.EVENT_CLICK));
                        }
                    }
                }
            };

    private static String appLovinAdToString(AppLovinAd ad) {
        return String.format("zoneid:%s\nAdType:%s", ad.getZoneId(), ad.getType().toString());
    }

    private String getDetailMessage() {
        return "userVerified:"
                + userVerified
                + " userCancel:"
                + userCancel
                + " userOverQuota:"
                + userOverQuota
                + " userRewardRejected:"
                + userRewardRejected;
    }

    private static String errorCodeToString(int errorCode) {
        switch (errorCode) {
            case AppLovinErrorCodes.SDK_DISABLED:
                return "SDK_DISABLED";
            case AppLovinErrorCodes.FETCH_AD_TIMEOUT:
                return "FETCH_AD_TIMEOUT";
            case AppLovinErrorCodes.NO_NETWORK:
                return "NO_NETWORK";
            case AppLovinErrorCodes.NO_FILL:
                return "NO_FILL";
            case AppLovinErrorCodes.UNABLE_TO_RENDER_AD:
                return "UNABLE_TO_RENDER_AD";
            case AppLovinErrorCodes.INVALID_ZONE:
                return "INVALID_ZONE";
            case AppLovinErrorCodes.INVALID_AD_TOKEN:
                return "INVALID_AD_TOKEN";
            case AppLovinErrorCodes.UNSPECIFIED_ERROR:
                return "UNSPECIFIED_ERROR";
            case AppLovinErrorCodes.INCENTIVIZED_NO_AD_PRELOADED:
                return "INCENTIVIZED_NO_AD_PRELOADED";
            case AppLovinErrorCodes.INCENTIVIZED_UNKNOWN_SERVER_ERROR:
                return "INCENTIVIZED_UNKNOWN_SERVER_ERROR";
            case AppLovinErrorCodes.INCENTIVIZED_SERVER_TIMEOUT:
                return "INCENTIVIZED_SERVER_TIMEOUT";
            case AppLovinErrorCodes.INCENTIVIZED_USER_CLOSED_VIDEO:
                return "INCENTIVIZED_USER_CLOSED_VIDEO";
            case AppLovinErrorCodes.INVALID_RESPONSE:
                return "INVALID_RESPONSE";
            case AppLovinErrorCodes.INVALID_URL:
                return "INVALID_URL";
            case AppLovinErrorCodes.UNABLE_TO_PRECACHE_RESOURCES:
                return "UNABLE_TO_PRECACHE_RESOURCES";
            case AppLovinErrorCodes.UNABLE_TO_PRECACHE_IMAGE_RESOURCES:
                return "UNABLE_TO_PRECACHE_IMAGE_RESOURCES";
            case AppLovinErrorCodes.UNABLE_TO_PRECACHE_VIDEO_RESOURCES:
                return "UNABLE_TO_PRECACHE_VIDEO_RESOURCES";
            default:
                return "Unknown Error:" + errorCode;
        }
    }
}
