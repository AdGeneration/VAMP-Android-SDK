package jp.supership.vamp.mediation.maio

import jp.maio.sdk.android.v2.request.MaioRequest

// MaioRequestの第三引数のbitDataがデフォルト引数で定義されているが、
// Javaだとデフォルト引数がサポートされていないためKotlinでラップする
class MaioRequestBuilder(
    private val zoneId: String,
    private val testMode: Boolean,
) {
    fun build(): MaioRequest {
        return MaioRequest(
            zoneId = zoneId,
            testMode = testMode,
        )
    }
}
