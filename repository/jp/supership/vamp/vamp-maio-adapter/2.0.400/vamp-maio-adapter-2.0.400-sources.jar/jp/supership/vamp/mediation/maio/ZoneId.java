package jp.supership.vamp.mediation.maio;

import android.text.TextUtils;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

final class ZoneId {
    @NonNull final String value;

    ZoneId(@Nullable final String value) throws InvalidParameterException {
        String id = null;

        if (!TextUtils.isEmpty(value)) {
            id = value.trim();
        }

        if (TextUtils.isEmpty(id)) {
            throw new InvalidParameterException();
        }

        this.value = id;
    }

    @NonNull
    @Override
    public String toString() {
        return "ZoneId(" + value + ")";
    }
}
