package jp.supership.vamp.mediation.maio;

import jp.supership.vamp.VAMPError;

class MaioError {
    public final int errorCode;
    public final VAMPError vampError;
    public final String errorMessage;

    public MaioError(final int errorCode) {
        this.errorCode = errorCode;

        int errorMainCode = errorCode >= 10000 ? errorCode / 100 : 0;

        if (errorMainCode == 107) {
            vampError = VAMPError.NO_ADSTOCK;
        } else {
            vampError = VAMPError.ADNETWORK_ERROR;
        }

        switch (errorMainCode) {
            case 101:
                errorMessage = "ネットワーク接続がありません。";
                break;
            case 102:
                errorMessage = "ネットワーク接続がタイムアウトしました。";
                break;
            case 103:
                errorMessage = "広告の取得中に中断されました。";
                break;
            case 104:
                errorMessage = "サーバーから正しくないレスポンスが返ってきました。";
                break;
            case 105:
                errorMessage = "存在しないゾーンが指定されました。";
                break;
            case 106:
                errorMessage = "無効なゾーンが指定されました。";
                break;
            case 107:
                errorMessage = "表示可能な広告がありません。";
                break;
            case 108:
                errorMessage = "MaioRequest が null でした。";
                break;
            case 109:
                errorMessage = "ディスク容量が不十分でした。";
                break;
            case 110:
                errorMessage = "対応していない Android バージョンです。";
                break;
            case 201:
                errorMessage = "広告の有効期限が切れました。";
                break;
            case 202:
                errorMessage = "広告の準備ができていません。";
                break;
            case 203:
                errorMessage = "広告はすでに表示されています。";
                break;
            case 204:
                errorMessage = "広告の再生中に問題が発生しました。";
                break;
            case 205:
                errorMessage = "Contextがnullでした。";
                break;
            default:
                errorMessage = "Unknown error";
        }
    }
}
