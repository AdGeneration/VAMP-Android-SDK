package jp.supership.vamp.mediation.maio;

import androidx.annotation.NonNull;

import jp.supership.vamp.mediation.AdapterConfiguration;

final class TestModeFlag {
    /** VAMPの公開用テスト広告枠ID */
    private static final String PUBLIC_PLACEMENT_ID = "59756";

    final boolean value;

    TestModeFlag(@NonNull final AdapterConfiguration config) {
        boolean isTestMode = config.isTestMode();

        // placementIdが公開用広告枠IDと等しい場合は強制的にテストモードにする
        if (config.getPlacementID().equals(PUBLIC_PLACEMENT_ID)) {
            isTestMode = true;
        }

        value = isTestMode;
    }
}
