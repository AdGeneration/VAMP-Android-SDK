package jp.supership.vamp.mediation.maio;

final class InvalidParameterException extends Exception {}
