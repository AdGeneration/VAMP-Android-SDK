package jp.supership.vamp.mediation.maio;

import android.app.Activity;
import android.content.Context;
import android.os.Build;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import jp.maio.sdk.android.v2.Version;
import jp.maio.sdk.android.v2.request.MaioRequest;
import jp.maio.sdk.android.v2.rewarddata.RewardData;
import jp.maio.sdk.android.v2.rewarded.IRewardedLoadCallback;
import jp.maio.sdk.android.v2.rewarded.IRewardedShowCallback;
import jp.maio.sdk.android.v2.rewarded.Rewarded;
import jp.supership.vamp.VAMPError;
import jp.supership.vamp.VAMPLogger;
import jp.supership.vamp.mediation.AdNetworkErrorInfo;
import jp.supership.vamp.mediation.Adapter;
import jp.supership.vamp.mediation.AdapterConfiguration;
import jp.supership.vamp.mediation.AdapterEventListener;
import jp.supership.vamp.mediation.Event;

import java.lang.ref.WeakReference;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;

public class MaioAdapter implements Adapter {
    @NonNull private static final String ADNW_NAME = "maio";

    @NonNull private final String adapterName = MaioAdapter.class.getSimpleName();
    @NonNull private final VAMPLogger logger = new VAMPLogger(adapterName);
    @Nullable private AdapterEventListener adapterListener;
    @Nullable private AdapterConfiguration adapterConfiguration;
    @Nullable private ZoneId zoneId;
    @Nullable private Rewarded rewarded;

    @Override
    public boolean isSupported() {
        // https://github.com/imobile-maio/maio-Android-SDK
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN;
    }

    @NonNull
    @Override
    public String getAdNetworkVersion() {
        return Version.Companion.getInstance().toString();
    }

    @NonNull
    @Override
    public String getAdapterVersion() {
        return BuildConfig.VERSION_NAME;
    }

    @NonNull
    @Override
    public String getAdNetworkName() {
        return ADNW_NAME;
    }

    @NonNull
    @Override
    public List<String> getAdNetworkAdIdentifiers() {
        if (zoneId != null) {
            return Collections.singletonList(zoneId.value);
        } else {
            return Collections.emptyList();
        }
    }

    @Override
    public boolean prepare(
            @NonNull final Context context,
            @NonNull final AdapterConfiguration configuration,
            @Nullable final AdapterEventListener listener) {
        this.adapterConfiguration = configuration;
        this.adapterListener = listener;

        final Map<String, String> mediationParams = configuration.getMediationParams();

        try {
            zoneId = new ZoneId(mediationParams.get("zoneId"));
        } catch (InvalidParameterException e) {
            logger.w(String.format("Failed to prepare %s. zoneId is invalid.", adapterName));
            return false;
        }

        logger.d(String.format("%s is prepared.", adapterName));

        return true;
    }

    @Override
    public void load(@NonNull final Context context) {
        if (!(context instanceof Activity)) {
            if (adapterListener != null) {
                adapterListener.onEvent(Event.newActivityNotFoundErrorEvent("load"));
            }

            return;
        }

        if (adapterConfiguration == null || zoneId == null) {
            if (adapterListener != null) {
                adapterListener.onEvent(
                        Event.newNullOrEmptyParameterErrorEvent(
                                "load", Arrays.asList("adapterConfiguration", "zoneId")));
            }

            return;
        }

        TestModeFlag testMode = new TestModeFlag(adapterConfiguration);

        logger.d(String.format("Initializes MaioRequest. Test mode is %s.", testMode.value));

        MaioRequest request = new MaioRequestBuilder(zoneId.value, testMode.value).build();
        Rewarded.loadAd(request, context, new RLCallback(this));
    }

    @Override
    public boolean isReady() {
        return rewarded != null;
    }

    @Override
    public void show(@NonNull final Context context) {
        if (rewarded == null) {
            final String message = "rewarded hasn't been loaded yet.";
            logger.w(message);

            final AdNetworkErrorInfo errorInfo =
                    new AdNetworkErrorInfo.Builder("show", VAMPError.NOT_LOADED_AD)
                            .setErrorMessage(message)
                            .build();

            if (adapterListener != null) {
                adapterListener.onEvent(new Event(Event.EVENT_FAIL, errorInfo));
            }

            return;
        }

        rewarded.show(context, new RSCallback(this));
    }

    @Override
    public void destroy() {
        rewarded = null;
    }

    /** メモリリークを防ぐためにadapterオブジェクトを弱参照で持つリスナークラスです */
    private static final class RLCallback implements IRewardedLoadCallback {
        @NonNull private final WeakReference<MaioAdapter> adapterRef;

        RLCallback(@NonNull final MaioAdapter adapter) {
            adapterRef = new WeakReference<>(adapter);
        }

        // 広告の読み込みが完了した時に呼ばれるイベント。
        @Override
        public void loaded(@NonNull Rewarded rewarded) {
            final MaioAdapter adapter = adapterRef.get();
            if (adapter == null) {
                return;
            }

            adapter.logger.d("loaded called.");
            adapter.rewarded = rewarded;

            if (adapter.adapterListener != null) {
                adapter.adapterListener.onEvent(new Event(Event.EVENT_LOAD_SUCCESS));
            }
        }

        // 広告の読み込みが完了した時に呼ばれるイベント。
        @Override
        public void failed(@NonNull Rewarded rewarded, int errorCode) {
            final MaioAdapter adapter = adapterRef.get();
            if (adapter == null) {
                return;
            }

            final MaioError error = new MaioError(errorCode);

            adapter.logger.d(
                    "failed called. errorCode="
                            + error.errorCode
                            + ", errorMessage="
                            + error.errorMessage);

            final AdNetworkErrorInfo errorInfo =
                    new AdNetworkErrorInfo.Builder("failed", error.vampError)
                            .setAdNetworkErrorCode("" + error.errorCode)
                            .setAdNetworkErrorMessage(error.errorMessage)
                            .build();

            if (adapter.adapterListener != null) {
                adapter.adapterListener.onEvent(new Event(Event.EVENT_FAIL, errorInfo));
            }
        }
    }

    private static final class RSCallback implements IRewardedShowCallback {
        @NonNull private final WeakReference<MaioAdapter> adapterRef;

        RSCallback(@NonNull final MaioAdapter adapter) {
            adapterRef = new WeakReference<>(adapter);
        }

        // 広告がオープンされた時に呼ばれるイベント。
        @Override
        public void opened(@NonNull Rewarded rewarded) {
            final MaioAdapter adapter = adapterRef.get();
            if (adapter == null) {
                return;
            }

            adapter.logger.d("opened called.");

            if (adapter.adapterListener != null) {
                adapter.adapterListener.onEvent(new Event(Event.EVENT_OPEN));
            }
        }

        // 広告がクローズされた時に呼ばれるイベント。
        @Override
        public void closed(@NonNull Rewarded rewarded) {
            final MaioAdapter adapter = adapterRef.get();
            if (adapter == null) {
                return;
            }

            adapter.logger.d("closed called.");

            if (adapter.adapterListener != null) {
                adapter.adapterListener.onEvent(new Event(Event.EVENT_CLOSE));
            }
        }

        @Override
        public void clicked(@NonNull Rewarded rewarded) {
            final MaioAdapter adapter = adapterRef.get();
            if (adapter == null) {
                return;
            }

            adapter.logger.d("clicked called.");

            if (adapter.adapterListener != null) {
                adapter.adapterListener.onEvent(new Event(Event.EVENT_CLICK));
            }
        }

        // リワード付与のタイミングで通知されるイベント。
        // リワード動画広告の場合は視聴完了時、リワードプレイアブル広告の場合は広告で定められたタイミングで通知されます。
        @Override
        public void rewarded(@NonNull Rewarded rewarded, @NonNull RewardData rewardData) {
            final MaioAdapter adapter = adapterRef.get();
            if (adapter == null) {
                return;
            }

            adapter.logger.d("rewarded called. rewardData=" + rewardData.getValue());

            if (adapter.adapterListener != null) {
                adapter.adapterListener.onEvent(new Event(Event.EVENT_COMPLETE));
            }
        }

        // 広告の表示に失敗した時に呼ばれるイベント。
        @Override
        public void failed(@NonNull Rewarded rewarded, int errorCode) {
            final MaioAdapter adapter = adapterRef.get();
            if (adapter == null) {
                return;
            }

            final MaioError error = new MaioError(errorCode);

            adapter.logger.d(
                    "failed called. errorCode="
                            + error.errorCode
                            + ", errorMessage="
                            + error.errorMessage);

            final AdNetworkErrorInfo errorInfo =
                    new AdNetworkErrorInfo.Builder("failed", error.vampError)
                            .setAdNetworkErrorCode("" + error.errorCode)
                            .setAdNetworkErrorMessage(error.errorMessage)
                            .build();

            if (adapter.adapterListener != null) {
                adapter.adapterListener.onEvent(new Event(Event.EVENT_FAIL, errorInfo));
            }
        }
    }
}
