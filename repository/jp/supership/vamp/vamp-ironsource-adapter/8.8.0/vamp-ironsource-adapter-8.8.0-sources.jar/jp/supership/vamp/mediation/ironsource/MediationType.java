package jp.supership.vamp.mediation.ironsource;

import androidx.annotation.NonNull;

import jp.supership.vamp.VAMP;

final class MediationType {

    /**
     * メディエーションタイプを返します<br>
     * ex.) VAMP73011SDKv472beta1
     *
     * @return Mediation type
     */
    @NonNull
    static String get() {
        // We recommend using the format:
        // MediationName + Adapter Version + "SDK" + Mediation SDK version.
        // should be alphanumeric and 1-64 chars in length.
        String type =
                ("VAMP" + BuildConfig.VERSION_NAME + "SDK" + VAMP.SDKVersion())
                        .trim()
                        .replaceAll("[^a-zA-Z0-9]", "");
        return type.substring(0, Math.min(type.length(), 64));
    }
}
