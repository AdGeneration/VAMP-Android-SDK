package jp.supership.vamp.mediation.ironsource;

import android.text.TextUtils;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

final class InstanceId {
    @NonNull final String value;

    InstanceId(@Nullable final String value) throws InvalidParameterException {
        String id = null;

        if (!TextUtils.isEmpty(value)) {
            id = value.trim();
        }

        if (TextUtils.isEmpty(id)) {
            throw new InvalidParameterException();
        }

        this.value = id;
    }

    @NonNull
    @Override
    public String toString() {
        return "InstanceId(" + value + ")";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        InstanceId that = (InstanceId) o;
        return value.equals(that.value);
    }

    @Override
    public int hashCode() {
        return value.hashCode();
    }
}
