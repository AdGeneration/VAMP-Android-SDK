package jp.supership.vamp.mediation.ironsource;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.ironsource.mediationsdk.IronSource;
import com.ironsource.mediationsdk.demandOnly.ISDemandOnlyRewardedVideoListener;
import com.ironsource.mediationsdk.logger.IronSourceError;

import jp.supership.vamp.VAMPLogger;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

final class ISListenerManager implements ISDemandOnlyRewardedVideoListener {
    interface ISListener {
        @Nullable
        InstanceId getInstanceId();

        void onRewardedVideoAdLoadSuccess(@NonNull InstanceId instanceId);

        void onRewardedVideoAdLoadFailed(
                @NonNull InstanceId instanceId, @NonNull IronSourceError error);

        void onRewardedVideoAdOpened(@NonNull InstanceId instanceId);

        void onRewardedVideoAdClosed(@NonNull InstanceId instanceId);

        void onRewardedVideoAdShowFailed(
                @NonNull InstanceId instanceId, @NonNull IronSourceError error);

        void onRewardedVideoAdClicked(@NonNull InstanceId instanceId);

        void onRewardedVideoAdRewarded(@NonNull InstanceId instanceId);
    }

    static final class ObjectId {
        final String value;

        ObjectId() {
            value = UUID.randomUUID().toString();
        }

        @NonNull
        @Override
        public String toString() {
            return "ObjectId(" + value + ")";
        }

        @Override
        public boolean equals(@Nullable final Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            ObjectId that = (ObjectId) o;
            return value.equals(that.value);
        }

        @Override
        public int hashCode() {
            return value.hashCode();
        }
    }

    @NonNull private static final ISListenerManager instance = new ISListenerManager();

    @NonNull private final Map<ObjectId, ISListener> listeners = new HashMap<>();

    @NonNull
    private final VAMPLogger logger = new VAMPLogger(ISListenerManager.class.getSimpleName());

    private ISListenerManager() {}

    @NonNull
    static ISListenerManager getInstance() {
        return instance;
    }

    void putISListener(@NonNull final ObjectId id, @NonNull final ISListener listener) {
        listeners.put(id, listener);
        IronSource.setISDemandOnlyRewardedVideoListener(this);
    }

    void removeISListener(@NonNull final ObjectId id) {
        listeners.remove(id);
    }

    // Invoked when the RewardedVideo ad load is successful.
    @Override
    public void onRewardedVideoAdLoadSuccess(final String instanceId) {
        try {
            final InstanceId id = new InstanceId(instanceId);
            for (Map.Entry<ObjectId, ISListener> entry : listeners.entrySet()) {
                final ISListener obj = entry.getValue();
                if (id.equals(obj.getInstanceId())) {
                    obj.onRewardedVideoAdLoadSuccess(id);
                }
            }
        } catch (InvalidParameterException e) {
            logger.e("Invalid instance id.");
        }
    }

    // Invoked when the RewardedVideo ad load failed.
    @Override
    public void onRewardedVideoAdLoadFailed(final String instanceId, final IronSourceError error) {
        try {
            final InstanceId id = new InstanceId(instanceId);
            for (Map.Entry<ObjectId, ISListener> entry : listeners.entrySet()) {
                final ISListener obj = entry.getValue();
                if (id.equals(obj.getInstanceId())) {
                    obj.onRewardedVideoAdLoadFailed(id, error);
                }
            }
        } catch (InvalidParameterException e) {
            logger.e("Invalid instance id.");
        }
    }

    // Invoked when the RewardedVideo ad view is about to open.
    @Override
    public void onRewardedVideoAdOpened(final String instanceId) {
        try {
            final InstanceId id = new InstanceId(instanceId);
            for (Map.Entry<ObjectId, ISListener> entry : listeners.entrySet()) {
                final ISListener obj = entry.getValue();
                if (id.equals(obj.getInstanceId())) {
                    obj.onRewardedVideoAdOpened(id);
                }
            }
        } catch (InvalidParameterException e) {
            logger.e("Invalid instance id.");
        }
    }

    // Invoked when the RewardedVideo ad view is about to be closed.
    // Your activity will now regain its focus.
    @Override
    public void onRewardedVideoAdClosed(final String instanceId) {
        try {
            final InstanceId id = new InstanceId(instanceId);
            for (Map.Entry<ObjectId, ISListener> entry : listeners.entrySet()) {
                final ISListener obj = entry.getValue();
                if (id.equals(obj.getInstanceId())) {
                    obj.onRewardedVideoAdClosed(id);
                }
            }
        } catch (InvalidParameterException e) {
            logger.e("Invalid instance id.");
        }
    }

    // Invoked when RewardedVideo call to show a rewarded video has
    // failed. IronSourceError contains the reason for the failure.
    @Override
    public void onRewardedVideoAdShowFailed(final String instanceId, final IronSourceError error) {
        try {
            final InstanceId id = new InstanceId(instanceId);
            for (Map.Entry<ObjectId, ISListener> entry : listeners.entrySet()) {
                final ISListener obj = entry.getValue();
                if (id.equals(obj.getInstanceId())) {
                    obj.onRewardedVideoAdShowFailed(id, error);
                }
            }
        } catch (InvalidParameterException e) {
            logger.e("Invalid instance id.");
        }
    }

    // Invoked when the end user clicked on the RewardedVideo ad
    @Override
    public void onRewardedVideoAdClicked(final String instanceId) {
        try {
            final InstanceId id = new InstanceId(instanceId);
            for (Map.Entry<ObjectId, ISListener> entry : listeners.entrySet()) {
                final ISListener obj = entry.getValue();
                if (id.equals(obj.getInstanceId())) {
                    obj.onRewardedVideoAdClicked(id);
                }
            }
        } catch (InvalidParameterException e) {
            logger.e("Invalid instance id.");
        }
    }

    // Invoked when the user completed the video and should be rewarded.
    // If using server-to-server callbacks you may ignore this events and
    // wait for the callback from the ironSource server.
    @Override
    public void onRewardedVideoAdRewarded(final String instanceId) {
        try {
            final InstanceId id = new InstanceId(instanceId);
            for (Map.Entry<ObjectId, ISListener> entry : listeners.entrySet()) {
                final ISListener obj = entry.getValue();
                if (id.equals(obj.getInstanceId())) {
                    obj.onRewardedVideoAdRewarded(id);
                }
            }
        } catch (InvalidParameterException e) {
            logger.e("Invalid instance id.");
        }
    }
}
