package jp.supership.vamp.mediation.ironsource;

import android.text.TextUtils;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

final class AppKey {
    /** ironSourceのデモアプリに記載されているキー */
    private static final String IRONSOURCE_DEMO_KEY = "85460dcd";

    @NonNull final String value;

    AppKey(@Nullable final String value) throws InvalidParameterException {
        String id = null;

        if (!TextUtils.isEmpty(value)) {
            id = value.trim();
        }

        if (TextUtils.isEmpty(id)) {
            throw new InvalidParameterException();
        }

        this.value = id;
    }

    @NonNull
    static AppKey ironSourceDemoKey() {
        AppKey key = null;
        try {
            key = new AppKey(IRONSOURCE_DEMO_KEY);
        } catch (InvalidParameterException ignored) {
        }

        assert key != null;
        return key;
    }

    @NonNull
    @Override
    public String toString() {
        return "AppKey(" + value + ")";
    }
}
