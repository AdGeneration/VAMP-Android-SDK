package jp.supership.vamp.mediation.ironsource;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import jp.supership.vamp.VAMPError;
import jp.supership.vamp.mediation.AdNetworkErrorInfo;

final class RewardResult {
    @Nullable final AdNetworkErrorInfo errorInfo;

    private RewardResult(@Nullable AdNetworkErrorInfo errorInfo) {
        this.errorInfo = errorInfo;
    }

    /** 報酬付与可な状態でインスタンスを生成します */
    @NonNull
    static RewardResult resultCompleted() {
        return new RewardResult(null);
    }

    /**
     * 報酬付与不可な状態でインスタンスを生成します
     *
     * @param errorInfo エラー情報
     */
    @NonNull
    static RewardResult resultFailed(@NonNull AdNetworkErrorInfo errorInfo) {
        return new RewardResult(errorInfo);
    }

    /** 不定状態でインスタンスを生成します。このインスタンスのisCompleted()はfalseを返します */
    @NonNull
    static RewardResult resultUnknown() {
        AdNetworkErrorInfo errorInfo =
                new AdNetworkErrorInfo.Builder("resultUnknown", VAMPError.UNKNOWN).build();
        return new RewardResult(errorInfo);
    }

    /** trueならば報酬付与可になった状態 */
    boolean isCompleted() {
        return errorInfo == null;
    }

    /** trueならばエラーが発生した状態 */
    boolean isFailed() {
        return errorInfo != null && errorInfo.getError() != VAMPError.UNKNOWN;
    }
}
