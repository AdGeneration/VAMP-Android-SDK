package jp.supership.vamp.mediation.ironsource;

final class InvalidParameterException extends Exception {}
