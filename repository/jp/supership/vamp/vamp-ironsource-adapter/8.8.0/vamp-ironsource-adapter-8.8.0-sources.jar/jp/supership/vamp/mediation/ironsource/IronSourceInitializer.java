package jp.supership.vamp.mediation.ironsource;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.ironsource.mediationsdk.logger.IronSourceError;
import com.unity3d.ironsourceads.InitListener;
import com.unity3d.ironsourceads.InitRequest;
import com.unity3d.ironsourceads.IronSourceAds;

import java.util.ArrayList;

public class IronSourceInitializer implements InitListener {
    private enum State {
        UNINITIALIZED,
        INITIALIZING,
        INITIALIZED
    }

    private State state = State.UNINITIALIZED;
    private final ArrayList<InitializationListener> listeners = new ArrayList<>();

    private static IronSourceInitializer instance = null;

    private IronSourceInitializer() {}

    static synchronized IronSourceInitializer getInstance() {
        if (instance == null) {
            instance = new IronSourceInitializer();
        }

        return instance;
    }

    boolean isInitialized() {
        return state == State.INITIALIZED;
    }

    void initialize(
            @NonNull Context context,
            @NonNull InitRequest request,
            @Nullable InitializationListener listener) {
        if (state == State.INITIALIZED) {
            if (listener != null) {
                listener.onSuccess();
            }

            return;
        }

        if (listener != null) {
            listeners.add(listener);
        }

        if (state != State.INITIALIZING) {
            synchronized (this) {
                state = State.INITIALIZING;
            }

            IronSourceAds.init(context, request, this);
        }
    }

    @Override
    public void onInitSuccess() {
        synchronized (this) {
            state = State.INITIALIZED;
        }

        for (InitializationListener listener : listeners) {
            listener.onSuccess();
        }

        listeners.clear();
    }

    @Override
    public void onInitFailed(@NonNull IronSourceError ironSourceError) {
        // エラーの場合も初期化済みとする
        synchronized (this) {
            state = State.INITIALIZED;
        }

        for (InitializationListener listener : listeners) {
            listener.onFail(ironSourceError);
        }

        listeners.clear();
    }

    interface InitializationListener {
        void onSuccess();

        void onFail(IronSourceError error);
    }
}
