package jp.supership.vamp.mediation.ironsource;

import android.app.Activity;
import android.content.Context;
import android.os.Build;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.ironsource.mediationsdk.IronSource;
import com.ironsource.mediationsdk.logger.IronSourceError;
import com.unity3d.ironsourceads.InitRequest;
import com.unity3d.ironsourceads.IronSourceAds;
import com.unity3d.ironsourceads.LogLevel;

import jp.supership.vamp.VAMP;
import jp.supership.vamp.VAMPError;
import jp.supership.vamp.VAMPLogger;
import jp.supership.vamp.VAMPPrivacySettings;
import jp.supership.vamp.mediation.AdNetworkErrorInfo;
import jp.supership.vamp.mediation.Adapter;
import jp.supership.vamp.mediation.AdapterConfiguration;
import jp.supership.vamp.mediation.AdapterEventListener;
import jp.supership.vamp.mediation.Event;

import java.lang.ref.WeakReference;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

public final class IronSourceAdapter implements Adapter {
    @NonNull private static final String ADNW_NAME = "ironSource";
    @NonNull private final String adapterName = IronSourceAdapter.class.getSimpleName();
    @NonNull private final VAMPLogger logger = new VAMPLogger(adapterName);
    @Nullable private AdapterEventListener adapterListener;
    @Nullable private AppKey appKey;
    @Nullable private InstanceId instanceId;
    @NonNull private RewardResult rewardResult = RewardResult.resultUnknown();
    @Nullable private Timer waitForRewardTimer;
    @NonNull private final ISListenerManager.ObjectId objectId = new ISListenerManager.ObjectId();

    @Override
    public boolean isSupported() {
        // VAMP Androidとして、最小サポートOSを6.0にする
        // https://scaleout.backlog.jp/view/VIDEO_RWD-2535
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.M;
    }

    @NonNull
    @Override
    public String getAdNetworkVersion() {
        return IronSourceAds.getSdkVersion();
    }

    @NonNull
    @Override
    public String getAdNetworkName() {
        return ADNW_NAME;
    }

    @NonNull
    @Override
    public List<String> getAdNetworkAdIdentifiers() {
        if (instanceId != null) {
            return Collections.singletonList(instanceId.value);
        } else {
            return Collections.emptyList();
        }
    }

    @NonNull
    @Override
    public String getAdapterVersion() {
        return BuildConfig.VERSION_NAME;
    }

    @Override
    public boolean prepare(
            @NonNull final Context context,
            @NonNull final AdapterConfiguration configuration,
            @Nullable final AdapterEventListener listener) {
        this.adapterListener = listener;

        final Map<String, String> mediationParams = configuration.getMediationParams();

        try {
            appKey = new AppKey(configuration.getAdID());
            //            appKey = AppKey.ironSourceDemoKey();
        } catch (InvalidParameterException e) {
            logger.w(String.format("Failed to prepare %s. appKey is invalid.", adapterName));
            return false;
        }

        try {
            instanceId = new InstanceId(mediationParams.get("instance"));
        } catch (InvalidParameterException e) {
            logger.w(String.format("Failed to prepare %s. instanceId is invalid.", adapterName));

            // Demand Only対応により、Placementは廃止され、Instance Idが使用されるようになったため、
            // 広告枠がまだPlacement設定のままである場合、警告ログを出力する
            if (mediationParams.containsKey("placement")) {
                Log.w(adapterName, "Placement is deprecated. Use Instance Id instead.");
            }

            return false;
        }

        // GDPR
        if (configuration.getConsentStatus() != VAMPPrivacySettings.ConsentStatus.UNKNOWN) {
            final boolean accepted =
                    VAMPPrivacySettings.getConsentStatus()
                            == VAMPPrivacySettings.ConsentStatus.ACCEPTED;
            IronSourceAds.setConsent(accepted);

            logger.d(String.format("IronSource.setConsent() is %s.", accepted));
        }

        // COPPA
        if (configuration.getChildDirected() != VAMPPrivacySettings.ChildDirected.UNKNOWN) {
            final String flag =
                    configuration.getChildDirected() == VAMPPrivacySettings.ChildDirected.TRUE
                            ? "true"
                            : "false";
            IronSourceAds.setMetaData("is_child_directed", flag);

            logger.d(String.format("IronSource.setMetaData(is_child_directed) is %s.", flag));
        }

        logger.d(String.format("%s is prepared.", adapterName));

        return true;
    }

    @Override
    public void load(@NonNull Context context) {
        if (appKey == null || instanceId == null) {
            if (adapterListener != null) {
                adapterListener.onEvent(
                        Event.newNullOrEmptyParameterErrorEvent(
                                "load", Arrays.asList("appKey", "instanceId")));
            }

            return;
        }

        if (!(context instanceof Activity)) {
            if (adapterListener != null) {
                adapterListener.onEvent(Event.newActivityNotFoundErrorEvent("load"));
            }

            return;
        }

        if (!IronSourceInitializer.getInstance().isInitialized()) {
            logger.d("Initialize ironSource.");

            // use Application Context, instead of Activity.
            InitRequest request =
                    new InitRequest.Builder(appKey.value)
                            .withLegacyAdFormats(
                                    Collections.singletonList(IronSourceAds.AdFormat.REWARDED))
                            .withLogLevel(VAMP.isDebugMode() ? LogLevel.VERBOSE : LogLevel.NONE)
                            .build();
            IronSourceInitializer.getInstance()
                    .initialize(
                            context.getApplicationContext(),
                            request,
                            new IronSourceInitializer.InitializationListener() {
                                @Override
                                public void onSuccess() {
                                    load(context);
                                }

                                @Override
                                public void onFail(IronSourceError error) {
                                    if (adapterListener != null) {
                                        adapterListener.onEvent(
                                                new Event(
                                                        Event.EVENT_FAIL,
                                                        new AdNetworkErrorInfo.Builder(
                                                                        "IronSourceInitializer.onFail",
                                                                        VAMPError.ADNETWORK_ERROR)
                                                                .setAdNetworkErrorCode(
                                                                        "" + error.getErrorCode())
                                                                .setAdNetworkErrorMessage(
                                                                        error.getErrorMessage())
                                                                .build()));
                                    }
                                }
                            });
        } else {
            IronSource.setMediationType(MediationType.get());

            ISListenerManager.getInstance().putISListener(objectId, new RewardedListener(this));

            IronSource.loadISDemandOnlyRewardedVideo((Activity) context, instanceId.value);
        }
    }

    @Override
    public boolean isReady() {
        if (instanceId == null) {
            logger.e("Failed to check a rewarded video is loaded. instanceId is null.");
            return false;
        }

        return IronSource.isISDemandOnlyRewardedVideoAvailable(instanceId.value);
    }

    @Override
    public void show(@NonNull Context context) {
        if (instanceId == null) {
            if (adapterListener != null) {
                adapterListener.onEvent(
                        Event.newNullOrEmptyParameterErrorEvent(
                                "load", Collections.singletonList("instanceId")));
            }

            return;
        }

        ISListenerManager.getInstance().putISListener(objectId, new RewardedListener(this));

        IronSource.showISDemandOnlyRewardedVideo(instanceId.value);
    }

    @Override
    public void destroy() {
        ISListenerManager.getInstance().removeISListener(objectId);
    }

    public static void onResume(@NonNull Activity activity) {
        IronSource.onResume(activity);
    }

    public static void onPause(@NonNull Activity activity) {
        IronSource.onPause(activity);
    }

    /** メモリリークを防ぐためにadapterオブジェクトを弱参照で持つリスナークラスです */
    private static final class RewardedListener implements ISListenerManager.ISListener {
        @NonNull private final WeakReference<IronSourceAdapter> adapterRef;

        RewardedListener(@NonNull final IronSourceAdapter adapter) {
            adapterRef = new WeakReference<>(adapter);
        }

        @Nullable
        @Override
        public InstanceId getInstanceId() {
            final IronSourceAdapter adapter = adapterRef.get();
            if (adapter == null) {
                return null;
            } else {
                return adapter.instanceId;
            }
        }

        @Override
        public void onRewardedVideoAdLoadSuccess(@NonNull final InstanceId instanceId) {
            final IronSourceAdapter adapter = adapterRef.get();
            if (adapter == null) {
                return;
            }

            adapter.logger.d("onRewardedVideoAdLoadSuccess called. instanceId is " + instanceId);

            if (adapter.adapterListener != null) {
                adapter.adapterListener.onEvent(new Event(Event.EVENT_LOAD_SUCCESS));
            }
        }

        @Override
        public void onRewardedVideoAdLoadFailed(
                @NonNull final InstanceId instanceId, @NonNull final IronSourceError error) {
            final IronSourceAdapter adapter = adapterRef.get();
            if (adapter == null) {
                return;
            }

            adapter.logger.d(
                    "onRewardedVideoAdLoadFailed called. instanceId is "
                            + instanceId
                            + " error="
                            + error);

            if (adapter.adapterListener != null) {
                adapter.adapterListener.onEvent(
                        new Event(
                                Event.EVENT_FAIL,
                                new AdNetworkErrorInfo.Builder(
                                                "onRewardedVideoAdLoadFailed",
                                                VAMPError.ADNETWORK_ERROR)
                                        .setAdNetworkErrorCode("" + error.getErrorCode())
                                        .setAdNetworkErrorMessage(error.getErrorMessage())
                                        .build()));
            }
        }

        @Override
        public void onRewardedVideoAdOpened(@NonNull final InstanceId instanceId) {
            final IronSourceAdapter adapter = adapterRef.get();
            if (adapter == null) {
                return;
            }

            adapter.logger.d("onRewardedVideoAdOpened called. instanceId is " + instanceId);

            if (adapter.adapterListener != null) {
                adapter.adapterListener.onEvent(new Event(Event.EVENT_OPEN));
            }
        }

        @Override
        public void onRewardedVideoAdClosed(@NonNull final InstanceId instanceId) {
            final IronSourceAdapter adapter = adapterRef.get();
            if (adapter == null) {
                return;
            }

            adapter.logger.d("onRewardedVideoAdClosed called. instanceId is " + instanceId);

            if (adapter.rewardResult.isCompleted()) {
                if (adapter.adapterListener != null) {
                    adapter.adapterListener.onEvent(
                            new Event(Event.EVENT_COMPLETE | Event.EVENT_CLOSE));
                }
            } else if (adapter.rewardResult.isFailed()) {
                if (adapter.adapterListener != null) {
                    adapter.adapterListener.onEvent(
                            new Event(
                                    Event.EVENT_FAIL | Event.EVENT_CLOSE,
                                    adapter.rewardResult.errorInfo));
                }
            } else {
                // ISの仕様ではonRewardedVideoAdClosedの後にonRewardedVideoAdRewardedが
                // 呼ばれる可能性もあるため、onRewardedVideoAdRewardedが呼ばれるまで
                // CLOSEイベントの発火を適当時間待機する
                final WaitForRewardTimerTask task = new WaitForRewardTimerTask(adapter);
                adapter.waitForRewardTimer = new Timer();
                adapter.waitForRewardTimer.schedule(task, WaitForRewardTimerTask.WAIT_TIME);
            }
        }

        @Override
        public void onRewardedVideoAdShowFailed(
                @NonNull final InstanceId instanceId, @NonNull final IronSourceError error) {
            final IronSourceAdapter adapter = adapterRef.get();
            if (adapter == null) {
                return;
            }

            adapter.logger.d(
                    "onRewardedVideoAdShowFailed called. instanceId is "
                            + instanceId
                            + " error="
                            + error);

            final VAMPError vampError =
                    error.getErrorCode() == IronSourceError.ERROR_CODE_NO_ADS_TO_SHOW
                            ? VAMPError.NO_ADSTOCK
                            : VAMPError.ADNETWORK_ERROR;

            if (adapter.adapterListener != null) {
                adapter.adapterListener.onEvent(
                        new Event(
                                Event.EVENT_FAIL,
                                new AdNetworkErrorInfo.Builder(
                                                "onRewardedVideoAdShowFailed", vampError)
                                        .setAdNetworkErrorCode("" + error.getErrorCode())
                                        .setAdNetworkErrorMessage(error.getErrorMessage())
                                        .build()));
            }
        }

        @Override
        public void onRewardedVideoAdClicked(@NonNull final InstanceId instanceId) {
            final IronSourceAdapter adapter = adapterRef.get();
            if (adapter == null) {
                return;
            }

            adapter.logger.d("onRewardedVideoAdClicked called. instanceId is " + instanceId);

            if (adapter.adapterListener != null) {
                adapter.adapterListener.onEvent(new Event(Event.EVENT_CLICK));
            }
        }

        @Override
        public void onRewardedVideoAdRewarded(@NonNull final InstanceId instanceId) {
            final IronSourceAdapter adapter = adapterRef.get();
            if (adapter == null) {
                return;
            }

            adapter.logger.d("onRewardedVideoAdRewarded called. instanceId is " + instanceId);

            adapter.rewardResult = RewardResult.resultCompleted();

            // onRewardedVideoAdClosedが既に呼ばれている場合は、
            // 待機タイマーを解除してCLOSEイベントを発火
            if (adapter.waitForRewardTimer != null) {
                adapter.waitForRewardTimer.cancel();
                adapter.waitForRewardTimer = null;

                if (adapter.adapterListener != null) {
                    // adapter.rewardResult.isCompleted()=trueは明らか
                    adapter.adapterListener.onEvent(
                            new Event(Event.EVENT_COMPLETE | Event.EVENT_CLOSE));
                }
            }
        }
    }

    /**
     * onAdRewardedが呼ばれるまでCLOSEイベントを待機するタイマーです。 待機時間内にonAdRewardedが呼ばれなかった場合は、
     * このタイマーを発動させ、エラー状態で強制CLOSEさせます
     */
    private static final class WaitForRewardTimerTask extends TimerTask {
        static final long WAIT_TIME = 3000; // ms

        @NonNull private final WeakReference<IronSourceAdapter> adapterRef;

        WaitForRewardTimerTask(@NonNull final IronSourceAdapter adapter) {
            adapterRef = new WeakReference<>(adapter);
        }

        @Override
        public void run() {
            // 時間内にonAdRewardedが呼ばれなかったため、強制CLOSE

            final IronSourceAdapter adapter = adapterRef.get();
            if (adapter == null) {
                return;
            }

            if (adapter.adapterListener != null) {
                adapter.adapterListener.onEvent(
                        new Event(
                                Event.EVENT_FAIL | Event.EVENT_CLOSE,
                                new AdNetworkErrorInfo.Builder(
                                                "WaitForRewardTimerTask#run",
                                                VAMPError.ADNETWORK_ERROR)
                                        .build()));
            }
        }
    }
}
