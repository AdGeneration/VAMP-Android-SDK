//
//  Copyright © 2026 Supership Inc. All rights reserved.
//
package jp.supership.vamp.mediation.pangle;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.os.Build;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.VisibleForTesting;
import com.bytedance.sdk.openadsdk.api.PAGConstant;
import com.bytedance.sdk.openadsdk.api.init.PAGConfig;
import com.bytedance.sdk.openadsdk.api.init.PAGSdk;
import java.lang.ref.WeakReference;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import jp.supership.vamp.VAMPError;
import jp.supership.vamp.VAMPLogger;
import jp.supership.vamp.VAMPPrivacySettings;
import jp.supership.vamp.mediation.AdNetworkErrorInfo;
import jp.supership.vamp.mediation.Adapter;
import jp.supership.vamp.mediation.AdapterConfiguration;
import jp.supership.vamp.mediation.AdapterEventListener;
import jp.supership.vamp.mediation.Event;

public class PangleAdapter implements Adapter, AdListener {
    @NonNull private static final String ADNW_NAME = "Pangle";
    @NonNull private final String adapterName = PangleAdapter.class.getSimpleName();
    @NonNull private final VAMPLogger logger = new VAMPLogger(adapterName);
    @Nullable private AdapterConfiguration adapterConfiguration;
    @Nullable private AdapterEventListener adapterListener;
    @Nullable private Ad ad;
    @Nullable private AppId appId;
    @Nullable private SlotId slotId;
    // destroy済みかどうか (破棄後に非同期コールバックでイベント通知しないためのガード)
    private volatile boolean destroyed = false;

    @SuppressLint("ObsoleteSdkInt")
    @Override
    public boolean isSupported() {
        // https://www.pangleglobal.com/integration/integrate-pangle-sdk-for-android
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP;
    }

    @NonNull
    @Override
    public String getAdNetworkName() {
        return ADNW_NAME;
    }

    @NonNull
    @Override
    public List<String> getAdNetworkAdIdentifiers() {
        // destroy()と別スレッドで競合してもnullチェック後にフィールドが変化しないよう、
        // ローカル変数に一度だけ読み込んでから使用する
        final SlotId currentSlotId = slotId;
        if (currentSlotId != null) {
            return Collections.singletonList(currentSlotId.value);
        } else {
            return Collections.emptyList();
        }
    }

    @NonNull
    @Override
    public String getAdNetworkVersion() {
        return PAGSdk.getSDKVersion();
    }

    @NonNull
    @Override
    public String getAdapterVersion() {
        return BuildConfig.VERSION_NAME;
    }

    @Override
    public boolean prepare(
            @NonNull final Context context,
            @NonNull final AdapterConfiguration configuration,
            @Nullable final AdapterEventListener listener) {
        adapterConfiguration = configuration;
        adapterListener = listener;

        try {
            appId =
                    configuration.isTestMode()
                            ? AppId.testAppId()
                            : new AppId(adapterConfiguration.getAdID());
        } catch (InvalidParameterException e) {
            logger.w(String.format("Failed to prepare %s. appId is invalid.", adapterName));
            return false;
        }

        final Map<String, String> mediationParams = adapterConfiguration.getMediationParams();

        final boolean isLandscape =
                context.getResources().getConfiguration().orientation
                        == Configuration.ORIENTATION_LANDSCAPE;

        try {
            ad = new AdProvider().provide(adapterConfiguration, logger, this);
        } catch (InvalidParameterException e) {
            logger.w(String.format("Failed to prepare %s. ad is invalid.", adapterName));
            return false;
        }

        try {
            if (configuration.isTestMode()) {
                // テストモード時は広告フォーマットに応じたテストSlotIdを使用
                slotId = ad.getTestSlotId(isLandscape);
            } else {
                slotId = new SlotId(mediationParams.get("codeId"));
            }
        } catch (InvalidParameterException e) {
            logger.w(String.format("Failed to prepare %s. slotId is invalid.", adapterName));
            return false;
        }

        logger.d(String.format("%s is prepared.", adapterName));

        return true;
    }

    @Override
    public void load(@NonNull final Context context) {
        if (destroyed) {
            return;
        }

        // destroy()と別スレッドで競合してもnullチェック後にフィールドが変化しないよう、
        // ローカル変数に一度だけ読み込んでから使用する
        final AppId currentAppId = appId;

        if (adapterConfiguration == null || currentAppId == null) {
            onEvent(
                    Event.newNullOrEmptyParameterErrorEvent(
                            "load", Arrays.asList("adapterConfiguration", "appId")));

            return;
        }

        PAGConfig.Builder config =
                new PAGConfig.Builder()
                        .appId(currentAppId.value)
                        .debugLog(adapterConfiguration.isDebugMode());

        if (adapterConfiguration.getConsentStatus() != VAMPPrivacySettings.ConsentStatus.UNKNOWN
                || adapterConfiguration.getChildDirected()
                        != VAMPPrivacySettings.ChildDirected.UNKNOWN) {
            if (adapterConfiguration.getConsentStatus() == VAMPPrivacySettings.ConsentStatus.DENIED
                    || adapterConfiguration.getChildDirected()
                            == VAMPPrivacySettings.ChildDirected.TRUE) {
                config.setPAConsent(PAGConstant.PAGPAConsentType.PAG_PA_CONSENT_TYPE_NO_CONSENT);
            } else {
                config.setPAConsent(PAGConstant.PAGPAConsentType.PAG_PA_CONSENT_TYPE_CONSENT);
            }
        }

        PAGSdk.init(context, config.build(), new InitCallback(PangleAdapter.this));
    }

    @Override
    public boolean isReady() {
        // destroy()と別スレッドで競合してもnullチェック後にフィールドが変化しないよう、
        // ローカル変数に一度だけ読み込んでから使用する
        final Ad currentAd = ad;
        return currentAd != null && currentAd.isReady();
    }

    @Override
    public void show(@NonNull final Context context) {
        if (destroyed) {
            return;
        }

        if (!(context instanceof Activity)) {
            onEvent(Event.newActivityNotFoundErrorEvent("show"));

            return;
        }

        // destroy()と別スレッドで競合してもnullチェック後にフィールドが変化しないよう、
        // ローカル変数に一度だけ読み込んでから使用する
        final Ad currentAd = ad;

        if (currentAd == null || !currentAd.isReady()) {
            final String logMessage = "Failed to show an ad from Pangle: " + "ad is not loaded.";
            logger.w(logMessage);

            onEvent(
                    new Event(
                            Event.EVENT_FAIL,
                            new AdNetworkErrorInfo.Builder("show", VAMPError.NOT_LOADED_AD)
                                    .setErrorMessage(logMessage)
                                    .build()));

            return;
        }

        currentAd.show((Activity) context);
    }

    @Override
    public void destroy() {
        // destroyedを最初に立てることで、ad.destroy()が引き起こす非同期コールバック
        // (onError/onAdLoaded等)がonEvent()のガードに到達する前にすり抜ける窓を閉じる。
        // load()/show()は先頭でdestroyedを判定し早期returnする。loadAd()/isReady()/
        // getAdNetworkAdIdentifiers()はdestroyedを判定しないが、フィールドをローカル変数へ
        // 一度だけ読み込むことでnull安全性のみを担保しており、destroy()前後どちらの値を
        // 読んでも実害がないため、この順序変更の影響を受けない。
        destroyed = true;

        // destroy()と別スレッドで競合してもnullチェック後にフィールドが変化しないよう、
        // ローカル変数に一度だけ読み込んでから使用する
        final Ad currentAd = ad;
        if (currentAd != null) {
            currentAd.destroy();
        }
        ad = null;
        slotId = null;
        appId = null;
    }

    @Override
    public void onEvent(@NonNull Event event) {
        if (destroyed) {
            return;
        }

        if (adapterListener != null) {
            adapterListener.onEvent(event);
        }
    }

    private void loadAd() {
        // destroy()と別スレッドで競合してもnullチェック後にフィールドが変化しないよう、
        // ローカル変数に一度だけ読み込んでから使用する
        final SlotId currentSlotId = slotId;
        final Ad currentAd = ad;
        if (currentSlotId == null || currentAd == null) return;
        currentAd.load(currentSlotId);
    }

    @VisibleForTesting(otherwise = VisibleForTesting.PACKAGE_PRIVATE)
    void setListener(@Nullable final AdapterEventListener listener) {
        adapterListener = listener;
    }

    @VisibleForTesting(otherwise = VisibleForTesting.PACKAGE_PRIVATE)
    void setAd(@Nullable final Ad ad) {
        this.ad = ad;
    }

    @VisibleForTesting(otherwise = VisibleForTesting.PACKAGE_PRIVATE)
    void setSlotId(@Nullable final SlotId slotId) {
        this.slotId = slotId;
    }

    /** WeakReferenceからadapterを取得し、destroy済み・GC済みの場合はnullを返します。 各コールバックの冒頭で共通に使用します。 */
    @Nullable
    private static PangleAdapter resolveIfActive(@NonNull final WeakReference<PangleAdapter> ref) {
        final PangleAdapter adapter = ref.get();
        return (adapter == null || adapter.destroyed) ? null : adapter;
    }

    /** メモリリークを防ぐためにadapterオブジェクトを弱参照で持つコールバッククラスです */
    @VisibleForTesting(otherwise = VisibleForTesting.PACKAGE_PRIVATE)
    static class InitCallback implements PAGSdk.PAGInitCallback {
        @NonNull private final WeakReference<PangleAdapter> adapterRef;

        InitCallback(@NonNull final PangleAdapter adapter) {
            adapterRef = new WeakReference<>(adapter);
        }

        @Override
        public void success() {
            // load pangle ads after this method is triggered.
            final PangleAdapter adapter = resolveIfActive(adapterRef);
            if (adapter == null) {
                return;
            }

            adapter.logger.d("Pangle SDK is initialized by VAMP.");
            adapter.loadAd();
        }

        @Override
        public void fail(final int code, final String msg) {
            final PangleAdapter adapter = resolveIfActive(adapterRef);
            if (adapter == null) {
                return;
            }

            adapter.logger.e(
                    String.format(
                            Locale.getDefault(),
                            "Failed to initialize Pangle SDK. code=%d message=%s",
                            code,
                            msg));

            // adapterListenerへ直接通知せずadapter.onEvent()経由にすることで、
            // 他の全コールバック経路と同じdestroyedガードを通す
            adapter.onEvent(
                    new Event(
                            Event.EVENT_FAIL,
                            new AdNetworkErrorInfo.Builder(
                                            "PAGInitCallback#fail", VAMPError.ADNETWORK_ERROR)
                                    .setAdNetworkErrorCode("" + code)
                                    .setAdNetworkErrorMessage(msg)
                                    .build()));
        }
    }
}
