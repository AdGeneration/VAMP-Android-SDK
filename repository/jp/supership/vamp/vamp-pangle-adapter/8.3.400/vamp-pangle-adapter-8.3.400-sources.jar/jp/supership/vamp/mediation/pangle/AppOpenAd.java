//
//  Copyright © 2026 Supership Inc. All rights reserved.
//
package jp.supership.vamp.mediation.pangle;

import android.app.Activity;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.VisibleForTesting;
import com.bytedance.sdk.openadsdk.api.model.PAGErrorModel;
import com.bytedance.sdk.openadsdk.api.open.PAGAppOpenAd;
import com.bytedance.sdk.openadsdk.api.open.PAGAppOpenAdInteractionCallback;
import com.bytedance.sdk.openadsdk.api.open.PAGAppOpenAdLoadListener;
import com.bytedance.sdk.openadsdk.api.open.PAGAppOpenRequest;
import java.lang.ref.WeakReference;
import java.util.Locale;
import jp.supership.vamp.VAMPError;
import jp.supership.vamp.VAMPLogger;
import jp.supership.vamp.mediation.AdNetworkErrorInfo;
import jp.supership.vamp.mediation.Event;

final class AppOpenAd implements Ad {
    @NonNull private final VAMPLogger logger;
    @Nullable private final AdListener adListener;
    @Nullable private PAGAppOpenAd appOpenAd;
    private boolean showFailureNotified = false;
    // destroy済みかどうか (破棄後に非同期コールバックでイベント通知しないためのガード)
    private volatile boolean destroyed = false;

    AppOpenAd(@NonNull VAMPLogger logger, @Nullable AdListener adListener) {
        this.logger = logger;
        this.adListener = adListener;
    }

    @NonNull
    @Override
    public SlotId getTestSlotId(boolean isLandscape) {
        return SlotId.AppOpen.testSlotIdWaterfall(isLandscape);
    }

    @Override
    public boolean isReady() {
        return appOpenAd != null;
    }

    @Override
    public void load(@NonNull SlotId slotId) {
        if (destroyed) {
            return;
        }

        logger.d("load");
        final PAGAppOpenRequest request = new PAGAppOpenRequest();
        PAGAppOpenAd.loadAd(
                slotId.value,
                request,
                new PAGAppOpenAdLoadListener() {
                    @Override
                    public void onError(final int code, @NonNull String message) {
                        if (destroyed) {
                            return;
                        }

                        // This method is invoked when an ad fails to load.
                        // It includes an error parameter of type Error that indicates what type of
                        // failure occurred.
                        // For more information, refer to the ErrorCode section.
                        logger.e(
                                String.format(
                                        Locale.getDefault(),
                                        "onError called. Failed to load a Pangle ad. code=%d"
                                                + " message=%s",
                                        code,
                                        message));

                        final VAMPError vampError =
                                code == PANGLE_NO_FILL_CODE
                                        ? VAMPError.NO_ADSTOCK
                                        : VAMPError.ADNETWORK_ERROR;

                        if (adListener != null) {
                            adListener.onEvent(
                                    new Event(
                                            Event.EVENT_FAIL,
                                            new AdNetworkErrorInfo.Builder("onError", vampError)
                                                    .setAdNetworkErrorCode("" + code)
                                                    .setAdNetworkErrorMessage(message)
                                                    .build()));
                        }
                    }

                    @Override
                    public void onAdLoaded(@NonNull PAGAppOpenAd pagAppOpenAd) {
                        if (destroyed) {
                            return;
                        }

                        // This method is executed when an ad material is loaded successfully.
                        logger.d("onAdLoaded called.");

                        final InteractionListener listener =
                                new InteractionListener(AppOpenAd.this);
                        pagAppOpenAd.setAdInteractionCallback(listener);
                        AppOpenAd.this.appOpenAd = pagAppOpenAd;

                        if (adListener != null) {
                            adListener.onEvent(new Event(Event.EVENT_LOAD_SUCCESS));
                        }
                    }
                });
    }

    @Override
    public void show(@NonNull Activity activity) {
        if (destroyed) {
            return;
        }

        // destroy()と別スレッドで競合してもnullチェック後にフィールドが変化しないよう、
        // ローカル変数に一度だけ読み込んでから使用する
        final PAGAppOpenAd currentAppOpenAd = appOpenAd;

        if (currentAppOpenAd == null) {
            final String logMessage =
                    "Failed to show an ad from Pangle: " + "appOpenAd is not loaded.";
            logger.w(logMessage);

            if (adListener != null) {
                adListener.onEvent(
                        new Event(
                                Event.EVENT_FAIL,
                                new AdNetworkErrorInfo.Builder("show", VAMPError.NOT_LOADED_AD)
                                        .setErrorMessage(logMessage)
                                        .build()));
            }

            return;
        }

        currentAppOpenAd.show(activity);
    }

    /** WeakReferenceからadを取得し、destroy済み・GC済みの場合はnullを返します。 各コールバックの冒頭で共通に使用します。 */
    @Nullable
    private static AppOpenAd resolveIfActive(@NonNull final WeakReference<AppOpenAd> ref) {
        final AppOpenAd ad = ref.get();
        return (ad == null || ad.destroyed) ? null : ad;
    }

    /** メモリリークを防ぐためにadapterオブジェクトを弱参照で持つリスナークラスです */
    @VisibleForTesting(otherwise = VisibleForTesting.PRIVATE)
    static class InteractionListener extends PAGAppOpenAdInteractionCallback {
        @NonNull private final WeakReference<AppOpenAd> adRef;

        InteractionListener(@NonNull final AppOpenAd ad) {
            adRef = new WeakReference<>(ad);
        }

        @Override
        public void onAdShowed() {
            // This method is invoked when the ad is displayed,
            // covering the device's screen.
            final AppOpenAd ad = resolveIfActive(adRef);
            if (ad == null) {
                return;
            }

            ad.logger.d("onAdShowed called.");

            if (ad.adListener != null) {
                ad.adListener.onEvent(new Event(Event.EVENT_OPEN));
            }
        }

        @Override
        public void onAdClicked() {
            // This method is invoked when the ad is clicked by the user.
            final AppOpenAd ad = resolveIfActive(adRef);
            if (ad == null) {
                return;
            }

            ad.logger.d("onAdClicked called.");

            if (ad.adListener != null) {
                ad.adListener.onEvent(new Event(Event.EVENT_CLICK));
            }
        }

        @Override
        public void onAdDismissed() {
            // This method is invoked when the ad disappears.
            final AppOpenAd ad = resolveIfActive(adRef);
            if (ad == null) {
                return;
            }

            ad.logger.d("onAdDismissed called.");

            if (ad.showFailureNotified) {
                // onAdShowFailedで既に終端イベントを通知済みのため、このイベントは無視する
                return;
            }

            if (ad.adListener != null) {
                ad.adListener.onEvent(new Event(Event.EVENT_CLOSE));
            }
        }

        @Override
        public void onAdShowFailed(final PAGErrorModel errorModel) {
            // This method is invoked when the ad fails to show.
            // 現行のPangle SDK(pag-sdk-ad unfat-8104時点)ではApp Open広告の実装からこのメソッドが
            // 呼ばれることは確認できていないが、SDK側が将来対応した際に備えて実装しておく
            final AppOpenAd ad = resolveIfActive(adRef);
            if (ad == null) {
                return;
            }

            if (ad.showFailureNotified) {
                // 既に通知済み。onAdShowFailedが複数回呼ばれるケースでも冪等にしておく
                return;
            }

            final int errorCode = errorModel != null ? errorModel.getErrorCode() : -1;
            final String errorMsg = errorModel != null ? errorModel.getErrorMessage() : null;

            ad.logger.e(
                    String.format(
                            Locale.getDefault(),
                            "onAdShowFailed called. errorCode=%d errorMsg=%s",
                            errorCode,
                            errorMsg));

            // onAdShowFailed後にonAdDismissedも呼ばれるケースに備え、showFailureNotifiedを立てておく。
            // これによりonAdDismissed側は何もしないため、1回のshow失敗に対してイベントが
            // 二重発行されることを防ぐ
            ad.showFailureNotified = true;

            if (ad.adListener != null) {
                ad.adListener.onEvent(
                        new Event(
                                Event.EVENT_FAIL,
                                new AdNetworkErrorInfo.Builder(
                                                "onAdShowFailed", VAMPError.ADNETWORK_ERROR)
                                        .setAdNetworkErrorCode("" + errorCode)
                                        .setAdNetworkErrorMessage(errorMsg)
                                        .build()));
            }
        }
    }

    @Override
    public void destroy() {
        appOpenAd = null;
        // 他フィールドをnull化した後にvolatileフラグを立てることで、destroyed==trueを観測した
        // 別スレッドから見てもnull化が完了していることを保証する(安全な公開パターン)
        destroyed = true;
    }
}
