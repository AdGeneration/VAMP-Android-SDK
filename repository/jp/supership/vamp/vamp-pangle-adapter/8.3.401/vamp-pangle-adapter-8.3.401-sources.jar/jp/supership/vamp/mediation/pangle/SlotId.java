//
//  Copyright © 2026 Supership Inc. All rights reserved.
//
package jp.supership.vamp.mediation.pangle;

import android.text.TextUtils;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import java.util.Map;

final class SlotId {
    // Test ID
    // https://www.pangleglobal.com/integration/How-to-Test-Pangle-Ads-with-Ad-ID

    /** iOS と共通のキー。App Open の配信設定はこのキーで slot ID を返す */
    static final String PARAM_KEY_PLACEMENT_ID = "placementId";

    /** Android の既存の動画リワード枠の配信設定が使うキー */
    static final String PARAM_KEY_CODE_ID = "codeId";

    @NonNull final String value;

    /**
     * 配信設定の mediation param から slot ID を取り出します。
     *
     * <p>iOS と同じ {@code placementId} を優先し、空なら既存の動画リワード枠の {@code codeId} を使います。
     *
     * @throws InvalidParameterException どちらのキーも空の場合
     */
    @NonNull
    static SlotId fromMediationParams(@Nullable final Map<String, String> mediationParams)
            throws InvalidParameterException {
        if (mediationParams == null) {
            throw new InvalidParameterException();
        }

        final String placementId = mediationParams.get(PARAM_KEY_PLACEMENT_ID);
        if (!TextUtils.isEmpty(placementId) && !TextUtils.isEmpty(placementId.trim())) {
            return new SlotId(placementId);
        }

        return new SlotId(mediationParams.get(PARAM_KEY_CODE_ID));
    }

    SlotId(@Nullable final String value) throws InvalidParameterException {
        String id = null;

        if (!TextUtils.isEmpty(value)) {
            id = value.trim();
        }

        if (TextUtils.isEmpty(id)) {
            throw new InvalidParameterException();
        }

        this.value = id;
    }

    /** リワード広告用テストSlot ID */
    static final class RewardedAd {
        private static final String TEST_SLOT_ID_SERVER_BIDDING_VERTICAL = "980088190";
        private static final String TEST_SLOT_ID_SERVER_BIDDING_HORIZONTAL = "980099800";
        private static final String TEST_SLOT_ID_WATERFALL_VERTICAL = "980088192";
        private static final String TEST_SLOT_ID_WATERFALL_HORIZONTAL = "980099801";

        @NonNull
        static SlotId testSlotIdServerBidding(boolean isLandscape) {
            return createSlotId(
                    isLandscape,
                    TEST_SLOT_ID_SERVER_BIDDING_VERTICAL,
                    TEST_SLOT_ID_SERVER_BIDDING_HORIZONTAL);
        }

        @NonNull
        static SlotId testSlotIdWaterfall(boolean isLandscape) {
            return createSlotId(
                    isLandscape,
                    TEST_SLOT_ID_WATERFALL_VERTICAL,
                    TEST_SLOT_ID_WATERFALL_HORIZONTAL);
        }
    }

    /** App Open広告用テストSlot ID */
    static final class AppOpen {
        private static final String TEST_SLOT_ID_SERVER_BIDDING_VERTICAL = "890008769";
        private static final String TEST_SLOT_ID_SERVER_BIDDING_HORIZONTAL = "890008770";
        private static final String TEST_SLOT_ID_WATERFALL_VERTICAL = "890000078";
        private static final String TEST_SLOT_ID_WATERFALL_HORIZONTAL = "890000079";

        @NonNull
        static SlotId testSlotIdServerBidding(boolean isLandscape) {
            return createSlotId(
                    isLandscape,
                    TEST_SLOT_ID_SERVER_BIDDING_VERTICAL,
                    TEST_SLOT_ID_SERVER_BIDDING_HORIZONTAL);
        }

        @NonNull
        static SlotId testSlotIdWaterfall(boolean isLandscape) {
            return createSlotId(
                    isLandscape,
                    TEST_SLOT_ID_WATERFALL_VERTICAL,
                    TEST_SLOT_ID_WATERFALL_HORIZONTAL);
        }
    }

    @NonNull
    private static SlotId createSlotId(
            boolean isLandscape, @NonNull String verticalId, @NonNull String horizontalId) {
        SlotId slotId = null;
        try {
            slotId = new SlotId(isLandscape ? horizontalId : verticalId);
        } catch (InvalidParameterException ignored) {
        }
        assert slotId != null;
        return slotId;
    }

    @NonNull
    @Override
    public String toString() {
        return "SlotId(" + value + ")";
    }
}
