package jp.supership.vamp.mediation.pangle;

import android.app.Activity;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import jp.supership.vamp.VAMPLogger;
import jp.supership.vamp.mediation.AdapterConfiguration;

interface Ad {
    int PANGLE_NO_FILL_CODE = 20001;

    @NonNull
    SlotId getTestSlotId(final boolean isLandscape);

    boolean isReady();

    void load(@NonNull SlotId slotId);

    void show(@NonNull Activity activity);

    void destroy();
}

final class AdProvider {
    @NonNull
    Ad provide(
            @NonNull AdapterConfiguration adapterConfiguration,
            @NonNull VAMPLogger logger,
            @Nullable AdListener adListener)
            throws InvalidParameterException {
        // どのad_formatの広告を表示するかはad_formatを見て判定します
        String adFormat = adapterConfiguration.getMediationParams().get("ad_format");

        // ad_formatが未設定の場合はrewardedにフォールバック（既存広告枠との互換性維持）
        if (adFormat == null || adFormat.trim().isEmpty()) {
            adFormat = "rewarded";
            logger.w("`ad_format` is nil or empty. Fallback to `rewarded`.");
        }

        if (adFormat.equals("rewarded")) {
            return new RewardedAd(logger, adListener);
        } else if (adFormat.equals("app_open")) {
            return new AppOpenAd(logger, adListener);
        } else {
            throw new InvalidParameterException();
        }
    }
}
