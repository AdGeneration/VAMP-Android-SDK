package jp.supership.vamp.mediation.pangle;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.os.Build;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.bytedance.sdk.openadsdk.api.PAGConstant;
import com.bytedance.sdk.openadsdk.api.init.PAGConfig;
import com.bytedance.sdk.openadsdk.api.init.PAGSdk;

import jp.supership.vamp.VAMPError;
import jp.supership.vamp.VAMPLogger;
import jp.supership.vamp.VAMPPrivacySettings;
import jp.supership.vamp.mediation.AdNetworkErrorInfo;
import jp.supership.vamp.mediation.Adapter;
import jp.supership.vamp.mediation.AdapterConfiguration;
import jp.supership.vamp.mediation.AdapterEventListener;
import jp.supership.vamp.mediation.Event;

import java.lang.ref.WeakReference;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class PangleAdapter implements Adapter, AdListener {
    @NonNull private static final String ADNW_NAME = "Pangle";
    @NonNull private final String adapterName = PangleAdapter.class.getSimpleName();
    @NonNull private final VAMPLogger logger = new VAMPLogger(adapterName);
    @Nullable private AdapterConfiguration adapterConfiguration;
    @Nullable private AdapterEventListener adapterListener;
    @Nullable private Ad ad;
    @Nullable private AppId appId;
    @Nullable private SlotId slotId;

    @SuppressLint("ObsoleteSdkInt")
    @Override
    public boolean isSupported() {
        // https://www.pangleglobal.com/integration/integrate-pangle-sdk-for-android
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP;
    }

    @NonNull
    @Override
    public String getAdNetworkName() {
        return ADNW_NAME;
    }

    @NonNull
    @Override
    public List<String> getAdNetworkAdIdentifiers() {
        if (slotId != null) {
            return Collections.singletonList(slotId.value);
        } else {
            return Collections.emptyList();
        }
    }

    @NonNull
    @Override
    public String getAdNetworkVersion() {
        return PAGSdk.getSDKVersion();
    }

    @NonNull
    @Override
    public String getAdapterVersion() {
        return BuildConfig.VERSION_NAME;
    }

    @Override
    public boolean prepare(
            @NonNull final Context context,
            @NonNull final AdapterConfiguration configuration,
            @Nullable final AdapterEventListener listener) {
        adapterConfiguration = configuration;
        adapterListener = listener;

        try {
            appId =
                    configuration.isTestMode()
                            ? AppId.testAppId()
                            : new AppId(adapterConfiguration.getAdID());
        } catch (InvalidParameterException e) {
            logger.w(String.format("Failed to prepare %s. appId is invalid.", adapterName));
            return false;
        }

        final Map<String, String> mediationParams = adapterConfiguration.getMediationParams();

        final boolean isLandscape =
                context.getResources().getConfiguration().orientation
                        == Configuration.ORIENTATION_LANDSCAPE;

        try {
            ad = new AdProvider().provide(adapterConfiguration, logger, this);
        } catch (InvalidParameterException e) {
            logger.w(String.format("Failed to prepare %s. ad is invalid.", adapterName));
            return false;
        }

        try {
            if (configuration.isTestMode()) {
                // テストモード時は広告フォーマットに応じたテストSlotIdを使用
                slotId = ad.getTestSlotId(isLandscape);
            } else {
                slotId = new SlotId(mediationParams.get("codeId"));
            }
        } catch (InvalidParameterException e) {
            logger.w(String.format("Failed to prepare %s. slotId is invalid.", adapterName));
            return false;
        }

        logger.d(String.format("%s is prepared.", adapterName));

        return true;
    }

    @Override
    public void load(@NonNull final Context context) {
        if (adapterConfiguration == null || appId == null) {
            if (adapterListener != null) {
                adapterListener.onEvent(
                        Event.newNullOrEmptyParameterErrorEvent(
                                "load", Arrays.asList("adapterConfiguration", "appId")));
            }

            return;
        }

        PAGConfig.Builder config =
                new PAGConfig.Builder()
                        .appId(appId.value)
                        .debugLog(adapterConfiguration.isDebugMode());

        if (adapterConfiguration.getConsentStatus() != VAMPPrivacySettings.ConsentStatus.UNKNOWN
                || adapterConfiguration.getChildDirected()
                        != VAMPPrivacySettings.ChildDirected.UNKNOWN) {
            if (adapterConfiguration.getConsentStatus() == VAMPPrivacySettings.ConsentStatus.DENIED
                    || adapterConfiguration.getChildDirected()
                            == VAMPPrivacySettings.ChildDirected.TRUE) {
                config.setPAConsent(PAGConstant.PAGPAConsentType.PAG_PA_CONSENT_TYPE_NO_CONSENT);
            } else {
                config.setPAConsent(PAGConstant.PAGPAConsentType.PAG_PA_CONSENT_TYPE_CONSENT);
            }
        }

        PAGSdk.init(context, config.build(), new InitCallback(PangleAdapter.this));
    }

    @Override
    public boolean isReady() {
        return ad != null && ad.isReady();
    }

    @Override
    public void show(@NonNull final Context context) {
        if (!(context instanceof Activity)) {
            if (adapterListener != null) {
                adapterListener.onEvent(Event.newActivityNotFoundErrorEvent("show"));
            }

            return;
        }

        if (ad == null || !ad.isReady()) {
            final String logMessage = "Failed to show an ad from Pangle: " + "ad is not loaded.";
            logger.w(logMessage);

            if (adapterListener != null) {
                adapterListener.onEvent(
                        new Event(
                                Event.EVENT_FAIL,
                                new AdNetworkErrorInfo.Builder("show", VAMPError.NOT_LOADED_AD)
                                        .setErrorMessage(logMessage)
                                        .build()));
            }

            return;
        }

        ad.show((Activity) context);
    }

    @Override
    public void destroy() {
        if (ad != null) {
            ad.destroy();
        }
        ad = null;
    }

    @Override
    public void onEvent(@NonNull Event event) {
        if (adapterListener != null) {
            adapterListener.onEvent(event);
        }
    }

    private void loadAd() {
        if (slotId == null || ad == null) return;
        ad.load(slotId);
    }

    /** メモリリークを防ぐためにadapterオブジェクトを弱参照で持つコールバッククラスです */
    private static class InitCallback implements PAGSdk.PAGInitCallback {
        @NonNull private final WeakReference<PangleAdapter> adapterRef;

        InitCallback(@NonNull final PangleAdapter adapter) {
            adapterRef = new WeakReference<>(adapter);
        }

        @Override
        public void success() {
            // load pangle ads after this method is triggered.
            final PangleAdapter adapter = adapterRef.get();
            if (adapter == null) {
                return;
            }

            adapter.logger.d("Pangle SDK is initialized by VAMP.");
            adapter.loadAd();
        }

        @Override
        public void fail(final int code, final String msg) {
            final PangleAdapter adapter = adapterRef.get();
            if (adapter == null) {
                return;
            }

            adapter.logger.e(
                    String.format(
                            Locale.getDefault(),
                            "Failed to initialize Pangle SDK. code=%d message=%s",
                            code,
                            msg));

            if (adapter.adapterListener != null) {
                adapter.adapterListener.onEvent(
                        new Event(
                                Event.EVENT_FAIL,
                                new AdNetworkErrorInfo.Builder(
                                                "PAGInitCallback#fail", VAMPError.ADNETWORK_ERROR)
                                        .setAdNetworkErrorCode("" + code)
                                        .setAdNetworkErrorMessage(msg)
                                        .build()));
            }
        }
    }
}
