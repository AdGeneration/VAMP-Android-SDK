package jp.supership.vamp.mediation.pangle;

import android.app.Activity;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.bytedance.sdk.openadsdk.api.reward.PAGRewardItem;
import com.bytedance.sdk.openadsdk.api.reward.PAGRewardedAd;
import com.bytedance.sdk.openadsdk.api.reward.PAGRewardedAdInteractionListener;
import com.bytedance.sdk.openadsdk.api.reward.PAGRewardedAdLoadListener;
import com.bytedance.sdk.openadsdk.api.reward.PAGRewardedRequest;

import jp.supership.vamp.VAMPError;
import jp.supership.vamp.VAMPLogger;
import jp.supership.vamp.mediation.AdNetworkErrorInfo;
import jp.supership.vamp.mediation.Event;

import java.lang.ref.WeakReference;
import java.util.Locale;

final class RewardedAd implements Ad {
    @NonNull private final VAMPLogger logger;
    @Nullable private final AdListener adListener;
    @Nullable private PAGRewardedAd rewardedAd;
    @NonNull private RewardResult rewardResult = RewardResult.resultUnknown();

    RewardedAd(@NonNull VAMPLogger logger, @Nullable AdListener adListener) {
        this.logger = logger;
        this.adListener = adListener;
    }

    @NonNull
    @Override
    public SlotId getTestSlotId(boolean isLandscape) {
        return SlotId.RewardedAd.testSlotIdWaterfall(isLandscape);
    }

    @Override
    public boolean isReady() {
        return rewardedAd != null;
    }

    @Override
    public void load(@NonNull SlotId slotId) {
        final PAGRewardedRequest request = new PAGRewardedRequest();
        PAGRewardedAd.loadAd(
                slotId.value,
                request,
                new PAGRewardedAdLoadListener() {
                    @Override
                    public void onError(final int code, final String message) {
                        // This method is invoked when an ad fails to load.
                        // It includes an error parameter of type Error that indicates what type of
                        // failure occurred. For more information, refer to the ErrorCode section
                        logger.e(
                                String.format(
                                        Locale.getDefault(),
                                        "onError called. Failed to load a Pangle ad. code=%d"
                                                + " message=%s",
                                        code,
                                        message));

                        final VAMPError vampError =
                                code == PANGLE_NO_FILL_CODE
                                        ? VAMPError.NO_ADSTOCK
                                        : VAMPError.ADNETWORK_ERROR;

                        if (adListener != null) {
                            adListener.onEvent(
                                    new Event(
                                            Event.EVENT_FAIL,
                                            new AdNetworkErrorInfo.Builder("onError", vampError)
                                                    .setAdNetworkErrorCode("" + code)
                                                    .setAdNetworkErrorMessage(message)
                                                    .build()));
                        }
                    }

                    @Override
                    public void onAdLoaded(final PAGRewardedAd pagRewardedAd) {
                        // This method is executed when an ad material is loaded successfully.
                        logger.d("onAdLoaded called.");

                        final InteractionListener interactionListener =
                                new InteractionListener(RewardedAd.this);
                        pagRewardedAd.setAdInteractionListener(interactionListener);
                        RewardedAd.this.rewardedAd = pagRewardedAd;

                        if (adListener != null) {
                            adListener.onEvent(new Event(Event.EVENT_LOAD_SUCCESS));
                        }
                    }
                });
    }

    @Override
    public void show(@NonNull Activity activity) {
        if (rewardedAd == null) {
            final String logMessage =
                    "Failed to show an ad from Pangle: " + "rewardedAd is not loaded.";
            logger.w(logMessage);

            if (adListener != null) {
                adListener.onEvent(
                        new Event(
                                Event.EVENT_FAIL,
                                new AdNetworkErrorInfo.Builder("show", VAMPError.NOT_LOADED_AD)
                                        .setErrorMessage(logMessage)
                                        .build()));
            }

            return;
        }

        rewardedAd.show(activity);
    }

    @Override
    public void destroy() {
        rewardedAd = null;
    }

    /** メモリリークを防ぐためにadapterオブジェクトを弱参照で持つリスナークラスです */
    private static class InteractionListener implements PAGRewardedAdInteractionListener {
        @NonNull private final WeakReference<RewardedAd> adRef;

        InteractionListener(@NonNull final RewardedAd ad) {
            adRef = new WeakReference<>(ad);
        }

        @Override
        public void onUserEarnedReward(final PAGRewardItem item) {
            // The method is invoked when the user should be rewarded.
            RewardedAd ad = adRef.get();
            if (ad == null) {
                return;
            }

            ad.logger.d("onUserEarnedReward called.");
            ad.rewardResult = RewardResult.resultCompleted();
        }

        @Override
        public void onUserEarnedRewardFail(final int errorCode, final String errorMsg) {
            // The method is invoked when the user rewarded failed.
            final RewardedAd ad = adRef.get();
            if (ad == null) {
                return;
            }

            ad.logger.d(
                    String.format(
                            Locale.getDefault(),
                            "onUserEarnedRewardFail called. errorCode=%d errorMsg=%s",
                            errorCode,
                            errorMsg));

            final AdNetworkErrorInfo errorInfo =
                    new AdNetworkErrorInfo.Builder(
                                    "onUserEarnedRewardFail", VAMPError.ADNETWORK_ERROR)
                            .setAdNetworkErrorCode("" + errorCode)
                            .setAdNetworkErrorMessage(errorMsg)
                            .build();
            ad.rewardResult = RewardResult.resultFailed(errorInfo);
        }

        @Override
        public void onAdShowed() {
            // This method is invoked when the ad is displayed,
            // covering the device's screen.
            final RewardedAd ad = adRef.get();
            if (ad == null) {
                return;
            }

            ad.logger.d("onAdShowed called.");

            if (ad.adListener != null) {
                ad.adListener.onEvent(new Event(Event.EVENT_OPEN));
            }
        }

        @Override
        public void onAdClicked() {
            // This method is invoked when the ad is clicked by the user.
            final RewardedAd ad = adRef.get();
            if (ad == null) {
                return;
            }

            ad.logger.d("onAdClicked called.");

            if (ad.adListener != null) {
                ad.adListener.onEvent(new Event(Event.EVENT_CLICK));
            }
        }

        @Override
        public void onAdDismissed() {
            // This method is invoked when the ad disappears.
            final RewardedAd ad = adRef.get();
            if (ad == null) {
                return;
            }

            ad.logger.d("onAdDismissed called.");

            if (ad.adListener != null) {
                if (ad.rewardResult.isCompleted()) {
                    ad.adListener.onEvent(new Event(Event.EVENT_COMPLETE | Event.EVENT_CLOSE));
                } else if (ad.rewardResult.isUnknown()) {
                    /*
                     * 広告再生中に広告タップで画面遷移した際、広告Activityが破棄されると、onAdDismissedが呼ばれユーザキャンセル扱いになる。
                     *
                     * <p>1. onAdShowed（広告再生開始） 2. onAdClicked（広告タップ） 3.
                     * onAdDismissed（Activity破棄されてDismissedが呼ばれる） =>
                     * onUserEarnedRewardもonUserEarnedRewardFail呼ばれないためユーザキャンセル ※これは対処できない事象です
                     */
                    final String message =
                            "Both onUserEarnedReward and onUserEarnedRewardFail were not called.";
                    ad.adListener.onEvent(
                            new Event(
                                    Event.EVENT_FAIL | Event.EVENT_CLOSE,
                                    new AdNetworkErrorInfo.Builder(
                                                    "onAdDismissed", VAMPError.USER_CANCEL)
                                            .setErrorMessage(message)
                                            .build()));
                } else {
                    ad.adListener.onEvent(
                            new Event(
                                    Event.EVENT_FAIL | Event.EVENT_CLOSE,
                                    ad.rewardResult.errorInfo));
                }
            }
        }
    }
}
