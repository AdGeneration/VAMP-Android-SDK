package jp.supership.vamp.mediation.pangle;

import android.app.Activity;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.bytedance.sdk.openadsdk.api.open.PAGAppOpenAd;
import com.bytedance.sdk.openadsdk.api.open.PAGAppOpenAdInteractionListener;
import com.bytedance.sdk.openadsdk.api.open.PAGAppOpenAdLoadListener;
import com.bytedance.sdk.openadsdk.api.open.PAGAppOpenRequest;

import jp.supership.vamp.VAMPError;
import jp.supership.vamp.VAMPLogger;
import jp.supership.vamp.mediation.AdNetworkErrorInfo;
import jp.supership.vamp.mediation.Event;

import java.lang.ref.WeakReference;
import java.util.Locale;

final class AppOpenAd implements Ad {
    @NonNull private final VAMPLogger logger;
    @Nullable private final AdListener adListener;
    @Nullable private PAGAppOpenAd appOpenAd;

    AppOpenAd(@NonNull VAMPLogger logger, @Nullable AdListener adListener) {
        this.logger = logger;
        this.adListener = adListener;
    }

    @NonNull
    @Override
    public SlotId getTestSlotId(boolean isLandscape) {
        return SlotId.AppOpen.testSlotIdWaterfall(isLandscape);
    }

    @Override
    public boolean isReady() {
        return appOpenAd != null;
    }

    @Override
    public void load(@NonNull SlotId slotId) {
        logger.d("load");
        final PAGAppOpenRequest request = new PAGAppOpenRequest();
        PAGAppOpenAd.loadAd(
                slotId.value,
                request,
                new PAGAppOpenAdLoadListener() {
                    @Override
                    public void onError(final int code, @NonNull String message) {
                        // This method is invoked when an ad fails to load.
                        // It includes an error parameter of type Error that indicates what type of
                        // failure occurred.
                        // For more information, refer to the ErrorCode section.
                        logger.e(
                                String.format(
                                        Locale.getDefault(),
                                        "onError called. Failed to load a Pangle ad. code=%d"
                                                + " message=%s",
                                        code,
                                        message));

                        final VAMPError vampError =
                                code == PANGLE_NO_FILL_CODE
                                        ? VAMPError.NO_ADSTOCK
                                        : VAMPError.ADNETWORK_ERROR;

                        if (adListener != null) {
                            adListener.onEvent(
                                    new Event(
                                            Event.EVENT_FAIL,
                                            new AdNetworkErrorInfo.Builder("onError", vampError)
                                                    .setAdNetworkErrorCode("" + code)
                                                    .setAdNetworkErrorMessage(message)
                                                    .build()));
                        }
                    }

                    @Override
                    public void onAdLoaded(@NonNull PAGAppOpenAd pagAppOpenAd) {
                        // This method is executed when an ad material is loaded successfully.
                        logger.d("onAdLoaded called.");

                        final InteractionListener listener =
                                new InteractionListener(AppOpenAd.this);
                        pagAppOpenAd.setAdInteractionListener(listener);
                        AppOpenAd.this.appOpenAd = pagAppOpenAd;

                        if (adListener != null) {
                            adListener.onEvent(new Event(Event.EVENT_LOAD_SUCCESS));
                        }
                    }
                });
    }

    @Override
    public void show(@NonNull Activity activity) {
        if (appOpenAd == null) {
            final String logMessage =
                    "Failed to show an ad from Pangle: " + "appOpenAd is not loaded.";
            logger.w(logMessage);

            if (adListener != null) {
                adListener.onEvent(
                        new Event(
                                Event.EVENT_FAIL,
                                new AdNetworkErrorInfo.Builder("show", VAMPError.NOT_LOADED_AD)
                                        .setErrorMessage(logMessage)
                                        .build()));
            }

            return;
        }

        appOpenAd.show(activity);
    }

    /** メモリリークを防ぐためにadapterオブジェクトを弱参照で持つリスナークラスです */
    private static class InteractionListener implements PAGAppOpenAdInteractionListener {
        @NonNull private final WeakReference<AppOpenAd> adRef;

        InteractionListener(@NonNull final AppOpenAd ad) {
            adRef = new WeakReference<>(ad);
        }

        @Override
        public void onAdShowed() {
            // This method is invoked when the ad is displayed,
            // covering the device's screen.
            final AppOpenAd ad = adRef.get();
            if (ad == null) {
                return;
            }

            ad.logger.d("onAdShowed called.");

            if (ad.adListener != null) {
                ad.adListener.onEvent(new Event(Event.EVENT_OPEN));
            }
        }

        @Override
        public void onAdClicked() {
            // This method is invoked when the ad is clicked by the user.
            final AppOpenAd ad = adRef.get();
            if (ad == null) {
                return;
            }

            ad.logger.d("onAdClicked called.");

            if (ad.adListener != null) {
                ad.adListener.onEvent(new Event(Event.EVENT_CLICK));
            }
        }

        @Override
        public void onAdDismissed() {
            // This method is invoked when the ad disappears.
            final AppOpenAd ad = adRef.get();
            if (ad == null) {
                return;
            }

            ad.logger.d("onAdDismissed called.");

            if (ad.adListener != null) {
                ad.adListener.onEvent(new Event(Event.EVENT_CLOSE));
            }
        }
    }

    @Override
    public void destroy() {
        appOpenAd = null;
    }
}
