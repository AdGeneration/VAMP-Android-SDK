package jp.supership.vamp.mediation.pangle;

import android.text.TextUtils;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

final class AppId {
    private static final String TEST_APP_ID = "8025677";

    @NonNull final String value;

    AppId(@Nullable final String value) throws InvalidParameterException {
        String appId = null;

        if (!TextUtils.isEmpty(value)) {
            appId = value.trim();
        }

        if (TextUtils.isEmpty(appId)) {
            throw new InvalidParameterException();
        }

        this.value = appId;
    }

    @NonNull
    static AppId testAppId() {
        AppId appId = null;
        try {
            appId = new AppId(TEST_APP_ID);
        } catch (InvalidParameterException ignored) {
        }

        assert appId != null;
        return appId;
    }

    @NonNull
    @Override
    public String toString() {
        return "AppId(" + value + ")";
    }
}
