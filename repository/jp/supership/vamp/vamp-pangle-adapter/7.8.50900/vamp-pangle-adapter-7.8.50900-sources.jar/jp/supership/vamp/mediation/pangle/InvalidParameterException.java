package jp.supership.vamp.mediation.pangle;

final class InvalidParameterException extends Exception {}
