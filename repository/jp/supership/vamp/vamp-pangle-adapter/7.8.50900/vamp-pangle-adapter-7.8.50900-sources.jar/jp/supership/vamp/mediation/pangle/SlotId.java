package jp.supership.vamp.mediation.pangle;

import android.text.TextUtils;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

final class SlotId {
    // Test ID
    // https://www.pangleglobal.com/integration/How-to-Test-Pangle-Ads-with-Ad-ID

    private static final String TEST_SLOT_ID_SERVER_BIDDING_VERTICAL = "980088190";
    private static final String TEST_SLOT_ID_SERVER_BIDDING_HORIZONTAL = "980099800";
    private static final String TEST_SLOT_ID_WATERFALL_VERTICAL = "980088192";
    private static final String TEST_SLOT_ID_WATERFALL_HORIZONTAL = "980099801";

    @NonNull final String value;

    SlotId(@Nullable final String value) throws InvalidParameterException {
        String id = null;

        if (!TextUtils.isEmpty(value)) {
            id = value.trim();
        }

        if (TextUtils.isEmpty(id)) {
            throw new InvalidParameterException();
        }

        this.value = id;
    }

    @NonNull
    static SlotId testSlotIdServerBidding(boolean isLandscape) {
        SlotId slotId = null;
        try {
            slotId =
                    new SlotId(
                            isLandscape
                                    ? TEST_SLOT_ID_SERVER_BIDDING_HORIZONTAL
                                    : TEST_SLOT_ID_SERVER_BIDDING_VERTICAL);
        } catch (InvalidParameterException ignored) {
        }

        assert slotId != null;
        return slotId;
    }

    @NonNull
    static SlotId testSlotIdWaterfall(boolean isLandscape) {
        SlotId slotId = null;
        try {
            slotId =
                    new SlotId(
                            isLandscape
                                    ? TEST_SLOT_ID_WATERFALL_HORIZONTAL
                                    : TEST_SLOT_ID_WATERFALL_VERTICAL);
        } catch (InvalidParameterException ignored) {
        }

        assert slotId != null;
        return slotId;
    }

    @NonNull
    @Override
    public String toString() {
        return "SlotId(" + value + ")";
    }
}
