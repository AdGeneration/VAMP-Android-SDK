package jp.supership.vamp.mediation.pangle;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.os.Build;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.bytedance.sdk.openadsdk.api.PAGConstant;
import com.bytedance.sdk.openadsdk.api.init.PAGConfig;
import com.bytedance.sdk.openadsdk.api.init.PAGSdk;
import com.bytedance.sdk.openadsdk.api.reward.PAGRewardItem;
import com.bytedance.sdk.openadsdk.api.reward.PAGRewardedAd;
import com.bytedance.sdk.openadsdk.api.reward.PAGRewardedAdInteractionListener;
import com.bytedance.sdk.openadsdk.api.reward.PAGRewardedAdLoadListener;
import com.bytedance.sdk.openadsdk.api.reward.PAGRewardedRequest;

import jp.supership.vamp.VAMPError;
import jp.supership.vamp.VAMPLogger;
import jp.supership.vamp.VAMPPrivacySettings;
import jp.supership.vamp.mediation.AdNetworkErrorInfo;
import jp.supership.vamp.mediation.Adapter;
import jp.supership.vamp.mediation.AdapterConfiguration;
import jp.supership.vamp.mediation.AdapterEventListener;
import jp.supership.vamp.mediation.Event;

import java.lang.ref.WeakReference;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class PangleAdapter implements Adapter {
    @NonNull private static final String ADNW_NAME = "Pangle";
    private static final int PANGLE_NO_FILL_CODE = 20001;

    @NonNull private final String adapterName = PangleAdapter.class.getSimpleName();
    @NonNull private final VAMPLogger logger = new VAMPLogger(adapterName);
    @Nullable private AdapterConfiguration adapterConfiguration;
    @Nullable private AdapterEventListener adapterListener;
    @Nullable private PAGRewardedAd rewardedAd;
    @Nullable private AppId appId;
    @Nullable private SlotId slotId;
    @NonNull private RewardResult rewardResult = RewardResult.resultUnknown();

    @SuppressLint("ObsoleteSdkInt")
    @Override
    public boolean isSupported() {
        // https://www.pangleglobal.com/integration/integrate-pangle-sdk-for-android
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP;
    }

    @NonNull
    @Override
    public String getAdNetworkName() {
        return ADNW_NAME;
    }

    @NonNull
    @Override
    public List<String> getAdNetworkAdIdentifiers() {
        if (slotId != null) {
            return Collections.singletonList(slotId.value);
        } else {
            return Collections.emptyList();
        }
    }

    @NonNull
    @Override
    public String getAdNetworkVersion() {
        return PAGSdk.getSDKVersion();
    }

    @NonNull
    @Override
    public String getAdapterVersion() {
        return BuildConfig.VERSION_NAME;
    }

    @Override
    public boolean prepare(
            @NonNull final Context context,
            @NonNull final AdapterConfiguration configuration,
            @Nullable final AdapterEventListener listener) {
        adapterConfiguration = configuration;
        adapterListener = listener;

        try {
            appId =
                    configuration.isTestMode()
                            ? AppId.testAppId()
                            : new AppId(adapterConfiguration.getAdID());
        } catch (InvalidParameterException e) {
            logger.w(String.format("Failed to prepare %s. appId is invalid.", adapterName));
            return false;
        }

        final Map<String, String> mediationParams = adapterConfiguration.getMediationParams();

        final boolean isLandscape =
                context.getResources().getConfiguration().orientation
                        == Configuration.ORIENTATION_LANDSCAPE;

        try {
            slotId =
                    configuration.isTestMode()
                            ? SlotId.testSlotIdWaterfall(isLandscape)
                            : new SlotId(mediationParams.get("codeId"));
        } catch (InvalidParameterException e) {
            logger.w(String.format("Failed to prepare %s. slotId is invalid.", adapterName));
            return false;
        }

        logger.d(String.format("%s is prepared.", adapterName));

        return true;
    }

    @Override
    public void load(@NonNull final Context context) {
        if (PAGSdk.isInitSuccess()) {
            logger.d("Pangle SDK is already initialized.");
            loadAd();
            return;
        }

        if (adapterConfiguration == null || appId == null) {
            if (adapterListener != null) {
                adapterListener.onEvent(
                        Event.newNullOrEmptyParameterErrorEvent(
                                "load", Arrays.asList("adapterConfiguration", "appId")));
            }

            return;
        }

        PAGConfig.Builder config =
                new PAGConfig.Builder()
                        .appId(appId.value)
                        .debugLog(adapterConfiguration.isDebugMode());

        if (adapterConfiguration.getConsentStatus() != VAMPPrivacySettings.ConsentStatus.UNKNOWN
                || adapterConfiguration.getChildDirected()
                        != VAMPPrivacySettings.ChildDirected.UNKNOWN) {
            if (adapterConfiguration.getConsentStatus() == VAMPPrivacySettings.ConsentStatus.DENIED
                    || adapterConfiguration.getChildDirected()
                            == VAMPPrivacySettings.ChildDirected.TRUE) {
                config.setPAConsent(PAGConstant.PAGPAConsentType.PAG_PA_CONSENT_TYPE_NO_CONSENT);
            } else {
                config.setPAConsent(PAGConstant.PAGPAConsentType.PAG_PA_CONSENT_TYPE_CONSENT);
            }
        }
        PAGSdk.init(context, config.build(), new InitCallback(this));
    }

    @Override
    public boolean isReady() {
        return rewardedAd != null;
    }

    @Override
    public void show(@NonNull final Context context) {
        if (!(context instanceof Activity)) {
            if (adapterListener != null) {
                adapterListener.onEvent(Event.newActivityNotFoundErrorEvent("show"));
            }

            return;
        }

        if (rewardedAd == null) {
            final String logMessage =
                    "Failed to show an ad from Pangle: " + "rewardedAd is not loaded.";
            logger.w(logMessage);

            if (adapterListener != null) {
                adapterListener.onEvent(
                        new Event(
                                Event.EVENT_FAIL,
                                new AdNetworkErrorInfo.Builder("show", VAMPError.NOT_LOADED_AD)
                                        .setErrorMessage(logMessage)
                                        .build()));
            }

            return;
        }

        rewardedAd.show((Activity) context);
    }

    @Override
    public void destroy() {
        rewardedAd = null;
    }

    private void loadAd() {
        if (slotId == null) return;
        final PAGRewardedRequest request = new PAGRewardedRequest();
        PAGRewardedAd.loadAd(
                slotId.value,
                request,
                new PAGRewardedAdLoadListener() {
                    @Override
                    public void onError(final int code, final String message) {
                        // This method is invoked when an ad fails to load.
                        // It includes an error parameter of type Error that indicates what type of
                        // failure occurred. For more information, refer to the ErrorCode section
                        logger.e(
                                String.format(
                                        Locale.getDefault(),
                                        "onError called. Failed to load a Pangle ad. code=%d"
                                                + " message=%s",
                                        code,
                                        message));

                        final VAMPError vampError =
                                code == PANGLE_NO_FILL_CODE
                                        ? VAMPError.NO_ADSTOCK
                                        : VAMPError.ADNETWORK_ERROR;

                        if (adapterListener != null) {
                            adapterListener.onEvent(
                                    new Event(
                                            Event.EVENT_FAIL,
                                            new AdNetworkErrorInfo.Builder("onError", vampError)
                                                    .setAdNetworkErrorCode("" + code)
                                                    .setAdNetworkErrorMessage(message)
                                                    .build()));
                        }
                    }

                    @Override
                    public void onAdLoaded(final PAGRewardedAd rewardedAd) {
                        // This method is executed when an ad material is loaded successfully.
                        logger.d("onAdLoaded called.");

                        final InteractionListener listener =
                                new InteractionListener(PangleAdapter.this);
                        rewardedAd.setAdInteractionListener(listener);
                        PangleAdapter.this.rewardedAd = rewardedAd;

                        if (adapterListener != null) {
                            adapterListener.onEvent(new Event(Event.EVENT_LOAD_SUCCESS));
                        }
                    }
                });
    }

    /** メモリリークを防ぐためにadapterオブジェクトを弱参照で持つコールバッククラスです */
    private static class InitCallback implements PAGSdk.PAGInitCallback {
        @NonNull private final WeakReference<PangleAdapter> adapterRef;

        InitCallback(@NonNull final PangleAdapter adapter) {
            adapterRef = new WeakReference<>(adapter);
        }

        @Override
        public void success() {
            // load pangle ads after this method is triggered.
            final PangleAdapter adapter = adapterRef.get();
            if (adapter == null) {
                return;
            }

            adapter.logger.d("Pangle SDK is initialized by VAMP.");
            adapter.loadAd();
        }

        @Override
        public void fail(final int code, final String msg) {
            final PangleAdapter adapter = adapterRef.get();
            if (adapter == null) {
                return;
            }

            adapter.logger.e(
                    String.format(
                            Locale.getDefault(),
                            "Failed to initialize Pangle SDK. code=%d message=%s",
                            code,
                            msg));

            if (adapter.adapterListener != null) {
                adapter.adapterListener.onEvent(
                        new Event(
                                Event.EVENT_FAIL,
                                new AdNetworkErrorInfo.Builder(
                                                "PAGInitCallback#fail", VAMPError.ADNETWORK_ERROR)
                                        .setAdNetworkErrorCode("" + code)
                                        .setAdNetworkErrorMessage(msg)
                                        .build()));
            }
        }
    }

    /** メモリリークを防ぐためにadapterオブジェクトを弱参照で持つリスナークラスです */
    private static class InteractionListener implements PAGRewardedAdInteractionListener {
        @NonNull private final WeakReference<PangleAdapter> adapterRef;

        InteractionListener(@NonNull final PangleAdapter adapter) {
            adapterRef = new WeakReference<>(adapter);
        }

        @Override
        public void onUserEarnedReward(final PAGRewardItem item) {
            // The method is invoked when the user should be rewarded.
            PangleAdapter adapter = adapterRef.get();
            if (adapter == null) {
                return;
            }

            adapter.logger.d("onUserEarnedReward called.");

            adapter.rewardResult = RewardResult.resultCompleted();
        }

        @Override
        public void onUserEarnedRewardFail(final int errorCode, final String errorMsg) {
            // The method is invoked when the user rewarded failed.
            final PangleAdapter adapter = adapterRef.get();
            if (adapter == null) {
                return;
            }

            adapter.logger.d(
                    String.format(
                            Locale.getDefault(),
                            "onUserEarnedRewardFail called. errorCode=%d errorMsg=%s",
                            errorCode,
                            errorMsg));

            final AdNetworkErrorInfo errorInfo =
                    new AdNetworkErrorInfo.Builder(
                                    "onUserEarnedRewardFail", VAMPError.ADNETWORK_ERROR)
                            .setAdNetworkErrorCode("" + errorCode)
                            .setAdNetworkErrorMessage(errorMsg)
                            .build();
            adapter.rewardResult = RewardResult.resultFailed(errorInfo);
        }

        @Override
        public void onAdShowed() {
            // This method is invoked when the ad is displayed,
            // covering the device's screen.
            final PangleAdapter adapter = adapterRef.get();
            if (adapter == null) {
                return;
            }

            adapter.logger.d("onAdShowed called.");

            if (adapter.adapterListener != null) {
                adapter.adapterListener.onEvent(new Event(Event.EVENT_OPEN));
            }
        }

        @Override
        public void onAdClicked() {
            // This method is invoked when the ad is clicked by the user.
            final PangleAdapter adapter = adapterRef.get();
            if (adapter == null) {
                return;
            }

            adapter.logger.d("onAdClicked called.");

            if (adapter.adapterListener != null) {
                adapter.adapterListener.onEvent(new Event(Event.EVENT_CLICK));
            }
        }

        @Override
        public void onAdDismissed() {
            // This method is invoked when the ad disappears.
            final PangleAdapter adapter = adapterRef.get();
            if (adapter == null) {
                return;
            }

            adapter.logger.d("onAdDismissed called.");

            if (adapter.adapterListener != null) {
                if (adapter.rewardResult.isCompleted()) {
                    adapter.adapterListener.onEvent(
                            new Event(Event.EVENT_COMPLETE | Event.EVENT_CLOSE));
                } else if (adapter.rewardResult.isUnknown()) {
                    /*
                     * 広告再生中に広告タップで画面遷移した際、広告Activityが破棄されると、onAdDismissedが呼ばれユーザキャンセル扱いになる。
                     *
                     * <p>1. onAdShowed（広告再生開始） 2. onAdClicked（広告タップ） 3.
                     * onAdDismissed（Activity破棄されてDismissedが呼ばれる） =>
                     * onUserEarnedRewardもonUserEarnedRewardFail呼ばれないためユーザキャンセル ※これは対処できない事象です
                     */
                    final String message =
                            "Both onUserEarnedReward and onUserEarnedRewardFail were not called.";
                    adapter.adapterListener.onEvent(
                            new Event(
                                    Event.EVENT_FAIL | Event.EVENT_CLOSE,
                                    new AdNetworkErrorInfo.Builder(
                                                    "onAdDismissed", VAMPError.USER_CANCEL)
                                            .setErrorMessage(message)
                                            .build()));
                } else {
                    adapter.adapterListener.onEvent(
                            new Event(
                                    Event.EVENT_FAIL | Event.EVENT_CLOSE,
                                    adapter.rewardResult.errorInfo));
                }
            }
        }
    }
}
