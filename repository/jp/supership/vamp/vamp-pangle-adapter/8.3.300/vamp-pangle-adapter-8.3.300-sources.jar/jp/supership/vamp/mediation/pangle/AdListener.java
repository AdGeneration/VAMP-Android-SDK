//
//  Copyright © 2026 Supership Inc. All rights reserved.
//
package jp.supership.vamp.mediation.pangle;

import androidx.annotation.NonNull;
import jp.supership.vamp.mediation.Event;

interface AdListener {
    void onEvent(@NonNull Event event);
}
