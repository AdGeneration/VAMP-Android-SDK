package jp.supership.vamp.mediation.lineads;

import android.text.TextUtils;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

final class AppId {
    @NonNull final String value;

    AppId(@Nullable final String value) throws InvalidParameterException {
        String appId = null;

        if (!TextUtils.isEmpty(value)) {
            appId = value.trim();
        }

        if (TextUtils.isEmpty(appId)) {
            throw new InvalidParameterException();
        }

        this.value = appId;
    }

    @NonNull
    @Override
    public String toString() {
        return "AppId(" + value + ")";
    }
}
