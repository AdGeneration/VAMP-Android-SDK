package jp.supership.vamp.mediation.lineads;

import android.text.TextUtils;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

final class SlotId {
    @NonNull final String value;

    SlotId(@Nullable final String value) throws InvalidParameterException {
        String slotId = null;

        if (!TextUtils.isEmpty(value)) {
            slotId = value.trim();
        }

        if (TextUtils.isEmpty(slotId)) {
            throw new InvalidParameterException();
        }

        this.value = slotId;
    }

    @NonNull
    @Override
    public String toString() {
        return "SlotId(" + value + ")";
    }
}
