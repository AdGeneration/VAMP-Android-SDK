package jp.supership.vamp.mediation.lineads;

final class InvalidParameterException extends Exception {}
