package jp.supership.vamp.mediation.lineads;

import android.app.Activity;
import android.content.Context;
import android.os.Build;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.five_corp.ad.AdLoader;
import com.five_corp.ad.AdSlotConfig;
import com.five_corp.ad.CreativeType;
import com.five_corp.ad.FiveAd;
import com.five_corp.ad.FiveAdAgeRating;
import com.five_corp.ad.FiveAdConfig;
import com.five_corp.ad.FiveAdErrorCode;
import com.five_corp.ad.FiveAdInterface;
import com.five_corp.ad.FiveAdVideoReward;
import com.five_corp.ad.FiveAdVideoRewardEventListener;
import com.five_corp.ad.NeedChildDirectedTreatment;
import com.five_corp.ad.NeedGdprNonPersonalizedAdsTreatment;

import jp.supership.vamp.VAMPError;
import jp.supership.vamp.VAMPLogger;
import jp.supership.vamp.VAMPPrivacySettings;
import jp.supership.vamp.mediation.AdNetworkErrorInfo;
import jp.supership.vamp.mediation.Adapter;
import jp.supership.vamp.mediation.AdapterConfiguration;
import jp.supership.vamp.mediation.AdapterEventListener;
import jp.supership.vamp.mediation.Event;

import java.util.Collections;
import java.util.List;
import java.util.Map;

public class LINEAdsAdapter implements Adapter {
    private enum State {
        IDLE,
        LOADED,
        SHOWING,
    }

    @NonNull private static final String ADNW_NAME = "LINEAds";

    @NonNull private final String adapterName = LINEAdsAdapter.class.getSimpleName();
    @NonNull private final VAMPLogger logger = new VAMPLogger(adapterName);
    @Nullable private AdapterEventListener adapterListener;
    @Nullable private AdapterConfiguration adapterConfiguration;
    @Nullable private SlotId slotId;
    @Nullable private AdLoader adLoader;
    @Nullable private FiveAdVideoReward videoReward = null;
    @NonNull private State state = State.IDLE;

    @Override
    public boolean isSupported() {
        // Android 対応バージョン4.0以上。
        // VAMPでは5.0以上とする
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP;
    }

    @NonNull
    @Override
    public String getAdNetworkVersion() {
        return FiveAd.getSdkSemanticVersion();
    }

    @NonNull
    @Override
    public String getAdNetworkName() {
        return ADNW_NAME;
    }

    @NonNull
    @Override
    public List<String> getAdNetworkAdIdentifiers() {
        if (slotId != null) {
            return Collections.singletonList(slotId.value);
        } else {
            return Collections.emptyList();
        }
    }

    @NonNull
    @Override
    public String getAdapterVersion() {
        return BuildConfig.VERSION_NAME;
    }

    @Override
    public boolean prepare(
            @NonNull final Context context,
            @NonNull final AdapterConfiguration configuration,
            @Nullable final AdapterEventListener listener) {
        this.adapterListener = listener;
        this.adapterConfiguration = configuration;

        final Map<String, String> mediationParams = adapterConfiguration.getMediationParams();

        final AppId appId;
        try {
            appId = new AppId(configuration.getAdID());
        } catch (InvalidParameterException e) {
            logger.w(String.format("Failed to prepare %s. appId is invalid.", adapterName));
            return false;
        }

        try {
            slotId = new SlotId(mediationParams.get("slotId"));
        } catch (InvalidParameterException e) {
            logger.w(String.format("Failed to prepare %s. slotId is invalid.", adapterName));
            return false;
        }

        if (adLoader == null) {
            final FiveAdConfig fiveAdConfig = new FiveAdConfig(appId.value);

            fiveAdConfig.isTest = adapterConfiguration.isTestMode();
            logger.d(String.format("FiveAdConfig test flag is %s.", fiveAdConfig.isTest));

            // config.maxAdAgeRating によって広告コンテンツの年齢別上限レーティングを指定できます
            if (adapterConfiguration.getUnderAgeOfConsent()
                    != VAMPPrivacySettings.UnderAgeOfConsent.UNKNOWN) {
                // FiveAdAgeRating.AGE_ALL
                // 全年齢対象の広告のみ配信されます。
                // FiveAdAgeRating.AGE_13_AND_OVER
                // 13歳以上対象の広告まで配信されます。
                // FiveAdAgeRating.AGE_15_AND_OVER
                // 15歳以上対象の広告まで配信されます。
                // FiveAdAgeRating.AGE_18_AND_OVER
                // すべてのレーティングの広告が配信されます。

                // 同意年齢未満の場合は全年齢対象広告のみ配信する
                fiveAdConfig.fiveAdAgeRating =
                        adapterConfiguration.getUnderAgeOfConsent()
                                        == VAMPPrivacySettings.UnderAgeOfConsent.TRUE
                                ? FiveAdAgeRating.ALL_AGE
                                : FiveAdAgeRating.AGE_18_AND_OVER;
            }
            logger.d(
                    String.format(
                            "FiveAdConfig fiveAdAgeRating is %s.",
                            fiveAdConfig.getFiveAdAgeRating()));

            // GDPR
            // config.needGdprNonPersonalizedAdsTreatment によって、
            // EUの一般データ保護規則(GDPR)に基づくパーソナライズされた広告の
            // 配信へのユーザの同意を指定できます。
            if (adapterConfiguration.getConsentStatus()
                    != VAMPPrivacySettings.ConsentStatus.UNKNOWN) {
                // FALSE: ユーザがパーソナライズド広告の配信に同意したものとして
                // 広告リクエストを行います。
                // パーソナライズド広告が配信されます。
                // また、FIVE以外のDSPに対する広告リクエストを行います

                // TRUE: ユーザがパーソナライズド広告の配信に同意しなかったものとして
                // 広告リクエストを行います。
                // パーソナライズド広告が配信されません。
                // また、FIVE以外のDSPに対する広告リクエストを行いません。

                fiveAdConfig.needGdprNonPersonalizedAdsTreatment =
                        VAMPPrivacySettings.getConsentStatus()
                                        == VAMPPrivacySettings.ConsentStatus.ACCEPTED
                                ? NeedGdprNonPersonalizedAdsTreatment.TRUE
                                : NeedGdprNonPersonalizedAdsTreatment.FALSE;
            }
            logger.d(
                    String.format(
                            "FiveAdConfig needGdprNonPersonalizedAdsTreatment is %s.",
                            fiveAdConfig.getNeedGdprNonPersonalizedAdsTreatment()));

            // COPPA
            // config.needChildDirectedTreatment によって、
            // 米児童オンラインプライバシー保護法(COPPA)における「子供向け取り扱い」および
            // EU一般データ保護規則(GDPR)における「同意年齢に満たないユーザ」を指定できます。
            if (adapterConfiguration.getChildDirected()
                    != VAMPPrivacySettings.ChildDirected.UNKNOWN) {
                // FALSE: 子供向けでないものとして指定します。
                // パーソナライズド広告が配信されます。
                // また、FIVE以外のDSPに対する広告リクエストを行います。

                // TRUE: 子供向けであるものとして指定します。
                // パーソナライズド広告が配信されません。
                // また、FIVE以外のDSPに対する広告リクエストを行いません

                fiveAdConfig.needChildDirectedTreatment =
                        adapterConfiguration.getChildDirected()
                                        == VAMPPrivacySettings.ChildDirected.TRUE
                                ? NeedChildDirectedTreatment.TRUE
                                : NeedChildDirectedTreatment.FALSE;
            }
            logger.d(
                    String.format(
                            "FiveAdConfig needChildDirectedTreatment is %s.",
                            fiveAdConfig.getNeedChildDirectedTreatment()));

            adLoader = AdLoader.forConfig(context, fiveAdConfig);
            logger.d("AdLoader is initialized by VAMP.");
        }

        logger.d(String.format("%s is prepared.", adapterName));

        return true;
    }

    @Override
    public void load(@NonNull final Context context) {
        if (slotId == null) {
            if (adapterListener != null) {
                adapterListener.onEvent(
                        Event.newNullOrEmptyParameterErrorEvent(
                                "load", Collections.singletonList("slotId")));
            }

            return;
        }

        if (!(context instanceof Activity)) {
            if (adapterListener != null) {
                adapterListener.onEvent(Event.newActivityNotFoundErrorEvent("load"));
            }

            return;
        }

        if (adLoader == null) {
            final String logMessage = "AdLoader is not initialized.";
            logger.w(logMessage);
            if (adapterListener != null) {
                adapterListener.onEvent(
                        new Event(
                                Event.EVENT_FAIL,
                                new AdNetworkErrorInfo.Builder("load", VAMPError.ADNETWORK_ERROR)
                                        .setErrorMessage(logMessage)
                                        .build()));
            }
            return;
        }

        state = State.IDLE;
        final AdSlotConfig adSlotConfig = new AdSlotConfig(slotId.value);
        adLoader.loadRewardAd(adSlotConfig, loadRewardAdCallback);
    }

    @Override
    public boolean isReady() {
        return videoReward != null && state == State.LOADED;
    }

    @Override
    public void show(@NonNull Context context) {
        if (!(context instanceof Activity)) {
            if (adapterListener != null) {
                adapterListener.onEvent(Event.newActivityNotFoundErrorEvent("show"));
            }

            return;
        }

        if (videoReward != null && state == State.LOADED) {
            videoReward.showAd();
            state = State.SHOWING;
        } else {
            final String logMessage = "LINEAds is not loaded.";
            logger.w(logMessage);

            if (adapterListener != null) {
                adapterListener.onEvent(
                        new Event(
                                Event.EVENT_FAIL,
                                new AdNetworkErrorInfo.Builder("show", VAMPError.NOT_LOADED_AD)
                                        .setErrorMessage(logMessage)
                                        .build()));
            }
        }
    }

    @Override
    public void destroy() {
        videoReward = null;
    }

    @NonNull
    private final AdLoader.LoadRewardAdCallback loadRewardAdCallback =
            new AdLoader.LoadRewardAdCallback() {
                @Override
                public void onLoad(@NonNull final FiveAdVideoReward fiveAdVideoReward) {
                    // 広告読み込み成功時に呼ばれます
                    logger.d("onLoad called.");

                    if (adapterConfiguration != null && adapterConfiguration.isDebugMode()) {
                        outputDebugLog(fiveAdVideoReward);
                    }

                    if (slotId == null || !slotId.value.equals(fiveAdVideoReward.getSlotId())) {
                        return;
                    }

                    videoReward = fiveAdVideoReward;
                    videoReward.setEventListener(fiveAdVideoRewardEventListener);

                    state = State.LOADED;

                    if (adapterListener != null) {
                        adapterListener.onEvent(new Event(Event.EVENT_LOAD_SUCCESS));
                    }
                }

                @Override
                public void onError(@NonNull final FiveAdErrorCode errorCode) {
                    // ロードエラー時の処理
                    final String message =
                            String.format("onLoad error called. errorCode=%s", errorCode);
                    logger.d(message);

                    if (adapterConfiguration != null
                            && adapterConfiguration.isDebugMode()
                            && slotId != null) {
                        outputErrorLog(slotId.value, errorCode);
                    }

                    VAMPError vampError = VAMPError.ADNETWORK_ERROR;

                    if (errorCode.equals(FiveAdErrorCode.NO_AD)) {
                        vampError = VAMPError.NO_ADSTOCK;
                    }

                    if (adapterListener != null) {
                        adapterListener.onEvent(
                                new Event(
                                        Event.EVENT_FAIL,
                                        new AdNetworkErrorInfo.Builder("onLoad", vampError)
                                                .setErrorMessage(message)
                                                .setAdNetworkErrorCode(errorCode.toString())
                                                .build()));
                    }
                }
            };

    @NonNull
    private final FiveAdVideoRewardEventListener fiveAdVideoRewardEventListener =
            new FiveAdVideoRewardEventListener() {
                @Override
                public void onViewError(
                        @NonNull FiveAdVideoReward fiveAdVideoReward,
                        @NonNull FiveAdErrorCode fiveAdErrorCode) {
                    // 表示エラー時の処理
                    final String message =
                            String.format("onViewError called. errorCode=%s", fiveAdErrorCode);
                    logger.d(message);

                    if (adapterConfiguration != null && adapterConfiguration.isDebugMode()) {
                        outputDebugLog(fiveAdVideoReward);
                    }

                    if (slotId == null || !slotId.value.equals(fiveAdVideoReward.getSlotId())) {
                        return;
                    }

                    VAMPError vampError = VAMPError.ADNETWORK_ERROR;

                    if (fiveAdErrorCode.equals(FiveAdErrorCode.NO_AD)) {
                        vampError = VAMPError.NO_ADSTOCK;
                    }

                    if (adapterListener != null) {
                        adapterListener.onEvent(
                                new Event(
                                        Event.EVENT_FAIL,
                                        new AdNetworkErrorInfo.Builder("onViewError", vampError)
                                                .setErrorMessage(message)
                                                .setAdNetworkErrorCode(fiveAdErrorCode.toString())
                                                .build()));
                    }
                }

                @Override
                public void onReward(@NonNull FiveAdVideoReward fiveAdVideoReward) {
                    // リワード付与の処理
                    logger.d("onReward called.");

                    if (adapterConfiguration != null && adapterConfiguration.isDebugMode()) {
                        outputDebugLog(fiveAdVideoReward);
                    }

                    if (slotId == null || !slotId.value.equals(fiveAdVideoReward.getSlotId())) {
                        return;
                    }

                    if (adapterListener != null) {
                        adapterListener.onEvent(new Event(Event.EVENT_COMPLETE));
                    }
                }

                @Override
                public void onPlay(@NonNull FiveAdVideoReward fiveAdVideoReward) {
                    // 動画広告が再生開始したときに呼ばれます
                    logger.d("onPlay called.");

                    if (adapterConfiguration != null && adapterConfiguration.isDebugMode()) {
                        outputDebugLog(fiveAdVideoReward);
                    }
                }

                @Override
                public void onPause(@NonNull FiveAdVideoReward fiveAdVideoReward) {
                    // 動画広告が一時停止したときに呼ばれます
                    logger.d("onPause called.");

                    if (adapterConfiguration != null && adapterConfiguration.isDebugMode()) {
                        outputDebugLog(fiveAdVideoReward);
                    }
                }

                @Override
                public void onImpression(@NonNull FiveAdVideoReward fiveAdVideoReward) {
                    // インプレッション時の処理
                    logger.d("onImpression called.");

                    if (adapterConfiguration != null && adapterConfiguration.isDebugMode()) {
                        outputDebugLog(fiveAdVideoReward);
                    }
                }

                @Override
                public void onViewThrough(@NonNull FiveAdVideoReward fiveAdVideoReward) {
                    // 動画広告が再度始めから再生されたときに呼ばれます
                    logger.d("onViewThrough called.");

                    if (adapterConfiguration != null && adapterConfiguration.isDebugMode()) {
                        outputDebugLog(fiveAdVideoReward);
                    }
                }

                @Override
                public void onClick(@NonNull FiveAdVideoReward fiveAdVideoReward) {
                    // 広告がクリックされたときに呼ばれます
                    logger.d("onClick called.");

                    if (adapterConfiguration != null && adapterConfiguration.isDebugMode()) {
                        outputDebugLog(fiveAdVideoReward);
                    }

                    if (slotId == null || !slotId.value.equals(fiveAdVideoReward.getSlotId())) {
                        return;
                    }

                    if (adapterListener != null) {
                        adapterListener.onEvent(new Event(Event.EVENT_CLICK));
                    }
                }

                @Override
                public void onFullScreenOpen(@NonNull FiveAdVideoReward fiveAdVideoReward) {
                    // 動画広告が再生開始したときに呼ばれます
                    logger.d("onFullScreenOpen called.");

                    if (adapterConfiguration != null && adapterConfiguration.isDebugMode()) {
                        outputDebugLog(fiveAdVideoReward);
                    }

                    if (slotId == null || !slotId.value.equals(fiveAdVideoReward.getSlotId())) {
                        return;
                    }

                    if (adapterListener != null) {
                        adapterListener.onEvent(new Event(Event.EVENT_OPEN));
                    }
                }

                @Override
                public void onFullScreenClose(@NonNull FiveAdVideoReward fiveAdVideoReward) {
                    // フルスクリーン広告ビュークローズ時の処理
                    logger.d("onFullScreenClose called.");

                    if (adapterConfiguration != null && adapterConfiguration.isDebugMode()) {
                        outputDebugLog(fiveAdVideoReward);
                    }

                    if (slotId == null || !slotId.value.equals(fiveAdVideoReward.getSlotId())) {
                        return;
                    }

                    if (adapterListener != null) {
                        adapterListener.onEvent(new Event(Event.EVENT_CLOSE));
                    }

                    // CLOSEイベント発火済みのため、これ以降不要なイベントを発火しないように解放する
                    adapterListener = null;
                }
            };

    private void outputDebugLog(@NonNull final FiveAdInterface fiveAdInterface) {
        final String slotId = fiveAdInterface.getSlotId();
        final CreativeType creativeType = fiveAdInterface.getCreativeType();
        final boolean isSoundEnabled = fiveAdInterface.isSoundEnabled();
        final String fiveAdTag = fiveAdInterface.getFiveAdTag();

        logger.d(
                "FiveAdInterface:\nslotId: "
                        + slotId
                        + "\n"
                        + "creativeType: "
                        + creativeType
                        + "\n"
                        + "isSoundEnabled: "
                        + isSoundEnabled
                        + "\n"
                        + "fiveAdTag: "
                        + (fiveAdTag != null ? fiveAdTag : ""));
    }

    private void outputErrorLog(
            @NonNull final String slotId, @NonNull final FiveAdErrorCode errorCode) {
        logger.d("FiveAd load error:\n" + "slotId: " + slotId + "\n" + "errorCode: " + errorCode);
    }
}
