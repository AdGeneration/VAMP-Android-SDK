//
//  Copyright © 2026 Supership Inc. All rights reserved.
//
package jp.supership.vamp.mediation.lineads;

final class InvalidParameterException extends Exception {}
