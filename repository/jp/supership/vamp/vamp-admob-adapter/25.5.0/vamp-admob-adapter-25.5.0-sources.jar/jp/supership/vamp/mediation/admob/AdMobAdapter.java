//
//  Copyright © 2026 Supership Inc. All rights reserved.
//
package jp.supership.vamp.mediation.admob;

import android.app.Activity;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.VisibleForTesting;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AgeRestrictedTreatment;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.OnUserEarnedRewardListener;
import com.google.android.gms.ads.RequestConfiguration;
import com.google.android.gms.ads.ResponseInfo;
import com.google.android.gms.ads.rewarded.RewardItem;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;
import java.lang.ref.WeakReference;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;
import jp.supership.vamp.VAMPError;
import jp.supership.vamp.VAMPLogger;
import jp.supership.vamp.VAMPPrivacySettings;
import jp.supership.vamp.mediation.AdNetworkErrorInfo;
import jp.supership.vamp.mediation.Adapter;
import jp.supership.vamp.mediation.AdapterConfiguration;
import jp.supership.vamp.mediation.AdapterEventListener;
import jp.supership.vamp.mediation.Event;

public class AdMobAdapter implements Adapter {
    @NonNull private static final String ADNW_NAME = "AdMob";

    @NonNull private final String adapterName = AdMobAdapter.class.getSimpleName();
    @NonNull private final VAMPLogger logger = new VAMPLogger(adapterName);
    @Nullable private AdUnitId adUnitId;
    @Nullable private RewardedAd rewardedAd;
    @Nullable private AdapterEventListener listener;
    @Nullable private AdapterConfiguration adapterConfiguration;
    private boolean isCompleted = false;
    // destroy 済みかどうか (破棄後に非同期コールバックでイベント通知しないためのガード)
    private volatile boolean destroyed = false;
    // 表示中または表示済みかどうか (show()の多重呼び出しを防ぐためのガード)。
    // 呼び出しスレッドが保証されないため、判定と更新を compareAndSet でアトミックに行う
    private final AtomicBoolean isShowing = new AtomicBoolean(false);

    @Override
    public boolean isSupported() {
        // AdMob SDK (play-services-ads) 25.5.0 以降が minSdk 24 を要求するため N (API 24) 以上
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.N;
    }

    @NonNull
    @Override
    public String getAdNetworkName() {
        return ADNW_NAME;
    }

    @NonNull
    @Override
    public List<String> getAdNetworkAdIdentifiers() {
        if (adUnitId != null) {
            return Collections.singletonList(adUnitId.value);
        } else {
            return Collections.emptyList();
        }
    }

    @NonNull
    @Override
    public String getAdNetworkVersion() {
        // MobileAds.getVersion() は AdMob SDK のクラス初期化を伴う。
        // AdMob SDK (play-services-ads) 25.5.0 以降は minSdk 24 で API 23 での初期化は保証外
        // （失敗すると Error 系になり呼び出し元の catch (Exception) を突き抜ける）ため参照しない
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) {
            return "";
        }
        return MobileAds.getVersion().toString();
    }

    @NonNull
    @Override
    public String getAdapterVersion() {
        return BuildConfig.VERSION_NAME;
    }

    @Override
    public boolean prepare(
            @NonNull final Context context,
            @NonNull final AdapterConfiguration configuration,
            @Nullable final AdapterEventListener listener) {
        this.adapterConfiguration = configuration;
        this.listener = listener;

        final Map<String, String> mediationParams = configuration.getMediationParams();

        try {
            if (configuration.isTestMode()) {
                adUnitId = AdUnitId.testAdUnitId();

                logger.d(String.format("%s uses Test Unit ID: %s", adapterName, adUnitId));
            } else {
                adUnitId = new AdUnitId(mediationParams.get("unitid"));
            }
        } catch (InvalidParameterException e) {
            logger.w(String.format("Failed to prepare %s. adUnitId is invalid.", adapterName));
            return false;
        }

        // 既存のグローバル RequestConfiguration (アプリ側で設定した testDeviceIds 等) を
        // 引き継ぎ、ageRestrictedTreatment のみ更新する
        final RequestConfiguration.Builder builder =
                MobileAds.getRequestConfiguration().toBuilder();

        // COPPA / TFUA
        // AdMob 25.3.0 で setTagForChildDirectedTreatment / setTagForUnderAgeOfConsent が
        // 非推奨化され、単一の AgeRestrictedTreatment へ集約された。公式移行ガイド
        // (https://developers.google.com/admob/android/targeting) の対応表に従い、
        // TAG_FOR_CHILD_DIRECTED_TREATMENT_TRUE / TAG_FOR_UNDER_AGE_OF_CONSENT_TRUE は
        // いずれも CHILD へマッピングする (TEEN は旧 API に対応物のない新設値のため使わない):
        //   1. 両軸とも UNKNOWN (VAMP 側で未指定) -> 変更しない
        //      (アプリ側で設定済みの AgeRestrictedTreatment を保持する。
        //      他アダプター (UnityAds / Pangle) の UNKNOWN 時スキップと同じ方針)
        //   2. ChildDirected == TRUE または UnderAgeOfConsent == TRUE -> CHILD
        //   3. それ以外 (いずれかが明示的 FALSE) -> UNSPECIFIED
        // 注意: 新 API に旧 TAG_*_FALSE に相当する「明示的 FALSE」は存在しないため、
        // FALSE 設定は UNSPECIFIED へ縮退する (未指定と区別されず AdMob へ送信されない)。
        // これは新 API の制約による意図的な挙動変更 (詳細は #1078)。
        if (configuration.getChildDirected() != VAMPPrivacySettings.ChildDirected.UNKNOWN
                || configuration.getUnderAgeOfConsent()
                        != VAMPPrivacySettings.UnderAgeOfConsent.UNKNOWN) {
            final AgeRestrictedTreatment ageRestrictedTreatment;
            if (configuration.getChildDirected() == VAMPPrivacySettings.ChildDirected.TRUE
                    || configuration.getUnderAgeOfConsent()
                            == VAMPPrivacySettings.UnderAgeOfConsent.TRUE) {
                ageRestrictedTreatment = AgeRestrictedTreatment.CHILD;
            } else {
                ageRestrictedTreatment = AgeRestrictedTreatment.UNSPECIFIED;
            }

            builder.setAgeRestrictedTreatment(ageRestrictedTreatment);

            // 入力 2 軸も併記し、優先順位でどちらが採用されたかログから追えるようにする
            logger.d(
                    String.format(
                            Locale.getDefault(),
                            "AgeRestrictedTreatment is %s. (ChildDirected=%s,"
                                    + " UnderAgeOfConsent=%s)",
                            ageRestrictedTreatment.name(),
                            configuration.getChildDirected(),
                            configuration.getUnderAgeOfConsent()));
        }

        MobileAds.setRequestConfiguration(builder.build());

        logger.d(String.format("%s is prepared.", adapterName));

        return true;
    }

    @Override
    public boolean isReady() {
        return rewardedAd != null;
    }

    @Override
    public void load(@NonNull final Context context) {
        if (destroyed) {
            return;
        }

        final Context appContext;
        if (context instanceof Activity) {
            // このメソッド内で使用するAdMob APIはアプリケーションコンテキストで動作するため、
            // Activityの場合はアプリケーションコンテキストを取得する
            appContext = context.getApplicationContext();
        } else {
            appContext = context;
        }

        if (!AdMobInitializer.getInstance().isInitialized()) {
            AdMobInitializer.getInstance()
                    .initialize(appContext, new InitCallback(this, appContext));

            return;
        }

        final AdRequest.Builder builder = new AdRequest.Builder();

        final AdapterConfiguration config = adapterConfiguration;
        if (config != null) {
            // GDPR
            if (config.getConsentStatus() == VAMPPrivacySettings.ConsentStatus.DENIED) {
                final Bundle extras = new Bundle();
                extras.putString("npa", "1");
                builder.addNetworkExtrasBundle(
                        com.google.ads.mediation.admob.AdMobAdapter.class, extras);

                logger.d(
                        String.format(
                                Locale.getDefault(),
                                "%s adds npa=1 for network extras.",
                                adapterName));
            }

            // atp (App Content URL)
            // 旧 vamp コア（5.3.8 未満）には getContentUrl() が無く NoSuchMethodError で落ちるため、
            // 捕捉して contentUrl なしで続行する（VAMP-iOS #1332 と同型の互換ガード）
            String contentUrl = null;
            try {
                contentUrl = config.getContentUrl();
            } catch (NoSuchMethodError e) {
                logger.w(
                        String.format(
                                Locale.getDefault(),
                                "%s skips contentUrl because the vamp core is outdated. VAMP SDK"
                                        + " 5.3.8 or later is required for contentUrl support.",
                                adapterName));
            }

            if (contentUrl != null) {
                builder.setContentUrl(contentUrl);

                logger.d(
                        String.format(
                                Locale.getDefault(),
                                "%s sets contentUrl for AdRequest.",
                                adapterName));
            }
        }

        final AdRequest request = builder.build();

        // RewardedAd.loadメソッドはメインスレッドで実行する必要がある。
        // アダプタのloadメソッドの実行スレッドは不明であるため、確実にメインスレッドで実行する
        new Handler(Looper.getMainLooper()).post(new LoadRunnable(this, appContext, request));
    }

    /** RewardedAd.loadを実行します。destroy済みの場合はLoadRunnableの時点で呼び出されません。 */
    @VisibleForTesting
    void loadRewardedAd(@NonNull final Context appContext, @NonNull final AdRequest request) {
        if (adUnitId == null) {
            return;
        }

        RewardedAd.load(appContext, adUnitId.value, request, new RALCallback(this));
    }

    @Override
    public void show(@NonNull Context context) {
        if (destroyed) {
            return;
        }

        if (!(context instanceof Activity)) {
            if (listener != null) {
                listener.onEvent(Event.newActivityNotFoundErrorEvent("show"));
            }

            return;
        }

        // destroy()との競合でnullチェック後にフィールドが再読込されNPEになる窓を防ぐため、
        // ローカル変数へキャプチャしてから使用する
        final RewardedAd ad = rewardedAd;
        if (ad == null) {
            notifyNotLoadedAdFailure("rewardedAd hasn't been loaded yet.");
            return;
        }

        if (!isShowing.compareAndSet(false, true)) {
            notifyNotLoadedAdFailure("show() has already been called.");
            return;
        }

        ad.setFullScreenContentCallback(new FSCCallback(this));
        ad.show((Activity) context, new OUERListener(this));
    }

    /** 広告未ロードまたはshow()の多重呼び出しによる失敗をVAMPError.NOT_LOADED_ADとして通知します。 */
    private void notifyNotLoadedAdFailure(@NonNull final String message) {
        logger.w(message);

        final AdNetworkErrorInfo errorInfo =
                new AdNetworkErrorInfo.Builder("show", VAMPError.NOT_LOADED_AD)
                        .setErrorMessage(message)
                        .build();

        if (listener != null) {
            listener.onEvent(new Event(Event.EVENT_FAIL, errorInfo));
        }
    }

    @Override
    public void destroy() {
        // destroyed への書き込みを最後に行うことで、destroyed==trueを観測したスレッドから
        // listener/rewardedAdがnullであることも保証する (安全な公開)
        listener = null;
        rewardedAd = null;
        destroyed = true;
    }

    /** WeakReferenceからadapterを取得し、destroy済み・GC済みの場合はnullを返します。 各コールバックの冒頭で共通に使用します。 */
    @Nullable
    private static AdMobAdapter resolveIfActive(@NonNull final WeakReference<AdMobAdapter> ref) {
        final AdMobAdapter adapter = ref.get();
        return (adapter == null || adapter.destroyed) ? null : adapter;
    }

    @VisibleForTesting
    void setListener(@Nullable final AdapterEventListener listener) {
        this.listener = listener;
    }

    @VisibleForTesting
    boolean isCompleted() {
        return isCompleted;
    }

    /** メモリリークを防ぐためにadapterオブジェクトを弱参照で持つ初期化完了リスナークラスです */
    @VisibleForTesting
    static final class InitCallback implements AdMobInitializer.InitializationListener {
        @NonNull private final WeakReference<AdMobAdapter> adapterRef;
        @NonNull private final Context appContext;

        InitCallback(@NonNull final AdMobAdapter adapter, @NonNull final Context appContext) {
            adapterRef = new WeakReference<>(adapter);
            this.appContext = appContext;
        }

        @Override
        public void onComplete() {
            final AdMobAdapter adapter = resolveIfActive(adapterRef);
            if (adapter == null) {
                return;
            }

            adapter.logger.d("AdMob is initialized by VAMP.");

            adapter.load(appContext);
        }
    }

    /** メモリリークを防ぐためにadapterオブジェクトを弱参照で持つロード実行クラスです */
    @VisibleForTesting
    static final class LoadRunnable implements Runnable {
        @NonNull private final WeakReference<AdMobAdapter> adapterRef;
        @NonNull private final Context appContext;
        @NonNull private final AdRequest request;

        LoadRunnable(
                @NonNull final AdMobAdapter adapter,
                @NonNull final Context appContext,
                @NonNull final AdRequest request) {
            adapterRef = new WeakReference<>(adapter);
            this.appContext = appContext;
            this.request = request;
        }

        @Override
        public void run() {
            final AdMobAdapter adapter = resolveIfActive(adapterRef);
            if (adapter == null) {
                return;
            }

            adapter.loadRewardedAd(appContext, request);
        }
    }

    /** メモリリークを防ぐためにadapterオブジェクトを弱参照で持つコールバッククラスです */
    @VisibleForTesting
    static final class RALCallback extends RewardedAdLoadCallback {
        @NonNull private final WeakReference<AdMobAdapter> adapterRef;

        RALCallback(@NonNull final AdMobAdapter adapter) {
            adapterRef = new WeakReference<>(adapter);
        }

        @Override
        public void onAdLoaded(@NonNull final RewardedAd ad) {
            final AdMobAdapter adapter = resolveIfActive(adapterRef);
            if (adapter == null) {
                return;
            }

            adapter.logger.d("onAdLoaded called.");

            adapter.rewardedAd = ad;

            if (adapter.adapterConfiguration != null
                    && adapter.adapterConfiguration.isDebugMode()) {
                ResponseInfo responseInfo = ad.getResponseInfo();
                adapter.logger.d("ResponseId: " + responseInfo.getResponseId());
                adapter.logger.d(
                        "MediationAdapterClassName: "
                                + responseInfo.getMediationAdapterClassName());
            }

            if (adapter.listener != null) {
                adapter.listener.onEvent(new Event(Event.EVENT_LOAD_SUCCESS));
            }
        }

        @Override
        public void onAdFailedToLoad(@NonNull final LoadAdError loadAdError) {
            final AdMobAdapter adapter = resolveIfActive(adapterRef);
            if (adapter == null) {
                return;
            }

            adapter.logger.d("onAdFailedToLoad called. error code=" + loadAdError.getCode());

            final VAMPError vampError =
                    loadAdError.getCode() == AdRequest.ERROR_CODE_NO_FILL
                            ? VAMPError.NO_ADSTOCK
                            : VAMPError.ADNETWORK_ERROR;

            final AdNetworkErrorInfo errorInfo =
                    new AdNetworkErrorInfo.Builder("onAdFailedToLoad", vampError)
                            .setAdNetworkErrorCode("" + loadAdError.getCode())
                            .setAdNetworkErrorMessage(loadAdError.getMessage())
                            .build();

            if (adapter.listener != null) {
                adapter.listener.onEvent(new Event(Event.EVENT_FAIL, errorInfo));
            }
        }
    }

    /** メモリリークを防ぐためにadapterオブジェクトを弱参照で持つコールバッククラスです */
    @VisibleForTesting
    static final class FSCCallback extends FullScreenContentCallback {
        @NonNull private final WeakReference<AdMobAdapter> adapterRef;

        FSCCallback(@NonNull final AdMobAdapter adapter) {
            adapterRef = new WeakReference<>(adapter);
        }

        @Override
        public void onAdImpression() {
            final AdMobAdapter adapter = resolveIfActive(adapterRef);
            if (adapter == null) {
                return;
            }

            adapter.logger.d("onAdImpression called.");
        }

        @Override
        public void onAdShowedFullScreenContent() {
            final AdMobAdapter adapter = resolveIfActive(adapterRef);
            if (adapter == null) {
                return;
            }

            adapter.logger.d("onAdShowedFullScreenContent called.");

            if (adapter.listener != null) {
                adapter.listener.onEvent(new Event(Event.EVENT_OPEN));
            }
        }

        @Override
        public void onAdFailedToShowFullScreenContent(@NonNull final AdError adError) {
            final AdMobAdapter adapter = resolveIfActive(adapterRef);
            if (adapter == null) {
                return;
            }

            adapter.logger.d(
                    "onAdFailedToShowFullScreenContent called. error code=" + adError.getCode());

            final AdNetworkErrorInfo errorInfo =
                    new AdNetworkErrorInfo.Builder(
                                    "onAdFailedToShowFullScreenContent", VAMPError.ADNETWORK_ERROR)
                            .setAdNetworkErrorCode("" + adError.getCode())
                            .setAdNetworkErrorMessage(adError.getMessage())
                            .build();

            if (adapter.listener != null) {
                adapter.listener.onEvent(new Event(Event.EVENT_FAIL, errorInfo));
            }
        }

        @Override
        public void onAdDismissedFullScreenContent() {
            final AdMobAdapter adapter = resolveIfActive(adapterRef);
            if (adapter == null) {
                return;
            }

            adapter.logger.d("onAdDismissedFullScreenContent called.");

            if (!adapter.isCompleted) {
                final String message = "onUserEarnedReward method has not been called yet.";
                adapter.logger.d(message);

                final AdNetworkErrorInfo errorInfo =
                        new AdNetworkErrorInfo.Builder(
                                        "onAdDismissedFullScreenContent", VAMPError.USER_CANCEL)
                                .setErrorMessage(message)
                                .build();

                if (adapter.listener != null) {
                    adapter.listener.onEvent(
                            new Event(Event.EVENT_FAIL | Event.EVENT_CLOSE, errorInfo));
                }

                return;
            }

            if (adapter.listener != null) {
                adapter.listener.onEvent(new Event(Event.EVENT_COMPLETE | Event.EVENT_CLOSE));
            }
        }
    }

    /** メモリリークを防ぐためにadapterオブジェクトを弱参照で持つリスナークラスです */
    @VisibleForTesting
    static final class OUERListener implements OnUserEarnedRewardListener {
        @NonNull private final WeakReference<AdMobAdapter> adapterRef;

        OUERListener(@NonNull final AdMobAdapter adapter) {
            adapterRef = new WeakReference<>(adapter);
        }

        @Override
        public void onUserEarnedReward(@NonNull final RewardItem rewardItem) {
            final AdMobAdapter adapter = resolveIfActive(adapterRef);
            if (adapter == null) {
                return;
            }

            if (adapter.isCompleted) {
                adapter.logger.d("onUserEarnedReward method has already been called.");
                return;
            }

            adapter.isCompleted = true;

            final Map<String, String> rewardMap = new HashMap<>();
            rewardMap.put("type", rewardItem.getType());
            rewardMap.put("amount", "" + rewardItem.getAmount());
            adapter.logger.d("onUserEarnedReward called. rewardItem=" + rewardMap);
        }
    }
}
