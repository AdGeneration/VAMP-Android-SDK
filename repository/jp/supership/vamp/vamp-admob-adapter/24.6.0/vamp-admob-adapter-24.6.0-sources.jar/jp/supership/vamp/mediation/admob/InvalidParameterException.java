package jp.supership.vamp.mediation.admob;

final class InvalidParameterException extends Exception {}
