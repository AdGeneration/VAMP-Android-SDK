package jp.supership.vamp.mediation.admob;

import android.app.Activity;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.OnUserEarnedRewardListener;
import com.google.android.gms.ads.RequestConfiguration;
import com.google.android.gms.ads.ResponseInfo;
import com.google.android.gms.ads.rewarded.RewardItem;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;

import jp.supership.vamp.VAMPError;
import jp.supership.vamp.VAMPLogger;
import jp.supership.vamp.VAMPPrivacySettings;
import jp.supership.vamp.mediation.AdNetworkErrorInfo;
import jp.supership.vamp.mediation.Adapter;
import jp.supership.vamp.mediation.AdapterConfiguration;
import jp.supership.vamp.mediation.AdapterEventListener;
import jp.supership.vamp.mediation.Event;

import java.lang.ref.WeakReference;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class AdMobAdapter implements Adapter {
    @NonNull private static final String ADNW_NAME = "AdMob";

    @NonNull private final String adapterName = AdMobAdapter.class.getSimpleName();
    @NonNull private final VAMPLogger logger = new VAMPLogger(adapterName);
    @Nullable private AdUnitId adUnitId;
    @Nullable private RewardedAd rewardedAd;
    @Nullable private AdapterEventListener listener;
    @Nullable private AdapterConfiguration adapterConfiguration;
    private boolean isCompleted = false;

    @Override
    public boolean isSupported() {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.M;
    }

    @NonNull
    @Override
    public String getAdNetworkName() {
        return ADNW_NAME;
    }

    @NonNull
    @Override
    public List<String> getAdNetworkAdIdentifiers() {
        if (adUnitId != null) {
            return Collections.singletonList(adUnitId.value);
        } else {
            return Collections.emptyList();
        }
    }

    @NonNull
    @Override
    public String getAdNetworkVersion() {
        return MobileAds.getVersion().toString();
    }

    @NonNull
    @Override
    public String getAdapterVersion() {
        return BuildConfig.VERSION_NAME;
    }

    @Override
    public boolean prepare(
            @NonNull final Context context,
            @NonNull final AdapterConfiguration configuration,
            @Nullable final AdapterEventListener listener) {
        this.adapterConfiguration = configuration;
        this.listener = listener;

        final Map<String, String> mediationParams = configuration.getMediationParams();

        try {
            if (configuration.isTestMode()) {
                adUnitId = AdUnitId.testAdUnitId();

                logger.d(String.format("%s uses Test Unit ID: %s", adapterName, adUnitId));
            } else {
                adUnitId = new AdUnitId(mediationParams.get("unitid"));
            }
        } catch (InvalidParameterException e) {
            logger.w(String.format("Failed to prepare %s. adUnitId is invalid.", adapterName));
            return false;
        }

        final RequestConfiguration.Builder builder = new RequestConfiguration.Builder();

        // COPPA
        if (configuration.getChildDirected() != VAMPPrivacySettings.ChildDirected.UNKNOWN) {
            int tagForChildDirectedTreatment =
                    configuration.getChildDirected() == VAMPPrivacySettings.ChildDirected.TRUE
                            ? RequestConfiguration.TAG_FOR_CHILD_DIRECTED_TREATMENT_TRUE
                            : RequestConfiguration.TAG_FOR_CHILD_DIRECTED_TREATMENT_FALSE;

            builder.setTagForChildDirectedTreatment(tagForChildDirectedTreatment);

            logger.d(
                    String.format(
                            Locale.getDefault(),
                            "TagForChildDirectedTreatment is %s.",
                            tagForChildDirectedTreatment
                                    == RequestConfiguration.TAG_FOR_CHILD_DIRECTED_TREATMENT_TRUE));
        }

        // TFUA
        if (configuration.getUnderAgeOfConsent() != VAMPPrivacySettings.UnderAgeOfConsent.UNKNOWN) {
            int tagForUnderAgeOfConsent =
                    configuration.getUnderAgeOfConsent()
                                    == VAMPPrivacySettings.UnderAgeOfConsent.TRUE
                            ? RequestConfiguration.TAG_FOR_UNDER_AGE_OF_CONSENT_TRUE
                            : RequestConfiguration.TAG_FOR_UNDER_AGE_OF_CONSENT_FALSE;

            builder.setTagForUnderAgeOfConsent(tagForUnderAgeOfConsent);

            logger.d(
                    String.format(
                            Locale.getDefault(),
                            "TagForUnderAgeOfConsent is %s.",
                            tagForUnderAgeOfConsent
                                    == RequestConfiguration.TAG_FOR_UNDER_AGE_OF_CONSENT_TRUE));
        }

        MobileAds.setRequestConfiguration(builder.build());

        logger.d(String.format("%s is prepared.", adapterName));

        return true;
    }

    @Override
    public boolean isReady() {
        return rewardedAd != null;
    }

    @Override
    public void load(@NonNull final Context context) {
        final Context appContext;
        if (context instanceof Activity) {
            // このメソッド内で使用するAdMob APIはアプリケーションコンテキストで動作するため、
            // Activityの場合はアプリケーションコンテキストを取得する
            appContext = context.getApplicationContext();
        } else {
            appContext = context;
        }

        if (!AdMobInitializer.getInstance().isInitialized()) {
            AdMobInitializer.getInstance()
                    .initialize(
                            appContext,
                            new AdMobInitializer.InitializationListener() {
                                @Override
                                public void onComplete() {
                                    logger.d("AdMob is initialized by VAMP.");

                                    load(appContext);
                                }
                            });

            return;
        }

        final AdRequest.Builder builder = new AdRequest.Builder();

        // GDPR
        if (adapterConfiguration != null
                && adapterConfiguration.getConsentStatus()
                        == VAMPPrivacySettings.ConsentStatus.DENIED) {
            final Bundle extras = new Bundle();
            extras.putString("npa", "1");
            builder.addNetworkExtrasBundle(
                    com.google.ads.mediation.admob.AdMobAdapter.class, extras);

            logger.d(
                    String.format(
                            Locale.getDefault(), "%s adds npa=1 for network extras.", adapterName));
        }

        final AdRequest request = builder.build();

        // RewardedAd.loadメソッドはメインスレッドで実行する必要がある。
        // アダプタのloadメソッドの実行スレッドは不明であるため、確実にメインスレッドで実行する
        new Handler(Looper.getMainLooper())
                .post(
                        new Runnable() {
                            @Override
                            public void run() {
                                if (adUnitId == null) return;
                                RewardedAd.load(
                                        appContext,
                                        adUnitId.value,
                                        request,
                                        new RALCallback(AdMobAdapter.this));
                            }
                        });
    }

    @Override
    public void show(@NonNull Context context) {
        if (!(context instanceof Activity)) {
            if (listener != null) {
                listener.onEvent(Event.newActivityNotFoundErrorEvent("show"));
            }

            return;
        }

        if (rewardedAd == null) {
            final String message = "rewardedAd hasn't been loaded yet.";
            logger.w(message);

            final AdNetworkErrorInfo errorInfo =
                    new AdNetworkErrorInfo.Builder("show", VAMPError.NOT_LOADED_AD)
                            .setErrorMessage(message)
                            .build();

            if (listener != null) {
                listener.onEvent(new Event(Event.EVENT_FAIL, errorInfo));
            }

            return;
        }

        rewardedAd.setFullScreenContentCallback(new FSCCallback(this));
        rewardedAd.show((Activity) context, new OUERListener(this));
    }

    @Override
    public void destroy() {
        rewardedAd = null;
    }

    /** メモリリークを防ぐためにadapterオブジェクトを弱参照で持つコールバッククラスです */
    private static final class RALCallback extends RewardedAdLoadCallback {
        @NonNull private final WeakReference<AdMobAdapter> adapterRef;

        RALCallback(@NonNull final AdMobAdapter adapter) {
            adapterRef = new WeakReference<>(adapter);
        }

        @Override
        public void onAdLoaded(@NonNull final RewardedAd ad) {
            final AdMobAdapter adapter = adapterRef.get();
            if (adapter == null) {
                return;
            }

            adapter.logger.d("onAdLoaded called.");

            adapter.rewardedAd = ad;

            if (adapter.adapterConfiguration != null
                    && adapter.adapterConfiguration.isDebugMode()) {
                ResponseInfo responseInfo = ad.getResponseInfo();
                adapter.logger.d("ResponseId: " + responseInfo.getResponseId());
                adapter.logger.d(
                        "MediationAdapterClassName: "
                                + responseInfo.getMediationAdapterClassName());
            }

            if (adapter.listener != null) {
                adapter.listener.onEvent(new Event(Event.EVENT_LOAD_SUCCESS));
            }
        }

        @Override
        public void onAdFailedToLoad(@NonNull final LoadAdError loadAdError) {
            final AdMobAdapter adapter = adapterRef.get();
            if (adapter == null) {
                return;
            }

            adapter.logger.d("onAdFailedToLoad called. error code=" + loadAdError.getCode());

            final VAMPError vampError =
                    loadAdError.getCode() == AdRequest.ERROR_CODE_NO_FILL
                            ? VAMPError.NO_ADSTOCK
                            : VAMPError.ADNETWORK_ERROR;

            final AdNetworkErrorInfo errorInfo =
                    new AdNetworkErrorInfo.Builder("onAdFailedToLoad", vampError)
                            .setAdNetworkErrorCode("" + loadAdError.getCode())
                            .setAdNetworkErrorMessage(loadAdError.getMessage())
                            .build();

            if (adapter.listener != null) {
                adapter.listener.onEvent(new Event(Event.EVENT_FAIL, errorInfo));
            }
        }
    }

    /** メモリリークを防ぐためにadapterオブジェクトを弱参照で持つコールバッククラスです */
    private static final class FSCCallback extends FullScreenContentCallback {
        @NonNull private final WeakReference<AdMobAdapter> adapterRef;

        FSCCallback(@NonNull final AdMobAdapter adapter) {
            adapterRef = new WeakReference<>(adapter);
        }

        @Override
        public void onAdImpression() {
            final AdMobAdapter adapter = adapterRef.get();
            if (adapter == null) {
                return;
            }

            adapter.logger.d("onAdImpression called.");
        }

        @Override
        public void onAdShowedFullScreenContent() {
            final AdMobAdapter adapter = adapterRef.get();
            if (adapter == null) {
                return;
            }

            adapter.logger.d("onAdShowedFullScreenContent called.");

            if (adapter.listener != null) {
                adapter.listener.onEvent(new Event(Event.EVENT_OPEN));
            }
        }

        @Override
        public void onAdFailedToShowFullScreenContent(@NonNull final AdError adError) {
            final AdMobAdapter adapter = adapterRef.get();
            if (adapter == null) {
                return;
            }

            adapter.logger.d(
                    "onAdFailedToShowFullScreenContent called. error code=" + adError.getCode());

            final AdNetworkErrorInfo errorInfo =
                    new AdNetworkErrorInfo.Builder(
                                    "onAdFailedToShowFullScreenContent", VAMPError.ADNETWORK_ERROR)
                            .setAdNetworkErrorCode("" + adError.getCode())
                            .setAdNetworkErrorMessage(adError.getMessage())
                            .build();

            if (adapter.listener != null) {
                adapter.listener.onEvent(new Event(Event.EVENT_FAIL, errorInfo));
            }
        }

        @Override
        public void onAdDismissedFullScreenContent() {
            final AdMobAdapter adapter = adapterRef.get();
            if (adapter == null) {
                return;
            }

            adapter.logger.d("onAdDismissedFullScreenContent called.");

            if (!adapter.isCompleted) {
                final String message = "onUserEarnedReward method has not been called yet.";
                adapter.logger.d(message);

                final AdNetworkErrorInfo errorInfo =
                        new AdNetworkErrorInfo.Builder(
                                        "onAdDismissedFullScreenContent", VAMPError.USER_CANCEL)
                                .setErrorMessage(message)
                                .build();

                if (adapter.listener != null) {
                    adapter.listener.onEvent(
                            new Event(Event.EVENT_FAIL | Event.EVENT_CLOSE, errorInfo));
                }

                return;
            }

            if (adapter.listener != null) {
                adapter.listener.onEvent(new Event(Event.EVENT_COMPLETE | Event.EVENT_CLOSE));
            }
        }
    }

    /** メモリリークを防ぐためにadapterオブジェクトを弱参照で持つリスナークラスです */
    private static final class OUERListener implements OnUserEarnedRewardListener {
        @NonNull private final WeakReference<AdMobAdapter> adapterRef;

        OUERListener(@NonNull final AdMobAdapter adapter) {
            adapterRef = new WeakReference<>(adapter);
        }

        @Override
        public void onUserEarnedReward(@NonNull final RewardItem rewardItem) {
            final AdMobAdapter adapter = adapterRef.get();
            if (adapter == null) {
                return;
            }

            if (adapter.isCompleted) {
                adapter.logger.d("onUserEarnedReward method has already been called.");
                return;
            }

            adapter.isCompleted = true;

            final Map<String, String> rewardMap = new HashMap<>();
            rewardMap.put("type", rewardItem.getType());
            rewardMap.put("amount", "" + rewardItem.getAmount());
            adapter.logger.d("onUserEarnedReward called. rewardItem=" + rewardMap);
        }
    }
}
