package jp.supership.vamp.mediation.admob;

import android.text.TextUtils;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

final class AdUnitId {
    private static final String TEST_ID = "ca-app-pub-3940256099942544/5224354917";

    @NonNull final String value;

    AdUnitId(@Nullable final String value) throws InvalidParameterException {
        String adUnitId = null;

        if (!TextUtils.isEmpty(value)) {
            adUnitId = value.trim();
        }

        if (TextUtils.isEmpty(adUnitId)) {
            throw new InvalidParameterException();
        }

        this.value = adUnitId;
    }

    @NonNull
    static AdUnitId testAdUnitId() {
        AdUnitId adUnitId = null;
        try {
            adUnitId = new AdUnitId(TEST_ID);
        } catch (InvalidParameterException ignored) {
        }

        assert adUnitId != null;
        return adUnitId;
    }

    @NonNull
    @Override
    public String toString() {
        return "AdUnitId(" + value + ")";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AdUnitId that = (AdUnitId) o;
        return value.equals(that.value);
    }

    @Override
    public int hashCode() {
        return value.hashCode();
    }
}
