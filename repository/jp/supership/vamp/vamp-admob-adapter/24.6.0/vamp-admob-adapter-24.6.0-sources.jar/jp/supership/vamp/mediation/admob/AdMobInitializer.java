package jp.supership.vamp.mediation.admob;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;

import java.util.ArrayList;

class AdMobInitializer implements OnInitializationCompleteListener {

    private enum State {
        UNINITIALIZED,
        INITIALIZING,
        INITIALIZED
    }

    private State state = State.UNINITIALIZED;
    private final ArrayList<InitializationListener> listeners = new ArrayList<>();

    private static AdMobInitializer instance = null;

    private AdMobInitializer() {}

    static synchronized AdMobInitializer getInstance() {
        if (instance == null) {
            instance = new AdMobInitializer();
        }

        return instance;
    }

    boolean isInitialized() {
        return state == State.INITIALIZED;
    }

    void initialize(@NonNull Context context, @Nullable InitializationListener listener) {
        if (state == State.INITIALIZED) {
            if (listener != null) {
                listener.onComplete();
            }

            return;
        }

        if (listener != null) {
            listeners.add(listener);
        }

        if (state != State.INITIALIZING) {
            state = State.INITIALIZING;
            MobileAds.initialize(context, this);
        }
    }

    @Override
    public void onInitializationComplete(@NonNull InitializationStatus initState) {
        state = State.INITIALIZED;

        for (InitializationListener listener : listeners) {
            listener.onComplete();
        }

        listeners.clear();
    }

    interface InitializationListener {
        void onComplete();
    }
}
