/**
 * Automatically generated file. DO NOT MODIFY
 */
package jp.supership.vamp.mediation.unityads;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "jp.supership.vamp.mediation.unityads";
  public static final String BUILD_TYPE = "release";
  // Field from default config.
  public static final String VERSION_NAME = "4.16.600";
}
