//
//  Copyright © 2026 Supership Inc. All rights reserved.
//
package jp.supership.vamp.mediation.unityads;

import android.app.Activity;
import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.unity3d.ads.AdExpiredListener;
import com.unity3d.ads.InitializationConfiguration;
import com.unity3d.ads.InitializationListener;
import com.unity3d.ads.LoadConfiguration;
import com.unity3d.ads.LogLevel;
import com.unity3d.ads.RewardedAd;
import com.unity3d.ads.RewardedShowListener;
import com.unity3d.ads.ShowConfiguration;
import com.unity3d.ads.ShowFinishState;
import com.unity3d.ads.UnityAds;
import com.unity3d.ads.UnityAdsError;
import java.lang.ref.WeakReference;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import jp.supership.vamp.VAMPError;
import jp.supership.vamp.VAMPLogger;
import jp.supership.vamp.VAMPPrivacySettings;
import jp.supership.vamp.mediation.AdNetworkErrorInfo;
import jp.supership.vamp.mediation.Adapter;
import jp.supership.vamp.mediation.AdapterConfiguration;
import jp.supership.vamp.mediation.AdapterEventListener;
import jp.supership.vamp.mediation.Event;

public class UnityAdsAdapter implements Adapter {
    private enum State {
        IDLE,
        LOADED,
        SHOWING,
    }

    @NonNull private static final String ADNW_NAME = "UnityAds";

    // no fill を示す `UnityAdsError.code` (UnityAds Android 4.19.0 公式 docs の Error codes reference より。
    // Load: 52100 = No fill。
    // https://docs.unity.com/en-us/ads-android/4.19.0/sdk-integration/troubleshoot/errors-reference
    // )
    private static final int UNITYADS_ERROR_CODE_NO_FILL = 52100;

    @NonNull private final String adapterName = UnityAdsAdapter.class.getSimpleName();
    @NonNull private final VAMPLogger logger = new VAMPLogger(adapterName);
    @NonNull private final Handler mainHandler = new Handler(Looper.getMainLooper());
    @Nullable private AdapterEventListener adapterListener;
    @Nullable private AdapterConfiguration adapterConfiguration;
    @Nullable private GameId gameId;
    @Nullable private PlacementId placementId;
    @Nullable private RewardedAd rewardedAd;
    @NonNull private State state = State.IDLE;
    // `EVENT_COMPLETE` を通知済みかどうか (`onRewarded` / `onCompleted` の二重通知防止)
    private boolean rewardNotified = false;
    // `onCompleted` の処理を終えたかどうか (終了後に届いた `onRewarded` の通知抑止)
    private boolean showFinished = false;
    // destroy 済みかどうか (破棄後に非同期コールバックで状態遷移・イベント通知しないためのガード)
    private volatile boolean destroyed = false;

    @Override
    public boolean isSupported() {
        // UnityAds.isSupported()ではGINGERBREAD(2.3)対応となっているが実際に表示すると
        // ビデオ再生エラーでいきなりエンドカードが表示され、「×ボタン」で閉じると
        // アプリが落ちてしまうので、実際に表示が確認出来たJELLY_BEAN(4.1)以降に変更
        // https://github.com/Unity-Technologies/unity-ads-android/blob/master/lib/src/main/java/com/unity3d/services/UnityServices.java#L104
        // 4.3でshowしても表示されないので4.4に変更
        // 4系での動作が安定しないため、5に変更
        // 以下の課題にて6に変更
        // https://scaleout.backlog.jp/view/VIDEO_RWD-2655
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.M;
    }

    @NonNull
    @Override
    public String getAdNetworkVersion() {
        return UnityAds.getVersion();
    }

    @NonNull
    @Override
    public String getAdNetworkName() {
        return ADNW_NAME;
    }

    @NonNull
    @Override
    public List<String> getAdNetworkAdIdentifiers() {
        if (placementId != null) {
            return Collections.singletonList(placementId.value);
        } else {
            return Collections.emptyList();
        }
    }

    @NonNull
    @Override
    public String getAdapterVersion() {
        return BuildConfig.VERSION_NAME;
    }

    @Override
    public boolean prepare(
            @NonNull final Context context,
            @NonNull final AdapterConfiguration configuration,
            @Nullable final AdapterEventListener listener) {
        this.adapterListener = listener;
        this.adapterConfiguration = configuration;

        final Map<String, String> mediationParams = adapterConfiguration.getMediationParams();

        try {
            this.placementId = new PlacementId(mediationParams.get("zone"));
        } catch (InvalidParameterException e) {
            logger.w(String.format("Failed to prepare %s. placementId is invalid.", adapterName));
            return false;
        }

        try {
            this.gameId = new GameId(adapterConfiguration.getAdID());
        } catch (InvalidParameterException e) {
            logger.w(String.format("Failed to prepare %s. gameId is invalid.", adapterName));
            return false;
        }

        if (configuration.getConsentStatus() != VAMPPrivacySettings.ConsentStatus.UNKNOWN) {
            final boolean accepted =
                    configuration.getConsentStatus() == VAMPPrivacySettings.ConsentStatus.ACCEPTED;

            // UADSMetaData("privacy.consent") は 4.19.0 で deprecated 化されたため後継 API へ移行
            UnityAds.setUserConsent(accepted);

            logger.d(String.format("Sets %s to privacy consent.", accepted));
        }

        if (configuration.getUnderAgeOfConsent() != VAMPPrivacySettings.UnderAgeOfConsent.UNKNOWN
                || configuration.getChildDirected() != VAMPPrivacySettings.ChildDirected.UNKNOWN) {
            // 年齢制限未満でない場合にtrue
            final boolean overAgeLimit =
                    !(configuration.getUnderAgeOfConsent()
                                    == VAMPPrivacySettings.UnderAgeOfConsent.TRUE
                            || configuration.getChildDirected()
                                    == VAMPPrivacySettings.ChildDirected.TRUE);

            // UADSMetaData("privacy.useroveragelimit") は 4.19.0 で deprecated 化されたため後継 API へ移行。
            // 年齢制限未満 (overAgeLimit == false) の場合に非行動ターゲティング広告を有効にする
            UnityAds.setNonBehavioral(!overAgeLimit);

            logger.d(String.format("Sets %s to privacy user over age limit.", overAgeLimit));
        }

        // UnityAds.setDebugMode は 4.19.0 で deprecated 化されたため、
        // ログレベルは InitializationConfiguration#withLogLevel で設定する (load 参照)

        logger.d(String.format("%s is prepared.", adapterName));

        return true;
    }

    @Override
    public void load(@NonNull final Context applicationContext) {
        if (adapterConfiguration == null || placementId == null || gameId == null) {
            if (adapterListener != null) {
                adapterListener.onEvent(
                        Event.newNullOrEmptyParameterErrorEvent(
                                "load",
                                Arrays.asList("adapterConfiguration", "placementId", "gameId")));
            }

            return;
        }

        final AdapterConfiguration configuration = adapterConfiguration;
        final GameId currentGameId = gameId;

        // UnityAds.initialize / RewardedAd.load はメインスレッドで実行する必要がある。
        // アダプタの load メソッドの実行スレッドは不明であるため、確実にメインスレッドで実行する
        runOnMainThread(
                () -> {
                    if (destroyed) {
                        return;
                    }

                    // 同一インスタンスで再ロードされる場合に備え、リワード通知フラグを初期化する
                    rewardNotified = false;
                    showFinished = false;

                    if (UnityAds.isInitialized()) {
                        loadRewardedAd();
                        return;
                    }

                    final InitializationConfiguration initConfiguration =
                            new InitializationConfiguration.Builder(currentGameId.value)
                                    .withTestMode(configuration.isTestMode())
                                    .withLogLevel(
                                            configuration.isDebugMode()
                                                    ? LogLevel.DEBUG
                                                    : LogLevel.INFO)
                                    .build();

                    final WeakReference<UnityAdsAdapter> adapterRef = new WeakReference<>(this);
                    UnityAds.initialize(
                            initConfiguration,
                            new InitializationListener() {
                                @Override
                                public void onInitializationComplete(
                                        @Nullable final UnityAdsError error) {
                                    // コールバックの実行スレッドは保証されないため、
                                    // 状態遷移は main thread に直列化する
                                    final UnityAdsAdapter adapter = adapterRef.get();
                                    if (adapter == null) {
                                        return;
                                    }

                                    adapter.runOnMainThread(
                                            () -> {
                                                if (adapter.destroyed) {
                                                    return;
                                                }

                                                if (error != null) {
                                                    adapter.handleInitializationError(error);
                                                    return;
                                                }

                                                adapter.logger.d(
                                                        "UnityAds SDK is initialized by VAMP.");

                                                adapter.loadRewardedAd();
                                            });
                                }
                            });
                });
    }

    @Override
    public boolean isReady() {
        return UnityAds.isInitialized() && state == State.LOADED && rewardedAd != null;
    }

    @Override
    public void show(@NonNull final Context context) {
        if (!(context instanceof Activity)) {
            if (adapterListener != null) {
                adapterListener.onEvent(Event.newActivityNotFoundErrorEvent("show"));
            }

            return;
        }

        // イベント到達タイミングを調整するため、
        // onStartedコールバックを待たずにEVENT_OPENを発火する
        if (adapterListener != null) {
            adapterListener.onEvent(new Event(Event.EVENT_OPEN));
        }

        // 踏み台Activityの表示を開始。
        // onResumeを検知するためイベントリスナーを登録し、
        // onResumeを検知したら広告の表示を開始
        EventDispatcher.getInstance().addListener(eventListener);
        ScaffoldActivity.show((Activity) context);
    }

    @Override
    public void destroy() {
        destroyed = true;
        EventDispatcher.getInstance().removeListener(eventListener);
        rewardedAd = null;
    }

    /** RewardedAd をロードします。 */
    private void loadRewardedAd() {
        if (placementId == null) {
            return;
        }

        final LoadConfiguration configuration =
                new LoadConfiguration.Builder(placementId.value).build();

        RewardedAd.load(configuration, new LoadListener(this));
    }

    /** メインスレッドで処理を実行します。 */
    private void runOnMainThread(@NonNull final Runnable runnable) {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            runnable.run();
        } else {
            mainHandler.post(runnable);
        }
    }

    /** 初期化に失敗した場合に呼ばれます。 */
    private void handleInitializationError(@NonNull final UnityAdsError error) {
        logger.w(
                "Failed to initialize UnityAds SDK. code="
                        + error.getCode()
                        + " message="
                        + error.getMessage());

        state = State.IDLE;

        if (adapterListener != null) {
            adapterListener.onEvent(
                    new Event(
                            Event.EVENT_FAIL,
                            new AdNetworkErrorInfo.Builder("load", VAMPError.ADNETWORK_ERROR)
                                    .setAdNetworkErrorCode(String.valueOf(error.getCode()))
                                    .setAdNetworkErrorMessage(error.getMessage())
                                    .build()));
        }
    }

    /** RewardedAd のロードが完了した場合に呼ばれます。 */
    private void handleAdLoaded(@NonNull final RewardedAd loadedAd) {
        logger.d(
                "onAdLoaded called. placementId="
                        + (placementId != null ? placementId.value : null));

        rewardedAd = loadedAd;
        rewardedAd.setOnAdExpired(new ExpiredListener(this));
        state = State.LOADED;

        if (adapterListener != null) {
            adapterListener.onEvent(new Event(Event.EVENT_LOAD_SUCCESS));
        }
    }

    /** RewardedAd のロードに失敗した場合に呼ばれます。 */
    private void handleLoadError(@Nullable final UnityAdsError error) {
        final int code = error != null ? error.getCode() : -1;
        final String message = error != null ? error.getMessage() : null;

        logger.d(
                String.format(
                        "onAdLoaded failed. placementId=%s code=%d message=%s",
                        placementId != null ? placementId.value : null, code, message));

        state = State.IDLE;
        rewardedAd = null;

        final boolean noFill =
                code == UNITYADS_ERROR_CODE_NO_FILL
                        || (message != null
                                && message.toLowerCase(Locale.ROOT).contains("no ad fill"));
        final VAMPError vampError = noFill ? VAMPError.NO_ADSTOCK : VAMPError.ADNETWORK_ERROR;

        if (adapterListener != null) {
            adapterListener.onEvent(
                    new Event(
                            Event.EVENT_FAIL,
                            new AdNetworkErrorInfo.Builder("onAdLoaded", vampError)
                                    .setAdNetworkErrorCode(String.valueOf(code))
                                    .setAdNetworkErrorMessage(message)
                                    .build()));
        }
    }

    /** ロード済みの RewardedAd が期限切れになった場合に呼ばれます。 */
    private void handleAdExpired() {
        logger.w("rewarded ad is expired.");

        // ロード済みの状態でのみ広告を破棄する (表示中の破棄は show コールバックを阻害するため行わない)
        if (state == State.LOADED) {
            rewardedAd = null;
            state = State.IDLE;
        }
    }

    /** 広告の表示が開始された場合に呼ばれます。 */
    private void handleShowStarted() {
        logger.d(
                "onStarted called. placementId="
                        + (placementId != null ? placementId.value : null));

        // このコールバックでEVENT_OPENを発火すると、
        // 広告Activityが表示され、裏に回ったアプリ側のActivityが破棄された場合、
        // イベント到達タイミングが遅れてしまう。(アプリ側Activityが再生成されたとき)
        // そのため、Adapter#showメソッドでEVENT_OPENを発火する
    }

    /** 広告がクリックされた場合に呼ばれます。 */
    private void handleShowClick() {
        logger.d(
                "onClicked called. placementId="
                        + (placementId != null ? placementId.value : null));

        if (adapterListener != null) {
            adapterListener.onEvent(new Event(Event.EVENT_CLICK));
        }
    }

    /** ユーザーがリワードを獲得した場合に呼ばれます。 */
    private void handleRewarded() {
        logger.d(
                "onRewarded called. placementId="
                        + (placementId != null ? placementId.value : null));

        // 終了処理 (onCompleted) 後、または通知済みの場合は通知しない
        if (showFinished || rewardNotified) {
            return;
        }

        // リワード付与は本コールバックを正 (せい) とする (Unity 推奨)
        rewardNotified = true;

        if (adapterListener != null) {
            adapterListener.onEvent(new Event(Event.EVENT_COMPLETE));
        }
    }

    /** 広告の表示が完了した場合に呼ばれます。 */
    private void handleShowComplete(@NonNull final ShowFinishState finishState) {
        logger.d(
                String.format(
                        "onCompleted called. placementId=%s finishState=%s",
                        placementId != null ? placementId.value : null, finishState));

        // 踏み台Activityは自動では閉じないため、UNITY_ADS_CLOSEイベントを送り、
        // Activity#finishを実行させる
        EventDispatcher.getInstance().dispatch(EventDispatcher.Event.UNITY_ADS_CLOSE, null);

        showFinished = true;

        if (rewardNotified) {
            // リワードは onRewarded で通知済みのため、ここではクローズのみ通知する
            if (adapterListener != null) {
                adapterListener.onEvent(new Event(Event.EVENT_CLOSE));
            }
        } else if (finishState == ShowFinishState.COMPLETED) {
            // onRewarded が来ないまま COMPLETED となった場合のフォールバック
            if (adapterListener != null) {
                adapterListener.onEvent(new Event(Event.EVENT_COMPLETE | Event.EVENT_CLOSE));
            }
        } else if (finishState == ShowFinishState.SKIPPED) {
            // 途中キャンセル
            if (adapterListener != null) {
                adapterListener.onEvent(
                        new Event(
                                Event.EVENT_FAIL | Event.EVENT_CLOSE,
                                new AdNetworkErrorInfo.Builder("onCompleted", VAMPError.USER_CANCEL)
                                        .setErrorMessage(finishState.toString())
                                        .build()));
            }
        } else {
            if (adapterListener != null) {
                adapterListener.onEvent(
                        new Event(
                                Event.EVENT_FAIL | Event.EVENT_CLOSE,
                                new AdNetworkErrorInfo.Builder(
                                                "onCompleted", VAMPError.ADNETWORK_ERROR)
                                        .setErrorMessage(finishState.toString())
                                        .build()));
            }
        }

        // 表示が完了したので、同一インスタンスで再ロードできるよう状態を戻す
        rewardedAd = null;
        state = State.IDLE;
    }

    /** 広告の表示に失敗した場合に呼ばれます。 */
    private void handleShowFailed(@Nullable final UnityAdsError error) {
        final int code = error != null ? error.getCode() : -1;
        final String message = error != null ? error.getMessage() : null;

        logger.d(String.format("onFailed called. code=%d message=%s", code, message));

        // 踏み台Activityが残らないよう UNITY_ADS_CLOSE を送り Activity#finish を実行させる
        EventDispatcher.getInstance().dispatch(EventDispatcher.Event.UNITY_ADS_CLOSE, null);

        if (adapterListener != null) {
            adapterListener.onEvent(
                    new Event(
                            Event.EVENT_FAIL | Event.EVENT_CLOSE,
                            new AdNetworkErrorInfo.Builder("onFailed", VAMPError.ADNETWORK_ERROR)
                                    .setAdNetworkErrorCode(String.valueOf(code))
                                    .setAdNetworkErrorMessage(message)
                                    .build()));
        }

        // 表示に失敗したので、同一インスタンスで再ロードできるよう状態を戻す
        rewardedAd = null;
        state = State.IDLE;
    }

    /** メモリリークを防ぐためにadapterオブジェクトを弱参照で持つリスナークラスです */
    private static class LoadListener implements com.unity3d.ads.LoadListener<RewardedAd> {
        @NonNull private final WeakReference<UnityAdsAdapter> adapterRef;

        LoadListener(@NonNull final UnityAdsAdapter adapter) {
            adapterRef = new WeakReference<>(adapter);
        }

        @Override
        public void onAdLoaded(
                @Nullable final RewardedAd loadedAd, @Nullable final UnityAdsError error) {
            final UnityAdsAdapter adapter = adapterRef.get();
            if (adapter == null) {
                return;
            }

            adapter.runOnMainThread(
                    () -> {
                        if (adapter.destroyed) {
                            return;
                        }

                        if (adapter.state != State.IDLE && adapter.state != State.LOADED) {
                            // showing 等では何もしない
                            return;
                        }

                        if (error != null || loadedAd == null) {
                            adapter.handleLoadError(error);
                            return;
                        }

                        adapter.handleAdLoaded(loadedAd);
                    });
        }
    }

    /** ロード済み広告の期限切れを弱参照で受け取るリスナークラスです */
    private static class ExpiredListener implements AdExpiredListener<RewardedAd> {
        @NonNull private final WeakReference<UnityAdsAdapter> adapterRef;

        ExpiredListener(@NonNull final UnityAdsAdapter adapter) {
            adapterRef = new WeakReference<>(adapter);
        }

        @Override
        public void onAdExpired(@Nullable final RewardedAd expiredAd) {
            final UnityAdsAdapter adapter = adapterRef.get();
            if (adapter == null) {
                return;
            }

            adapter.runOnMainThread(
                    () -> {
                        if (adapter.destroyed) {
                            return;
                        }

                        if (expiredAd != null && expiredAd != adapter.rewardedAd) {
                            return;
                        }

                        adapter.handleAdExpired();
                    });
        }
    }

    /** メモリリークを防ぐためにadapterオブジェクトを弱参照で持つリスナークラスです */
    private static class ShowListener implements RewardedShowListener {
        @NonNull private final WeakReference<UnityAdsAdapter> adapterRef;

        ShowListener(@NonNull final UnityAdsAdapter adapter) {
            adapterRef = new WeakReference<>(adapter);
        }

        @Override
        public void onStarted(final RewardedAd unityAd) {
            dispatch(unityAd, true, UnityAdsAdapter::handleShowStarted);
        }

        @Override
        public void onClicked(final RewardedAd unityAd) {
            dispatch(unityAd, false, UnityAdsAdapter::handleShowClick);
        }

        @Override
        public void onRewarded(final RewardedAd unityAd) {
            dispatch(unityAd, true, UnityAdsAdapter::handleRewarded);
        }

        @Override
        public void onCompleted(final RewardedAd unityAd, final ShowFinishState finishState) {
            final UnityAdsAdapter adapter = adapterRef.get();
            if (adapter == null) {
                return;
            }

            adapter.runOnMainThread(
                    () -> {
                        if (unityAd != adapter.rewardedAd) {
                            return;
                        }

                        if (adapter.state != State.SHOWING) {
                            adapter.logger.d("state is not showing. state=" + adapter.state);
                            return;
                        }

                        adapter.handleShowComplete(finishState);
                    });
        }

        @Override
        public void onFailed(final RewardedAd unityAd, final UnityAdsError error) {
            final UnityAdsAdapter adapter = adapterRef.get();
            if (adapter == null) {
                return;
            }

            adapter.runOnMainThread(
                    () -> {
                        if (unityAd != adapter.rewardedAd) {
                            return;
                        }

                        adapter.handleShowFailed(error);
                    });
        }

        /**
         * 自身が保持する広告かつ表示中の場合のみ、メインスレッドで処理を実行します。
         *
         * @param requireShowing true の場合は state == SHOWING を要求する
         */
        private void dispatch(
                @Nullable final RewardedAd unityAd,
                final boolean requireShowing,
                @NonNull final AdapterAction action) {
            final UnityAdsAdapter adapter = adapterRef.get();
            if (adapter == null) {
                return;
            }

            adapter.runOnMainThread(
                    () -> {
                        if (unityAd != adapter.rewardedAd) {
                            // 自身が保持する広告でない場合は何もしない
                            return;
                        }

                        if (requireShowing && adapter.state != State.SHOWING) {
                            adapter.logger.d("state is not showing. state=" + adapter.state);
                            return;
                        }

                        action.run(adapter);
                    });
        }
    }

    /** ShowListener から adapter のインスタンスメソッドを呼ぶための関数型インターフェースです */
    private interface AdapterAction {
        void run(@NonNull UnityAdsAdapter adapter);
    }

    @NonNull
    private final EventDispatcher.Listener eventListener =
            new EventDispatcher.Listener() {
                @Override
                public void onListen(
                        @NonNull final EventDispatcher.Event event, @Nullable final Object data) {
                    if (event == EventDispatcher.Event.ACTIVITY_RESUME) {
                        if (data instanceof Activity) {
                            // 踏み台Activityを使って広告を表示。
                            // onCreateでshowすると表示できなかったため、onResumeで実行する。
                            // また、showメソッドを複数回呼び出すとバグるため、
                            // 一度だけ呼び出すように制御する
                            if (state == State.LOADED
                                    && rewardedAd != null
                                    && placementId != null) {
                                state = State.SHOWING;

                                final ShowConfiguration configuration =
                                        new ShowConfiguration.Builder().build();

                                rewardedAd.show(
                                        (Activity) data,
                                        configuration,
                                        new ShowListener(UnityAdsAdapter.this));
                            } else if (state != State.SHOWING) {
                                // isReady() 後〜show 実行前に期限切れ (handleAdExpired) 等で
                                // 広告が利用不可になったレース。踏み台Activityを閉じてエラーを通知する
                                EventDispatcher.getInstance()
                                        .dispatch(EventDispatcher.Event.UNITY_ADS_CLOSE, null);

                                if (adapterListener != null) {
                                    adapterListener.onEvent(
                                            new Event(
                                                    Event.EVENT_FAIL | Event.EVENT_CLOSE,
                                                    new AdNetworkErrorInfo.Builder(
                                                                    "show",
                                                                    VAMPError.ADNETWORK_ERROR)
                                                            .setErrorMessage(
                                                                    "Rewarded ad is not available"
                                                                            + " (expired or failed).")
                                                            .build()));
                                }
                            }
                        }
                    }
                }
            };
}
