//
//  Copyright © 2026 Supership Inc. All rights reserved.
//
package jp.supership.vamp.mediation.unityads;

final class InvalidParameterException extends Exception {}
