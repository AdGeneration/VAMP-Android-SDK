//
//  Copyright © 2026 Supership Inc. All rights reserved.
//
package jp.supership.vamp.mediation.unityads;

import android.text.TextUtils;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

final class PlacementId {
    @NonNull final String value;

    PlacementId(@Nullable final String value) throws InvalidParameterException {
        String placementId = null;

        if (!TextUtils.isEmpty(value)) {
            placementId = value.trim();
        }

        if (TextUtils.isEmpty(placementId)) {
            throw new InvalidParameterException();
        }

        this.value = placementId;
    }

    @NonNull
    @Override
    public String toString() {
        return "PlacementId(" + value + ")";
    }
}
