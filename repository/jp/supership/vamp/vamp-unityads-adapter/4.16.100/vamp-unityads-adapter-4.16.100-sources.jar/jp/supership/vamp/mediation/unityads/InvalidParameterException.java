package jp.supership.vamp.mediation.unityads;

final class InvalidParameterException extends Exception {}
