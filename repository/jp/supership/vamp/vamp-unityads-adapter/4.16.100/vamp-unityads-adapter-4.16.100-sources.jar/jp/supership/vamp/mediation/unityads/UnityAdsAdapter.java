package jp.supership.vamp.mediation.unityads;

import android.app.Activity;
import android.content.Context;
import android.os.Build;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.unity3d.ads.IUnityAdsInitializationListener;
import com.unity3d.ads.IUnityAdsLoadListener;
import com.unity3d.ads.IUnityAdsShowListener;
import com.unity3d.ads.UnityAds;
import com.unity3d.ads.metadata.MetaData;

import jp.supership.vamp.VAMPError;
import jp.supership.vamp.VAMPLogger;
import jp.supership.vamp.VAMPPrivacySettings;
import jp.supership.vamp.mediation.AdNetworkErrorInfo;
import jp.supership.vamp.mediation.Adapter;
import jp.supership.vamp.mediation.AdapterConfiguration;
import jp.supership.vamp.mediation.AdapterEventListener;
import jp.supership.vamp.mediation.Event;

import java.lang.ref.WeakReference;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;

public class UnityAdsAdapter implements Adapter {
    private enum State {
        IDLE,
        LOADED,
        SHOWING,
    }

    @NonNull private static final String ADNW_NAME = "UnityAds";

    @NonNull private final String adapterName = UnityAdsAdapter.class.getSimpleName();
    @NonNull private final VAMPLogger logger = new VAMPLogger(adapterName);
    @Nullable private AdapterEventListener adapterListener;
    @Nullable private AdapterConfiguration adapterConfiguration;
    @Nullable private GameId gameId;
    @Nullable private PlacementId placementId;
    @NonNull private State state = State.IDLE;

    @Override
    public boolean isSupported() {
        // UnityAds.isSupported()ではGINGERBREAD(2.3)対応となっているが実際に表示すると
        // ビデオ再生エラーでいきなりエンドカードが表示され、「×ボタン」で閉じると
        // アプリが落ちてしまうので、実際に表示が確認出来たJELLY_BEAN(4.1)以降に変更
        // https://github.com/Unity-Technologies/unity-ads-android/blob/master/lib/src/main/java/com/unity3d/services/UnityServices.java#L104
        // 4.3でshowしても表示されないので4.4に変更
        // 4系での動作が安定しないため、5に変更
        // 以下の課題にて6に変更
        // https://scaleout.backlog.jp/view/VIDEO_RWD-2655
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.M;
    }

    @NonNull
    @Override
    public String getAdNetworkVersion() {
        return UnityAds.getVersion();
    }

    @NonNull
    @Override
    public String getAdNetworkName() {
        return ADNW_NAME;
    }

    @NonNull
    @Override
    public List<String> getAdNetworkAdIdentifiers() {
        if (placementId != null) {
            return Collections.singletonList(placementId.value);
        } else {
            return Collections.emptyList();
        }
    }

    @NonNull
    @Override
    public String getAdapterVersion() {
        return BuildConfig.VERSION_NAME;
    }

    @Override
    public boolean prepare(
            @NonNull final Context context,
            @NonNull final AdapterConfiguration configuration,
            @Nullable final AdapterEventListener listener) {
        this.adapterListener = listener;
        this.adapterConfiguration = configuration;

        final Map<String, String> mediationParams = adapterConfiguration.getMediationParams();

        try {
            this.placementId = new PlacementId(mediationParams.get("zone"));
        } catch (InvalidParameterException e) {
            logger.w(String.format("Failed to prepare %s. placementId is invalid.", adapterName));
            return false;
        }

        try {
            this.gameId = new GameId(adapterConfiguration.getAdID());
        } catch (InvalidParameterException e) {
            logger.w(String.format("Failed to prepare %s. gameId is invalid.", adapterName));
            return false;
        }

        if (configuration.getConsentStatus() != VAMPPrivacySettings.ConsentStatus.UNKNOWN) {
            final boolean accepted =
                    configuration.getConsentStatus() == VAMPPrivacySettings.ConsentStatus.ACCEPTED;

            final MetaData metaData = new MetaData(context);
            metaData.set("privacy.consent", accepted);
            metaData.commit();

            logger.d(String.format("Sets %s to privacy consent.", accepted));
        }

        if (configuration.getUnderAgeOfConsent() != VAMPPrivacySettings.UnderAgeOfConsent.UNKNOWN
                || configuration.getChildDirected() != VAMPPrivacySettings.ChildDirected.UNKNOWN) {
            // 年齢制限未満でない場合にtrue
            final boolean overAgeLimit =
                    !(configuration.getUnderAgeOfConsent()
                                    == VAMPPrivacySettings.UnderAgeOfConsent.TRUE
                            || configuration.getChildDirected()
                                    == VAMPPrivacySettings.ChildDirected.TRUE);

            final MetaData metaData = new MetaData(context);
            metaData.set("privacy.useroveragelimit", overAgeLimit);
            metaData.commit();

            logger.d(String.format("Sets %s to privacy user over age limit.", overAgeLimit));
        }

        UnityAds.setDebugMode(configuration.isDebugMode());

        logger.d(String.format("%s is prepared.", adapterName));

        return true;
    }

    @Override
    public void load(@NonNull final Context applicationContext) {
        if (adapterConfiguration == null || placementId == null || gameId == null) {
            if (adapterListener != null) {
                adapterListener.onEvent(
                        Event.newNullOrEmptyParameterErrorEvent(
                                "load",
                                Arrays.asList("adapterConfiguration", "placementId", "gameId")));
            }

            return;
        }

        final LoadListener loadListener = new LoadListener(this);

        if (UnityAds.isInitialized()) {
            UnityAds.load(placementId.value, loadListener);
            return;
        }

        UnityAds.initialize(
                applicationContext,
                gameId.value,
                adapterConfiguration.isTestMode(),
                new IUnityAdsInitializationListener() {
                    @Override
                    public void onInitializationComplete() {
                        logger.d("UnityAds SDK is initialized by VAMP.");

                        UnityAds.load(placementId.value, loadListener);
                    }

                    @Override
                    public void onInitializationFailed(
                            final UnityAds.UnityAdsInitializationError error,
                            final String message) {
                        logger.w(
                                "Failed to initialize UnityAds SDK. error="
                                        + error
                                        + " message="
                                        + message);

                        if (adapterListener != null) {
                            adapterListener.onEvent(
                                    new Event(
                                            Event.EVENT_FAIL,
                                            new AdNetworkErrorInfo.Builder(
                                                            "load", VAMPError.ADNETWORK_ERROR)
                                                    .setAdNetworkErrorCode(error.name())
                                                    .setAdNetworkErrorMessage(message)
                                                    .build()));
                        }
                    }
                });
    }

    @Override
    public boolean isReady() {
        return UnityAds.isInitialized() && state == State.LOADED;
    }

    @Override
    public void show(@NonNull final Context context) {
        if (!(context instanceof Activity)) {
            if (adapterListener != null) {
                adapterListener.onEvent(Event.newActivityNotFoundErrorEvent("show"));
            }

            return;
        }

        // イベント到達タイミングを調整するため、
        // onUnityAdsShowStartコールバックを待たずにEVENT_OPENを発火する
        if (adapterListener != null) {
            adapterListener.onEvent(new Event(Event.EVENT_OPEN));
        }

        // 踏み台Activityの表示を開始。
        // onResumeを検知するためイベントリスナーを登録し、
        // onResumeを検知したら広告の表示を開始
        EventDispatcher.getInstance().addListener(eventListener);
        ScaffoldActivity.show((Activity) context);
    }

    @Override
    public void destroy() {
        EventDispatcher.getInstance().removeListener(eventListener);
    }

    /** メモリリークを防ぐためにadapterオブジェクトを弱参照で持つリスナークラスです */
    private static class LoadListener implements IUnityAdsLoadListener {
        @NonNull private final WeakReference<UnityAdsAdapter> adapterRef;

        LoadListener(@NonNull final UnityAdsAdapter adapter) {
            adapterRef = new WeakReference<>(adapter);
        }

        @Override
        public void onUnityAdsAdLoaded(final String pid) {
            final UnityAdsAdapter adapter = adapterRef.get();
            if (adapter == null) {
                return;
            }

            adapter.logger.d("onUnityAdsAdLoaded called. placementId=" + pid);

            if (adapter.placementId == null || !adapter.placementId.value.equals(pid)) {
                adapter.logger.d("Unmatched placementId.");
                return;
            }

            adapter.state = State.LOADED;

            if (adapter.adapterListener != null) {
                adapter.adapterListener.onEvent(new Event(Event.EVENT_LOAD_SUCCESS));
            }
        }

        @Override
        public void onUnityAdsFailedToLoad(
                final String pid, final UnityAds.UnityAdsLoadError error, final String message) {
            final UnityAdsAdapter adapter = adapterRef.get();
            if (adapter == null) {
                return;
            }

            adapter.logger.d(
                    String.format(
                            "onUnityAdsFailedToLoad called. placementId=%s error=%s message=%s",
                            pid, error, message));

            if (adapter.placementId == null || !adapter.placementId.value.equals(pid)) {
                adapter.logger.d("Unmatched placementId.");
                return;
            }

            final VAMPError vampError =
                    error == UnityAds.UnityAdsLoadError.NO_FILL
                            ? VAMPError.NO_ADSTOCK
                            : VAMPError.ADNETWORK_ERROR;

            if (adapter.adapterListener != null) {
                adapter.adapterListener.onEvent(
                        new Event(
                                Event.EVENT_FAIL,
                                new AdNetworkErrorInfo.Builder("onUnityAdsFailedToLoad", vampError)
                                        .setAdNetworkErrorCode(error.name())
                                        .setAdNetworkErrorMessage(message)
                                        .build()));
            }
        }
    }

    /** メモリリークを防ぐためにadapterオブジェクトを弱参照で持つリスナークラスです */
    private static class ShowListener implements IUnityAdsShowListener {
        @NonNull private final WeakReference<UnityAdsAdapter> adapterRef;

        ShowListener(@NonNull final UnityAdsAdapter adapter) {
            adapterRef = new WeakReference<>(adapter);
        }

        @Override
        public void onUnityAdsShowFailure(
                final String pid, final UnityAds.UnityAdsShowError error, final String message) {
            final UnityAdsAdapter adapter = adapterRef.get();
            if (adapter == null) {
                return;
            }

            adapter.logger.d(
                    String.format(
                            "onUnityAdsShowFailure called. errorCode=%s message=%s",
                            error, message));

            if (adapter.placementId == null || !adapter.placementId.value.equals(pid)) {
                adapter.logger.d("Unmatched placementId.");
                return;
            }

            if (adapter.adapterListener != null) {
                adapter.adapterListener.onEvent(
                        new Event(
                                Event.EVENT_FAIL,
                                new AdNetworkErrorInfo.Builder(
                                                "onUnityAdsShowFailure", VAMPError.ADNETWORK_ERROR)
                                        .setAdNetworkErrorCode(error.name())
                                        .setAdNetworkErrorMessage(message)
                                        .build()));
            }
        }

        @Override
        public void onUnityAdsShowStart(final String pid) {
            final UnityAdsAdapter adapter = adapterRef.get();
            if (adapter == null) {
                return;
            }

            adapter.logger.d("onUnityAdsShowStart called. placementId=" + pid);

            // このコールバックでEVENT_OPENを発火すると、
            // 広告Activityが表示され、裏に回ったアプリ側のActivityが破棄された場合、
            // イベント到達タイミングが遅れてしまう。(アプリ側Activityが再生成されたとき)
            // そのため、Adapter#showメソッドでEVENT_OPENを発火する
        }

        @Override
        public void onUnityAdsShowClick(final String pid) {
            final UnityAdsAdapter adapter = adapterRef.get();
            if (adapter == null) {
                return;
            }

            adapter.logger.d("onUnityAdsShowClick called. placementId=" + pid);

            if (adapter.placementId == null || !adapter.placementId.value.equals(pid)) {
                adapter.logger.d("Unmatched placementId.");
                return;
            }

            if (adapter.adapterListener != null) {
                adapter.adapterListener.onEvent(new Event(Event.EVENT_CLICK));
            }
        }

        @Override
        public void onUnityAdsShowComplete(
                final String pid, final UnityAds.UnityAdsShowCompletionState state) {
            final UnityAdsAdapter adapter = adapterRef.get();
            if (adapter == null) {
                return;
            }

            adapter.logger.d(
                    String.format(
                            "onUnityAdsShowComplete called. placementId=%s state=%s", pid, state));

            if (adapter.placementId == null || !adapter.placementId.value.equals(pid)) {
                adapter.logger.d("Unmatched placementId.");
                return;
            }

            // 踏み台Activityは自動では閉じないため、UNITY_ADS_CLOSEイベントを送り、
            // Activity#finishを実行させる
            EventDispatcher.getInstance().dispatch(EventDispatcher.Event.UNITY_ADS_CLOSE, null);

            if (state == UnityAds.UnityAdsShowCompletionState.COMPLETED) {
                if (adapter.adapterListener != null) {
                    adapter.adapterListener.onEvent(
                            new Event(Event.EVENT_COMPLETE | Event.EVENT_CLOSE));
                }
            } else if (state == UnityAds.UnityAdsShowCompletionState.SKIPPED) {
                // 途中キャンセル
                if (adapter.adapterListener != null) {
                    adapter.adapterListener.onEvent(
                            new Event(
                                    Event.EVENT_FAIL | Event.EVENT_CLOSE,
                                    new AdNetworkErrorInfo.Builder(
                                                    "onUnityAdsShowComplete", VAMPError.USER_CANCEL)
                                            .setErrorMessage(state.toString())
                                            .build()));
                }
            } else {
                if (adapter.adapterListener != null) {
                    adapter.adapterListener.onEvent(
                            new Event(
                                    Event.EVENT_FAIL | Event.EVENT_CLOSE,
                                    new AdNetworkErrorInfo.Builder(
                                                    "onUnityAdsShowComplete",
                                                    VAMPError.ADNETWORK_ERROR)
                                            .setErrorMessage(state.toString())
                                            .build()));
                }
            }
        }
    }

    @NonNull
    private final EventDispatcher.Listener eventListener =
            new EventDispatcher.Listener() {
                @Override
                public void onListen(
                        @NonNull final EventDispatcher.Event event, @Nullable final Object data) {
                    if (event == EventDispatcher.Event.ACTIVITY_RESUME) {
                        if (data instanceof Activity) {
                            // 踏み台Activityを使って広告を表示。
                            // onCreateでshowすると表示できなかったため、onResumeで実行する。
                            // また、showメソッドを複数回呼び出すとバグるため、
                            // 一度だけ呼び出すように制御する
                            if (state == State.LOADED) {
                                state = State.SHOWING;

                                UnityAds.show(
                                        (Activity) data,
                                        placementId.value,
                                        new ShowListener(UnityAdsAdapter.this));
                            }
                        }
                    }
                }
            };
}
