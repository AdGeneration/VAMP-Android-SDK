package jp.supership.vamp.mediation.unityads;

import android.text.TextUtils;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

final class GameId {
    @NonNull final String value;

    GameId(@Nullable final String value) throws InvalidParameterException {
        String gameId = null;

        if (!TextUtils.isEmpty(value)) {
            gameId = value.trim();
        }

        if (TextUtils.isEmpty(gameId)) {
            throw new InvalidParameterException();
        }

        this.value = gameId;
    }

    @NonNull
    @Override
    public String toString() {
        return "GameId(" + value + ")";
    }
}
