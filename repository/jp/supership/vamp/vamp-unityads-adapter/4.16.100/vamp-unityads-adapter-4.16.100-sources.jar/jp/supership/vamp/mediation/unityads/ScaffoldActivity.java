package jp.supership.vamp.mediation.unityads;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import jp.supership.vamp.VAMPLogger;

/**
 * UnityAdsは呼び出し元のActivity(アプリ側のActivity)を保持し続けてしまうため、 メモリリークが発生します。
 * そのため、このScaffoldActivityを呼び出し元のActivityとUnityAdsの間にはさみ、
 * このScaffoldActivityインスタンスからUnitAdsを表示するようにします。 これにより、ScaffoldActivityインスタンスが身代わりとなってUnityAdsに保持され、
 * 呼び出し元のActivityがメモリリークするのを防ぎます。 (ScaffoldActivityはメモリリークします)
 */
public final class ScaffoldActivity extends Activity {

    private final VAMPLogger logger = new VAMPLogger(UnityAdsAdapter.class.getSimpleName());

    static void show(@NonNull final Activity activity) {
        new Handler(Looper.getMainLooper())
                .post(
                        new Runnable() {
                            @Override
                            public void run() {
                                Intent intent =
                                        new Intent(activity, ScaffoldActivity.class)
                                                .setAction(Intent.ACTION_VIEW);
                                activity.startActivity(intent);
                            }
                        });
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        EventDispatcher.getInstance().addListener(listener);

        logger.d("ScaffoldActivity#onCreate called.");
    }

    @Override
    protected void onResume() {
        super.onResume();

        // RESUMEイベントを送り、広告表示を開始する
        EventDispatcher.getInstance().dispatch(EventDispatcher.Event.ACTIVITY_RESUME, this);

        logger.d("ScaffoldActivity#onResume called.");
    }

    @Override
    protected void onDestroy() {
        EventDispatcher.getInstance().removeListener(listener);

        logger.d("ScaffoldActivity#onDestroy called.");

        super.onDestroy();
    }

    private final EventDispatcher.Listener listener =
            new EventDispatcher.Listener() {
                @Override
                public void onListen(@NonNull EventDispatcher.Event event, @Nullable Object data) {
                    if (event == EventDispatcher.Event.UNITY_ADS_CLOSE) {
                        // 広告が閉じられたら、このActivityも閉じる
                        finish();
                    }
                }
            };
}
