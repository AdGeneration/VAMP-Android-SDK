package jp.supership.vamp.mediation.unityads;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;

final class EventDispatcher {
    enum Event {
        ACTIVITY_RESUME,
        UNITY_ADS_CLOSE,
    }

    interface Listener {
        void onListen(@NonNull Event event, @Nullable Object data);
    }

    private static final EventDispatcher instance = new EventDispatcher();

    private final ArrayList<Listener> listeners = new ArrayList<>();

    @NonNull
    static EventDispatcher getInstance() {
        return instance;
    }

    private EventDispatcher() {}

    void addListener(@NonNull Listener listener) {
        listeners.remove(listener);
        listeners.add(listener);
    }

    void removeListener(@NonNull Listener listener) {
        listeners.remove(listener);
    }

    void dispatch(@NonNull Event event, @Nullable Object data) {
        for (Listener listener : listeners) {
            listener.onListen(event, data);
        }
    }
}
